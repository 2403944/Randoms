"""
Coherence Evaluation Module
Evaluates whether assistant replies logically follow conversation history and maintain context continuity.
"""

import os
import json
import re
from typing import List, Any, Dict
from datetime import datetime
from langsmith import Client
from langchain_openai import AzureChatOpenAI
from utils import get_or_create_workbook, get_or_create_sheet
from token_tracker import track_tokens_used, count_tokens

# ============================================================
# TRACE EXTRACTION
# ============================================================

def fetch_spans(trace_id: str) -> List[Any]:
    """Fetch all spans for a given trace ID."""
    client = Client(api_key=os.environ["LANGSMITH_API_KEY"])
    spans = list(client.list_runs(trace_id=trace_id))
    if not spans:
        raise ValueError("No spans found for trace.")
    return sorted(spans, key=lambda r: r.start_time or 0)

# ============================================================
# CONVERSATION EXTRACTION
# ============================================================

def extract_conversation_from_execute_span(spans: List[Any]) -> List[Dict[str, str]]:
    """Extract conversation from Execute span messages."""
    execute_spans = [s for s in spans if s.name == "Execute"]

    if not execute_spans:
        raise ValueError("No Execute span found in trace")

    execute_span = execute_spans[0]
    messages     = execute_span.inputs.get("messages", [])

    conversation = []
    for msg in messages:
        if isinstance(msg, dict):
            role    = msg.get("type") or msg.get("role")
            content = msg.get("content")
        elif isinstance(msg, tuple) and len(msg) == 2:
            role, content = msg
        else:
            continue

        if role in ("human", "ai") and content:
            conversation.append({
                "role":    role.upper(),
                "content": content.strip(),
            })

    if len(conversation) < 2:
        raise ValueError("Not enough conversation turns")

    return conversation


# ============================================================
# EXTRACT HISTORY AND FINAL ASSISTANT RESPONSE
# ============================================================

def extract_history_and_final_response(conversation: List[Dict[str, str]]) -> Dict[str, str]:
    """
    Split conversation into:
      - conversation_history : ALL turns (human + ai) as one text block
      - target_turn          : the assistant's FINAL (last AI) response only
    """
    # Find index of last AI turn
    last_ai_index = None
    for i in range(len(conversation) - 1, -1, -1):
        if conversation[i]["role"] == "AI":
            last_ai_index = i
            break

    if last_ai_index is None:
        raise ValueError("No AI response found in conversation")

    # Everything before the final AI response = history
    history_turns = conversation[:last_ai_index]
    conversation_history = "\n".join(
        f"{t['role']}: {t['content']}"
        for t in history_turns
    ) if history_turns else "(No prior context)"

    # Final AI response = target turn
    target_turn = conversation[last_ai_index]["content"]

    return {
        "conversation_history": conversation_history,
        "target_turn":          target_turn,
    }


# ============================================================
# COHERENCE EVALUATION — single pass
# ============================================================

def evaluate_coherence(
    conversation_history: str,
    target_turn: str,
    llm_client: AzureChatOpenAI,
) -> Dict[str, Any]:
    """Evaluate coherence of the assistant's final response against full conversation history."""

    eval_prompt = f"""You are an expert conversation quality evaluator.

Your task is to judge whether the assistant's final response logically follows the full conversation history and maintains context continuity.

CONVERSATION HISTORY:
{conversation_history}

ASSISTANT FINAL RESPONSE:
{target_turn}

Evaluate on the following criteria:
1. Logical coherence: Does the response logically follow from the conversation history?
2. Context awareness: Does the response acknowledge and build upon previous context?
3. Continuity: Does the response maintain conversational flow without abrupt topic shifts?
4. Relevance: Is the response relevant to the user's implied or stated needs?

Provide your evaluation in the following JSON format:
{{
  "reasoning": "step by step analysis of coherence (max 200 words)",
  "score": 0.0 to 1.0
}}

Return ONLY the JSON object, no additional text."""

    response = llm_client.invoke(eval_prompt)
    tokens = count_tokens(response.content)
    track_tokens_used(tokens, eval_name="coherence")

    try:
        result = json.loads(response.content)
    except json.JSONDecodeError:
        match = re.search(r'\{.*\}', response.content, re.DOTALL)
        if match:
            try:
                result = json.loads(match.group())
            except json.JSONDecodeError:
                result = {"reasoning": response.content, "score": 0.5}
        else:
            result = {"reasoning": response.content, "score": 0.5}

    score = result.get("score", 0.5)
    if isinstance(score, str):
        try:
            score = float(score)
        except Exception:
            score = 0.5

    return {
        "reasoning": result.get("reasoning", ""),
        "score":     float(score),
    }


# ============================================================
# OVERALL SUMMARY
# ============================================================

def compute_coherence_overall_summary(
    eval_output: Dict[str, Any],
    llm_client: AzureChatOpenAI,
) -> Dict[str, Any]:
    """Compute overall summary from single coherence evaluation."""

    score = eval_output.get("score", 0.0)

    if score >= 0.7:
        overall_label = "PASS"
    elif score >= 0.5:
        overall_label = "BORDERLINE"
    else:
        overall_label = "FAIL"

    overall_reasoning_prompt = f"""You are an expert conversation quality evaluator.

Below is a coherence evaluation result for an AI assistant's final response.

Score: {score:.2f}
Reasoning: {eval_output.get("reasoning", "")}

Based on the above evaluation:
1. Summarize the overall coherence quality.
2. Highlight major issues (if any).
3. Mention what the assistant did well.
4. Provide a final overall verdict in 2-3 sentences.

Be concise, specific, and objective."""

    response          = llm_client.invoke(overall_reasoning_prompt)
    tokens = count_tokens(response.content)
    track_tokens_used(tokens, eval_name="coherence")
    overall_reasoning = response.content.strip()

    return {
        "overall_score":     round(score, 4),
        "overall_label":     overall_label,
        "overall_reason":    overall_reasoning,  # key main.py expects
        "overall_reasoning": overall_reasoning,  # kept for backward compat
    }


# ============================================================
# FULL PIPELINE
# ============================================================

def run_coherence_eval(
    trace_id: str,
    scenario: str,
    llm_client: AzureChatOpenAI,
) -> Dict[str, Any]:
    """Full coherence evaluation pipeline."""
    try:
        spans        = fetch_spans(trace_id)
        conversation = extract_conversation_from_execute_span(spans)
        extracted    = extract_history_and_final_response(conversation)

        conversation_history = extracted["conversation_history"]
        target_turn          = extracted["target_turn"]

        eval_output     = evaluate_coherence(conversation_history, target_turn, llm_client)
        overall_summary = compute_coherence_overall_summary(eval_output, llm_client)

        return {
            "eval_name": "coherence",
            "trace_id":  trace_id,
            "scenario":  scenario,
            "eval_inputs": {
                "conversation_history": conversation_history,
                "target_turn":          target_turn,
            },
            "eval_output":     eval_output,
            "overall_summary": overall_summary,
            "metadata": {
                "model":     "gpt-5",
                "timestamp": datetime.utcnow().isoformat(),
            },
            "status": "success",
        }

    except Exception as e:
        return {
            "eval_name":       "coherence",
            "trace_id":        trace_id,
            "scenario":        scenario,
            "eval_inputs":     {},
            "eval_output":     {},
            "overall_summary": {},
            "metadata": {
                "model":     "gpt-5",
                "timestamp": datetime.utcnow().isoformat(),
            },
            "status": "failed",
            "error":  str(e),
        }


# ============================================================
# EXCEL OUTPUT
# ============================================================

def dump_coherence_eval_to_excel(
    *,
    trace_id: str,
    query: str,
    eval_result: dict,
    excel_path: str = "final_eval_results.xlsx",
):
    """Save coherence evaluation results to Excel."""

    HEADERS = [
        "Query",
        "Conversation_History",
        "Target_Turn",
        "Score",
        "Reasoning",
        "Overall_Score",
        "Overall_Label",
        "Overall_Reasoning",
    ]

    wb    = get_or_create_workbook(excel_path)
    # Sheet name "Coherence" matches EVAL_SHEET_MAP["coherence"] → no stray sheet
    sheet = get_or_create_sheet(wb, "Coherence", HEADERS)

    overall_summary   = eval_result.get("overall_summary", {})
    overall_score     = overall_summary.get("overall_score", "")
    overall_label     = overall_summary.get("overall_label", "")
    overall_reasoning = overall_summary.get("overall_reasoning", "")

    eval_inputs = eval_result.get("eval_inputs", {})
    eval_output = eval_result.get("eval_output", {})

    if eval_result.get("status") == "failed":
        sheet.append([
            query,
            "",
            "",
            "",
            eval_result.get("error", "Unknown error"),
            "",
            "",
            "",
        ])
    else:
        sheet.append([
            query,
            eval_inputs.get("conversation_history", ""),
            eval_inputs.get("target_turn", ""),
            eval_output.get("score", ""),
            eval_output.get("reasoning", ""),
            overall_score,
            overall_label,
            overall_reasoning,
        ])

    wb.save(excel_path)