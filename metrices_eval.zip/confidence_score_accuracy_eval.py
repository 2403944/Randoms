"""
Confidence Score Accuracy Evaluation Module
============================================

Purpose:
  Verify whether confidence scores produced by the system are mathematically correct
  by recomputing them according to the authoritative calculation logic.

Evaluation Logic:
  1. Extract confidence calculation inputs from forecast confidence spans
  2. Recompute confidence using deterministic formula
  3. Compare computed vs actual confidence (±0.01 tolerance)
  4. Per-span: PASS/FAIL with score (1.0/0.0)
  5. Overall: score = passed / total

Span Target:
  "Calculate Forecast Confidence Tool"

Temperature Strategy:
  temperature=0 (deterministic, pure verification)
"""

import json
import ast
from uuid import UUID
from datetime import datetime
from langsmith import Client
from langchain_openai import AzureChatOpenAI


# ============================================================
# UUID SERIALIZER FOR JSON
# ============================================================

def uuid_serializer(obj):
    """Convert UUID objects to strings for JSON serialization."""
    if isinstance(obj, UUID):
        return str(obj)
    raise TypeError(f"Object of type {obj.__class__.__name__} is not JSON serializable")


# ============================================================
# JSON SAFE PARSER
# ============================================================

def safe_json_load(raw: str):
    """
    Parse JSON from raw LLM output with markdown cleanup.

    Handles:
    - Markdown code blocks (```json ... ```)
    - Nested JSON extraction
    """
    raw = raw.strip()
    if raw.startswith("```"):
        raw = raw.strip("`").strip()
        if raw.lower().startswith("json"):
            raw = raw[4:].strip()

    start, end = raw.find("{"), raw.rfind("}")
    if start == -1 or end == -1:
        raise ValueError(f"Non-JSON output:\n{raw}")

    return json.loads(raw[start:end + 1])


# ============================================================
# CONFIDENCE CALCULATION LOGIC (AUTHORITATIVE)
# ============================================================

def compute_confidence(
    extra_charges,
    total_estimated_cost,
    estimated_date_1,
    estimated_date_2,
    delivery_date,
):
    """
    Recompute confidence score using the authoritative formula.

    Formula:
      delay(d) = max((date(d) - date(delivery_date)).days, 0) or 0 if empty
      extra_risk = min(float(extra_charges) / 100, 1)
      cost_risk = min(float(total_estimated_cost) / 10000, 1)
      delay_risk = min((delay(date_1) + delay(date_2)) / 20, 1)
      multi_risk = 0.3 if date_2 present else 0
      confidence = 1 - (0.25*extra_risk + 0.25*cost_risk + 0.35*delay_risk + 0.15*multi_risk)
      final = round(clamp(confidence, 0, 1), 2)
    """
    try:
        from datetime import datetime as dt
        delivery_dt = dt.strptime(delivery_date, "%Y-%m-%d")

        def delay(date_str):
            if not date_str or date_str == "":
                return 0
            try:
                date_dt = dt.strptime(date_str, "%Y-%m-%d")
                return max((date_dt - delivery_dt).days, 0)
            except Exception:
                return 0

        delay_1    = delay(estimated_date_1)
        delay_2    = delay(estimated_date_2)

        extra_risk = min(float(extra_charges or 0) / 100, 1)
        cost_risk  = min(float(total_estimated_cost or 0) / 10000, 1)
        delay_risk = min((delay_1 + delay_2) / 20, 1)
        multi_risk = 0.3 if (estimated_date_2 and estimated_date_2.strip()) else 0

        confidence = 1 - (
            0.25 * extra_risk +
            0.25 * cost_risk +
            0.35 * delay_risk +
            0.15 * multi_risk
        )

        return round(max(0, min(1, confidence)), 2)

    except Exception:
        return None


# ============================================================
# VERIFICATION PROMPT (AUTHORITATIVE CONTRACT)
# ============================================================

CONFIDENCE_SCORE_ACCURACY_PROMPT = """You are an evaluation agent.
Your task is to verify whether a given confidence score is mathematically correct.

You are provided with:
1. Input fields used to compute confidence
2. The confidence score produced by the system

You MUST:
- Recompute the confidence score strictly using the logic below
- Compare your computed value with the provided confidence
- Decide whether the confidence is correct

DO NOT estimate, approximate, or use intuition.
ONLY validate mathematical correctness.
--------------------------------------------------
CONFIDENCE CALCULATION LOGIC (AUTHORITATIVE)
--------------------------------------------------
delay(d):
- If d is empty, null, or missing → return 0
- Else:
    max( (date(d) - date(delivery_date)).days , 0 )
extra_risk:
    min( float(extra_charges) / 100 , 1 )
cost_risk:
    min( float(total_estimated_cost) / 10000 , 1 )
delay_risk:
    min( ( delay(estimated_date_1) + delay(estimated_date_2) ) / 20 , 1 )
multi_risk:
    0.3 if estimated_date_2 is present and non-empty
    else 0
confidence:
    1 - (
        0.25 * extra_risk +
        0.25 * cost_risk +
        0.35 * delay_risk +
        0.15 * multi_risk
    )
Final confidence:
    round( clamp(confidence, 0, 1), 2 )
--------------------------------------------------
EVALUATION RULES
--------------------------------------------------
1. Recalculate the confidence score exactly.
2. Compare it to the provided confidence.
3. Allow a tolerance of ±0.01 due to rounding.
4. If within tolerance → PASS
5. Otherwise → FAIL
--------------------------------------------------
SCORING RULE
--------------------------------------------------
- PASS → score = 1.0
- FAIL → score = 0.0
--------------------------------------------------
OUTPUT FORMAT (STRICT JSON ONLY)
--------------------------------------------------
{
  "per_span_results": [
    {
      "span_id": "<string>",
      "expected_confidence": <number>,
      "actual_confidence": <number>,
      "difference": <number>,
      "result": "PASS" | "FAIL",
      "score": <number>,
      "reason": "matches calculation | short explanation"
    }
  ]
}
--------------------------------------------------
INPUT DATA
--------------------------------------------------
{input_json}
delivery_date: {delivery_date}
"""


# ============================================================
# OVERALL REASON PROMPT
# ============================================================

OVERALL_REASON_PROMPT = """You are an evaluation summarizer.

Given aggregate confidence score validation results, explain the overall outcome.

Rules:
- Do NOT compute or suggest numeric scores
- Do NOT change PASS/FAIL result
- Only explain why the overall result is PASS or FAIL
- Be concise and factual

Return ONLY this JSON:
{
  "overall_reason": "<short explanation>"
}
"""


# ============================================================
# MAIN EVALUATION FUNCTION
# ============================================================

def run_confidence_score_accuracy_eval(trace_id, scenario, llm_client):
    """
    Evaluate confidence score accuracy for a trace.

    Args:
        trace_id:   LangSmith trace ID
        scenario:   Scenario context/query description
        llm_client: Azure OpenAI client (temperature=0)

    Returns:
        dict with evaluation results ready for Excel dump.
    """
    try:
        client = Client()

        all_spans       = list(client.list_runs(trace_id=trace_id))
        forecast_spans  = [
            span for span in all_spans
            if span.name and "Calculate Forecast Confidence Tool" in span.name
        ]

        if not forecast_spans:
            return {
                "status":   "failed",
                "error":    "No 'Calculate Forecast Confidence Tool' spans found",
                "trace_id": trace_id,
                "scenario": scenario,
            }

        records = []
        for span in forecast_spans:
            raw_input = span.inputs.get("input", "{}")

            try:
                input_data = ast.literal_eval(raw_input)
                if not isinstance(input_data, dict):
                    input_data = {}
            except Exception:
                input_data = {}

            confidence = None
            try:
                content    = span.outputs["output"]["content"]
                confidence = json.loads(content).get("confidence")
            except Exception:
                pass

            records.append({
                "span_id":    span.id,
                "confidence": confidence,
                **input_data,
            })

        if not records:
            return {
                "status":   "failed",
                "error":    "No valid input/output records extracted",
                "trace_id": trace_id,
                "scenario": scenario,
            }

        delivery_date    = records[0].get("delivery_date", "2026-10-01")
        per_span_results = []

        for r in records:
            expected_confidence = compute_confidence(
                extra_charges=r.get("extra_charges"),
                total_estimated_cost=r.get("total_estimated_cost"),
                estimated_date_1=r.get("estimated_date_1"),
                estimated_date_2=r.get("estimated_date_2"),
                delivery_date=delivery_date,
            )

            actual_confidence = r.get("confidence")

            if expected_confidence is not None and actual_confidence is not None:
                difference        = abs(expected_confidence - actual_confidence)
                within_tolerance  = difference <= 0.01
                result            = "PASS" if within_tolerance else "FAIL"
                score             = 1.0 if within_tolerance else 0.0
                reason            = (
                    f"Expected {expected_confidence}, got {actual_confidence}"
                    if within_tolerance
                    else f"Expected {expected_confidence}, got {actual_confidence} (diff={difference:.4f})"
                )
            else:
                result     = "FAIL"
                score      = 0.0
                difference = None
                reason     = "Could not compute expected confidence"

            per_span_results.append({
                "span_id":             str(r.get("span_id")),
                "expected_confidence": expected_confidence,
                "actual_confidence":   actual_confidence,
                "difference":          difference,
                "result":              result,
                "score":               score,
                "reason":              reason,
            })

        total         = len(per_span_results)
        passed        = sum(1 for r in per_span_results if r["result"] == "PASS")
        failed        = total - passed
        overall_score = round(
            sum(r["score"] for r in per_span_results) / total, 2
        ) if total > 0 else 0.0
        overall_result = "PASS" if failed == 0 else "FAIL"

        # Generate overall reason via LLM
        payload = {
            "total_spans":      total,
            "passed":           passed,
            "failed":           failed,
            "overall_result":   overall_result,
            "per_span_results": [
                {
                    "span_id":    str(r["span_id"]),
                    "result":     r["result"],
                    "difference": r["difference"],
                }
                for r in per_span_results
            ],
        }

        try:
            response       = llm_client.invoke([
                ("system", OVERALL_REASON_PROMPT),
                ("human",  json.dumps(payload, indent=2)),
            ])
            overall_reason = safe_json_load(response.content).get("overall_reason", "")
        except Exception:
            overall_reason = ""

        return {
            "status":           "completed",
            "trace_id":         trace_id,
            "scenario":         scenario,
            "overall_result":   overall_result,
            "overall_score":    overall_score,
            "overall_reason":   overall_reason,
            "per_span_results": per_span_results,
            "timestamp":        datetime.utcnow().isoformat(),
        }

    except Exception as e:
        return {
            "status":   "failed",
            "error":    str(e),
            "trace_id": trace_id,
            "scenario": scenario,
        }


# ============================================================
# EXCEL DUMP FUNCTION  (columns aligned to headers exactly)
# ============================================================

def dump_confidence_score_accuracy_to_excel(eval_result, output_excel, utils):
    """
    Dump confidence score accuracy evaluation to Excel sheet.

    Columns (13):
        Query | Expected_Confidence | Actual_Confidence | Difference |
        Result | Reason | Overall_Score | Overall_Result | Overall_Reason |
        Traceback | Status | Timestamp

    Row layout:
        • One row per span.
        • Overall_Score / Overall_Result / Overall_Reason / Status / Timestamp
          populated on the FIRST span row only (blank on subsequent rows).
        • Traceback filled with error message on failed traces, empty on success.
    """
    try:
        SHEET_NAME = "Confidence Score Accuracy"
        HEADERS    = [
            "Query",
            "Expected_Confidence",
            "Actual_Confidence",
            "Difference",
            "Result",
            "Reason",
            "Overall_Score",
            "Overall_Result",
            "Overall_Reason",
            "Traceback",
            "Status",
            "Timestamp",
        ]

        wb    = utils.get_or_create_workbook(output_excel)
        sheet = utils.get_or_create_sheet(wb, SHEET_NAME, headers=HEADERS)

        status   = eval_result.get("status", "failed")
        scenario = eval_result.get("scenario", "")
        error    = eval_result.get("error", "")

        # ── Failed trace → single error row (12 values = 12 headers) ──
        if status == "failed":
            sheet.append([
                scenario,   # Query
                "",         # Expected_Confidence
                "",         # Actual_Confidence
                "",         # Difference
                "",         # Result
                "",         # Reason
                "",         # Overall_Score
                "",         # Overall_Result
                "",         # Overall_Reason
                error,      # Traceback
                "failed",   # Status
                "",         # Timestamp
            ])
            wb.save(output_excel)
            print(f"  [CSA] Saved failure row to '{SHEET_NAME}'")
            return

        # ── Successful trace → one row per span ───────────────────────
        per_span_results = eval_result.get("per_span_results", [])
        overall_score    = eval_result.get("overall_score", "")
        overall_result   = eval_result.get("overall_result", "")
        overall_reason   = eval_result.get("overall_reason", "")
        timestamp        = eval_result.get("timestamp", "")

        for i, span in enumerate(per_span_results):
            sheet.append([
                scenario if i == 0 else "",         # Query       — first row only
                span.get("expected_confidence"),    # Expected_Confidence
                span.get("actual_confidence"),      # Actual_Confidence
                span.get("difference"),             # Difference
                span.get("result"),                 # Result
                span.get("reason"),                 # Reason
                overall_score  if i == 0 else "",   # Overall_Score  — first row only
                overall_result if i == 0 else "",   # Overall_Result — first row only
                overall_reason if i == 0 else "",   # Overall_Reason — first row only
                "",                                 # Traceback — empty on success
                "completed" if i == 0 else "",      # Status    — first row only
                timestamp  if i == 0 else "",       # Timestamp — first row only
            ])

        wb.save(output_excel)
        print(f"  [CSA] Saved {len(per_span_results)} span row(s) to '{SHEET_NAME}'")

    except Exception as e:
        print(f"  [CSA] Excel dump failed: {e}")