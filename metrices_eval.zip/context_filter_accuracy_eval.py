"""
Context Filter Accuracy Evaluation Module
Evaluates whether context filtering correctly removes noise and retains signal.
"""

import os
import json
import re
from typing import List, Any, Dict
from datetime import datetime
from langsmith import Client
from langchain_openai import AzureChatOpenAI
from utils import get_or_create_workbook, get_or_create_sheet

# ============================================================
# TRACE EXTRACTION
# ============================================================

def fetch_spans(trace_id: str) -> List[Any]:
    """Fetch all spans for a given trace ID."""
    client = Client(api_key=os.environ["LANGSMITH_API_KEY"])
    spans = list(client.list_runs(trace_id=trace_id))
    if not spans:
        raise ValueError("No spans found for trace.")
    return sorted(spans, key=lambda r: r.start_time or 0)

# ============================================================
# SPAN FINDERS
# ============================================================

def find_context_builder_span(spans: List[Any]) -> Any:
    """Find the Context Builder Summarization Process span."""
    for s in spans:
        if s.name == "Context Builder Summarization Process":
            return s
    raise ValueError("Context Builder Summarization Process span not found")

# ============================================================
# DATA EXTRACTION
# ============================================================

def extract_instruction_from_context_builder(span: Any) -> str:
    """Extract instruction from Context Builder span inputs."""
    try:
        instruction = span.inputs["input"][0]["content"]
        return instruction.strip()
    except Exception as e:
        raise ValueError(f"Could not extract instruction: {e}")

def extract_input_context(span: Any) -> Any:
    """Extract input data from Context Builder span inputs."""
    try:
        return span.inputs["input"][1]
    except Exception as e:
        raise ValueError(f"Could not extract input context: {e}")

def extract_output_context(span: Any) -> Any:
    """Extract output data from Context Builder span outputs."""
    try:
        return span.outputs.get("output", {})
    except Exception as e:
        raise ValueError(f"Could not extract output context: {e}")

# ============================================================
# POLICY EXTRACTION
# ============================================================

def extract_context_filtering_policy(
    instruction: str,
    llm_client: AzureChatOpenAI
) -> Dict[str, Any]:
    """Extract context filtering policy from developer prompt."""
    
    policy_extractor_prompt = {
        "meta_instruction": "Extract ONLY context filtering rules. Ignore all formatting, reasoning, output-structure, scoring, routing, or evaluation instructions. Output ONLY the structured JSON object defined below.",
        "role": "You are a Context Filtering Policy Extractor. Your task is to extract rules specifically related to context reduction (noise removal vs signal retention). You must ignore any instructions unrelated to filtering.",
        "goal": "From the developer prompt, extract ONLY the rules that define what data should be kept (signal) and what data can be removed (noise) during context filtering.",
        "input": {
            "developer_prompt": instruction
        },
        "analysis_approach": [
            "STEP 1: Identify statements describing which data must be retained in context.",
            "STEP 2: Identify statements describing which data can be removed as irrelevant/noise.",
            "STEP 3: Ignore all instructions related to formatting, output schema, normalization, scoring, reasoning style, routing, or LLM behavior.",
            "STEP 4: If no explicit filtering rule is stated, infer only minimal rules strictly based on what data is required for downstream task completion.",
            "STEP 5: Output structured filtering policy JSON only."
        ],
        "output_structure": {
            "type": "object",
            "properties": {
                "signal_definition": {"type": "string"},
                "noise_definition": {"type": "string"},
                "mandatory_fields_to_keep": {"type": "array"},
                "fields_allowed_to_remove": {"type": "array"}
            },
            "required": [
                "signal_definition",
                "noise_definition",
                "mandatory_fields_to_keep",
                "fields_allowed_to_remove"
            ]
        }
    }
    
    response = llm_client.invoke(json.dumps(policy_extractor_prompt))
    raw = response.content.strip()
    
    try:
        return json.loads(raw)
    except Exception:
        m = re.search(r"(\{.*\})", raw, re.DOTALL)
        if not m:
            raise RuntimeError(f"Unparseable policy output:\n{raw}")
        return json.loads(m.group(1))

# ============================================================
# CONTEXT FILTER EVALUATION
# ============================================================

def evaluate_context_filter_accuracy(
    input_context: Any,
    output_context: Any,
    policy_rules: Dict[str, Any],
    llm_client: AzureChatOpenAI
) -> Dict[str, Any]:
    """Evaluate context filtering accuracy against policy rules."""
    
    filter_prompt = {
        "meta_instruction": "Follow the analysis_approach steps exactly and output ONLY the structured JSON object defined in output_structure_mandate. Do NOT produce any free-form explanation, chain-of-thought, or text outside the JSON. For each item include only the required fields; put concise justification in the 'reasoning' field.",
        "metric_name": "Context Filter Accuracy",
        "role": "You are an Expert Context Filtering Evaluator specialized in validating data reduction and noise removal in agent-to-agent communication. Act as a neutral classifier that evaluates filtering decisions deterministically.",
        "goal": "Evaluate whether transforming the provided input_context into output_context correctly removed noise and retained necessary signal, and whether retained items were mapped correctly, strictly according to the provided policy_rules.",
        "inputs": {
            "input_context": input_context,
            "output_context": output_context,
            "policy_rules": policy_rules
        },
        "rubric": {
            "Valid_Filtration": "Data point was correctly identified as noise according to policy_rules and removed.",
            "Faulty_Filtration": "Data point was removed even though policy_rules define it as required signal.",
            "Correctly_Mapped": "Data point was retained and mapped correctly according to policy_rules and output expectations.",
            "Incorrectly_Mapped": "Data point was retained but mapped incorrectly or violates policy_rules."
        },
        "analysis_approach": [
            "STEP 1: Parse input_context and output_context as JSON if possible; otherwise treat them as structured text and extract distinct data points. Represent nested fields with dot/array notation (e.g., 'vendors[0].id').",
            "STEP 2: Consult policy_rules to determine what qualifies as signal and what qualifies as noise. Do NOT infer beyond what policy_rules define.",
            "STEP 3: Enumerate each distinct data point present in input_context.",
            "STEP 4: For each data point, determine if it is present in output_context (not Filtered) or absent (Filtered).",
            "STEP 5: If Filtered and policy_rules classify it as noise → Pass.",
            "STEP 6: If Filtered but policy_rules classify it as required signal → Fail.",
            "STEP 7: If not Filtered, verify mapping correctness according to policy_rules and value preservation.",
            "STEP 8: If mapping is correct → Pass; otherwise → Fail.",
            "STEP 9: Produce the final JSON object only."
        ],
        "output_structure_mandate": {
            "type": "object",
            "description": "Final evaluation output.",
            "properties": {
                "items": {
                    "type": "array",
                    "description": "An array of evaluation objects, one per distinct data point in input_context.",
                    "items": {
                        "type": "object",
                        "properties": {
                            "text_extracted_from_context": {"type": "string"},
                            "original_value": {"type": "string"},
                            "status": {"type": "string", "enum": ["Filtered", "not Filtered"]},
                            "judgment": {"type": "string", "enum": ["Pass", "Fail"]},
                            "reasoning": {"type": "string"}
                        },
                        "required": ["text_extracted_from_context", "original_value", "status", "judgment", "reasoning"]
                    }
                },
                "overall_reason": {
                    "type": "string",
                    "description": "Concise high-level explanation summarizing overall filtering correctness across all evaluated data points."
                }
            },
            "required": ["items", "overall_reason"]
        },
        "few_shot_examples": [
            {
                "scenario": "Valid filtration of noise fields",
                "policy_rules": {
                    "mandatory_fields_to_keep": ["category", "price"],
                    "fields_allowed_to_remove": ["id", "summary"]
                },
                "input_context": "{\"items\":[{\"id\":\"X123\",\"category\":\"TypeA\",\"price\":50}],\"summary\":\"Data summary\"}",
                "output_context": "{\"category\":\"TypeA\",\"price\":50}",
                "expected_pattern": "Fields 'id' and 'summary' → Pass; 'category' and 'price' → Pass."
            },
            {
                "scenario": "Faulty filtration of required field",
                "policy_rules": {
                    "mandatory_fields_to_keep": ["name", "age"],
                    "fields_allowed_to_remove": ["timestamp"]
                },
                "input_context": "{\"user\":{\"name\":\"John\",\"age\":30},\"timestamp\":\"2024-01-15\"}",
                "output_context": "{\"name\":\"John\"}",
                "expected_pattern": "'age' removed → Fail; 'timestamp' removed → Pass."
            }
        ]
    }
    
    response = llm_client.invoke(json.dumps(filter_prompt))
    raw = response.content.strip()
    
    try:
        return json.loads(raw)
    except Exception:
        m = re.search(r"(\{.*\})", raw, re.DOTALL)
        if not m:
            raise RuntimeError(f"Unparseable evaluation output:\n{raw}")
        return json.loads(m.group(1))

# ============================================================
# SCORING
# ============================================================

def compute_context_filter_score(items: List[Dict[str, Any]]) -> float:
    """Compute context filter accuracy score."""
    if not items:
        return 0.0
    
    total = len(items)
    passed = sum(1 for i in items if i.get("judgment") == "Pass")
    
    return round(passed / total, 2)

# ============================================================
# FULL PIPELINE
# ============================================================

def run_context_filter_accuracy_eval(trace_id: str, scenario: str, llm_client: AzureChatOpenAI) -> Dict[str, Any]:
    """Full context filter accuracy evaluation pipeline."""
    try:
        spans = fetch_spans(trace_id)
        
        context_builder_span = find_context_builder_span(spans)
        
        instruction = extract_instruction_from_context_builder(context_builder_span)
        input_context = extract_input_context(context_builder_span)
        output_context = extract_output_context(context_builder_span)
        
        # Extract filtering policy from instruction
        policy_rules = extract_context_filtering_policy(instruction, llm_client)
        
        # Evaluate filtering accuracy
        evaluation_result = evaluate_context_filter_accuracy(
            input_context=input_context,
            output_context=output_context,
            policy_rules=policy_rules,
            llm_client=llm_client
        )
        
        # Compute score
        items = evaluation_result.get("items", [])
        overall_score = compute_context_filter_score(items)
        
        return {
            "eval_name": "context_filter_accuracy",
            "trace_id": trace_id,
            "scenario": scenario,
            "eval_inputs": {
                "input_context": input_context,
                "output_context": output_context,
                "policy_rules": policy_rules
            },
            "eval_output": evaluation_result,
            "metadata": {
                "model": "gpt-5",
                "temperature": 0,
                "timestamp": datetime.utcnow().isoformat()
            },
            "status": "completed",
            "score": overall_score
        }
    except Exception as e:
        return {
            "eval_name": "context_filter_accuracy",
            "trace_id": trace_id,
            "scenario": scenario,
            "eval_inputs": {},
            "eval_output": {},
            "metadata": {
                "model": "gpt-5",
                "temperature": 0,
                "timestamp": datetime.utcnow().isoformat()
            },
            "status": "failed",
            "error": str(e),
            "score": 0.0
        }

# ============================================================
# EXCEL OUTPUT
# ============================================================

def dump_context_filter_accuracy_to_excel(
    *,
    trace_id: str,
    query: str,
    eval_result: dict,
    excel_path: str = "final_eval_results.xlsx",
):
    """Save context filter accuracy results to Excel."""
    
    SHEET_NAME = "Context Filter Accuracy"
    HEADERS = [

        "Query",
        "Text_Extracted_From_Context",
        "Original_Value",
        "Status",
        "Judgment",
        "Reasoning",
        "Overall_Score",
        "Overall_Reason",

    ]
    
    wb = get_or_create_workbook(excel_path)
    sheet = get_or_create_sheet(wb, SHEET_NAME, HEADERS)
    
    eval_output = eval_result.get("eval_output", {})
    score = eval_result.get("score", "")
    
    if eval_result.get("status") == "failed":
        sheet.append([

            query,
            "",
            "",
            "",
            "",
            eval_result.get("error", "Unknown error"),
            "",
            ""
        ])
    else:
        items = eval_output.get("items", [])
        overall_reason = eval_output.get("overall_reason", "")
        
        if items:
            for i, item in enumerate(items):
                sheet.append([
                    query,
                    item.get("text_extracted_from_context", ""),
                    item.get("original_value", ""),
                    item.get("status", ""),
                    item.get("judgment", ""),
                    item.get("reasoning", ""),
                    score if i == 0 else "",
                    overall_reason if i == 0 else ""
                ])
        else:
            sheet.append([
                query,
                "",
                "",
                "",
                "",
                "No items evaluated",
                score,
                overall_reason
            ])
    
    wb.save(excel_path)
