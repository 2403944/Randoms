"""
LangSmith Trace Evaluation with Async/Await
Evaluates multiple traces from an Excel file using all eval metrics.

OUTPUT ROUTING:
  - Detailed_Log.xlsx      → one sheet per eval (create if missing, append if exists)
  - Metrics_template.xlsx  → 'Secondary LLM' sheet (critique/secondary LLM outputs)
                           → 'Test Data' sheet    (per-query overall score + reason)
  - report.html            → generated at the end by report_html.py
"""

import os
import re
import ast
import json
import asyncio
import threading
import time
import zipfile
import tiktoken
from xml.etree import ElementTree as ET
from datetime import datetime, timedelta, timezone
from pathlib import Path
from dotenv import load_dotenv
load_dotenv()
from langchain_openai import AzureChatOpenAI
from openpyxl import load_workbook, Workbook
from tqdm.asyncio import tqdm
from token_tracker import track_tokens_used, count_tokens, get_token_stats

# Import evaluation modules
from parameter_extraction_eval         import run_parameter_extraction_eval,      dump_parameter_eval_to_excel
from tool_call_accuracy_eval           import run_tool_call_accuracy_eval,        dump_tool_call_eval_to_excel
from trajectory_eval                   import run_trajectory_eval,                dump_trajectory_eval_to_excel
from refusal_eval                      import run_refusal_detection_eval,         dump_refusal_eval_to_excel
from plan_accuracy_eval                import run_plan_accuracy_eval,             dump_plan_accuracy_eval_to_excel
from summary_accuracy_eval             import run_summary_accuracy_eval,          dump_summary_accuracy_eval_to_excel
from hallucination_cove_eval           import run_hallucination_cove_eval,        dump_hallucination_cove_eval_to_excel
from agent_goal_accomplishment_eval    import run_agent_goal_accomplishment_eval, dump_agent_goal_accomplishment_to_excel
from context_filter_accuracy_eval      import run_context_filter_accuracy_eval,   dump_context_filter_accuracy_to_excel
from helpfulness_eval                  import run_helpfulness_eval,               dump_helpfulness_eval_to_excel
from knowledge_retention_eval          import run_knowledge_retention_eval,       dump_knowledge_retention_eval_to_excel
from convergence_eval                  import run_convergence_eval,               dump_convergence_eval_to_excel
from output_format_compliance_eval     import run_output_format_compliance_eval,  dump_output_format_compliance_to_excel
from confidence_score_accuracy_eval    import run_confidence_score_accuracy_eval, dump_confidence_score_accuracy_to_excel
from tool_call_error_detection_eval    import run_tool_call_error_detection_eval, dump_tool_call_error_detection_to_excel
from universal_critique_judge_eval     import run_universal_critique_judge,       dump_universal_critique_judge_to_excel
from Recovery_loop_eval                import run_recovery_loop_eval,             dump_recovery_loop_eval_to_excel

os.environ["LANGSMITH_API_KEY"] = os.getenv("LANGSMITH_API_KEY")

# ============================================================
# OUTPUT FILE PATHS
# ============================================================
DETAILED_LOG_EXCEL     = "Detailed_Log.xlsx"
METRICS_TEMPLATE_EXCEL = "Metrics_template.xlsx"
FINAL_EVAL_EXCEL       = "final_eval_results.xlsx"
HTML_REPORT_OUTPUT     = "report.html"

# ============================================================
# INPUT EXCEL CONFIG
# ============================================================
INPUT_EXCEL_PATH    = "input_scenarios.xlsx"
SHEET_NAME          = "Sheet1"
METRICS_SHEET_NAME  = "Metrices"
METRICS_COLUMN_NAME = "Metrices selected"

# ============================================================
# PER-FILE WRITE LOCKS
# ============================================================
_EXCEL_LOCKS: dict = {}
_EXCEL_LOCKS_MUTEX = threading.Lock()

def _get_lock(excel_path: str) -> threading.Lock:
    key = str(Path(excel_path).resolve())
    with _EXCEL_LOCKS_MUTEX:
        if key not in _EXCEL_LOCKS:
            _EXCEL_LOCKS[key] = threading.Lock()
        return _EXCEL_LOCKS[key]

# ============================================================
# EVAL NAME → DETAILED LOG SHEET NAME MAPPING
# ============================================================
EVAL_SHEET_MAP = {
    "parameter_extraction_accuracy": "Parameter Extraction Accuracy",
    "tool_call_accuracy":            "Tool Call Accuracy",
    "trajectory_match":              "Trajectory",
    "refusal_detection":             "Refusal",
    "supervisor_plan_accuracy":      "Plan Accuracy",
    "summary_accuracy":              "Output vs Context Accuracy",
    "hallucination_cove":            "Hallucination CoVe",
    "agent_goal_accomplishment":     "Goal Accomplishment",
    "context_filter_accuracy":       "Context Filter accuracy",
    "helpfulness":                   "Helpfulness",
    "knowledge_retention":           "Knowledge Retention",
    "convergence":                   "Convergence",
    "output_format_compliance":      "Output format Check",
    "confidence_score_accuracy":     "Confidence score accuracy",
    "tool_call_error_detection":     "Tool Call Error",
    "recovery_loop_eval":            "Recovery Loops",
}

_VALID_SHEET_NAMES: set = set(EVAL_SHEET_MAP.values())

STRAY_SHEET_MAP: dict = {
    "Supervisor Plan Accuracy":    "Plan Accuracy",
    "Summary Accuracy":            "Output vs Context Accuracy",
    "Agent Goal Accomplishment":   "Goal Accomplishment",
    "Context Filter Accuracy1":    "Context Filter Accuracy",
    "Output Format Compliance":    "Output format Check",
    "Confidence Score Accuracy1":  "Confidence score Accuracy",
    "Tool Call Error Detection":   "Tool Call Error",
    "Universal Critique Judge":    "Secondary LLM",
    "Recovery Loops":              "Recovery Loops",
}

# ============================================================
# TEST DATA SHEET — column header definitions
# ============================================================
TEST_DATA_METRIC_COLS = [
    ("Parameter Extraction Accuracy",  "Parameter Extraction Accuracy-reason"),
    ("Tool Call Accuracy",             "Tool Call Accuracy-reason"),
    ("Trajectory",                     "Trajectory-reason"),
    ("Refusal",                        "Refusal-reason"),
    ("Output vs Context Accuracy",     "Output vs Context Accuracy-reason"),
    ("Hallucination CoVe",             "Hallucination CoVe-reason"),
    ("Goal Accomplishment",            "Goal Accomplishment-reason"),
    ("Helpfulness",                    "Helpfulness-reason"),
    ("Convergence",                    "Convergence-reason"),
    ("Output format Check",            "Output format Check-reason"),
    ("Knowledge Retention",            "Knowledge Retention-reason"),
    ("Confidence score accuracy",      "Confidence score accuracy-reason"),
    ("Tool Call Error",                "Tool Call Error-reason"),
    ("Context Filter Accuracy",        "Context Filter Accuracy-reason"),
    ("Plan Accuracy",                  "Plan Accuracy-reason"),
    ("Recovery Loop",                  "Recovery Loop-reason"),
]

TEST_DATA_FULL_HEADERS = (
    ["Query", "Response"]
    + [col for pair in TEST_DATA_METRIC_COLS for col in pair]
)

# ============================================================
# SHARED CELL NORMALIZER
# ============================================================
def _normalize_cell(raw: str) -> str:
    """
    Normalize a raw Excel cell string before JSON/AST parsing:
      - Curly/smart quotes  → straight double quotes
      - Curly single quotes → straight single quotes
      - Other unicode quote variants
      - Python literals     → JSON literals
    """
    s = str(raw).strip()
    # Remove Excel carriage-return artifacts (_x000d_ is \r encoded by openpyxl)
    s = s.replace("_x000d_", "").replace("\r", "")
    # Unicode quote normalization
    s = (s.replace("\u201c", '"').replace("\u201d", '"')   # " "
          .replace("\u2018", "'").replace("\u2019", "'")   # ' '
          .replace("\u00ab", '"').replace("\u00bb", '"')   # « »
          .replace("\u2039", "'").replace("\u203a", "'")   # ‹ ›
          .replace("\u2032", "'").replace("\u2033", '"'))  # ′ ″
    # Python → JSON literals
    s = re.sub(r'\bTrue\b',  'true',  s)
    s = re.sub(r'\bFalse\b', 'false', s)
    s = re.sub(r'\bNone\b',  'null',  s)
    return s


def _try_parse_dict(text: str) -> dict:
    """
    Try json.loads first, then ast.literal_eval as fallback.
    Returns a dict or raises.
    """
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        return ast.literal_eval(text)


# ============================================================
# PARSE EXPECTED SCHEMA FROM EXCEL CELL
# ============================================================
def parse_expected_trajectory(raw, trace_id: str = ""):
    """
    Parse the 'expected_trajectory' cell value into a List[str].
    Returns None if cell is empty (skip Trajectory for this row).

    Accepts:
      - JSON array : ["Supervisor", "TaskPlanner", "Supervisor"]
      - Comma-sep  : Supervisor, TaskPlanner, Supervisor
    """
    if not raw or not str(raw).strip():
        return None

    cleaned = _normalize_cell(raw).replace("_x000d_", "").replace("\r", "").strip()

    # Try JSON array first
    try:
        parsed = json.loads(cleaned)
        if isinstance(parsed, list):
            return [str(item).strip().strip('"') for item in parsed if str(item).strip()]
    except json.JSONDecodeError:
        pass

    # Fallback: extract [...] portion if present
    if "[" in cleaned and "]" in cleaned:
        start = cleaned.index("[")
        end   = cleaned.rindex("]") + 1
        try:
            parsed = json.loads(cleaned[start:end])
            return [str(item).strip().strip('"') for item in parsed if str(item).strip()]
        except json.JSONDecodeError:
            pass

    # Last fallback: comma-separated plain string
    items = [item.strip().strip('"') for item in cleaned.split(",") if item.strip()]
    if items:
        return items

    raise ValueError(
        f"expected_trajectory for trace '{trace_id}' could not be parsed. "
        "Use a JSON array or comma-separated agent names."
    )


def parse_expected_schema(raw, trace_id: str = ""):
    """
    Parse the 'expected_parameters' cell value into a dict.
    Returns None if cell is empty (skip Parameter Extraction for this row).
    Raises ValueError on bad content.
    """
    if not raw or not str(raw).strip():
        return None

    cleaned = _normalize_cell(raw).rstrip(",")
    print(f"  [DEBUG expected_parameters trace={trace_id}] repr: {repr(cleaned[:80])}")

    as_json = "{" + cleaned + "}"
    parsed  = _try_parse_dict(as_json)

    if not isinstance(parsed, dict) or not parsed:
        raise ValueError(
            f"expected_parameters for trace '{trace_id}' is empty or not a dict. "
            "Check the cell content."
        )
    return parsed


# ============================================================
# PARSE EXPECTED TOOLS FROM EXCEL CELL
# ============================================================
def parse_expected_tools(raw, trace_id: str = ""):
    """
    Parse the 'expected_tool_calls' cell value into a dict.
    Returns None if cell is empty (skip Tool Call Accuracy for this row).
    Raises ValueError on bad content.
    """
    if not raw or not str(raw).strip():
        return None

    cleaned = _normalize_cell(raw)
    print(f"  [DEBUG expected_tool_calls trace={trace_id}] repr: {repr(cleaned[:80])}")

    for attempt in [cleaned, "{" + cleaned.rstrip(",") + "}"]:
        try:
            parsed = _try_parse_dict(attempt)
            if isinstance(parsed, dict) and parsed:
                return parsed
        except Exception:
            continue

    raise ValueError(
        f"expected_tool_calls for trace '{trace_id}' could not be parsed. "
        "Ensure it is valid JSON."
    )


# ============================================================
# LOAD TRACE IDs, SCENARIOS, AND EXPECTED SCHEMAS FROM EXCEL
# ============================================================
def load_scenarios_from_excel(excel_path: str) -> list:
    """
    Reads Sheet1 columns (resolved by header name):
      trace_id            → col 0 fallback
      scenario            → col 1 fallback
      expected_parameters → optional; None = skip Parameter Extraction
      expected_tool_calls → optional; None = skip Tool Call Accuracy
    """
    if not Path(excel_path).exists():
        raise FileNotFoundError(f"Excel file not found: {excel_path}")

    wb    = load_workbook(excel_path)
    sheet = wb[SHEET_NAME]

    headers = {
        str(cell.value).strip().lower(): idx
        for idx, cell in enumerate(sheet[1])
        if cell.value
    }

    col_trace      = headers.get("trace_id",             0)
    col_scenario   = headers.get("scenario",             1)
    col_schema     = headers.get("expected_parameters",  None)
    col_tools      = headers.get("expected_tool_calls",  None)
    col_trajectory = headers.get("expected_trajectory",  None)   # optional

    scenarios = []
    for row in sheet.iter_rows(min_row=2, values_only=True):
        trace_id = row[col_trace]    if len(row) > col_trace    else None
        scenario = row[col_scenario] if len(row) > col_scenario else None

        if not trace_id or not scenario:
            continue

        raw_schema     = row[col_schema]     if col_schema     is not None and len(row) > col_schema     else None
        raw_tools      = row[col_tools]      if col_tools      is not None and len(row) > col_tools      else None
        raw_trajectory = row[col_trajectory] if col_trajectory is not None and len(row) > col_trajectory else None

        expected_schema     = parse_expected_schema(raw_schema,         trace_id=str(trace_id))
        expected_tools      = parse_expected_tools(raw_tools,           trace_id=str(trace_id))
        expected_trajectory = parse_expected_trajectory(raw_trajectory, trace_id=str(trace_id))

        scenarios.append({
            "trace_id":             str(trace_id),
            "scenario":             str(scenario),
            "expected_schema":      expected_schema,
            "expected_tools":       expected_tools,
            "expected_trajectory":  expected_trajectory,
        })

    return scenarios


# ============================================================
# LOAD CONFIGURATION FROM "configuration" SHEET
# ============================================================
def load_configuration_from_excel(excel_path: str) -> dict:
    """
    Read the 'configuration' sheet for project_name and time_range.
    Returns dict with keys: 'project_name' (str) and 'time_range' (int).
    Falls back to 'default' / 24 hours if sheet/column/value is missing.
    """
    defaults = {"project_name": "default", "time_range": 24}
    wb = load_workbook(excel_path)

    if "configuration" not in wb.sheetnames:
        print("[WARN] 'configuration' sheet not found — using defaults (project='default', time=24h).")
        return defaults

    ws         = wb["configuration"]
    header_row = [str(cell.value).strip().lower() if cell.value else "" for cell in ws[1]]

    col_map = {}
    for key in ("project_name", "time_range"):
        try:
            col_map[key] = header_row.index(key)
        except ValueError:
            print(f"[WARN] '{key}' column not found in 'configuration' sheet — using default.")

    config = dict(defaults)

    for row in ws.iter_rows(min_row=2, values_only=True):
        if "project_name" in col_map:
            val = row[col_map["project_name"]] if len(row) > col_map["project_name"] else None
            if val is not None and str(val).strip():
                config["project_name"] = str(val).strip()

        if "time_range" in col_map:
            val = row[col_map["time_range"]] if len(row) > col_map["time_range"] else None
            if val is not None:
                try:
                    config["time_range"] = int(val)
                except (ValueError, TypeError):
                    pass

        break  # only read the first data row

    print(f"[OK] Configuration loaded: project='{config['project_name']}', time_range={config['time_range']}h")
    return config


# ============================================================
# FIND TRACE ID FOR A SCENARIO VIA LANGSMITH SEARCH
# ============================================================
def find_trace_id_for_scenario(scenario: str, time_range_hours: int, project_name: str = "default") -> str:
    """
    Search LangSmith for a root span whose input messages contain
    a human message with content matching the given scenario.

    Searches within the last `time_range_hours` hours.

    Args:
        scenario:         The query/scenario text to match.
        time_range_hours: How far back to search (e.g. 2, 24).

    Returns:
        The trace_id string of the matching root run.

    Raises:
        ValueError if no match is found.
    """
    from langsmith import Client

    client     = Client(api_key=os.environ["LANGSMITH_API_KEY"])
    end_time   = datetime.now(timezone.utc)
    start_time = end_time - timedelta(hours=time_range_hours)

    scenario_normalized = scenario.strip().lower()

    print(f"  [SEARCH] Looking for scenario in last {time_range_hours}h: '{scenario[:60]}...'")

    # LangSmith requires project_name (session) to query runs
    runs = client.list_runs(
        project_name=project_name,
        run_type="chain",
        start_time=start_time,
        end_time=end_time,
    )

    # Collect ALL matching root spans, then pick the latest
    matches = []
    for run in runs:
        # Root span has no parent
        if run.parent_run_id is not None:
            continue

        inputs   = run.inputs or {}
        messages = inputs.get("messages", [])

        for msg in messages:
            if isinstance(msg, dict):
                msg_type    = msg.get("type", "")
                msg_content = msg.get("content", "")
            else:
                msg_type    = getattr(msg, "type", "")
                msg_content = getattr(msg, "content", "")

            if msg_type == "human" and str(msg_content).strip().lower() == scenario_normalized:
                matches.append(run)
                break   # no need to check other messages in this run

    if not matches:
        raise ValueError(
            f"No trace found for scenario: '{scenario}' "
            f"within last {time_range_hours} hour(s). "
            "Check that the agent ran recently and the scenario text matches exactly."
        )

    # Pick the most recent match by start_time
    latest = max(matches, key=lambda r: r.start_time or datetime.min.replace(tzinfo=timezone.utc))
    resolved_id = str(latest.trace_id or latest.id)
    if len(matches) > 1:
        print(f"  [INFO] {len(matches)} traces matched — picking latest (start={latest.start_time})")
    print(f"  [FOUND] trace_id={resolved_id} for scenario: '{scenario[:60]}'")
    return resolved_id


# ============================================================
# UUID VALIDATION & TRACE ID RESOLUTION
# ============================================================
import re as _re

_UUID_RE = _re.compile(
    r'^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$',
    _re.IGNORECASE
)


def _is_valid_uuid(val) -> bool:
    return bool(val and _UUID_RE.match(str(val).strip()))


def resolve_trace_ids(scenarios: list, time_range_hours: int, project_name: str = "default") -> list:
    """
    For each scenario dict whose trace_id is missing OR is not a valid UUID,
    search LangSmith by scenario content and fill in the trace_id.
    Scenarios that fail to resolve are removed with a warning.
    """
    resolved = []
    for s in scenarios:
        trace_id = s.get("trace_id")

        if _is_valid_uuid(trace_id):
            # Already a valid UUID — use as-is
            resolved.append(s)
            continue

        if trace_id:
            print(f"  [WARN] trace_id '{str(trace_id)[:40]}' is not a valid UUID — will search LangSmith.")

        try:
            s["trace_id"] = find_trace_id_for_scenario(s["scenario"], time_range_hours, project_name)
            print(f"  [RESOLVED] '{s['scenario'][:50]}' → {s['trace_id']}")
            resolved.append(s)
        except ValueError as exc:
            print(f"  [WARN] Skipping scenario — {exc}")

    print(f"[OK] Resolved {len(resolved)}/{len(scenarios)} trace IDs.")
    return resolved


# ============================================================
# LOAD SELECTED METRICS FROM EXCEL
# ============================================================
def load_selected_metrics(excel_path: str) -> set:
    wb = load_workbook(excel_path)

    if METRICS_SHEET_NAME not in wb.sheetnames:
        print(f"[WARN] '{METRICS_SHEET_NAME}' sheet not found — running ALL metrics.")
        return set(METRIC_REGISTRY.keys())

    ws         = wb[METRICS_SHEET_NAME]
    header_row = [cell.value for cell in ws[1]]

    try:
        col_idx = header_row.index(METRICS_COLUMN_NAME)
    except ValueError:
        print(f"[WARN] Column '{METRICS_COLUMN_NAME}' not found — running ALL metrics.")
        return set(METRIC_REGISTRY.keys())

    selected = set()
    for row in ws.iter_rows(min_row=2, values_only=True):
        val = row[col_idx]
        if not val:
            continue
        name = str(val).strip()
        if name in METRIC_REGISTRY:
            selected.add(name)
        else:
            print(f"[WARN] Unknown metric in '{METRICS_SHEET_NAME}' sheet: '{name}' — skipping.")

    if not selected:
        print("[WARN] No valid metrics found in sheet — running ALL metrics.")
        return set(METRIC_REGISTRY.keys())

    print(f"[OK] Selected metrics ({len(selected)}): {sorted(selected)}")
    return selected


# ============================================================
# METRIC REGISTRY
# ============================================================
METRIC_REGISTRY = {
    "Parameter Extraction Accuracy": {
        "run_fn":      run_parameter_extraction_eval,
        "dump_fn":     dump_parameter_eval_to_excel,
        "sheet_key":   "parameter_extraction_accuracy",
        "result_key":  "param",
        "llm":         "default",
        "dump_kwargs": lambda trace_id, scenario, result, excel: dict(
            trace_id=trace_id, query=scenario, eval_result=result, excel_path=excel
        ),
    },
    "Tool Call Accuracy": {
        "run_fn":      run_tool_call_accuracy_eval,
        "dump_fn":     dump_tool_call_eval_to_excel,
        "sheet_key":   "tool_call_accuracy",
        "result_key":  "tool",
        "llm":         "default",
        "dump_kwargs": lambda trace_id, scenario, result, excel: dict(
            trace_id=trace_id, query=scenario, eval_result=result, excel_path=excel
        ),
    },
    "Trajectory": {
        "run_fn":      run_trajectory_eval,
        "dump_fn":     dump_trajectory_eval_to_excel,
        "sheet_key":   "trajectory_match",
        "result_key":  "trajectory",
        "llm":         "deterministic",
        "dump_kwargs": lambda trace_id, scenario, result, excel: dict(
            trace_id=trace_id, query=scenario, eval_result=result, excel_path=excel
        ),
    },
    "Refusal": {
        "run_fn":      run_refusal_detection_eval,
        "dump_fn":     dump_refusal_eval_to_excel,
        "sheet_key":   "refusal_detection",
        "result_key":  "refusal",
        "llm":         "default",
        "dump_kwargs": lambda trace_id, scenario, result, excel: dict(
            trace_id=trace_id, query=scenario, eval_result=result, excel_path=excel
        ),
    },
    "Plan Accuracy": {
        "run_fn":      run_plan_accuracy_eval,
        "dump_fn":     dump_plan_accuracy_eval_to_excel,
        "sheet_key":   "supervisor_plan_accuracy",
        "result_key":  "plan",
        "llm":         "default",
        "dump_kwargs": lambda trace_id, scenario, result, excel: dict(
            trace_id=trace_id, query=scenario, eval_result=result, excel_path=excel
        ),
    },
    "Output vs Context Accuracy": {
        "run_fn":      run_summary_accuracy_eval,
        "dump_fn":     dump_summary_accuracy_eval_to_excel,
        "sheet_key":   "summary_accuracy",
        "result_key":  "summary",
        "llm":         "default",
        "dump_kwargs": lambda trace_id, scenario, result, excel: dict(
            trace_id=trace_id, query=scenario, eval_result=result, excel_path=excel
        ),
    },
    "Hallucination CoVe": {
        "run_fn":      run_hallucination_cove_eval,
        "dump_fn":     dump_hallucination_cove_eval_to_excel,
        "sheet_key":   "hallucination_cove",
        "result_key":  "cove",
        "llm":         "default",
        "dump_kwargs": lambda trace_id, scenario, result, excel: dict(
            trace_id=trace_id, query=scenario, eval_result=result, excel_path=excel
        ),
    },
    "Goal Accomplishment": {
        "run_fn":      run_agent_goal_accomplishment_eval,
        "dump_fn":     dump_agent_goal_accomplishment_to_excel,
        "sheet_key":   "agent_goal_accomplishment",
        "result_key":  "goal",
        "llm":         "default",
        "dump_kwargs": lambda trace_id, scenario, result, excel: dict(
            trace_id=trace_id, query=scenario, eval_result=result, excel_path=excel
        ),
    },
    "Context Filter Accuracy": {
        "run_fn":      run_context_filter_accuracy_eval,
        "dump_fn":     dump_context_filter_accuracy_to_excel,
        "sheet_key":   "context_filter_accuracy",
        "result_key":  "filter",
        "llm":         "deterministic",
        "dump_kwargs": lambda trace_id, scenario, result, excel: dict(
            trace_id=trace_id, query=scenario, eval_result=result, excel_path=excel
        ),
    },
    "Helpfulness": {
        "run_fn":      run_helpfulness_eval,
        "dump_fn":     dump_helpfulness_eval_to_excel,
        "sheet_key":   "helpfulness",
        "result_key":  "helpfulness",
        "llm":         "default",
        "dump_kwargs": lambda trace_id, scenario, result, excel: dict(
            trace_id=trace_id, query=scenario, eval_result=result, excel_path=excel
        ),
    },
    "Knowledge Retention": {
        "run_fn":      run_knowledge_retention_eval,
        "dump_fn":     dump_knowledge_retention_eval_to_excel,
        "sheet_key":   "knowledge_retention",
        "result_key":  "knowledge_retention",
        "llm":         "default",
        "dump_kwargs": lambda trace_id, scenario, result, excel: dict(
            trace_id=trace_id, query=scenario, eval_result=result, excel_path=excel
        ),
    },
    "Convergence": {
        "run_fn":      run_convergence_eval,
        "dump_fn":     dump_convergence_eval_to_excel,
        "sheet_key":   "convergence",
        "result_key":  "convergence",
        "llm":         "none",
        "dump_kwargs": lambda trace_id, scenario, result, excel: dict(
            trace_id=trace_id, query=scenario, eval_result=result, excel_path=excel
        ),
    },
    "Output format Check": {
        "run_fn":      run_output_format_compliance_eval,
        "dump_fn":     dump_output_format_compliance_to_excel,
        "sheet_key":   "output_format_compliance",
        "result_key":  "format",
        "llm":         "deterministic",
        "dump_kwargs": lambda trace_id, scenario, result, excel: dict(
            trace_id=trace_id, query=scenario, eval_result=result, excel_path=excel
        ),
    },
    "Confidence score accuracy": {
        "run_fn":      run_confidence_score_accuracy_eval,
        "dump_fn":     dump_confidence_score_accuracy_to_excel,
        "sheet_key":   "confidence_score_accuracy",
        "result_key":  "confidence",
        "llm":         "deterministic",
        "dump_kwargs": lambda trace_id, scenario, result, excel: dict(
            eval_result=result, output_excel=excel
        ),
    },
    "Tool Call Error": {
        "run_fn":      run_tool_call_error_detection_eval,
        "dump_fn":     dump_tool_call_error_detection_to_excel,
        "sheet_key":   "tool_call_error_detection",
        "result_key":  "error_detect",
        "llm":         "deterministic",
        "dump_kwargs": lambda trace_id, scenario, result, excel: dict(
            eval_result=result, output_excel=excel
        ),
    },
    "Recovery Loop": {
        "run_fn":      run_recovery_loop_eval,
        "dump_fn":     dump_recovery_loop_eval_to_excel,
        "sheet_key":   "recovery_loop_eval",
        "result_key":  "recovery_loop",
        "llm":         "default",
        "dump_kwargs": lambda trace_id, scenario, result, excel: dict(
            trace_id=trace_id, query=scenario, eval_result=result, excel_path=excel
        ),
    },
}

# ============================================================
# WEIGHTED EVAL SCORE CALCULATOR
# ============================================================
METRIC_WEIGHTS = {
    "Parameter Extraction Accuracy": 0.058,
    "Tool Call Accuracy":            0.078,
    "Trajectory":                    0.078,
    "Refusal":                       0.049,
    "Plan Accuracy":                 0.245,
    "Output vs Context Accuracy":    0.078,
    "Hallucination CoVe":            0.078,
    "Goal Accomplishment":           0.059,
    "Context Filter Accuracy":       0.059,
    "Helpfulness":                   0.039,
    "Knowledge Retention":           0.039,
    "Convergence":                   0.039,
    "Output format Check":           0.029,
    "Confidence score accuracy":     0.029,
    "Tool Call Error":               0.020,
    "Recovery Loop":                 0.023,
}


def compute_weighted_score(scores_and_reasons: dict) -> dict:
    total_weight = sum(METRIC_WEIGHTS.values())
    if round(total_weight, 5) != 1.0:
        raise ValueError(f"Weights must sum to 1.0 (current={total_weight})")

    weighted_total = 0.0
    breakdown      = {}
    count          = 0

    for metric, weight in METRIC_WEIGHTS.items():
        metric_data = scores_and_reasons.get(metric, {})
        score       = metric_data.get("score")
        if score is None:
            continue
        try:
            score = float(score)
            score = max(0.0, min(1.0, score))
            count += 1
        except (ValueError, TypeError):
            score = 0.0

        weighted_score = score * weight
        weighted_total += weighted_score
        breakdown[metric] = {
            "score":                 round(score, 4),
            "weight":                weight,
            "weighted_contribution": round(weighted_score, 4),
        }

    return {
        "score":     round(weighted_total, 4),
        "breakdown": breakdown,
        "reason":    f"Weighted average of {count} metrics. Breakdown: {breakdown}",
    }


def dump_weighted_scores_to_sheet(
    query: str, scores_and_reasons: dict, excel_path: str = FINAL_EVAL_EXCEL
):
    sheet_name = "Weighted Scores"
    headers    = ["Query"] + list(METRIC_WEIGHTS.keys()) + ["Total Score"]

    with _get_lock(excel_path):
        wb, ws = _ensure_sheet(excel_path, sheet_name, headers=headers)

        header_to_col = {}
        for col_idx in range(1, ws.max_column + 1):
            val = ws.cell(1, col_idx).value
            if val:
                header_to_col[val] = col_idx

        next_col = ws.max_column + 1
        for header in headers:
            if header not in header_to_col:
                ws.cell(1, next_col).value = header
                header_to_col[header]      = next_col
                next_col += 1

        target_row = None
        for row_idx in range(2, ws.max_row + 1):
            if ws.cell(row_idx, 1).value == query:
                target_row = row_idx
                break
        if target_row is None:
            target_row = ws.max_row + 1

        ws.cell(target_row, header_to_col["Query"]).value = query

        for metric_name in METRIC_WEIGHTS.keys():
            if metric_name in header_to_col:
                metric_data = scores_and_reasons.get(metric_name, {})
                score       = metric_data.get("score")
                if score is not None:
                    ws.cell(target_row, header_to_col[metric_name]).value = score

        if "Total Score" in header_to_col and "__WEIGHTED_SCORE__" in scores_and_reasons:
            total_score = scores_and_reasons.get("__WEIGHTED_SCORE__", {}).get("score")
            if total_score is not None:
                ws.cell(target_row, header_to_col["Total Score"]).value = total_score

        wb.save(excel_path)


# ============================================================
# HELPERS
# ============================================================
def _get(d, *keys):
    for k in keys:
        d = (d or {}).get(k)
    return d


def count_tokens_tiktoken(text: str) -> int:
    try:
        encoding = tiktoken.get_encoding("cl100k_base")
        return len(encoding.encode(text))
    except Exception:
        return 0


def invoke_and_track_tokens(llm, prompt, eval_name: str = "unknown", scenario: str = None):
    response = llm.invoke(prompt)
    if hasattr(response, 'content'):
        response_tokens = count_tokens(response.content)
        track_tokens_used(response_tokens, query=scenario, eval_name=eval_name)
    return response


def _ensure_sheet(excel_path: str, sheet_name: str, headers: list = None):
    path = Path(excel_path)
    if path.exists():
        wb = load_workbook(excel_path)
    else:
        wb = Workbook()
        if "Sheet" in wb.sheetnames:
            del wb["Sheet"]

    target_key   = sheet_name.strip().lower()
    matched_name = None
    for existing in wb.sheetnames:
        if existing.strip().lower() == target_key:
            matched_name = existing
            break

    if matched_name is None:
        ws = wb.create_sheet(sheet_name)
        if headers:
            ws.append(headers)
    else:
        ws = wb[matched_name]

    return wb, ws


def _get_sheet_names(file_path: str) -> set:
    path = Path(file_path)
    if not path.exists():
        return set()
    try:
        with zipfile.ZipFile(file_path, 'r') as zf:
            with zf.open('xl/workbook.xml') as f:
                tree = ET.parse(f)
        ns = {'ns': 'http://schemas.openxmlformats.org/spreadsheetml/2006/main'}
        return {s.get('name') for s in tree.findall('.//ns:sheet', ns)}
    except Exception:
        return set()


def _dump_with_sheet_guard(file_path: str, expected_sheet: str, dump_fn, **kwargs):
    with _get_lock(file_path):
        if kwargs:
            dump_fn(**kwargs)
        else:
            dump_fn()

        if not Path(file_path).exists():
            return

        wb = load_workbook(file_path)
        try:
            changed  = False
            existing = {name.strip().lower(): name for name in wb.sheetnames}

            for stray_name in list(wb.sheetnames):
                if stray_name.strip().lower() == expected_sheet.strip().lower():
                    continue
                if stray_name in _VALID_SHEET_NAMES:
                    continue
                correct_name = STRAY_SHEET_MAP.get(stray_name)
                if not correct_name:
                    continue

                real_target = existing.get(correct_name.strip().lower())
                stray_ws    = wb[stray_name]

                if real_target:
                    target_ws = wb[real_target]
                    for row in stray_ws.iter_rows(values_only=True):
                        if any(cell is not None for cell in row):
                            target_ws.append(list(row))
                    del wb[stray_name]
                    print(f"    [GUARD] Merged stray sheet '{stray_name}' → '{real_target}' in {Path(file_path).name}")
                else:
                    stray_ws.title = correct_name
                    existing[correct_name.strip().lower()] = correct_name
                    print(f"    [GUARD] Renamed stray sheet '{stray_name}' → '{correct_name}' in {Path(file_path).name}")
                changed = True

            if changed:
                wb.save(file_path)
        finally:
            try:
                wb.close()
            except Exception:
                pass


def _delete_query_rows(ws, query: str, query_col: int = 1):
    rows_to_delete = [
        row_idx
        for row_idx in range(2, ws.max_row + 1)
        if ws.cell(row_idx, query_col).value == query
    ]
    for row_idx in reversed(rows_to_delete):
        ws.delete_rows(row_idx)
    return len(rows_to_delete)


def _clear_query_from_sheet(excel_path: str, sheet_name: str, query: str):
    if not Path(excel_path).exists():
        return
    with _get_lock(excel_path):
        wb = load_workbook(excel_path)
        try:
            target_key = sheet_name.strip().lower()
            matched    = next(
                (s for s in wb.sheetnames if s.strip().lower() == target_key), None
            )
            if matched is None:
                return
            ws      = wb[matched]
            removed = _delete_query_rows(ws, query, query_col=1)
            if removed:
                wb.save(excel_path)
                print(f"    [CLEAN] Removed {removed} stale row(s) for query in '{matched}'")
        finally:
            try:
                wb.close()
            except Exception:
                pass


# ============================================================
# UPDATE TEST DATA SHEET
# ============================================================
def update_test_data_sheet(
    query: str, response: str, scores_and_reasons: dict,
    excel_path: str = METRICS_TEMPLATE_EXCEL,
):
    sheet_name = "Test Data"

    with _get_lock(excel_path):
        wb, ws = _ensure_sheet(excel_path, sheet_name, headers=TEST_DATA_FULL_HEADERS)

        header_to_col = {}
        for col_idx in range(1, ws.max_column + 1):
            val = ws.cell(1, col_idx).value
            if val:
                header_to_col[val] = col_idx

        next_col = ws.max_column + 1
        for header in TEST_DATA_FULL_HEADERS:
            if header not in header_to_col:
                ws.cell(1, next_col).value = header
                header_to_col[header]      = next_col
                next_col += 1

        target_row = None
        for row_idx in range(2, ws.max_row + 1):
            if ws.cell(row_idx, 1).value == query:
                target_row = row_idx
                break

        if target_row is None:
            target_row = ws.max_row + 1
            print(f"    [TEST DATA] New row → row {target_row} for query")
        else:
            print(f"    [TEST DATA] Replacing existing row {target_row} for query")
            for col_idx in range(1, ws.max_column + 1):
                cell_header = ws.cell(1, col_idx).value
                if cell_header not in ("Query", "Response", None):
                    ws.cell(target_row, col_idx).value = None

        ws.cell(target_row, header_to_col["Query"]).value    = query
        ws.cell(target_row, header_to_col["Response"]).value = response or ""

        for score_col, reason_col in TEST_DATA_METRIC_COLS:
            metric_data = scores_and_reasons.get(score_col, {})
            score       = metric_data.get("score")
            reason      = metric_data.get("reason")
            if score_col  in header_to_col and score  is not None:
                ws.cell(target_row, header_to_col[score_col]).value  = score
            if reason_col in header_to_col and reason is not None:
                ws.cell(target_row, header_to_col[reason_col]).value = reason

        wb.save(excel_path)


# ============================================================
# EXTRACT OVERALL SCORE + REASON FROM EACH EVAL RESULT
# ============================================================
def extract_scores_and_reasons(
    param_result, tool_result, traj_result, refusal_result,
    plan_result, summary_result, cove_result, goal_result,
    filter_result, helpfulness_result, kr_result,
    convergence_result, format_result, confidence_result,
    error_detect_result, recovery_loop_result,
) -> dict:
    return {
        "Parameter Extraction Accuracy": {
            "score":  _get(param_result,       "score"),
            "reason": _get(param_result,       "overall_reason")
                      or _get(param_result,    "eval_output", "overall_reason"),
        },
        "Tool Call Accuracy": {
            "score":  _get(tool_result,        "score"),
            "reason": _get(tool_result,        "overall_reason")
                      or _get(tool_result,     "eval_output", "overall_reason"),
        },
        "Trajectory": {
            "score":  _get(traj_result,        "eval_output", "final_score"),
            "reason": _get(traj_result,        "eval_output", "overall_reason")
                      or _get(traj_result,     "overall_reason"),
        },
        "Refusal": {
            "score":  _get(refusal_result,     "eval_output", "score"),
            "reason": _get(refusal_result,     "eval_output", "overall_reason")
                      or _get(refusal_result,  "overall_reason"),
        },
        "Output vs Context Accuracy": {
            "score":  _get(summary_result,     "eval_output", "output_vs_context_accuracy_score"),
            "reason": _get(summary_result,     "eval_output", "overall_reason")
                      or _get(summary_result,  "overall_reason"),
        },
        "Hallucination CoVe": {
            "score":  _get(cove_result,        "eval_output", "score"),
            "reason": _get(cove_result,        "eval_output", "overall_reason")
                      or _get(cove_result,     "overall_reason"),
        },
        "Goal Accomplishment": {
            "score":  _get(goal_result,        "eval_output", "verdict"),
            "reason": _get(goal_result,        "eval_output", "overall_reason")
                      or _get(goal_result,     "overall_reason"),
        },
        "Helpfulness": {
            "score":  _get(helpfulness_result, "overall_summary", "overall_score"),
            "reason": _get(helpfulness_result, "overall_summary", "overall_reason")
                      or _get(helpfulness_result, "overall_reason"),
        },
        "Convergence": {
            "score":  _get(convergence_result, "score"),
            "reason": _get(convergence_result, "eval_output", "overall_reason")
                      or _get(convergence_result, "eval_output", "reasoning"),
        },
        "Output format Check": {
            "score":  _get(format_result,      "score"),
            "reason": _get(format_result,      "overall_reason"),
        },
        "Knowledge Retention": {
            "score":  _get(kr_result, "score"),
            "reason": _get(kr_result, "overall_reason"),
        },
        "Confidence score accuracy": {
            "score":  _get(confidence_result,  "overall_score"),
            "reason": _get(confidence_result,  "overall_reason"),
        },
        "Tool Call Error": {
            "score":  _get(error_detect_result, "overall_score"),
            "reason": _get(error_detect_result, "overall_reason"),
        },
        "Context Filter Accuracy": {
            "score":  _get(filter_result,      "score"),
            "reason": _get(filter_result,      "eval_output", "overall_reason")
                      or _get(filter_result,   "overall_reason"),
        },
        "Plan Accuracy": {
            "score":  _get(plan_result,        "eval_output", "score"),
            "reason": _get(plan_result,        "eval_output", "overall_reason")
                      or _get(plan_result,     "overall_reason"),
        },
        "Recovery Loop": {
            "score":  _get(recovery_loop_result, "eval_output", "recovery_score"),
            "reason": _get(recovery_loop_result, "eval_output", "reason"),
        },
    }


# ============================================================
# ASYNC WORKER — process one trace (only selected metrics)
# ============================================================
async def process_single_trace(
    scenario_data:     dict,
    llm_client:        AzureChatOpenAI,
    deterministic_llm: AzureChatOpenAI,
    selected_metrics:  set,
    output_excel:      str = "final_eval_results.xlsx",
):
    trace_id            = scenario_data.get("trace_id")
    scenario            = scenario_data.get("scenario")
    expected_schema     = scenario_data.get("expected_schema")
    expected_tools      = scenario_data.get("expected_tools")
    expected_trajectory = scenario_data.get("expected_trajectory")

    print(f"  Processing trace: {trace_id}  [{len(selected_metrics)} metrics]")

    loop = asyncio.get_event_loop()

    def _safe(result):
        if isinstance(result, BaseException):
            print(f"  [WARN] Eval raised exception for trace {trace_id}: {result}")
            return {}
        return result if isinstance(result, dict) else {}

    # ------------------------------------------------------------------
    # 1. Build tasks only for selected metrics (skip if no input data)
    # ------------------------------------------------------------------
    if not expected_schema and "Parameter Extraction Accuracy" in selected_metrics:
        print(f"  [SKIP] No expected_parameters for trace {trace_id} — skipping Parameter Extraction Accuracy.")
    if not expected_tools and "Tool Call Accuracy" in selected_metrics:
        print(f"  [SKIP] No expected_tool_calls for trace {trace_id} — skipping Tool Call Accuracy.")
    if not expected_trajectory and "Trajectory" in selected_metrics:
        print(f"  [SKIP] No expected_trajectory for trace {trace_id} — skipping Trajectory.")

    ordered_metrics = [
        m for m in METRIC_REGISTRY
        if m in selected_metrics
        and not (m == "Parameter Extraction Accuracy" and not expected_schema)
        and not (m == "Tool Call Accuracy"            and not expected_tools)
        and not (m == "Trajectory"                    and not expected_trajectory)
    ]

    def _make_task(metric_name):
        cfg = METRIC_REGISTRY[metric_name]

        if cfg["llm"] == "none":
            return loop.run_in_executor(None, cfg["run_fn"], trace_id, scenario)

        llm = deterministic_llm if cfg["llm"] == "deterministic" else llm_client

        if metric_name == "Parameter Extraction Accuracy":
            return loop.run_in_executor(
                None, cfg["run_fn"], trace_id, scenario, llm, expected_schema
            )
        if metric_name == "Tool Call Accuracy":
            return loop.run_in_executor(
                None, cfg["run_fn"], trace_id, scenario, llm, expected_tools
            )
        if metric_name == "Trajectory":
            return loop.run_in_executor(
                None, cfg["run_fn"], trace_id, scenario, llm, expected_trajectory
            )

        return loop.run_in_executor(None, cfg["run_fn"], trace_id, scenario, llm)

    raw_results = [
        _safe(r) for r in await asyncio.gather(
            *[_make_task(m) for m in ordered_metrics], return_exceptions=True
        )
    ]

    results_by_key = {cfg["result_key"]: {} for cfg in METRIC_REGISTRY.values()}
    for metric_name, result in zip(ordered_metrics, raw_results):
        key = METRIC_REGISTRY[metric_name]["result_key"]
        results_by_key[key] = result

    import utils  # noqa

    # ------------------------------------------------------------------
    # 2. Dump results for selected metrics only
    # ------------------------------------------------------------------
    for metric_name in ordered_metrics:
        cfg    = METRIC_REGISTRY[metric_name]
        result = results_by_key[cfg["result_key"]]
        if not result:
            continue
        sheet_name = EVAL_SHEET_MAP[cfg["sheet_key"]]
        kwargs     = cfg["dump_kwargs"](trace_id, scenario, result, output_excel)
        _clear_query_from_sheet(output_excel, sheet_name, scenario)
        _dump_with_sheet_guard(output_excel, sheet_name, cfg["dump_fn"], **kwargs)

    # ------------------------------------------------------------------
    # 3. Update Test Data sheet
    # ------------------------------------------------------------------
    response_text = (
        _get(results_by_key.get("summary"),  "eval_output", "actual_output")
        or _get(results_by_key.get("cove"),  "eval_output", "actual_output")
        or _get(results_by_key.get("goal"),  "eval_output", "actual_output")
        or ""
    )

    scores_and_reasons = extract_scores_and_reasons(
        results_by_key.get("param",               {}),
        results_by_key.get("tool",                {}),
        results_by_key.get("trajectory",          {}),
        results_by_key.get("refusal",             {}),
        results_by_key.get("plan",                {}),
        results_by_key.get("summary",             {}),
        results_by_key.get("cove",                {}),
        results_by_key.get("goal",                {}),
        results_by_key.get("filter",              {}),
        results_by_key.get("helpfulness",         {}),
        results_by_key.get("knowledge_retention", {}),
        results_by_key.get("convergence",         {}),
        results_by_key.get("format",              {}),
        results_by_key.get("confidence",          {}),
        results_by_key.get("error_detect",        {}),
        results_by_key.get("recovery_loop",       {}),
    )

    update_test_data_sheet(
        query=scenario, response=response_text,
        scores_and_reasons=scores_and_reasons, excel_path=METRICS_TEMPLATE_EXCEL,
    )
    update_test_data_sheet(
        query=scenario, response=response_text,
        scores_and_reasons=scores_and_reasons, excel_path=output_excel,
    )

    weighted_score_result = compute_weighted_score(scores_and_reasons)
    scores_and_reasons["__WEIGHTED_SCORE__"] = weighted_score_result
    dump_weighted_scores_to_sheet(
        query=scenario, scores_and_reasons=scores_and_reasons, excel_path=output_excel,
    )

    return {
        "trace_id": trace_id,
        "scenario": scenario,
        **{f"{cfg['result_key']}_status": results_by_key[cfg['result_key']].get("status")
           for cfg in METRIC_REGISTRY.values()},
        **{f"{cfg['result_key']}_score": results_by_key[cfg['result_key']].get("score")
           for cfg in METRIC_REGISTRY.values()},
        "eval_results": {
            cfg["result_key"]: results_by_key[cfg["result_key"]]
            for cfg in METRIC_REGISTRY.values()
        },
    }


# ============================================================
# ASYNC CRITIQUE JUDGE RUNNER
# ============================================================
async def run_critique_for_result(
    result:       dict,
    critique_llm: AzureChatOpenAI,
    output_excel: str = "final_eval_results.xlsx",
):
    import utils  # noqa

    trace_id          = result.get("trace_id")
    scenario          = result.get("scenario")
    eval_results_dict = result.get("eval_results", {})

    eval_mapping = {
        "param":               "Parameter Extraction Accuracy",
        "tool":                "Tool Call Accuracy",
        "trajectory":          "Trajectory",
        "refusal":             "Refusal",
        "plan":                "Plan Accuracy",
        "summary":             "Output vs Context Accuracy",
        "cove":                "Hallucination Cove",
        "goal":                "Goal Accomplishment",
        "filter":              "Context Filter accuracy",
        "helpfulness":         "Helpfulness",
        "knowledge_retention": "Knowledge Retention",
        "convergence":         "Convergence",
        "format":              "Output format Check",
        "confidence":          "Confidence score accuracy",
        "error_detect":        "Tool Call Error",
        "recovery_loop":       "Recovery Loop",
    }

    eval_records = []
    for key, eval_name in eval_mapping.items():
        eval_result = eval_results_dict.get(key, {})
        if eval_result and eval_result.get("status") in ("success", "completed"):
            eval_records.append({
                "eval_name":   eval_name,
                "eval_type":   eval_result.get("eval_type", "hybrid"),
                "trace_id":    trace_id,
                "scenario":    scenario,
                "eval_prompt": eval_result.get("eval_prompt", ""),
                "eval_inputs": eval_result.get("eval_inputs", {}),
                "eval_output": eval_result.get("eval_output", {}),
            })

    if not eval_records:
        return None

    loop            = asyncio.get_event_loop()
    critique_result = await loop.run_in_executor(
        None, run_universal_critique_judge, eval_records, critique_llm
    )

    _clear_query_from_sheet(METRICS_TEMPLATE_EXCEL, "Secondary LLM", scenario)
    _dump_with_sheet_guard(
        METRICS_TEMPLATE_EXCEL, "Secondary LLM",
        lambda: dump_universal_critique_judge_to_excel(critique_result, METRICS_TEMPLATE_EXCEL, utils),
    )
    _dump_with_sheet_guard(
        output_excel, "Secondary LLM",
        lambda: dump_universal_critique_judge_to_excel(critique_result, output_excel, utils),
    )

    status = critique_result.get("status")
    if status == "completed":
        print(f"  [OK] Critique done for trace {trace_id} ({len(eval_records)} evals)")
    else:
        print(f"  [ERROR] Critique failed for trace {trace_id}")

    return critique_result


# ============================================================
# MAIN ASYNC ORCHESTRATOR
# ============================================================
async def run_async_evaluation(
    scenarios:         list,
    llm_client:        AzureChatOpenAI,
    deterministic_llm: AzureChatOpenAI,
    critique_llm:      AzureChatOpenAI,
    semaphore_limit:   int = 4,
    output_excel:      str = "final_eval_results.xlsx",
):
    if not scenarios:
        print("No scenarios to process.")
        return []

    # ── Resolve trace IDs for any scenario where trace_id is missing ──
    config           = load_configuration_from_excel(INPUT_EXCEL_PATH)
    time_range_hours = config["time_range"]
    project_name     = config["project_name"]
    scenarios        = resolve_trace_ids(scenarios, time_range_hours, project_name)
    if not scenarios:
        print("[ERROR] No scenarios with resolved trace IDs — aborting.")
        return []

    selected_metrics = load_selected_metrics(INPUT_EXCEL_PATH)

    print(f"\n[INFO] Starting async evaluation (concurrency={semaphore_limit})")
    print(f"[INFO] Total traces   : {len(scenarios)}")
    print(f"[INFO] Active metrics : {len(selected_metrics)}/{len(METRIC_REGISTRY)}")
    print(f"[INFO] Full eval results   → {output_excel}")
    print(f"[INFO] Detailed log        → {DETAILED_LOG_EXCEL}")
    print(f"[INFO] Metrics/Test Data   → {METRICS_TEMPLATE_EXCEL}")
    print(f"[INFO] HTML report         → {HTML_REPORT_OUTPUT}\n")

    semaphore = asyncio.Semaphore(semaphore_limit)

    async def guarded_process(scenario_data):
        async with semaphore:
            return await process_single_trace(
                scenario_data, llm_client, deterministic_llm,
                selected_metrics, output_excel,
            )

    tasks          = [guarded_process(s) for s in scenarios]
    results        = []
    critique_tasks = []

    for coro in tqdm(asyncio.as_completed(tasks), total=len(tasks), desc="Traces"):
        result = await coro
        results.append(result)
        query        = result.get("scenario", "Unknown")
        token_stats  = get_token_stats()
        query_tokens = token_stats.get("per_query", {}).get(query, 0)
        if query_tokens > 0:
            print(f"  ✓ Query complete: {query} [{query_tokens:,} tokens]")
        # Print any per-eval errors so failures are visible
        for key, eval_res in result.get("eval_results", {}).items():
            if isinstance(eval_res, dict) and eval_res.get("status") == "failed":
                print(f"  [EVAL ERROR] {key}: {eval_res.get('error')}")

    print(f"\n[OK] All {len(results)} traces evaluated.")

    metrics_summary = [
        (name, f"{METRIC_REGISTRY[name]['result_key']}_status",
               f"{METRIC_REGISTRY[name]['result_key']}_score")
        for name in selected_metrics
    ]

    def _stats(results, status_key, score_key, ok_status="success"):
        successful = [r for r in results if r.get(status_key) == ok_status]
        avg = sum(r.get(score_key) or 0 for r in successful) / max(len(successful), 1)
        return len(successful), len(results) - len(successful), avg

    print("\n" + "=" * 60)
    print("EVALUATION SUMMARY")
    print("=" * 60)
    for label, status_key, score_key in metrics_summary:
        ok, fail, avg = _stats(results, status_key, score_key)
        print(f"\n  {label.upper()}")
        print(f"    Successful: {ok}/{len(results)}  |  Failed: {fail}/{len(results)}  |  Avg Score: {avg:.4f}")

    for result in results:
        if result and "eval_results" in result:
            critique_tasks.append(
                run_critique_for_result(result, critique_llm, output_excel)
            )

    if critique_tasks:
        print(f"\n{'='*60}")
        print("RUNNING UNIVERSAL CRITIQUE JUDGE (Secondary LLM)")
        print(f"{'='*60}")
        critique_results = await asyncio.gather(*critique_tasks, return_exceptions=True)
        ok_c   = sum(1 for r in critique_results if isinstance(r, dict) and r.get("status") == "completed")
        fail_c = len(critique_results) - ok_c
        print(f"  Critiqued: {ok_c}/{len(critique_results)}  |  Failed: {fail_c}")

        token_stats      = get_token_stats()
        secondary_tokens = token_stats.get("per_eval", {}).get("universal_critique_judge", 0)
        if secondary_tokens > 0:
            print(f"  [TOKENS] Secondary LLM (Critique): {secondary_tokens:,} tokens")

    print(f"\n{'='*60}")
    print("GENERATING HTML REPORT")
    print(f"{'='*60}")
    try:
        import pandas as pd
        from report_gen import ReportGenerator

        metrics_df = pd.read_excel(METRICS_TEMPLATE_EXCEL, sheet_name="Metrics Interpretability")
        details_df = pd.read_excel(METRICS_TEMPLATE_EXCEL, sheet_name="Test Data")
        summary_df = pd.read_excel(METRICS_TEMPLATE_EXCEL, sheet_name="Metrics_wise Pass-Fail")
        overall_df = pd.read_excel(METRICS_TEMPLATE_EXCEL, sheet_name="Overall Summary")

        generator    = ReportGenerator()
        html_content = generator.generate_report(metrics_df, details_df, summary_df, overall_df)

        with open(HTML_REPORT_OUTPUT, "w", encoding="utf-8") as f:
            f.write(html_content)
        print(f"  [OK] HTML report generated → {HTML_REPORT_OUTPUT}")

        try:
            from flask import Flask, send_file
            import webbrowser

            _flask_app  = Flask(__name__)
            _html_path  = str(Path(HTML_REPORT_OUTPUT).resolve())
            _flask_port = 5000

            @_flask_app.route("/")
            def _serve_report():
                return send_file(_html_path)

            def _run_flask():
                import logging
                log = logging.getLogger("werkzeug")
                log.setLevel(logging.ERROR)
                _flask_app.run(host="127.0.0.1", port=_flask_port, debug=False, use_reloader=False)

            _server_thread = threading.Thread(target=_run_flask, daemon=True)
            _server_thread.start()
            time.sleep(0.5)

            _url = f"http://127.0.0.1:{_flask_port}"
            print(f"\n  ╔══════════════════════════════════════════╗")
            print(f"  ║  📊 Report live at: {_url}  ║")
            print(f"  ╚══════════════════════════════════════════╝")
            print(f"  Press Ctrl+C to stop the server.\n")
            webbrowser.open(_url)

            try:
                while True:
                    time.sleep(1)
            except KeyboardInterrupt:
                print("\n  [OK] Server stopped.")

        except ImportError:
            print("  [INFO] Flask not installed — open report.html directly.")

    except ImportError:
        print("  [WARN] report_gen.py not found — skipping HTML generation.")
    except Exception as exc:
        print(f"  [ERROR] HTML generation failed: {exc}")

    print(f"\n{'='*60}")
    print("ALL DONE")
    print(f"  Detailed eval data  : {DETAILED_LOG_EXCEL}")
    print(f"  Full eval results   : {output_excel}")
    print(f"  Metrics / Critique  : {METRICS_TEMPLATE_EXCEL}")
    print(f"  HTML Report         : {HTML_REPORT_OUTPUT}")
    print(f"{'='*60}")

    print(f"\n{'='*60}")
    print("TOKEN USAGE SUMMARY")
    print(f"{'='*60}")

    token_stats  = get_token_stats()
    total_tokens = token_stats.get("total", 0)
    per_query    = token_stats.get("per_query", {})
    per_eval     = token_stats.get("per_eval", {})

    print(f"\n  Overall Total: {total_tokens:,} tokens")

    if per_query:
        print(f"\n  Per-Query Breakdown ({len(per_query)} queries):")
        for query, tokens in sorted(per_query.items(), key=lambda x: x[1], reverse=True):
            print(f"    - {query}: {tokens:,} tokens")

    if per_eval:
        print(f"\n  Per-Eval Module Breakdown:")
        for eval_name, tokens in sorted(per_eval.items(), key=lambda x: x[1], reverse=True):
            print(f"    - {eval_name}: {tokens:,} tokens")

    print(f"\n{'='*60}\n")
    return results


# ============================================================
# MAIN ENTRY POINT
# ============================================================
if __name__ == "__main__":
    api_key     = os.getenv("AZURE_OPENAI_API_KEY")
    endpoint    = os.getenv("AZURE_OPENAI_ENDPOINT")
    api_version = os.getenv("AZURE_OPENAI_API_VERSION")
    deployment  = os.getenv("AZURE_OPENAI_LLM_DEPLOYMENT")

    def make_llm(temperature: float) -> AzureChatOpenAI:
        return AzureChatOpenAI(
            openai_api_key=api_key,
            azure_endpoint=endpoint,
            openai_api_version=api_version,
            deployment_name=deployment,
            model="gpt-5",
            temperature=temperature,
        )

    llm_client        = make_llm(temperature=1)
    deterministic_llm = make_llm(temperature=0)
    critique_llm      = make_llm(temperature=1)

    print("[OK] Azure OpenAI clients initialized.")

    try:
        scenarios = load_scenarios_from_excel(INPUT_EXCEL_PATH)
        print(f"[OK] Loaded {len(scenarios)} scenarios from {INPUT_EXCEL_PATH}")
    except FileNotFoundError as exc:
        print(f"[WARN] {exc}")
        scenarios = []

    if scenarios:
        asyncio.run(run_async_evaluation(
            scenarios=scenarios,
            llm_client=llm_client,
            deterministic_llm=deterministic_llm,
            critique_llm=critique_llm,
            semaphore_limit=4,
            output_excel="final_eval_results.xlsx",
        ))
    else:
        print("[ERROR] No scenarios loaded. Please check input_scenarios.xlsx.")