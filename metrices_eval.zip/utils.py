"""
Shared utilities for LangSmith evaluation
"""

import os
import json
from pathlib import Path
from datetime import datetime
from openpyxl import Workbook, load_workbook
from typing import List


def get_or_create_workbook(path: str):
    """Load or create a workbook."""
    if Path(path).exists():
        wb = load_workbook(path)
    else:
        wb = Workbook()
        wb.remove(wb.active)
    return wb


def get_or_create_sheet(wb, sheet_name: str, headers: List[str]):
    """Get or create a sheet in the workbook."""
    if sheet_name in wb.sheetnames:
        sheet = wb[sheet_name]
    else:
        sheet = wb.create_sheet(sheet_name)
        sheet.append(headers)
    return sheet


def get_timestamp():
    """Get current UTC timestamp in ISO format."""
    return datetime.utcnow().isoformat()
