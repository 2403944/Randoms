"""
Parameter Extraction Accuracy Evaluation Module
"""

import os
import json
from datetime import datetime
from langsmith import Client
from langchain_openai import AzureChatOpenAI
from token_tracker import track_tokens_used, count_tokens


# ============================================================
# LANGSMITH HELPERS
# ============================================================
def fetch_spans(trace_id: str):
    """Fetch all spans for a given trace ID from LangSmith."""
    client = Client(api_key=os.environ["LANGSMITH_API_KEY"])
    return list(client.list_runs(trace_id=trace_id))


def find_taskplanner_span(spans):
    """Find the TaskPlanner span in the list of spans."""
    taskplanner_spans = [
        s for s in spans
        if s.run_type == "chain" and s.name == "TaskPlanner"
    ]
    if not taskplanner_spans:
        raise ValueError("No TaskPlanner span found")
    return taskplanner_spans[-1]


# ============================================================
# DATA EXTRACTION
# ============================================================
def extract_user_messages(span):
    """Extract user messages from span inputs."""
    messages = span.inputs.get("messages", [])
    return [
        m.get("content")
        for m in messages
        if m.get("type") == "human"
    ]


def extract_supervisor_extracted_parameters(span):
    """Extract supervisor-extracted parameters from span inputs."""
    messages = span.inputs.get("messages", [])
    try:
        extracted = messages[8].get("content")
    except (IndexError, AttributeError):
        raise ValueError("Expected extracted parameters at messages[8]")
    return extracted


# ============================================================
# AUDIT PROMPT TEMPLATE
# ============================================================
AUDIT_PROMPT_TEMPLATE = r'''
Role:
You are a STRICT Parameter Extraction Evaluation Engine.
You behave deterministically and mechanically.

Goal:
Evaluate extracted parameters using TWO SEQUENTIAL CHECKS.

Inputs:
INPUT_TEXT:
{INPUT_TEXT}

EXTRACTED_PARAMETERS:
{EXTRACTED_PARAMETERS}

EXPECTED_PARAMETER_SCHEMA:
{EXPECTED_PARAMETER_SCHEMA}

------------------------------------------------------------
EVALUATION FRAMEWORK (STRICT GATING LOGIC)
------------------------------------------------------------

You MUST evaluate parameters using EXACTLY TWO checks:

1. value_check
2. format_check

Additionally you MUST output:
- parameter_name
- expected_value  (value grounded from INPUT_TEXT)
- actual_value    (value from EXTRACTED_PARAMETERS)

------------------------------------------------------------
CHECK DEFINITIONS
------------------------------------------------------------

CHECK 1 — value_check

First, extract the EXPECTED VALUE for each parameter directly from INPUT_TEXT.

expected_value MUST:
- Be explicitly grounded in INPUT_TEXT.
- Never be inferred.
- Never be null.
- Reflect normalized enum mapping if applicable.

NORMALIZATION RULE (HIGH PRIORITY):

If EXTRACTED_PARAMETERS contains normalized classifications,
they are valid IF they are grounded in INPUT_TEXT.

Examples:
"normal goods" → Normal
"frozen fish" → Frozen
"glassware" → Fragile
"fresh apples" → Food

Normalization DOES NOT count as hallucination.

value_check = Pass
- If actual_value matches expected_value semantically.

value_check = Fail
- If actual_value contradicts expected_value.
- If actual_value is not grounded.
- If actual_value is fabricated.

CRITICAL GATING RULE:

If value_check = Fail:
- format_check MUST be "Fail"

------------------------------------------------------------

CHECK 2 — format_check

Evaluate ONLY if value_check = Pass.

Use EXPECTED_PARAMETER_SCHEMA for type validation.

Pass:
- actual_value matches schema type.
- If schema type contains "|", treat it as a union — Pass if actual_value matches ANY listed type.
  Example: "number|string" means both 12 and "12kg" are valid format-wise.

Fail:
- Type mismatch with ALL listed types.
- Malformed structure.

Valid types:
- string
- number

------------------------------------------------------------
STRICT RULES
------------------------------------------------------------

- Do NOT infer missing values.
- Do NOT use external knowledge.
- Respect gating rules EXACTLY.
- Every schema parameter MUST appear once in output.
- parameter_name MUST match schema key exactly.
- expected_value MUST come from INPUT_TEXT.
- actual_value MUST come from EXTRACTED_PARAMETERS.
- No extra commentary outside JSON.

------------------------------------------------------------
OUTPUT FORMAT (STRICT JSON ARRAY)
------------------------------------------------------------

[
  {
    "parameter_name": "string",
    "expected_parameter_value": "string",
    "actual_parameter_value": "string",
    "value_check": "Pass | Fail",
    "format_check": "Pass | Fail",
    "reason": "short deterministic explanation"
  }
]

------------------------------------------------------------
FEW SHOT EXAMPLE
------------------------------------------------------------

EXPECTED_PARAMETER_SCHEMA:
{"weight":"number|string"}

INPUT_TEXT:
"Ship 12kg box"

EXTRACTED_PARAMETERS:
{"weight":"12kg"}

Output:
[
  {
    "parameter_name":"weight",
    "expected_parameter_value":"12kg",
    "actual_parameter_value":"12kg",
    "value_check":"Pass",
    "format_check":"Pass",
    "reason":"Value grounded and matches union type number|string."
  }
]
'''

# ============================================================
# SCORING LOGIC
# ============================================================
def compute_score(audit_results: list, expected_schema: dict) -> float:
    """Compute overall score based on audit results."""
    total = len(expected_schema)
    score = 0.0

    for r in audit_results:
        value_check  = r.get("value_check",  "")
        format_check = r.get("format_check", "")

        if value_check == "Pass" and format_check == "Pass":
            score += 1.0
        elif value_check == "Pass" and format_check == "Fail":
            score += 0.5
        # else: 0.0

    return round(score / total, 2) if total else 0.0


# ============================================================
# OVERALL REASON GENERATION
# ============================================================
def generate_overall_reason(audit_results: list, llm_client: AzureChatOpenAI) -> str:
    """Generate an overall summary of the evaluation results."""
    prompt = f'''
Role:
You are a STRICT Evaluation Summary Generator.

Purpose:
Produce a concise structural summary describing grounding behaviour.

CRITICAL:
- Do NOT provide suggestions.
- Do NOT mention format/type issues.
- Describe only grounding (value_check).

audit_results:
{json.dumps(audit_results, indent=2)}

Return ONLY JSON:

{{
  "overall_reason": "1-3 concise factual sentences."
}}
'''
    response = llm_client.invoke(prompt)
    tokens   = count_tokens(response.content)
    track_tokens_used(tokens, eval_name="parameter_extraction")
    return json.loads(response.content).get("overall_reason", "")


# ============================================================
# MAIN EVALUATION PIPELINE
# ============================================================
def run_parameter_extraction_eval(
    trace_id:        str,
    scenario:        str,
    llm_client:      AzureChatOpenAI,
    expected_schema: dict,          # ← required; supplied by main.py from Excel
):
    """
    Run parameter extraction accuracy evaluation for a single trace.

    Args:
        trace_id:        LangSmith trace ID
        scenario:        Query/scenario text
        llm_client:      Azure OpenAI client
        expected_schema: Parameter schema dict read from the Excel
                         'expected_parameters' column. Required — raises
                         ValueError if missing or empty.

    Returns:
        Evaluation result dictionary compatible with main.py
    """
    if not expected_schema:
        raise ValueError(
            f"expected_schema is required for trace '{trace_id}' but was not provided. "
            "Ensure the 'expected_parameters' column is filled in Sheet1."
        )

    try:
        spans            = fetch_spans(trace_id)
        taskplanner_span = find_taskplanner_span(spans)

        user_msgs        = extract_user_messages(taskplanner_span)
        extracted_params = extract_supervisor_extracted_parameters(taskplanner_span)

        prompt = (
            AUDIT_PROMPT_TEMPLATE
            .replace("{INPUT_TEXT}",                json.dumps(user_msgs, indent=2))
            .replace("{EXTRACTED_PARAMETERS}",      extracted_params)
            .replace("{EXPECTED_PARAMETER_SCHEMA}", json.dumps(expected_schema, indent=2))
        )

        llm_response = llm_client.invoke(prompt)
        tokens       = count_tokens(llm_response.content)
        track_tokens_used(tokens, eval_name="parameter_extraction")

        audit_results  = json.loads(llm_response.content)
        score          = compute_score(audit_results, expected_schema)
        overall_reason = generate_overall_reason(audit_results, llm_client)

        return {
            "eval_name":   "parameter_extraction_accuracy",
            "trace_id":    trace_id,
            "scenario":    scenario,
            "eval_prompt": prompt,
            "eval_inputs": {
                "input_text":           user_msgs,
                "extracted_parameters": extracted_params,
                "expected_schema":      expected_schema,
            },
            "eval_output": {
                "audit_results":  audit_results,
                "score":          score,
                "overall_reason": overall_reason,
            },
            "score":          score,
            "overall_reason": overall_reason,
            "metadata": {
                "model":       "gpt-5",
                "temperature": 1,
                "timestamp":   datetime.utcnow().isoformat(),
            },
            "status": "success",
            "error":  None,
        }

    except Exception as e:
        return {
            "eval_name":      "parameter_extraction_accuracy",
            "trace_id":       trace_id,
            "scenario":       scenario,
            "status":         "failed",
            "error":          str(e),
            "eval_output":    {},
            "score":          None,
            "overall_reason": None,
            "metadata": {
                "timestamp": datetime.utcnow().isoformat(),
            },
        }


# ============================================================
# EXCEL STORAGE
# ============================================================
from openpyxl import Workbook, load_workbook
from pathlib import Path

SHEET_NAME_PEA = "Parameter Extraction Accuracy"

HEADERS_PEA = [
    "Query",
    "Parameter Name",
    "Expected Parameter Value",
    "Actual Parameter Value",
    "Value Check",
    "Format Check",
    "Reason",
    "Overall Score",
    "Overall Reason",
]


def get_or_create_workbook_pea(path: str):
    if Path(path).exists():
        wb = load_workbook(path)
    else:
        wb = Workbook()
        wb.remove(wb.active)
    return wb


def get_or_create_sheet_PEA(wb, sheet_name: str):
    if sheet_name in wb.sheetnames:
        return wb[sheet_name]
    sheet = wb.create_sheet(sheet_name)
    sheet.append(HEADERS_PEA)
    return sheet


def dump_parameter_eval_to_excel(
    *,
    trace_id:    str,
    query:       str,
    eval_result: dict,
    excel_path:  str = "final_eval_results.xlsx",
):
    wb    = get_or_create_workbook_pea(excel_path)
    sheet = get_or_create_sheet_PEA(wb, SHEET_NAME_PEA)

    eval_output    = eval_result.get("eval_output", {})
    parameters     = eval_output.get("audit_results", [])
    overall_score  = eval_output.get("score")
    overall_reason = eval_output.get("overall_reason", "")

    for param in parameters:
        sheet.append([
            query,
            param.get("parameter_name"),
            param.get("expected_parameter_value"),
            param.get("actual_parameter_value"),
            param.get("value_check"),
            param.get("format_check"),
            param.get("reason"),
            overall_score,
            overall_reason,
        ])

    wb.save(excel_path)