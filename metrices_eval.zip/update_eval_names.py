"""
Script to update eval names in final_eval_results_withoutWeight.xlsx
Maps internal eval names to display names
"""

from openpyxl import load_workbook
from pathlib import Path

# Mapping of old names to new display names
eval_name_mapping = {
    "parameter_extraction_accuracy": "Parameter Extraction Accuracy",
    "tool_call_accuracy": "Tool Call Accuracy",
    "trajectory_match": "Trajectory",
    "refusal_detection": "Refusal",
    "supervisor_plan_accuracy": "Plan Accuracy",
    "summary_accuracy": "Output vs Context Accuracy",
    "hallucination_cove": "Hallucination Cove",
    "agent_goal_accomplishment": "Goal Accomplishment",
    "context_filter_accuracy": "Context Filter accuracy",
    "helpfulness": "Helpfulness",
    "coherence": "Coherence",
    "convergence": "Convergence",
    "output_format_compliance": "Output format Check",
    "confidence_score_accuracy": "Confidence score accuracy",
    "tool_call_error_detection": "Tool Call Error",
    "recovery_loop_eval": "Recovery Loop",
}

# File to update
excel_file = "final_eval_results_withoutWeight.xlsx"

if not Path(excel_file).exists():
    print(f"File not found: {excel_file}")
    exit(1)

print(f"Opening {excel_file}...")
wb = load_workbook(excel_file)

# Iterate through all sheets
for sheet_name in wb.sheetnames:
    print(f"\nProcessing sheet: {sheet_name}")
    ws = wb[sheet_name]
    
    # Check first column for old eval names
    updated_count = 0
    for row_idx in range(1, ws.max_row + 1):
        cell_value = ws.cell(row_idx, 1).value
        
        # Check if this cell contains an old eval name
        if cell_value in eval_name_mapping:
            new_name = eval_name_mapping[cell_value]
            ws.cell(row_idx, 1).value = new_name
            updated_count += 1
            print(f"  Row {row_idx}: {cell_value} → {new_name}")
    
    if updated_count > 0:
        print(f"  Updated {updated_count} eval names in sheet '{sheet_name}'")

# Save the updated workbook
print(f"\nSaving {excel_file}...")
wb.save(excel_file)
print(f"✓ Done! All eval names updated.")
