"""
Knowledge Retention Eval — Pure prompt-based, no DeepEval dependency.

Replicates DeepEval's KnowledgeRetentionMetric logic exactly:
  - Builds a cumulative snapshot per ASSISTANT turn (same isolation as DeepEval)
  - Extracts USER-introduced facts visible only up to each turn
  - Checks each ASSISTANT turn for attritions (forgetting / contradicting)
  - Score = assistant turns WITHOUT attritions / total assistant turns

All in ONE LLM call per trace — no asyncio, no ThreadPoolExecutor, no deadlock.

Run standalone:
    python knowledge_retention_eval.py
"""

import json
import os
import time
import random
import threading
from datetime import datetime
from pathlib import Path


# ============================================================
# CONVERSATION EXTRACTOR  (original filtering logic unchanged)
# ============================================================

def extract_cumulative_turns_from_run(
    run_id: str,
    max_retries: int = 5,
    assistant_name: str = "Supervisor",
) -> list[dict]:
    """
    Extracts filtered + deduplicated conversation messages from the
    Supervisor child run.

    Returns a flat list of {"role": "USER"|"ASSISTANT", "content": str}.
    """
    from langsmith import Client

    client     = Client()
    child_runs = None

    for attempt in range(max_retries):
        try:
            child_runs = list(client.list_runs(parent_run_id=run_id))
            break
        except Exception as e:
            if "429" in str(e) and attempt < max_retries - 1:
                wait = (2 ** attempt) + random.uniform(0, 1)
                print(f"  [KR] LangSmith 429 — retrying in {wait:.1f}s "
                      f"(attempt {attempt + 1}/{max_retries})...")
                time.sleep(wait)
            else:
                raise

    if child_runs is None:
        raise RuntimeError(
            f"Failed to fetch child runs for trace {run_id} "
            f"after {max_retries} attempts"
        )

    supervisor_run = None
    max_msgs       = 0

    for run in child_runs:
        if run.name == "Supervisor":
            msgs = run.inputs.get("messages", [])
            if len(msgs) > max_msgs:
                max_msgs       = len(msgs)
                supervisor_run = run

    if not supervisor_run:
        raise ValueError("No Supervisor child run found")

    messages = supervisor_run.inputs.get("messages", [])

    filtered = []
    seen_ids = set()

    for msg in messages:
        msg_id   = msg.get("id")
        msg_type = msg.get("type")
        msg_name = msg.get("name", "")
        content  = msg.get("content", "")

        if msg_id and msg_id in seen_ids:
            continue
        if msg_id:
            seen_ids.add(msg_id)

        if msg_type == "human" and msg_name == "user":
            filtered.append({"role": "USER", "content": content.strip()})
        elif msg_type == "ai" and msg_name == assistant_name:
            filtered.append({"role": "ASSISTANT", "content": content.strip()})

    groups = []
    i      = 0

    while i < len(filtered):
        if filtered[i]["role"] == "USER":
            group = [filtered[i]]
            i += 1
            while i < len(filtered) and filtered[i]["role"] == "ASSISTANT":
                group.append(filtered[i])
                i += 1
            groups.append(group)
        else:
            i += 1

    conversation = []
    for group in groups:
        conversation.extend(group)

    return conversation


# ============================================================
# CUMULATIVE SNAPSHOT BUILDER
# ============================================================

def _build_cumulative_snapshots(conversation: list[dict]) -> list[dict]:
    """
    For each ASSISTANT turn, builds:
      - snapshot           : full [USER]/[ASSISTANT TURN N] formatted text (used in LLM prompt)
      - conversation_history: plain HUMAN:/AI: text of all messages BEFORE this turn
      - target_turn        : this ASSISTANT turn's content

    Returns a list of dicts per ASSISTANT turn.
    """
    snapshots   = []
    asst_turn_n = 0
    history     = []

    for msg in conversation:
        history.append(msg)
        if msg["role"] == "ASSISTANT":
            asst_turn_n += 1

            # Full snapshot for LLM prompt (original format preserved)
            snapshot_lines = []
            seen_asst      = 0
            for m in history:
                if m["role"] == "USER":
                    snapshot_lines.append(f"[USER]\n{m['content']}")
                else:
                    seen_asst += 1
                    if m is msg:
                        snapshot_lines.append(
                            f"[ASSISTANT TURN {asst_turn_n}]\n{m['content']}"
                        )
                    else:
                        snapshot_lines.append(
                            f"[ASSISTANT TURN {seen_asst}]\n{m['content']}"
                        )
            snapshot_text = "\n\n".join(snapshot_lines)

            # Plain-text conversation history (all messages BEFORE this turn)
            # — same HUMAN:/AI: format used by helpfulness eval_input
            prior_messages = history[:-1]  # exclude current ASSISTANT turn
            history_lines  = []
            for m in prior_messages:
                prefix = "HUMAN" if m["role"] == "USER" else "AI"
                history_lines.append(f"{prefix}: {m['content']}")
            conversation_history = "\n".join(history_lines) if history_lines else "(No prior context)"

            # USER facts visible at this point (for LLM prompt)
            user_msgs = [m for m in history if m["role"] == "USER"]
            user_facts_text = "\n\n".join(
                f"USER message {i + 1}: {m['content']}"
                for i, m in enumerate(user_msgs)
            )

            snapshots.append({
                "asst_turn_index":      asst_turn_n,
                "snapshot":             snapshot_text,
                "conversation_history": conversation_history,
                "target_turn":          msg["content"],
                "user_facts_visible":   user_facts_text,
            })

    return snapshots


# ============================================================
# PROMPT BUILDER
# ============================================================

def _build_prompt(scenario: str, conversation: list[dict]) -> str:
    snapshots   = _build_cumulative_snapshots(conversation)
    total_turns = len(snapshots)

    turn_blocks = ""
    for s in snapshots:
        turn_blocks += f"""
---
SNAPSHOT FOR ASSISTANT TURN {s['asst_turn_index']} (evaluate in complete isolation):

Conversation up to this point:
{s['snapshot']}

USER facts visible at this point (ONLY these facts existed when this ASSISTANT turn was produced):
{s['user_facts_visible']}
---
"""

    return f"""You are an expert evaluator measuring Knowledge Retention in a multi-turn AI conversation.

## What is Knowledge Retention?
Knowledge Retention measures whether the ASSISTANT correctly remembers and applies facts,
preferences, constraints, names, numbers, and dates that the USER introduced in earlier turns.

## Scoring Formula (replicate exactly)
Knowledge Retention Score = Number of ASSISTANT turns WITHOUT attritions / Total ASSISTANT turns
Total ASSISTANT turns = {total_turns}

An **attrition** occurs in an ASSISTANT turn when it:
- Forgets a fact the USER previously stated (e.g. wrong item name, wrong weight)
- Contradicts a fact the USER previously stated
- Re-asks for information the USER already provided

Silence about a fact is NOT an attrition. Only active forgetting or contradiction counts.

## CRITICAL INSTRUCTION — Evaluate each turn in STRICT ISOLATION
For each ASSISTANT turn below you are given ONLY the conversation snapshot up to that turn
and ONLY the USER facts that existed at that point. You MUST:
- Use ONLY the USER facts listed for that snapshot when judging that turn
- NEVER use facts from later turns to judge earlier turns
- Treat each snapshot as if you have no knowledge of what comes after it

## Scenario
{scenario}

## Per-turn evaluation snapshots
{turn_blocks}

## Output format
Respond ONLY with valid JSON, no markdown, no preamble:
{{
  "per_turn": [
    {{
      "turn_index": <ASSISTANT turn number, 1-based>,
      "facts_extracted": ["<each USER fact visible at this turn>"],
      "attrition": <true if this turn forgets or contradicts a fact, false otherwise>,
      "score": <1.0 if attrition=false, 0.0 if attrition=true>,
      "attritions_found": ["<description of each forgotten/contradicted fact — empty list if none>"],
      "reason": "<one sentence explaining the verdict for this turn>"
    }}
  ],
  "overall_score": <float = turns_without_attrition / {total_turns}, rounded to 4 decimal places>,
  "overall_reason": "<concise summary of retention patterns across the full conversation>"
}}"""


# ============================================================
# MAIN EVAL FUNCTION
# ============================================================

def run_knowledge_retention_eval(
    trace_id: str,
    scenario: str,
    llm_client,
    *,
    assistant_name: str = "Supervisor",
    max_retries: int = 5,
) -> dict:
    """
    Evaluates knowledge retention using a single LLM call that replicates
    DeepEval's KnowledgeRetentionMetric two-step logic.
    """
    try:
        # ── 1. Fetch and filter conversation ──────────────────────────
        conversation = extract_cumulative_turns_from_run(
            trace_id,
            max_retries=max_retries,
            assistant_name=assistant_name,
        )

        if not conversation:
            raise ValueError("No USER/ASSISTANT messages found in Supervisor run.")

        asst_turns = [m for m in conversation if m["role"] == "ASSISTANT"]
        print(f"  [KR] Trace {trace_id}: {len(conversation)} messages, "
              f"{len(asst_turns)} ASSISTANT turns to evaluate.")

        # ── 2. Build cumulative snapshots + prompt ─────────────────────
        snapshots = _build_cumulative_snapshots(conversation)
        prompt    = _build_prompt(scenario, conversation)

        # ── 3. Single LLM call with retry on Azure 429 ────────────────
        response = None
        for attempt in range(max_retries):
            try:
                response = llm_client.invoke(prompt)
                break
            except Exception as e:
                if "429" in str(e) and attempt < max_retries - 1:
                    wait = (2 ** attempt) + random.uniform(0, 1)
                    print(f"  [KR] Azure 429 — retrying in {wait:.1f}s "
                          f"(attempt {attempt + 1}/{max_retries})...")
                    time.sleep(wait)
                else:
                    raise

        raw_text = response.content if hasattr(response, "content") else str(response)

        # ── 4. Parse JSON ──────────────────────────────────────────────
        clean = raw_text.strip()
        if clean.startswith("```"):
            parts = clean.split("```")
            clean = parts[1] if len(parts) > 1 else clean
            if clean.startswith("json"):
                clean = clean[4:]
        clean  = clean.strip()
        parsed = json.loads(clean)

        # ── 5. Validate, normalise and attach per-turn eval_inputs ────
        snapshot_map = {s["asst_turn_index"]: s for s in snapshots}

        per_turn = parsed.get("per_turn", [])
        for t in per_turn:
            if "score" in t:
                t["score"] = round(max(0.0, min(1.0, float(t["score"]))), 4)
            s = snapshot_map.get(t.get("turn_index"), {})
            t["conversation_history"] = s.get("conversation_history", "")
            t["target_turn"]          = s.get("target_turn", "")

        overall_score  = round(
            max(0.0, min(1.0, float(parsed.get("overall_score", 0.0)))), 4
        )
        overall_reason = parsed.get("overall_reason", "")

        for t in per_turn:
            flag = "ATTRITION" if t.get("attrition") else "OK"
            print(f"  [KR] Turn {t['turn_index']:>2} | {flag:>9} | "
                  f"Score: {t.get('score', 'N/A')} | {t.get('reason', '')[:80]}")
        print(f"  [KR] Overall Score: {overall_score} | {overall_reason[:100]}")

        return {
            "eval_name":  "knowledge_retention_turnwise",
            "eval_type":  "multi_turn_conversational_memory",
            "trace_id":   trace_id,
            "status":     "success",
            "score":      overall_score,
            "eval_prompt": prompt,
            "eval_inputs": {
                "scenario":     scenario,
                "conversation": conversation,
            },
            "eval_output": per_turn,
            "overall_output": {
                "overall_score":     overall_score,
                "overall_reasoning": overall_reason,
            },
            "overall_reason": overall_reason,
            "metadata": {
                "model":            "gpt-5",
                "temperature":      1,
                "total_messages":   len(conversation),
                "total_asst_turns": len(asst_turns),
                "assistant_name":   assistant_name,
                "facts_identified": parsed.get("facts_identified", []),
                "timestamp":        datetime.utcnow().isoformat(),
            },
        }

    except Exception as e:
        print(f"  [KR] FAILED for trace {trace_id}: {e}")
        return {
            "eval_name": "knowledge_retention_turnwise",
            "eval_type": "multi_turn_conversational_memory",
            "trace_id":  trace_id,
            "status":    "failed",
            "error":     str(e),
            "overall_output": {
                "overall_score":     None,
                "overall_reasoning": str(e),
            },
        }


# ============================================================
# EXCEL HELPERS
# ============================================================

def clear_knowledge_retention_sheet(excel_path: str = "final_eval_results.xlsx"):
    """
    Wipes all data rows from the 'Knowledge Retention' sheet,
    keeping the header row intact. Creates the file/sheet if absent.
    Call this ONCE before starting any parallel trace evaluation.
    """
    from utils import get_or_create_workbook, get_or_create_sheet

    SHEET_NAME = "Knowledge Retention"
    HEADERS = [
        "Query", "Turn_Index", "Turn_Score", "Turn_Reasoning",
        "Overall_Score", "Overall_Reasoning", "Eval_Input", "Eval_Output", "Status",
    ]

    wb = get_or_create_workbook(excel_path)
    ws = get_or_create_sheet(wb, SHEET_NAME, HEADERS)

    # Delete every row below the header (row 2 onwards)
    if ws.max_row > 1:
        ws.delete_rows(2, ws.max_row)

    wb.save(excel_path)
    print(f"[KR] Cleared existing data from '{SHEET_NAME}' sheet in {excel_path}")


# ============================================================
# EXCEL DUMP — Eval_Input / Eval_Output match helpfulness format
# ============================================================

def dump_knowledge_retention_eval_to_excel(
    *,
    trace_id: str,
    query: str,
    eval_result: dict,
    excel_path: str = "final_eval_results.xlsx",
):
    """
    Writes to the 'Knowledge Retention' sheet.

    Columns:
        Query | Turn_Index | Turn_Score | Turn_Reasoning |
        Overall_Score | Overall_Reasoning | Eval_Input | Eval_Output | Status

    Eval_Input  → plain HUMAN:/AI: conversation text + target turn  (same as helpfulness)
    Eval_Output → JSON {"score": ..., "reason": ..., "attrition": ...,
                        "attritions_found": [...], "facts_extracted": [...]}
    """
    try:
        from utils import get_or_create_workbook, get_or_create_sheet

        SHEET_NAME = "Knowledge Retention"
        HEADERS    = [
            "Query",
            "Turn_Index",
            "Turn_Score",
            "Turn_Reasoning",
            "Overall_Score",
            "Overall_Reasoning",
            "Eval_Input",
            "Eval_Output",
            "Status",
        ]

        wb = get_or_create_workbook(excel_path)
        ws = get_or_create_sheet(wb, SHEET_NAME, HEADERS)

        status = eval_result.get("status", "failed")

        # ── Failed trace → single error row ───────────────────────────
        if status == "failed":
            ws.append([
                query, "", "",
                eval_result.get("error", "Unknown error"),
                "", "", "", "", "failed",
            ])
            wb.save(excel_path)
            print(f"  [KR] Saved failure row to '{SHEET_NAME}'")
            return

        # ── Successful trace → one row per ASSISTANT turn ─────────────
        oo             = eval_result.get("overall_output", {})
        overall_score  = oo.get("overall_score", "")
        overall_reason = oo.get("overall_reasoning", "")
        per_turn       = eval_result.get("eval_output", [])

        for i, t in enumerate(per_turn):
            score      = t.get("score")
            attritions = t.get("attritions_found", [])
            reason     = t.get("reason", "")
            if attritions:
                reason = reason + " | Attritions: " + "; ".join(attritions)

            # ── Eval_Input: plain HUMAN:/AI: text (matches helpfulness) ──
            history_text = t.get("conversation_history", "")
            target_text  = t.get("target_turn", "")
            if history_text and history_text != "(No prior context)":
                eval_input_text = history_text + "\nAI: " + target_text
            else:
                eval_input_text = "AI: " + target_text

            # ── Eval_Output: JSON verdict (matches helpfulness style) ─────
            eval_output_text = json.dumps({
                "score":            score,
                "reason":           t.get("reason", ""),
                "attrition":        t.get("attrition"),
                "attritions_found": t.get("attritions_found", []),
                "facts_extracted":  t.get("facts_extracted", []),
            }, indent=2)

            ws.append([
                query,
                t.get("turn_index", ""),
                score if score is not None else "N/A",
                reason,
                overall_score  if i == 0 else "", # Overall_Score — first row only
                overall_reason if i == 0 else "", # Overall_Reasoning — first row only
                eval_input_text,
                eval_output_text,
                "success" if i == 0 else "",      # Status — first row only
            ])

        wb.save(excel_path)
        print(f"  [KR] Saved {len(per_turn)} turn row(s) to '{SHEET_NAME}'")

    except Exception as exc:
        print(f"  [KR] Excel dump failed: {exc}")


# # ============================================================
# # STANDALONE ENTRY POINT
# # Run with: python knowledge_retention_eval.py
# # ============================================================

# if __name__ == "__main__":
#     from concurrent.futures import ThreadPoolExecutor, as_completed
#     from dotenv import load_dotenv
#     from openpyxl import load_workbook
#     from langchain_openai import AzureChatOpenAI

#     load_dotenv()

#     INPUT_EXCEL_PATH = "input_scenarios.xlsx"
#     OUTPUT_EXCEL     = "final_eval_results.xlsx"
#     INPUT_SHEET      = "Sheet1"
#     MAX_PARALLEL     = 4
#     ASSISTANT_NAME   = "Supervisor"

#     os.environ["LANGSMITH_API_KEY"] = os.getenv("LANGSMITH_API_KEY")

#     # ── Load scenarios ─────────────────────────────────────────────────
#     if not Path(INPUT_EXCEL_PATH).exists():
#         print(f"[ERROR] {INPUT_EXCEL_PATH} not found.")
#         raise SystemExit(1)

#     wb    = load_workbook(INPUT_EXCEL_PATH)
#     sheet = wb[INPUT_SHEET]
#     scenarios = [
#         {"trace_id": str(row[0]), "scenario": str(row[1])}
#         for row in sheet.iter_rows(min_row=2, values_only=True)
#         if row[0] and row[1]
#     ]
#     print(f"[KR] Loaded {len(scenarios)} scenarios from {INPUT_EXCEL_PATH}")

#     # ── Build LLM client ───────────────────────────────────────────────
#     llm_client = AzureChatOpenAI(
#         openai_api_key=os.getenv("AZURE_OPENAI_API_KEY"),
#         azure_endpoint=os.getenv("AZURE_OPENAI_ENDPOINT"),
#         openai_api_version=os.getenv("AZURE_OPENAI_API_VERSION"),
#         deployment_name=os.getenv("AZURE_OPENAI_LLM_DEPLOYMENT"),
#         model="gpt-5",
#         temperature=1,
#     )
#     print("[KR] LLM client initialized.")

#     # ── Write lock for Excel (concurrent dumps) ────────────────────────
#     _excel_lock = threading.Lock()

#     # ── Clear sheet ONCE before any parallel writes ────────────────────
#     clear_knowledge_retention_sheet(OUTPUT_EXCEL)

#     def _run_one(scenario_data: dict) -> dict:
#         trace_id = scenario_data["trace_id"]
#         scenario = scenario_data["scenario"]
#         print(f"\n[KR] Starting trace: {trace_id}")

#         result = run_knowledge_retention_eval(
#             trace_id, scenario, llm_client,
#             assistant_name=ASSISTANT_NAME,
#         )

#         with _excel_lock:
#             dump_knowledge_retention_eval_to_excel(
#                 trace_id=trace_id,
#                 query=scenario,
#                 eval_result=result,
#                 excel_path=OUTPUT_EXCEL,
#             )
#         return result

#     # ── Run all traces in parallel ─────────────────────────────────────
#     print(f"\n[KR] Running {len(scenarios)} traces "
#           f"(MAX_PARALLEL={MAX_PARALLEL}) → {OUTPUT_EXCEL}\n"
#           f"[KR] Each trace = 1 LLM call (no DeepEval, no asyncio deadlock)\n")

#     results = []
#     with ThreadPoolExecutor(max_workers=MAX_PARALLEL) as executor:
#         futures = {executor.submit(_run_one, s): s for s in scenarios}
#         for future in as_completed(futures):
#             try:
#                 result = future.result()
#                 results.append(result)
#                 score  = (result.get("overall_output") or {}).get("overall_score", "N/A")
#                 status = result.get("status", "unknown")
#                 print(f"\n  [KR] ✓ Trace done — status={status}, overall_score={score}")
#             except Exception as exc:
#                 print(f"\n  [KR] ✗ ERROR: {exc}")

#     # ── Summary ────────────────────────────────────────────────────────
#     ok   = sum(1 for r in results if r.get("status") == "success")
#     fail = len(results) - ok
#     scores = [
#         r["overall_output"]["overall_score"]
#         for r in results
#         if r.get("status") == "success"
#         and r.get("overall_output", {}).get("overall_score") is not None
#     ]
#     avg = round(sum(scores) / len(scores), 4) if scores else "N/A"

#     print(f"\n{'='*60}")
#     print("KNOWLEDGE RETENTION COMPLETE")
#     print(f"  Success      : {ok}/{len(results)}")
#     print(f"  Failed       : {fail}/{len(results)}")
#     print(f"  Average Score: {avg}")
#     print(f"  Output       : {OUTPUT_EXCEL} → 'Knowledge Retention' sheet")
#     print(f"{'='*60}")