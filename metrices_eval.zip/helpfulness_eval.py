from langsmith import Client
from langchain_openai import AzureChatOpenAI
import os
import json
import time
import random
from datetime import datetime


os.environ["LANGSMITH_API_KEY"] = "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"

client = Client(api_key=os.environ["LANGSMITH_API_KEY"])


# ============================================================
# EXTRACT MESSAGES — mirrors knowledge_retention pattern exactly
# ============================================================

def extract_conversation_from_run(
    run_id: str,
    max_retries: int = 5,
    assistant_name: str = "Supervisor",
) -> list:
    """
    Extracts filtered + deduplicated conversation messages from the
    Supervisor child run (largest message list), identical to the
    knowledge_retention extraction logic.

    Adds:
      - 429 retry with exponential back-off (same as KR)
      - USER→ASSISTANT grouping pass (same as KR)
      - Parameterised assistant_name instead of hardcoded "Supervisor"

    Returns a flat list of {"role": "human"/"ai", "content": "..."}
    """
    langsmith_client = Client()
    child_runs = None

    # ── Retry on LangSmith 429 ────────────────────────────────────────
    for attempt in range(max_retries):
        try:
            child_runs = list(langsmith_client.list_runs(parent_run_id=run_id))
            break
        except Exception as e:
            if "429" in str(e) and attempt < max_retries - 1:
                wait = (2 ** attempt) + random.uniform(0, 1)
                print(f"  [HE] LangSmith 429 — retrying in {wait:.1f}s "
                      f"(attempt {attempt + 1}/{max_retries})...")
                time.sleep(wait)
            else:
                raise

    if child_runs is None:
        raise RuntimeError(
            f"Failed to fetch child runs for trace {run_id} "
            f"after {max_retries} attempts"
        )

    # ── Pick Supervisor run with the most messages ────────────────────
    supervisor_run = None
    max_msgs = 0

    for run in child_runs:
        if run.name == "Supervisor":
            msgs = run.inputs.get("messages", [])
            if len(msgs) > max_msgs:
                max_msgs = len(msgs)
                supervisor_run = run

    if not supervisor_run:
        raise ValueError("No Supervisor child run found")

    messages = supervisor_run.inputs.get("messages", [])

    # ── Filter + deduplicate (identical to KR) ────────────────────────
    # Only keep:
    #   type="human", name="user"          → role "human"
    #   type="ai",    name=assistant_name  → role "ai"
    filtered = []
    seen_ids = set()

    for msg in messages:
        msg_id   = msg.get("id")
        msg_type = msg.get("type")
        msg_name = msg.get("name", "")
        content  = msg.get("content", "")

        if msg_id and msg_id in seen_ids:
            continue
        if msg_id:
            seen_ids.add(msg_id)

        if msg_type == "human" and msg_name == "user":
            filtered.append({"role": "human", "content": content.strip()})
        elif msg_type == "ai" and msg_name == assistant_name:
            filtered.append({"role": "ai", "content": content.strip()})

    # ── USER→ASSISTANT grouping pass (identical to KR) ───────────────
    # Ensures each USER turn is followed by its ASSISTANT response(s)
    # before the next USER turn, preserving correct turn ordering.
    groups = []
    i = 0

    while i < len(filtered):
        if filtered[i]["role"] == "human":
            group = [filtered[i]]
            i += 1
            while i < len(filtered) and filtered[i]["role"] == "ai":
                group.append(filtered[i])
                i += 1
            groups.append(group)
        else:
            i += 1

    conversation = []
    for group in groups:
        conversation.extend(group)

    if len(conversation) < 2:
        raise ValueError("Not enough conversation turns after filtering")

    return conversation


# ============================================================
# BUILD EVALUATION WINDOWS (turn-wise splitting)
# ============================================================

def build_eval_windows(conversation: list) -> list:
    """
    For each AI turn, builds:
      - context_turns : all messages BEFORE that AI turn
      - target_turn   : the AI turn's content

    Produces one window per AI turn, in order.
    """
    windows = []

    for i, turn in enumerate(conversation):
        if turn["role"] == "ai":
            context_turns = conversation[:i]
            target_turn   = turn["content"]
            windows.append((context_turns, target_turn))

    return windows


# ============================================================
# SCORE MAP
# ============================================================

SCORE_TO_OVERALL = {
    "Not Helpful At All": 0.0,
    "Very Unhelpful": 0.2,
    "Somewhat Unhelpful": 0.4,
    "Neutral/Mixed": 0.5,
    "Somewhat Helpful": 0.7,
    "Very Helpful": 0.9,
    "Above And Beyond": 1.0,
}

OVERALL_LABEL_THRESHOLDS = [
    (0.9,  "Above And Beyond"),
    (0.8,  "Very Helpful"),
    (0.6,  "Somewhat Helpful"),
    (0.5,  "Neutral/Mixed"),
    (0.3,  "Somewhat Unhelpful"),
    (0.1,  "Very Unhelpful"),
    (0.0,  "Not Helpful At All"),
]

def score_to_label(score):
    for threshold, label in OVERALL_LABEL_THRESHOLDS:
        if score >= threshold:
            return label
    return "Not Helpful At All"


# ============================================================
# PROMPT BUILDER
# ============================================================

EVAL_PROMPT = """
You are an objective judge evaluating the helpfulness of an AI assistant's response from the user's perspective. Your task is to assess whether the assistant's turn moves the user closer to achieving or formulating their goals.

IMPORTANT: Evaluate purely from the user's perspective, without considering the factual accuracy or backend operations. Focus only on how the response helps the user progress towards their goals.

**IMPORTANT**:
Base your evaluation strictly on the provided conversation context and target turn.
Do not introduce external facts or assumptions beyond the given inputs.

Infer the user's goals purely based on the user's initial request, and any additional context they may provide afterwards.

# Conversation Context:
## Previous turns:
<<context_text>>

## Target turn to evaluate:
<<target_turn>>

# Evaluation Guidelines:
Rate the helpfulness of the assistant's turn using this scale:

0. Not Helpful At All
- Gibberish or nonsense
- Actively obstructs goal progress
- Leads user down wrong path

1. Very Unhelpful
- Creates confusion or misunderstanding

2. Somewhat Unhelpful
- Delays goal progress
- Provides irrelevant information
- Makes unnecessary detours

3. Neutral/Mixed
- Has no impact on goal progress
- Appropriate chit-chat for conversation flow
- Contains mix of helpful and unhelpful elements that cancel out

4. Somewhat Helpful
- Moves user one step towards goal
- Provides relevant information
- Clarifies user's needs or situation

5. Very Helpful
- Moves user multiple steps towards goal
- Provides comprehensive, actionable information
- Significantly advances goal understanding or formation

6. Above And Beyond
- The response is Very Helpful and feedback about user input quality issues or content limitations are insightful and get the user as close as possible to their goal given the input's limitations
- The response is Very Helpful and it anticipates and addresses general user concerns.

The output should be a well-formatted JSON instance that conforms to the JSON schema below.

As an example, for the schema {"properties": {"foo": {"title": "Foo", "description": "a list of strings", "type": "array", "items": {"type": "string"}}}, "required": ["foo"]}
the object {"foo": ["bar", "baz"]} is a well-formatted instance of the schema. The object {"properties": {"foo": ["bar", "baz"]}} is not well-formatted.

Here is the output JSON schema:
```
{"properties": {"reasoning": {"description": "step by step reasoning to derive the final score, using no more than 250 words", "title": "Reasoning", "type": "string"}, "score": {"description": "score should be one of 'Not Helpful At All', 'Very Unhelpful', 'Somewhat Unhelpful', 'Neutral/Mixed', 'Somewhat Helpful', 'Very Helpful' or 'Above And Beyond'", "enum": ["Not Helpful At All", "Very Unhelpful", "Somewhat Unhelpful", "Neutral/Mixed", "Somewhat Helpful", "Very Helpful", "Above And Beyond"], "title": "Score", "type": "string"}}, "required": ["reasoning", "score"]}
```

Do not return any preamble or explanations, return only a pure JSON string surrounded by triple backticks (```).
"""


def build_eval_prompt(context_turns, target_turn):
    context_text = "\n".join(
        f"{'User' if turn['role'] == 'human' else 'AI'}: {turn['content']}"
        for turn in context_turns
    ) if context_turns else "(No prior context)"

    return (
        EVAL_PROMPT
        .replace("<<context_text>>", context_text)
        .replace("<<target_turn>>", target_turn)
    )


def parse_llm_json(raw_output):
    raw_output = raw_output.strip()
    if raw_output.startswith("```"):
        raw_output = raw_output.strip("`").strip()
        if raw_output.lower().startswith("json"):
            raw_output = raw_output[4:].strip()
    decoder = json.JSONDecoder()
    result, index = decoder.raw_decode(raw_output.strip())
    remaining = raw_output[index:].strip()
    if remaining:
        print("Warning: Extra trailing content detected and ignored.")
    return result


# ============================================================
# RUN HELPFULNESS EVAL
# ============================================================

def run_helpfulness_eval(trace_id: str, scenario: str, llm_client) -> dict:
    """
    Run helpfulness evaluation on a trace.

    Args:
        trace_id: LangSmith trace ID
        scenario: The query/scenario string
        llm_client: Azure OpenAI client

    Returns:
        dict with evaluation results
    """
    try:
        conversation = extract_conversation_from_run(trace_id)

        print(f"Total conversation turns extracted: {len(conversation)}")
        for i, msg in enumerate(conversation, start=1):
            print(f"  [{i}] {msg['role'].upper()}: {msg['content'][:80]}...")

        eval_windows = build_eval_windows(conversation)

        if not eval_windows:
            raise ValueError("No evaluatable AI turns found")

        print(f"Total evaluation windows: {len(eval_windows)}")

        # ============================================================
        # RUN TURN-LEVEL EVALUATIONS
        # ============================================================

        all_eval_results = []

        for eval_index, (context_turns, target_turn) in enumerate(eval_windows, start=1):

            print("\n" + "=" * 80)
            print(f"Running Evaluation {eval_index}/{len(eval_windows)}")

            eval_prompt = build_eval_prompt(context_turns, target_turn)
            context_text = "\n".join(
                f"{'User' if t['role'] == 'human' else 'AI'}: {t['content']}" for t in context_turns
            ) if context_turns else "(No prior context)"

            response = llm_client.invoke(eval_prompt)

            try:
                result = parse_llm_json(response.content)
            except (json.JSONDecodeError, ValueError):
                raise ValueError(f"Invalid JSON returned for eval {eval_index}:\n{response.content}")

            label_score = result.get("score")
            if label_score not in SCORE_TO_OVERALL:
                raise ValueError(f"Unexpected score label: {label_score}")

            numeric_score = SCORE_TO_OVERALL[label_score]

            eval_record = {
                "turn_index": eval_index,
                "total_windows": len(eval_windows),
                "eval_prompt": eval_prompt,
                "eval_inputs": {
                    "conversation_history": context_text,
                    "target_turn": target_turn
                },
                "eval_output": result,
                "numeric_score": numeric_score
            }

            all_eval_results.append(eval_record)

            print(f"Score: {label_score} ({numeric_score})")
            print(f"Reasoning: {result['reasoning']}")

        # ============================================================
        # COMPUTE AVERAGE SCORE + OVERALL LABEL
        # ============================================================

        avg_score = sum(r["numeric_score"] for r in all_eval_results) / len(all_eval_results)
        overall_label = score_to_label(avg_score)

        # ============================================================
        # OVERALL SUMMARY PROMPT (META-JUDGE)
        # ============================================================

        all_reasonings = "\n\n".join(
            f"Turn {r['turn_index']}:\n"
            f"Score: {r['eval_output']['score']} ({r['numeric_score']})\n"
            f"Reasoning: {r['eval_output']['reasoning']}"
            for r in all_eval_results
        )

        overall_prompt = f"""
You are an evaluation meta-judge.
Below are turn-level helpfulness evaluations of an AI conversation.
Your task:
- Produce a concise overall reasoning (max 50 words)
- Mention key strengths and weaknesses only
- Be objective

Conversation Turn Evaluations:
{all_reasonings}

Numeric Average Score: {avg_score:.4f}
Mapped Overall Label: {overall_label}

Return ONLY JSON:
{{
  "overall_reasoning": "string (max 50 words)",
  "overall_label": "{overall_label}"
}}
"""

        overall_response = llm_client.invoke(overall_prompt)

        try:
            overall_result = parse_llm_json(overall_response.content)
        except (json.JSONDecodeError, ValueError):
            raise ValueError(f"Invalid JSON from meta-judge:\n{overall_response.content}")

        # ============================================================
        # FINAL COMBINED OUTPUT
        # ============================================================

        final_output = {
            "eval_name": "helpfulness",
            "eval_type": "llm",
            "trace_id": trace_id,

            "turn_level_evaluations": all_eval_results,

            "eval_prompt": EVAL_PROMPT,

            "eval_inputs": [
                {
                    "conversation_history": r["eval_inputs"]["conversation_history"],
                    "target_turn": r["eval_inputs"]["target_turn"]
                }
                for r in all_eval_results
            ],

            "eval_output": [
                {
                    "reasoning": r["eval_output"]["reasoning"],
                    "score": r["eval_output"]["score"],
                }
                for r in all_eval_results
            ],

            "overall_summary": {
                "overall_score": round(avg_score, 4),
                "overall_label": overall_result["overall_label"],
                "overall_reason": overall_result["overall_reasoning"],
            },

            "metadata": {
                "total_turns_evaluated": len(all_eval_results),
                "timestamp": datetime.utcnow().isoformat()
            }
        }

        print("\n" + "=" * 80)
        print("FINAL HELPFULNESS EVAL OUTPUT")
        print(json.dumps(final_output, indent=2))

        return final_output

    except Exception as e:
        return {
            "eval_name": "helpfulness",
            "eval_type": "llm",
            "trace_id": trace_id,
            "status": "failed",
            "error": str(e)
        }


# ============================================================
# EXCEL DUMP FUNCTION
# ============================================================

def dump_helpfulness_eval_to_excel(
    *,
    trace_id: str,
    query: str,
    eval_result: dict,
    excel_path: str = "final_eval_results.xlsx",
):
    """
    Dump helpfulness evaluation results to Excel — one row per AI turn.

    Columns:
        Query            → repeated on first turn row only
        Eval_Input       → full conversation (context + target turn) as HUMAN:/AI: text
        Eval_Output      → raw target turn content (the AI message being evaluated)
        Label            → helpfulness label for this turn (e.g. "Somewhat Helpful")
        Reason           → LLM reasoning for this turn's score
        Overall_Score    → trace-level average score (first row only)
        Overall_Label    → trace-level label (first row only)
        Overall_Reason   → trace-level meta-judge reasoning (first row only)
    """
    try:
        from utils import get_or_create_workbook, get_or_create_sheet

        SHEET_NAME = "Helpfulness"
        HEADERS = [
            "Query",
            "Eval_Input",
            "Eval_Output",
            "Label",
            "Reason",
            "Overall_Score",
            "Overall_Label",
            "Overall_Reason",
        ]

        wb = get_or_create_workbook(excel_path)
        sheet = get_or_create_sheet(wb, SHEET_NAME, HEADERS)

        # ── Failed trace → single error row ──────────────────────────
        if eval_result.get("status") == "failed":
            sheet.append([
                query,
                eval_result.get("error", "Unknown error"),
                "", "", "", "", "", "", "failed",
            ])
            wb.save(excel_path)
            print("Helpfulness evaluation saved (failed) successfully.")
            return

        # ── Successful trace → one row per AI turn ────────────────────
        overall_summary = eval_result.get("overall_summary", {})
        overall_score   = overall_summary.get("overall_score", "")
        overall_label   = overall_summary.get("overall_label", "")
        overall_reason  = overall_summary.get("overall_reason", "")

        turn_records = eval_result.get("turn_level_evaluations", [])

        for i, record in enumerate(turn_records):
            turn_output = record.get("eval_output", {})

            # Eval_Input: full conversation including the target turn.
            # Labels: "User:" for human, "AI:" for Supervisor-only
            # (Supervisor filtering is enforced at extraction time in
            #  extract_conversation_from_run — name="Supervisor" only)
            raw_history = record.get("eval_inputs", {}).get("conversation_history", "")
            target_turn = record.get("eval_inputs", {}).get("target_turn", "")

            # Normalise "HUMAN:" → "User:" in stored history so the label
            # explicitly reflects the user/Supervisor split
            normalised_history = raw_history.replace("HUMAN:", "User:")

            if normalised_history and normalised_history != "(No prior context)":
                eval_input_text = normalised_history + "\nAI: " + target_turn
            else:
                eval_input_text = "AI: " + target_turn

            eval_output_text = json.dumps({
                "score":  record.get("numeric_score"),
                "reason": turn_output.get("reasoning", ""),
            }, indent=2)

            # Turn-level label and reason from LLM judge
            turn_output = record.get("eval_output", {})
            label  = turn_output.get("score", "")
            reason = turn_output.get("reasoning", "")

            sheet.append([
                query,
                eval_input_text,
                eval_output_text,
                label,
                reason,
                overall_score  if i == 0 else "", # Overall_Score — first row only
                overall_label  if i == 0 else "", # Overall_Label — first row only
                overall_reason if i == 0 else "", # Overall_Reason — first row only
            ])

        wb.save(excel_path)
        print(f"Helpfulness evaluation saved successfully ({len(turn_records)} turn rows).")

    except Exception as e:
        print(f"❌ Error dumping Helpfulness to Excel: {e}")