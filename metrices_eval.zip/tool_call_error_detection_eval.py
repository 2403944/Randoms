# """
# Tool Call Error Detection Evaluation Module
# ===========================================

# Purpose:
#   Classify tool calls as error_detected or no_error using explicit execution and logical signals.
#   Provides per-tool and overall error detection metrics.

# Evaluation Logic:
#   1. Extract all tool spans (run_type == "tool")
#   2. Examine: execution_status, error field, failed flag, logical_status
#   3. Per-tool: error_detected or no_error classification
#   4. Overall: deterministic aggregation (no_error_count / total_tools)
#   5. Score: 0.0-1.0 (higher = fewer errors detected)

# Temperature Strategy:
#   temperature=0 (deterministic, explicit signal matching only)
# """

# import ast
# import json
# from datetime import datetime
# from langsmith import Client
# from langchain_openai import AzureChatOpenAI
# from token_tracker import track_tokens_used, count_tokens


# # ============================================================
# # TOOL ERROR EVALUATION PROMPT (CANONICAL FORMAT)
# # ============================================================

# TOOL_ERROR_EVAL_PROMPT = {
#     "meta_instruction": (
#         "Follow the analysis steps internally but output ONLY the final JSON object "
#         "that conforms exactly to the output_structure_mandate."
#     ),

#     "metric_name": "Tool Call Error Detection",

#     "role": (
#         "You are an Expert Tool Execution Auditor. "
#         "You classify tool calls as error_detected or no_error using only "
#         "explicit execution and logical signals. "
#         "You MUST NOT guess or infer beyond provided fields."
#     ),

#     "goal": (
#         "Evaluate each tool call for execution or logical failure and provide "
#         "a concise overall error summary. Do NOT compute numeric scores."
#     ),

#     "inputs": {
#         "tool_calls": "{List of extracted tool call objects}"
#     },

#     "rubric": {
#         "error_detected": (
#             "An error is present if execution_status is 'error', "
#             "error field is not null, failed is true, "
#             "or logical_status explicitly indicates failure."
#         ),
#         "no_error": "No explicit error signal is present."
#     },

#     "analysis_approach": [
#         "Iterate through each tool call independently.",
#         "Check execution_status, error field, failed flag, and logical_status.",
#         "Assign error_detected or no_error without inference.",
#         "Determine error_type if applicable.",
#         "Summarize overall error status."
#     ],

#     "output_structure_mandate": {
#         "type": "object",
#         "properties": {
#             "tools": {
#                 "type": "array",
#                 "items": {
#                     "type": "object",
#                     "properties": {
#                         "span_id":   {"type": "string"},
#                         "tool_name": {"type": "string"},
#                         "error_status": {
#                             "type": "string",
#                             "description": "error_detected | no_error"
#                         },
#                         "error_type": {
#                             "type": "string",
#                             "description": "execution_error | logical_failure | none"
#                         },
#                         "error_reason": {"type": "string"}
#                     },
#                     "required": [
#                         "span_id",
#                         "tool_name",
#                         "error_status",
#                         "error_type",
#                         "error_reason"
#                     ]
#                 }
#             },
#             "overall_status": {
#                 "type": "string",
#                 "description": "error_detected | no_error"
#             },
#             "overall_reason": {"type": "string"}
#         },
#         "required": ["tools", "overall_status", "overall_reason"]
#     }
# }


# # ============================================================
# # JSON SAFE PARSER
# # ============================================================

# def safe_json_load(raw: str):
#     """Parse JSON from raw LLM output with markdown cleanup."""
#     raw = raw.strip()
#     if not raw:
#         raise ValueError("Empty LLM output")

#     if raw.startswith("```"):
#         raw = raw.strip("`").strip()
#         if raw.lower().startswith("json"):
#             raw = raw[4:].strip()

#     decoder = json.JSONDecoder()
#     obj, _ = decoder.raw_decode(raw)
#     return obj


# # ============================================================
# # MAIN EVALUATION FUNCTION
# # ============================================================

# def run_tool_call_error_detection_eval(trace_id, scenario, llm_client):
#     """
#     Evaluate tool call error detection for a trace.

#     Args:
#         trace_id:   LangSmith trace ID
#         scenario:   Scenario context/query description
#         llm_client: Azure OpenAI client (temperature=0)

#     Returns:
#         dict compatible with main.py
#     """
#     try:
#         client    = Client()
#         all_spans = list(client.list_runs(trace_id=trace_id))

#         tool_calls = []

#         for span in all_spans:
#             if span.run_type != "tool":
#                 continue

#             tool_name = span.name
#             span_id   = str(span.id)

#             tool_args  = {}
#             raw_inputs = span.inputs or {}

#             if isinstance(raw_inputs, dict):
#                 if "input" in raw_inputs:
#                     raw_input = raw_inputs["input"]
#                     if isinstance(raw_input, str):
#                         try:
#                             parsed = ast.literal_eval(raw_input)
#                             if isinstance(parsed, dict):
#                                 tool_args = parsed
#                         except Exception:
#                             tool_args = {}
#                     elif isinstance(raw_input, dict):
#                         tool_args = raw_input
#                 else:
#                     tool_args = raw_inputs

#             execution_status = span.status
#             execution_error  = span.error

#             logical_status = None
#             if isinstance(span.outputs, dict):
#                 if "status" in span.outputs:
#                     logical_status = span.outputs.get("status")
#                 elif (
#                     "output" in span.outputs
#                     and isinstance(span.outputs["output"], dict)
#                     and "status" in span.outputs["output"]
#                 ):
#                     logical_status = span.outputs["output"].get("status")

#             failed = execution_status == "error" or bool(execution_error)

#             tool_calls.append({
#                 "span_id":          span_id,
#                 "tool_name":        tool_name,
#                 "tool_arguments":   tool_args,
#                 "execution_status": execution_status,
#                 "logical_status":   logical_status,
#                 "error":            str(execution_error) if execution_error else None,
#                 "failed":           failed,
#             })

#         if not tool_calls:
#             return {
#                 "eval_name":  "tool_call_error_detection",
#                 "eval_type":  "hybrid",
#                 "status":     "completed",
#                 "trace_id":   trace_id,
#                 "scenario":   scenario,
#                 "eval_inputs":  {"total_spans_evaluated": 0},
#                 "eval_output":  {},
#                 "total_tools":          0,
#                 "no_error_count":       0,
#                 "error_detected_count": 0,
#                 "overall_status":  "no_error",
#                 "overall_reason":  "No tool calls found in trace",
#                 "overall_score":   1.0,
#                 "tools":           [],
#                 "model":           "gpt-5",
#                 "temperature":     0,
#                 "timestamp":       datetime.utcnow().isoformat(),
#             }

#         tool_call_audit_view = [
#             {
#                 "span_id":          t["span_id"],
#                 "tool_name":        t["tool_name"],
#                 "execution_status": t["execution_status"],
#                 "logical_status":   t["logical_status"],
#                 "error":            t["error"],
#                 "failed":           t["failed"],
#             }
#             for t in tool_calls
#         ]

#         messages = [
#             ("system", json.dumps(TOOL_ERROR_EVAL_PROMPT, indent=2)),
#             ("human",  json.dumps({"tool_calls": tool_call_audit_view}, indent=2)),
#         ]

#         response    = llm_client.invoke(messages)
#         tokens = count_tokens(response.content)
#         track_tokens_used(tokens, eval_name="tool_call_error_detection")
#         parsed_eval = safe_json_load(response.content)

#         tools = parsed_eval.get("tools", [])

#         if tools:
#             total_tools          = len(tools)
#             no_error_count       = sum(1 for t in tools if t.get("error_status") == "no_error")
#             error_detected_count = sum(1 for t in tools if t.get("error_status") == "error_detected")
#             overall_score        = round(no_error_count / total_tools, 4)
#         else:
#             total_tools          = 0
#             no_error_count       = 0
#             error_detected_count = 0
#             overall_score        = 0.0

#         overall_status = parsed_eval.get("overall_status", "no_error")
#         overall_reason = parsed_eval.get("overall_reason", "")

#         return {
#             "eval_name": "tool_call_error_detection",
#             "eval_type": "hybrid",
#             "eval_inputs": {
#                 "tool_calls":            tool_call_audit_view,
#                 "total_spans_evaluated": len(tool_calls),
#             },
#             "eval_output": {
#                 "tools":          tools,
#                 "overall_status": overall_status,
#                 "overall_reason": overall_reason,
#             },
#             "status":               "completed",
#             "trace_id":             trace_id,
#             "scenario":             scenario,
#             "total_tools":          total_tools,
#             "no_error_count":       no_error_count,
#             "error_detected_count": error_detected_count,
#             "overall_status":       overall_status,
#             "overall_reason":       overall_reason,
#             "overall_score":        overall_score,
#             "tools":                tools,
#             "model":                "gpt-5",
#             "temperature":          0,
#             "timestamp":            datetime.utcnow().isoformat(),
#         }

#     except Exception as e:
#         return {
#             "eval_name":     "tool_call_error_detection",
#             "eval_type":     "hybrid",
#             "status":        "failed",
#             "error":         str(e),
#             "trace_id":      trace_id,
#             "scenario":      scenario,
#             "eval_inputs":   {},
#             "eval_output":   {},
#             "overall_score":  0.0,
#             "overall_reason": "",
#         }


# # ============================================================
# # EXCEL DUMP FUNCTION
# # ============================================================

# def dump_tool_call_error_detection_to_excel(eval_result, output_excel, utils):
#     """
#     Dump tool call error detection evaluation to Excel sheet.

#     Headers: Query, Eval_Name, Error_Status, Overall_Count,
#              Pass_Count, Fail_Count, Overall_Score, Overall_Reason

#     Args:
#         eval_result:  dict from run_tool_call_error_detection_eval()
#         output_excel: path to Excel file
#         utils:        utils module with get_or_create_workbook, get_or_create_sheet
#     """
#     try:
#         HEADERS = [
#             "Query",
#             "Eval_Name",
#             "Error_Status",
#             "Overall_Count",
#             "Pass_Count",
#             "Fail_Count",
#             "Overall_Score",
#             "Overall_Reason",
#         ]

#         wb    = utils.get_or_create_workbook(output_excel)
#         sheet = utils.get_or_create_sheet(wb, "Tool Call Error", HEADERS)

#         scenario = eval_result.get("scenario", "")
#         status   = eval_result.get("status",   "")

#         if status == "failed":
#             sheet.append([
#                 scenario,
#                 "tool_call_error_detection",
#                 "",   # Error_Status
#                 "",   # Overall_Count
#                 "",   # Pass_Count
#                 "",   # Fail_Count
#                 "",   # Overall_Score
#                 eval_result.get("error", "Unknown error"),  # Overall_Reason
#             ])
#         else:
#             total_tools          = eval_result.get("total_tools",          0)
#             no_error_count       = eval_result.get("no_error_count",       0)
#             error_detected_count = eval_result.get("error_detected_count", 0)
#             overall_score        = eval_result.get("overall_score",        0.0)
#             overall_status       = eval_result.get("overall_status",       "")
#             overall_reason       = eval_result.get("overall_reason",       "")

#             sheet.append([
#                 scenario,
#                 "tool_call_error_detection",  # Eval_Name
#                 overall_status,               # Error_Status
#                 total_tools,                  # Overall_Count
#                 no_error_count,               # Pass_Count
#                 error_detected_count,         # Fail_Count
#                 overall_score,                # Overall_Score
#                 overall_reason,               # Overall_Reason
#             ])

#         wb.save(output_excel)

#     except Exception as e:
#         print(f"Error dumping Tool Call Error Detection to Excel: {e}")



"""
Tool Call Error Detection Evaluation Module
===========================================

Purpose:
  Classify tool calls as error_detected or no_error using explicit execution and logical signals.
  Provides per-tool and overall error detection metrics.

Evaluation Logic:
  1. Extract all tool spans (run_type == "tool")
  2. Examine: execution_status, error field, failed flag, logical_status
  3. Per-tool: error_detected or no_error classification
  4. Overall: deterministic aggregation (no_error_count / total_tools)
  5. Score: 0.0-1.0 (higher = fewer errors detected)

Temperature Strategy:
  temperature=0 (deterministic, explicit signal matching only)
"""

import ast
import json
from datetime import datetime
from langsmith import Client
from langchain_openai import AzureChatOpenAI
from token_tracker import track_tokens_used, count_tokens


# ============================================================
# TOOL ERROR EVALUATION PROMPT (CANONICAL FORMAT)
# ============================================================

TOOL_ERROR_EVAL_PROMPT = {
    "meta_instruction": (
        "Follow the analysis steps internally but output ONLY the final JSON object "
        "that conforms exactly to the output_structure_mandate."
    ),

    "metric_name": "Tool Call Error Detection",

    "role": (
        "You are an Expert Tool Execution Auditor. "
        "You classify tool calls as error_detected or no_error using only "
        "explicit execution and logical signals. "
        "You MUST NOT guess or infer beyond provided fields."
    ),

    "goal": (
        "Evaluate each tool call for execution or logical failure and provide "
        "a concise overall error summary. Do NOT compute numeric scores."
    ),

    "inputs": {
        "tool_calls": "{List of extracted tool call objects}"
    },

    "rubric": {
        "error_detected": (
            "An error is present if execution_status is 'error', "
            "error field is not null, failed is true, "
            "or logical_status explicitly indicates failure."
        ),
        "no_error": "No explicit error signal is present."
    },

    "analysis_approach": [
        "Iterate through each tool call independently.",
        "Check execution_status, error field, failed flag, and logical_status.",
        "Assign error_detected or no_error without inference.",
        "Determine error_type if applicable.",
        "Summarize overall error status."
    ],

    "output_structure_mandate": {
        "type": "object",
        "properties": {
            "tools": {
                "type": "array",
                "items": {
                    "type": "object",
                    "properties": {
                        "span_id":   {"type": "string"},
                        "tool_name": {"type": "string"},
                        "error_status": {
                            "type": "string",
                            "description": "error_detected | no_error"
                        },
                        "error_type": {
                            "type": "string",
                            "description": "execution_error | logical_failure | none"
                        },
                        "error_reason": {"type": "string"}
                    },
                    "required": [
                        "span_id",
                        "tool_name",
                        "error_status",
                        "error_type",
                        "error_reason"
                    ]
                }
            },
            "overall_status": {
                "type": "string",
                "description": "error_detected | no_error"
            },
            "overall_reason": {"type": "string"}
        },
        "required": ["tools", "overall_status", "overall_reason"]
    }
}


# ============================================================
# JSON SAFE PARSER
# ============================================================

def safe_json_load(raw: str):
    """Parse JSON from raw LLM output with markdown cleanup."""
    raw = raw.strip()
    if not raw:
        raise ValueError("Empty LLM output")

    if raw.startswith("```"):
        raw = raw.strip("`").strip()
        if raw.lower().startswith("json"):
            raw = raw[4:].strip()

    decoder = json.JSONDecoder()
    obj, _ = decoder.raw_decode(raw)
    return obj


# ============================================================
# MAIN EVALUATION FUNCTION
# ============================================================

def run_tool_call_error_detection_eval(trace_id, scenario, llm_client):
    """
    Evaluate tool call error detection for a trace.

    Args:
        trace_id:   LangSmith trace ID
        scenario:   Scenario context/query description
        llm_client: Azure OpenAI client (temperature=0)

    Returns:
        dict compatible with main.py
    """
    try:
        client    = Client()
        all_spans = list(client.list_runs(trace_id=trace_id))

        tool_calls = []

        for span in all_spans:
            if span.run_type != "tool":
                continue

            tool_name = span.name
            span_id   = str(span.id)

            tool_args  = {}
            raw_inputs = span.inputs or {}

            if isinstance(raw_inputs, dict):
                if "input" in raw_inputs:
                    raw_input = raw_inputs["input"]
                    if isinstance(raw_input, str):
                        try:
                            parsed = ast.literal_eval(raw_input)
                            if isinstance(parsed, dict):
                                tool_args = parsed
                        except Exception:
                            tool_args = {}
                    elif isinstance(raw_input, dict):
                        tool_args = raw_input
                else:
                    tool_args = raw_inputs

            execution_status = span.status
            execution_error  = span.error

            logical_status = None
            if isinstance(span.outputs, dict):
                if "status" in span.outputs:
                    logical_status = span.outputs.get("status")
                elif (
                    "output" in span.outputs
                    and isinstance(span.outputs["output"], dict)
                    and "status" in span.outputs["output"]
                ):
                    logical_status = span.outputs["output"].get("status")

            failed = execution_status == "error" or bool(execution_error)

            tool_calls.append({
                "span_id":          span_id,
                "tool_name":        tool_name,
                "tool_arguments":   tool_args,
                "execution_status": execution_status,
                "logical_status":   logical_status,
                "error":            str(execution_error) if execution_error else None,
                "failed":           failed,
            })

        if not tool_calls:
            return {
                "eval_name":  "tool_call_error_detection",
                "eval_type":  "hybrid",
                "status":     "completed",
                "trace_id":   trace_id,
                "scenario":   scenario,
                "eval_inputs":  {"total_spans_evaluated": 0},
                "eval_output":  {},
                "total_tools":          0,
                "no_error_count":       0,
                "error_detected_count": 0,
                "overall_status":  "no_error",
                "overall_reason":  "No tool calls found in trace",
                "overall_score":   1.0,
                "tools":           [],
                "failed_tool_details": [],
                "model":           "gpt-5",
                "temperature":     0,
                "timestamp":       datetime.utcnow().isoformat(),
            }

        tool_call_audit_view = [
            {
                "span_id":          t["span_id"],
                "tool_name":        t["tool_name"],
                "execution_status": t["execution_status"],
                "logical_status":   t["logical_status"],
                "error":            t["error"],
                "failed":           t["failed"],
            }
            for t in tool_calls
        ]

        messages = [
            ("system", json.dumps(TOOL_ERROR_EVAL_PROMPT, indent=2)),
            ("human",  json.dumps({"tool_calls": tool_call_audit_view}, indent=2)),
        ]

        response    = llm_client.invoke(messages)
        tokens = count_tokens(response.content)
        track_tokens_used(tokens, eval_name="tool_call_error_detection")
        parsed_eval = safe_json_load(response.content)

        tools = parsed_eval.get("tools", [])

        # Build a lookup from span_id to full tool_call data
        tool_calls_by_span_id = {t["span_id"]: t for t in tool_calls}

        # Collect complete error data for failed tool calls
        failed_tool_details = []
        for t in tools:
            if t.get("error_status") == "error_detected":
                span_id = t.get("span_id")
                full_data = tool_calls_by_span_id.get(span_id, {})
                failed_tool_details.append({
                    "span_id":          span_id,
                    "tool_name":        t.get("tool_name"),
                    "error_type":       t.get("error_type"),
                    "error_reason":     t.get("error_reason"),
                    "tool_arguments":   full_data.get("tool_arguments"),
                    "execution_status": full_data.get("execution_status"),
                    "logical_status":   full_data.get("logical_status"),
                    "error":            full_data.get("error"),
                    "failed":           full_data.get("failed"),
                })

        if tools:
            total_tools          = len(tools)
            no_error_count       = sum(1 for t in tools if t.get("error_status") == "no_error")
            error_detected_count = sum(1 for t in tools if t.get("error_status") == "error_detected")
            overall_score        = round(no_error_count / total_tools, 4)
        else:
            total_tools          = 0
            no_error_count       = 0
            error_detected_count = 0
            overall_score        = 0.0

        overall_status = parsed_eval.get("overall_status", "no_error")
        overall_reason = parsed_eval.get("overall_reason", "")

        return {
            "eval_name": "tool_call_error_detection",
            "eval_type": "hybrid",
            "eval_inputs": {
                "tool_calls":            tool_call_audit_view,
                "total_spans_evaluated": len(tool_calls),
            },
            "eval_output": {
                "tools":               tools,
                "overall_status":      overall_status,
                "overall_reason":      overall_reason,
                "failed_tool_details": failed_tool_details,
            },
            "status":               "completed",
            "trace_id":             trace_id,
            "scenario":             scenario,
            "total_tools":          total_tools,
            "no_error_count":       no_error_count,
            "error_detected_count": error_detected_count,
            "overall_status":       overall_status,
            "overall_reason":       overall_reason,
            "overall_score":        overall_score,
            "tools":                tools,
            "failed_tool_details":  failed_tool_details,
            "model":                "gpt-5",
            "temperature":          0,
            "timestamp":            datetime.utcnow().isoformat(),
        }

    except Exception as e:
        return {
            "eval_name":     "tool_call_error_detection",
            "eval_type":     "hybrid",
            "status":        "failed",
            "error":         str(e),
            "trace_id":      trace_id,
            "scenario":      scenario,
            "eval_inputs":   {},
            "eval_output":   {},
            "overall_score":  0.0,
            "overall_reason": "",
        }


# ============================================================
# EXCEL DUMP FUNCTION
# ============================================================

def dump_tool_call_error_detection_to_excel(eval_result, output_excel, utils):
    """
    Dump tool call error detection evaluation to Excel sheet.

    Headers: Query, Eval_Name, Error_Status, Overall_Count,
             Pass_Count, Fail_Count, Overall_Score, Overall_Reason,
             Failed_Tool_Details

    Args:
        eval_result:  dict from run_tool_call_error_detection_eval()
        output_excel: path to Excel file
        utils:        utils module with get_or_create_workbook, get_or_create_sheet
    """
    try:
        HEADERS = [
            "Query",
            "Eval_Name",
            "Error_Status",
            "Overall_Count",
            "Pass_Count",
            "Fail_Count",
            "Overall_Score",
            "Overall_Reason",
            "Failed_Tool_Details",
        ]

        wb    = utils.get_or_create_workbook(output_excel)
        sheet = utils.get_or_create_sheet(wb, "Tool Call Error", HEADERS)

        scenario = eval_result.get("scenario", "")
        status   = eval_result.get("status",   "")

        if status == "failed":
            sheet.append([
                scenario,
                "tool_call_error_detection",
                "",   # Error_Status
                "",   # Overall_Count
                "",   # Pass_Count
                "",   # Fail_Count
                "",   # Overall_Score
                eval_result.get("error", "Unknown error"),  # Overall_Reason
                "",   # Failed_Tool_Details
            ])
        else:
            total_tools          = eval_result.get("total_tools",          0)
            no_error_count       = eval_result.get("no_error_count",       0)
            error_detected_count = eval_result.get("error_detected_count", 0)
            overall_score        = eval_result.get("overall_score",        0.0)
            overall_status       = eval_result.get("overall_status",       "")
            overall_reason       = eval_result.get("overall_reason",       "")
            failed_tool_details  = eval_result.get("failed_tool_details",  [])

            failed_tool_details_str = (
                json.dumps(failed_tool_details, indent=2)
                if overall_status == "error_detected" and failed_tool_details
                else ""
            )

            sheet.append([
                scenario,
                "tool_call_error_detection",  # Eval_Name
                overall_status,               # Error_Status
                total_tools,                  # Overall_Count
                no_error_count,               # Pass_Count
                error_detected_count,         # Fail_Count
                overall_score,                # Overall_Score
                overall_reason,               # Overall_Reason
                failed_tool_details_str,      # Failed_Tool_Details
            ])

        wb.save(output_excel)

    except Exception as e:
        print(f"Error dumping Tool Call Error Detection to Excel: {e}")