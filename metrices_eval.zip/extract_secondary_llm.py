"""
Extract Secondary LLM data from final_eval_results.xlsx and create new Excel
with display names for Eval_Name column
"""

from openpyxl import load_workbook, Workbook
from pathlib import Path

# Mapping of old names to new display names
eval_name_mapping = {
    "parameter_extraction_accuracy": "Parameter Extraction Accuracy",
    "tool_call_accuracy": "Tool Call Accuracy",
    "trajectory_match": "Trajectory",
    "refusal_detection": "Refusal",
    "supervisor_plan_accuracy": "Plan Accuracy",
    "summary_accuracy": "Output vs Context Accuracy",
    "hallucination_cove": "Hallucination Cove",
    "agent_goal_accomplishment": "Goal Accomplishment",
    "context_filter_accuracy": "Context Filter accuracy",
    "helpfulness": "Helpfulness",
    "coherence": "Coherence",
    "convergence": "Convergence",
    "output_format_compliance": "Output format Check",
    "confidence_score_accuracy": "Confidence score accuracy",
    "tool_call_error_detection": "Tool Call Error",
    "recovery_loop_eval": "Recovery Loop",
}

# Also handle display names that might already be there
display_names = {v: v for v in eval_name_mapping.values()}
full_mapping = {**eval_name_mapping, **display_names}

# Try both source files
source_files = [
    "final_eval_results.xlsx"
    # "Metrics_template.xlsx",
    # "final_eval_results_withoutWeight.xlsx"
]

output_file = "Secondary_LLM_Extract.xlsx"
source_file = None
source_ws = None

# Find which file has Secondary LLM sheet with data
for file in source_files:
    if not Path(file).exists():
        continue
    
    print(f"Checking {file}...")
    wb = load_workbook(file)
    
    if "Secondary LLM" in wb.sheetnames:
        ws = wb["Secondary LLM"]
        if ws.max_row > 1:  # Has data
            source_file = file
            source_ws = ws
            print(f"  ✓ Found Secondary LLM sheet with {ws.max_row - 1} data rows")
            break
    
    if "Universal Critique Judge" in wb.sheetnames:
        ws = wb["Universal Critique Judge"]
        if ws.max_row > 1:  # Has data
            source_file = file
            source_ws = ws
            print(f"  ✓ Found Universal Critique Judge sheet with {ws.max_row - 1} data rows")
            break

if source_ws is None:
    print("\nNo Secondary LLM or Universal Critique Judge sheet with data found in any file")
    exit(1)

print(f"\nUsing source: {source_file}")

# Create new workbook
new_wb = Workbook()
new_ws = new_wb.active
new_ws.title = "Secondary LLM"

# Copy headers
headers = []
for col_idx in range(1, source_ws.max_column + 1):
    header = source_ws.cell(1, col_idx).value
    headers.append(header)
    new_ws.cell(1, col_idx).value = header

print(f"Headers: {headers}")

# Find Eval_Name column index
eval_name_col_idx = None
for col_idx, header in enumerate(headers, 1):
    if header == "Eval_Name":
        eval_name_col_idx = col_idx
        break

# Copy data rows with eval_name mapping
row_count = 0
header_set = set(h.lower().strip() if h else "" for h in headers)

for row_idx in range(2, source_ws.max_row + 1):
    # Get first column value
    first_col_value = source_ws.cell(row_idx, 1).value
    if not first_col_value:
        continue
    
    # Check if this row is a duplicate header row
    first_col_str = str(first_col_value).lower().strip()
    is_header_row = first_col_str in [h.lower() for h in headers if h]
    
    if is_header_row:
        print(f"  Skipping duplicate header row at row {row_idx}")
        continue
    
    for col_idx in range(1, source_ws.max_column + 1):
        cell_value = source_ws.cell(row_idx, col_idx).value
        
        # If this is the Eval_Name column, map the name
        if col_idx == eval_name_col_idx and cell_value:
            mapped_name = full_mapping.get(cell_value, cell_value)
            new_ws.cell(row_count + 2, col_idx).value = mapped_name
        else:
            new_ws.cell(row_count + 2, col_idx).value = cell_value
    
    row_count += 1

# Save new workbook
print(f"\nSaving {output_file}...")
new_wb.save(output_file)
print(f"✓ Done! Created {output_file} with {row_count} data rows")
print(f"  All Eval_Name values have been mapped to display names")
