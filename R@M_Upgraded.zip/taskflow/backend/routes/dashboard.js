const express = require('express');
const { getDb } = require('../models/database');
const { authenticate } = require('../middleware/auth');

const router = express.Router();

// GET /api/dashboard
router.get('/', authenticate, (req, res) => {
  const db = getDb();
  const userId = req.user.id;
  const isAdmin = req.user.role === 'admin';

  const today = new Date().toISOString().split('T')[0];

  let stats, recentTasks, myTasks, overdueCount;

  if (isAdmin) {
    stats = db.prepare(`
      SELECT
        (SELECT COUNT(*) FROM projects) as total_projects,
        (SELECT COUNT(*) FROM projects WHERE status = 'active') as active_projects,
        (SELECT COUNT(*) FROM tasks) as total_tasks,
        (SELECT COUNT(*) FROM tasks WHERE status = 'done') as completed_tasks,
        (SELECT COUNT(*) FROM tasks WHERE status = 'in_progress') as in_progress_tasks,
        (SELECT COUNT(*) FROM tasks WHERE status = 'todo') as todo_tasks,
        (SELECT COUNT(*) FROM tasks WHERE deadline < ? AND status != 'done') as overdue_tasks,
        (SELECT COUNT(*) FROM users) as total_users
    `).get(today);

    recentTasks = db.prepare(`
      SELECT t.*, p.name as project_name, u.name as assignee_name
      FROM tasks t
      JOIN projects p ON t.project_id = p.id
      LEFT JOIN users u ON t.assignee_id = u.id
      ORDER BY t.updated_at DESC LIMIT 10
    `).all();

    myTasks = db.prepare(`
      SELECT t.*, p.name as project_name
      FROM tasks t
      JOIN projects p ON t.project_id = p.id
      WHERE t.assignee_id = ? AND t.status != 'done'
      ORDER BY t.deadline ASC NULLS LAST LIMIT 5
    `).all(userId);
  } else {
    stats = db.prepare(`
      SELECT
        (SELECT COUNT(*) FROM projects p
          LEFT JOIN project_members pm ON p.id = pm.project_id AND pm.user_id = ?
          WHERE p.owner_id = ? OR pm.user_id = ?) as total_projects,
        (SELECT COUNT(*) FROM tasks WHERE assignee_id = ?) as total_tasks,
        (SELECT COUNT(*) FROM tasks WHERE assignee_id = ? AND status = 'done') as completed_tasks,
        (SELECT COUNT(*) FROM tasks WHERE assignee_id = ? AND status = 'in_progress') as in_progress_tasks,
        (SELECT COUNT(*) FROM tasks WHERE assignee_id = ? AND status = 'todo') as todo_tasks,
        (SELECT COUNT(*) FROM tasks WHERE assignee_id = ? AND deadline < ? AND status != 'done') as overdue_tasks
    `).get(userId, userId, userId, userId, userId, userId, userId, userId, today);

    recentTasks = db.prepare(`
      SELECT t.*, p.name as project_name, u.name as assignee_name
      FROM tasks t
      JOIN projects p ON t.project_id = p.id
      LEFT JOIN users u ON t.assignee_id = u.id
      LEFT JOIN project_members pm ON p.id = pm.project_id AND pm.user_id = ?
      WHERE p.owner_id = ? OR pm.user_id = ?
      ORDER BY t.updated_at DESC LIMIT 10
    `).all(userId, userId, userId);

    myTasks = db.prepare(`
      SELECT t.*, p.name as project_name
      FROM tasks t
      JOIN projects p ON t.project_id = p.id
      WHERE t.assignee_id = ? AND t.status != 'done'
      ORDER BY t.deadline ASC NULLS LAST LIMIT 5
    `).all(userId);
  }

  // Task distribution by status
  const tasksByStatus = db.prepare(`
    SELECT status, COUNT(*) as count FROM tasks
    ${isAdmin ? '' : 'WHERE assignee_id = ?'}
    GROUP BY status
  `).all(...(isAdmin ? [] : [userId]));

  // Tasks by priority
  const tasksByPriority = db.prepare(`
    SELECT priority, COUNT(*) as count FROM tasks
    WHERE status != 'done' ${isAdmin ? '' : 'AND assignee_id = ?'}
    GROUP BY priority
  `).all(...(isAdmin ? [] : [userId]));

  res.json({ stats, recentTasks, myTasks, tasksByStatus, tasksByPriority });
});

module.exports = router;
