const express = require('express');
const { body, validationResult } = require('express-validator');
const { getDb } = require('../models/database');
const { authenticate, requireProjectAccess, requireProjectAdmin } = require('../middleware/auth');

const router = express.Router({ mergeParams: true });

// GET /api/projects/:projectId/tasks
router.get('/', authenticate, requireProjectAccess, (req, res) => {
  const db = getDb();
  const tasks = db.prepare(`
    SELECT t.*,
      u1.name as assignee_name, u1.avatar as assignee_avatar,
      u2.name as creator_name
    FROM tasks t
    LEFT JOIN users u1 ON t.assignee_id = u1.id
    LEFT JOIN users u2 ON t.creator_id = u2.id
    WHERE t.project_id = ?
    ORDER BY 
      CASE t.priority WHEN 'critical' THEN 1 WHEN 'high' THEN 2 WHEN 'medium' THEN 3 ELSE 4 END,
      t.created_at DESC
  `).all(req.params.projectId);

  res.json({ tasks });
});

// POST /api/projects/:projectId/tasks
router.post('/', authenticate, requireProjectAccess, [
  body('title').trim().notEmpty().withMessage('Task title required'),
  body('description').optional().trim(),
  body('priority').optional().isIn(['low', 'medium', 'high', 'critical']),
  body('assignee_id').optional().isInt(),
  body('deadline').optional().isDate(),
], (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) return res.status(400).json({ errors: errors.array() });

  const { title, description, priority = 'medium', assignee_id, deadline } = req.body;
  const db = getDb();

  // Validate assignee is in project
  if (assignee_id) {
    const member = db.prepare(
      'SELECT id FROM project_members WHERE project_id = ? AND user_id = ?'
    ).get(req.params.projectId, assignee_id);
    if (!member) return res.status(400).json({ error: 'Assignee must be a project member' });
  }

  const result = db.prepare(`
    INSERT INTO tasks (title, description, priority, assignee_id, deadline, project_id, creator_id)
    VALUES (?, ?, ?, ?, ?, ?, ?)
  `).run(title, description || null, priority, assignee_id || null, deadline || null, req.params.projectId, req.user.id);

  const task = db.prepare(`
    SELECT t.*, u1.name as assignee_name, u1.avatar as assignee_avatar, u2.name as creator_name
    FROM tasks t
    LEFT JOIN users u1 ON t.assignee_id = u1.id
    LEFT JOIN users u2 ON t.creator_id = u2.id
    WHERE t.id = ?
  `).get(result.lastInsertRowid);

  res.status(201).json({ task });
});

// PUT /api/projects/:projectId/tasks/:taskId
router.put('/:taskId', authenticate, requireProjectAccess, [
  body('status').optional().isIn(['todo', 'in_progress', 'review', 'done']),
  body('priority').optional().isIn(['low', 'medium', 'high', 'critical']),
], (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) return res.status(400).json({ errors: errors.array() });

  const db = getDb();
  const task = db.prepare('SELECT * FROM tasks WHERE id = ? AND project_id = ?')
    .get(req.params.taskId, req.params.projectId);

  if (!task) return res.status(404).json({ error: 'Task not found' });

  // Members can only update their own tasks or tasks assigned to them
  const isProjectAdmin = req.projectMember?.role === 'admin' || req.user.role === 'admin' || req.project.owner_id === req.user.id;
  const isOwnerOrAssignee = task.creator_id === req.user.id || task.assignee_id === req.user.id;

  if (!isProjectAdmin && !isOwnerOrAssignee) {
    return res.status(403).json({ error: 'Not authorized to update this task' });
  }

  const { title, description, status, priority, assignee_id, deadline } = req.body;
  const updates = [];
  const values = [];

  if (title) { updates.push('title = ?'); values.push(title); }
  if (description !== undefined) { updates.push('description = ?'); values.push(description); }
  if (status) { updates.push('status = ?'); values.push(status); }
  if (priority) { updates.push('priority = ?'); values.push(priority); }
  if (assignee_id !== undefined) { updates.push('assignee_id = ?'); values.push(assignee_id || null); }
  if (deadline !== undefined) { updates.push('deadline = ?'); values.push(deadline || null); }

  if (updates.length === 0) return res.status(400).json({ error: 'No fields to update' });

  values.push(req.params.taskId);
  db.prepare(`UPDATE tasks SET ${updates.join(', ')} WHERE id = ?`).run(...values);

  const updated = db.prepare(`
    SELECT t.*, u1.name as assignee_name, u1.avatar as assignee_avatar, u2.name as creator_name
    FROM tasks t
    LEFT JOIN users u1 ON t.assignee_id = u1.id
    LEFT JOIN users u2 ON t.creator_id = u2.id
    WHERE t.id = ?
  `).get(req.params.taskId);

  res.json({ task: updated });
});

// DELETE /api/projects/:projectId/tasks/:taskId
router.delete('/:taskId', authenticate, requireProjectAccess, requireProjectAdmin, (req, res) => {
  const db = getDb();
  db.prepare('DELETE FROM tasks WHERE id = ? AND project_id = ?')
    .run(req.params.taskId, req.params.projectId);
  res.json({ message: 'Task deleted' });
});

// GET /api/projects/:projectId/tasks/:taskId/comments
router.get('/:taskId/comments', authenticate, requireProjectAccess, (req, res) => {
  const db = getDb();
  const comments = db.prepare(`
    SELECT c.*, u.name, u.avatar
    FROM task_comments c
    JOIN users u ON c.user_id = u.id
    WHERE c.task_id = ?
    ORDER BY c.created_at ASC
  `).all(req.params.taskId);
  res.json({ comments });
});

// POST /api/projects/:projectId/tasks/:taskId/comments
router.post('/:taskId/comments', authenticate, requireProjectAccess, [
  body('content').trim().notEmpty().withMessage('Comment content required'),
], (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) return res.status(400).json({ errors: errors.array() });

  const db = getDb();
  const result = db.prepare(
    'INSERT INTO task_comments (task_id, user_id, content) VALUES (?, ?, ?)'
  ).run(req.params.taskId, req.user.id, req.body.content);

  const comment = db.prepare(`
    SELECT c.*, u.name, u.avatar FROM task_comments c
    JOIN users u ON c.user_id = u.id WHERE c.id = ?
  `).get(result.lastInsertRowid);

  res.status(201).json({ comment });
});

module.exports = router;
