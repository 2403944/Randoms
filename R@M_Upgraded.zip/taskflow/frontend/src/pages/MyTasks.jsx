import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Calendar, CheckSquare, AlertTriangle, Clock, CheckCircle2 } from 'lucide-react';
import api from '../utils/api';
import { useAuth } from '../context/AuthContext';
import { formatDate } from '../components/Avatar';

const priorityColors = { low:'priority-low', medium:'priority-medium', high:'priority-high', critical:'priority-critical' };
const statusColors   = { todo:'status-todo', in_progress:'status-in_progress', review:'status-review', done:'status-done' };

export default function MyTasks() {
  const { user } = useAuth();
  const [allTasks, setAllTasks] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState('active');

  useEffect(() => {
    api.get('/projects').then(async res => {
      const projects = res.data.projects;
      const results = await Promise.all(projects.map(p =>
        api.get(`/projects/${p.id}/tasks`).then(r => r.data.tasks.map(t => ({ ...t, project_name: p.name, project_id: p.id })))
      ));
      setAllTasks(results.flat().filter(t => t.assignee_id === user.id || t.creator_id === user.id));
    }).finally(() => setLoading(false));
  }, []);

  const today = new Date();
  const filtered = allTasks.filter(t => {
    if (filter === 'active') return t.status !== 'done';
    if (filter === 'overdue') return t.deadline && new Date(t.deadline) < today && t.status !== 'done';
    if (filter === 'done') return t.status === 'done';
    return true;
  });

  const counts = {
    active: allTasks.filter(t => t.status !== 'done').length,
    overdue: allTasks.filter(t => t.deadline && new Date(t.deadline) < today && t.status !== 'done').length,
    done: allTasks.filter(t => t.status === 'done').length,
    all: allTasks.length,
  };

  if (loading) return <div className="loading-page"><div className="spinner" /></div>;

  return (
    <div>
      <div className="page-header">
        <div>
          <div className="page-eyebrow">Tasks</div>
          <div className="page-title">My Tasks</div>
          <div className="page-subtitle">All tasks assigned to or created by you</div>
        </div>
      </div>

      {/* Summary cards */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4,1fr)', gap: 12, marginBottom: 28 }}>
        {[
          { key: 'active', label: 'Active', icon: <Clock size={16}/>, color: 'blue' },
          { key: 'overdue', label: 'Overdue', icon: <AlertTriangle size={16}/>, color: 'red' },
          { key: 'done', label: 'Completed', icon: <CheckCircle2 size={16}/>, color: 'emerald' },
          { key: 'all', label: 'All Tasks', icon: <CheckSquare size={16}/>, color: 'violet' },
        ].map(s => (
          <div key={s.key} className={`stat-card ${s.color}`} style={{ cursor: 'pointer', opacity: filter === s.key ? 1 : 0.7 }}
            onClick={() => setFilter(s.key)}>
            <div className="stat-icon-wrap">{s.icon}</div>
            <div className="stat-value">{counts[s.key]}</div>
            <div className="stat-label">{s.label}</div>
          </div>
        ))}
      </div>

      {filtered.length === 0 ? (
        <div className="empty-state">
          <div className="empty-icon-wrap"><CheckSquare size={28} /></div>
          <div className="empty-title">{filter === 'overdue' ? "You're all caught up! 🎉" : "No tasks here"}</div>
          <div className="empty-text">Nothing to show in this category</div>
        </div>
      ) : (
        <div className="table-wrap">
          <table>
            <thead>
              <tr>
                <th>Task</th>
                <th>Project</th>
                <th>Status</th>
                <th>Priority</th>
                <th>Deadline</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map(task => {
                const overdue = task.deadline && new Date(task.deadline) < today && task.status !== 'done';
                return (
                  <tr key={`${task.project_id}-${task.id}`}>
                    <td>
                      <div style={{ fontWeight: 600, letterSpacing: '-0.01em' }}>{task.title}</div>
                      {task.description && <div style={{ fontSize: 12, color: 'var(--text-3)', marginTop: 2 }}>{task.description.slice(0,60)}{task.description.length > 60 ? '…' : ''}</div>}
                    </td>
                    <td>
                      <Link to={`/projects/${task.project_id}`} style={{ color: 'var(--blue-bright)', textDecoration: 'none', fontSize: 13, fontWeight: 500 }}>
                        {task.project_name}
                      </Link>
                    </td>
                    <td><span className={`status-badge ${statusColors[task.status]}`}>{task.status.replace('_',' ')}</span></td>
                    <td><span className={`priority ${priorityColors[task.priority]}`}>{task.priority}</span></td>
                    <td>
                      {task.deadline ? (
                        <span className={`deadline ${overdue ? 'overdue' : ''}`}>
                          <Calendar size={10}/> {formatDate(task.deadline)} {overdue && '⚠️'}
                        </span>
                      ) : <span style={{ color: 'var(--text-4)' }}>—</span>}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
