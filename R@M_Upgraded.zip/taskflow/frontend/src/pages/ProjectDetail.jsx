import { useState, useEffect } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { Plus, UserPlus, ArrowLeft, Trash2, LayoutGrid, List, Users, X } from 'lucide-react';
import api from '../utils/api';
import { useAuth } from '../context/AuthContext';
import { Avatar, formatDate } from '../components/Avatar';
import TaskModal from '../components/TaskModal';

const COLS = [
  { key: 'todo', label: 'To Do', cls: 'col-todo' },
  { key: 'in_progress', label: 'In Progress', cls: 'col-progress' },
  { key: 'review', label: 'Review', cls: 'col-review' },
  { key: 'done', label: 'Done', cls: 'col-done' },
];

const priorityColors = { low:'priority-low', medium:'priority-medium', high:'priority-high', critical:'priority-critical' };

export default function ProjectDetail() {
  const { id } = useParams();
  const { user } = useAuth();
  const navigate = useNavigate();
  const [project, setProject] = useState(null);
  const [members, setMembers] = useState([]);
  const [tasks, setTasks] = useState([]);
  const [loading, setLoading] = useState(true);
  const [tab, setTab] = useState('board');
  const [selectedTask, setSelectedTask] = useState(null);
  const [showNewTask, setShowNewTask] = useState(false);
  const [showAddMember, setShowAddMember] = useState(false);
  const [newTaskStatus, setNewTaskStatus] = useState('todo');

  useEffect(() => {
    Promise.all([api.get(`/projects/${id}`), api.get(`/projects/${id}/tasks`)])
      .then(([p, t]) => { setProject(p.data.project); setMembers(p.data.members); setTasks(t.data.tasks); })
      .finally(() => setLoading(false));
  }, [id]);

  const isAdmin = user.role === 'admin' || project?.owner_id === user.id ||
    members.find(m => m.id === user.id)?.role === 'admin';

  const handleTaskUpdated = (u) => { setTasks(tasks.map(t => t.id === u.id ? u : t)); setSelectedTask(u); };
  const handleTaskDeleted = (tid) => { setTasks(tasks.filter(t => t.id !== tid)); setSelectedTask(null); };
  const handleDeleteProject = async () => {
    if (!confirm(`Delete "${project.name}"? This cannot be undone.`)) return;
    await api.delete(`/projects/${id}`);
    navigate('/projects');
  };

  if (loading) return <div className="loading-page"><div className="spinner" /></div>;
  if (!project) return <div>Project not found</div>;

  const overdue = tasks.filter(t => t.deadline && new Date(t.deadline) < new Date() && t.status !== 'done');
  const progress = tasks.length > 0 ? Math.round((tasks.filter(t => t.status === 'done').length / tasks.length) * 100) : 0;

  return (
    <div>
      <div className="page-header">
        <div>
          <Link to="/projects" style={{ display: 'inline-flex', alignItems: 'center', gap: 6, fontSize: 12, color: 'var(--text-3)', textDecoration: 'none', marginBottom: 10, fontWeight: 500 }}>
            <ArrowLeft size={13} /> All Projects
          </Link>
          <div style={{ display: 'flex', alignItems: 'center', gap: 12, flexWrap: 'wrap' }}>
            <div className="page-title">{project.name}</div>
            <span className={`project-status-badge status-${project.status}`}>{project.status}</span>
          </div>
          {project.description && <div className="page-subtitle">{project.description}</div>}
          {/* Progress */}
          <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginTop: 12 }}>
            <div style={{ flex: 1, maxWidth: 200 }}>
              <div className="progress-bar" style={{ margin: 0 }}>
                <div className="progress-fill" style={{ width: `${progress}%` }} />
              </div>
            </div>
            <span style={{ fontSize: 12, color: 'var(--text-3)', fontWeight: 600 }}>{progress}% complete</span>
            <span style={{ fontSize: 12, color: 'var(--text-3)' }}>{tasks.filter(t=>t.status==='done').length}/{tasks.length} tasks</span>
          </div>
        </div>
        <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
          {isAdmin && <button className="btn btn-secondary" onClick={() => setShowAddMember(true)}><UserPlus size={14} /> Add Member</button>}
          <button className="btn btn-primary" onClick={() => setShowNewTask(true)}><Plus size={14} /> New Task</button>
          {isAdmin && <button className="btn btn-danger btn-icon" onClick={handleDeleteProject} title="Delete project"><Trash2 size={14} /></button>}
        </div>
      </div>

      {overdue.length > 0 && (
        <div className="alert alert-error" style={{ marginBottom: 20 }}>
          ⚠️ <strong>{overdue.length} overdue task{overdue.length > 1 ? 's' : ''}</strong> — these need immediate attention
        </div>
      )}

      <div className="tabs">
        <button className={`tab ${tab==='board' ? 'active' : ''}`} onClick={() => setTab('board')}>
          <LayoutGrid size={13} /> Board <span className="tab-count">{tasks.length}</span>
        </button>
        <button className={`tab ${tab==='list' ? 'active' : ''}`} onClick={() => setTab('list')}>
          <List size={13} /> List
        </button>
        <button className={`tab ${tab==='members' ? 'active' : ''}`} onClick={() => setTab('members')}>
          <Users size={13} /> Members <span className="tab-count">{members.length}</span>
        </button>
      </div>

      {tab === 'board' && (
        <div className="board">
          {COLS.map(col => {
            const colTasks = tasks.filter(t => t.status === col.key);
            return (
              <div key={col.key} className={`board-col ${col.cls}`}>
                <div className="board-col-header">
                  <div className="board-col-top" />
                  <div className="board-col-title">{col.label}</div>
                  <div className="board-col-count">{colTasks.length}</div>
                  <button className="btn btn-ghost btn-icon" style={{ padding: 4, marginLeft: 2 }}
                    onClick={() => { setNewTaskStatus(col.key); setShowNewTask(true); }} title="Add task">
                    <Plus size={13} />
                  </button>
                </div>
                <div className="board-cards">
                  {colTasks.length === 0 && (
                    <div style={{ padding: '20px 8px', textAlign: 'center', color: 'var(--text-4)', fontSize: 12, borderRadius: 'var(--r-md)', border: '1px dashed var(--border-1)' }}>
                      Drop tasks here
                    </div>
                  )}
                  {colTasks.map(task => (
                    <div key={task.id} className="task-card" onClick={() => setSelectedTask(task)}>
                      <div className="task-card-title">{task.title}</div>
                      <div className="task-card-meta">
                        <span className={`priority ${priorityColors[task.priority]}`}>{task.priority}</span>
                        {task.assignee_name && (
                          <span style={{ display: 'flex', alignItems: 'center', gap: 4, fontSize: 11, color: 'var(--text-3)' }}>
                            <Avatar avatarData={task.assignee_avatar} name={task.assignee_name}
                              style={{ width: 18, height: 18, fontSize: 8 }} />
                            {task.assignee_name.split(' ')[0]}
                          </span>
                        )}
                        {task.deadline && (
                          <span className={`deadline ${new Date(task.deadline) < new Date() && task.status !== 'done' ? 'overdue' : ''}`}>
                            📅 {formatDate(task.deadline)}
                          </span>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            );
          })}
        </div>
      )}

      {tab === 'list' && (
        <div className="table-wrap">
          <table>
            <thead>
              <tr><th>Task</th><th>Status</th><th>Priority</th><th>Assignee</th><th>Deadline</th></tr>
            </thead>
            <tbody>
              {tasks.length === 0 ? (
                <tr><td colSpan={5} style={{ textAlign: 'center', color: 'var(--text-3)', padding: 48 }}>No tasks yet — create one!</td></tr>
              ) : tasks.map(task => (
                <tr key={task.id} style={{ cursor: 'pointer' }} onClick={() => setSelectedTask(task)}>
                  <td>
                    <div style={{ fontWeight: 600, letterSpacing: '-0.01em' }}>{task.title}</div>
                    {task.description && <div style={{ fontSize: 12, color: 'var(--text-3)', marginTop: 2 }}>{task.description.slice(0,60)}</div>}
                  </td>
                  <td><span className={`status-badge status-${task.status}`}>{task.status.replace('_',' ')}</span></td>
                  <td><span className={`priority priority-${task.priority}`}>{task.priority}</span></td>
                  <td>
                    {task.assignee_name ? (
                      <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                        <Avatar avatarData={task.assignee_avatar} name={task.assignee_name} />
                        <span style={{ fontSize: 13 }}>{task.assignee_name}</span>
                      </div>
                    ) : <span style={{ color: 'var(--text-4)' }}>—</span>}
                  </td>
                  <td>
                    {task.deadline ? (
                      <span className={`deadline ${new Date(task.deadline)<new Date() && task.status!=='done' ? 'overdue':''}`}>
                        {formatDate(task.deadline)}
                      </span>
                    ) : <span style={{ color: 'var(--text-4)' }}>—</span>}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {tab === 'members' && (
        <div className="card">
          <div className="section-title">
            Team Members
            {isAdmin && <button className="btn btn-secondary btn-sm" onClick={() => setShowAddMember(true)}><UserPlus size={13}/> Add</button>}
          </div>
          {members.map(m => (
            <div key={m.id} className="member-row">
              <Avatar avatarData={m.avatar} name={m.name} size="avatar-lg" />
              <div style={{ flex: 1 }}>
                <div style={{ fontWeight: 600, letterSpacing: '-0.01em' }}>{m.name}{m.id===user.id ? <span style={{ color:'var(--blue-bright)', fontSize:11, marginLeft:6 }}>you</span>:''}</div>
                <div style={{ fontSize: 12, color: 'var(--text-3)' }}>{m.email}</div>
              </div>
              <span className={`role-badge ${m.role}`}>{m.role}</span>
              {isAdmin && m.id !== user.id && (
                <button className="btn btn-danger btn-xs" onClick={async () => {
                  await api.delete(`/projects/${id}/members/${m.id}`);
                  setMembers(members.filter(x => x.id !== m.id));
                }}>Remove</button>
              )}
            </div>
          ))}
        </div>
      )}

      {selectedTask && (
        <TaskModal task={selectedTask} projectId={id} members={members}
          onClose={() => setSelectedTask(null)}
          onUpdated={handleTaskUpdated} onDeleted={handleTaskDeleted}
          canManage={isAdmin || selectedTask.creator_id === user.id || selectedTask.assignee_id === user.id} />
      )}

      {showNewTask && (
        <NewTaskModal projectId={id} members={members} defaultStatus={newTaskStatus}
          onClose={() => setShowNewTask(false)}
          onCreated={task => { setTasks([...tasks, task]); setShowNewTask(false); }} />
      )}

      {showAddMember && (
        <AddMemberModal projectId={id}
          onClose={() => setShowAddMember(false)}
          onAdded={m => { setMembers([...members, m]); setShowAddMember(false); }} />
      )}
    </div>
  );
}

function NewTaskModal({ projectId, members, defaultStatus, onClose, onCreated }) {
  const [form, setForm] = useState({ title:'', description:'', priority:'medium', status:defaultStatus, assignee_id:'', deadline:'' });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault(); setLoading(true); setError('');
    try {
      const payload = { ...form, assignee_id: form.assignee_id || undefined, deadline: form.deadline || undefined };
      const res = await api.post(`/projects/${projectId}/tasks`, payload);
      onCreated(res.data.task);
    } catch (err) { setError(err.response?.data?.error || 'Failed'); }
    finally { setLoading(false); }
  };

  return (
    <div className="modal-overlay" onClick={e => e.target === e.currentTarget && onClose()}>
      <div className="modal">
        <div className="modal-header">
          <div className="modal-title">New Task</div>
          <button className="btn btn-ghost btn-icon" onClick={onClose}><X size={16}/></button>
        </div>
        <form onSubmit={handleSubmit}>
          <div className="modal-body">
            {error && <div className="alert alert-error">{error}</div>}
            <div className="form-group">
              <label className="form-label">Title *</label>
              <input className="form-input" placeholder="What needs to be done?" value={form.title}
                onChange={e => setForm({...form,title:e.target.value})} required autoFocus />
            </div>
            <div className="form-group">
              <label className="form-label">Description</label>
              <textarea className="form-textarea" placeholder="Add details, context, or acceptance criteria…" value={form.description}
                onChange={e => setForm({...form,description:e.target.value})} />
            </div>
            <div className="form-row">
              <div className="form-group">
                <label className="form-label">Priority</label>
                <select className="form-select" value={form.priority} onChange={e => setForm({...form,priority:e.target.value})}>
                  <option value="low">Low</option><option value="medium">Medium</option>
                  <option value="high">High</option><option value="critical">Critical</option>
                </select>
              </div>
              <div className="form-group">
                <label className="form-label">Status</label>
                <select className="form-select" value={form.status} onChange={e => setForm({...form,status:e.target.value})}>
                  <option value="todo">To Do</option><option value="in_progress">In Progress</option>
                  <option value="review">Review</option><option value="done">Done</option>
                </select>
              </div>
            </div>
            <div className="form-row">
              <div className="form-group">
                <label className="form-label">Assignee</label>
                <select className="form-select" value={form.assignee_id} onChange={e => setForm({...form,assignee_id:e.target.value})}>
                  <option value="">Unassigned</option>
                  {members.map(m => <option key={m.id} value={m.id}>{m.name}</option>)}
                </select>
              </div>
              <div className="form-group">
                <label className="form-label">Deadline</label>
                <input className="form-input" type="date" value={form.deadline} onChange={e => setForm({...form,deadline:e.target.value})} />
              </div>
            </div>
          </div>
          <div className="modal-footer">
            <button type="button" className="btn btn-ghost" onClick={onClose}>Cancel</button>
            <button type="submit" className="btn btn-primary" disabled={loading}>
              {loading ? <span className="spinner"/> : 'Create Task'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

function AddMemberModal({ projectId, onClose, onAdded }) {
  const [email, setEmail] = useState('');
  const [role, setRole] = useState('member');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault(); setLoading(true); setError('');
    try {
      const res = await api.post(`/projects/${projectId}/members`, { email, role });
      onAdded({ ...res.data.user, role });
    } catch (err) { setError(err.response?.data?.error || 'Failed'); }
    finally { setLoading(false); }
  };

  return (
    <div className="modal-overlay" onClick={e => e.target === e.currentTarget && onClose()}>
      <div className="modal">
        <div className="modal-header">
          <div className="modal-title">Add Team Member</div>
          <button className="btn btn-ghost btn-icon" onClick={onClose}><X size={16}/></button>
        </div>
        <form onSubmit={handleSubmit}>
          <div className="modal-body">
            {error && <div className="alert alert-error">{error}</div>}
            <div className="form-group">
              <label className="form-label">Email Address</label>
              <input className="form-input" type="email" placeholder="teammate@company.com"
                value={email} onChange={e => setEmail(e.target.value)} required autoFocus />
              <div className="form-hint">They must already have a TaskFlow account</div>
            </div>
            <div className="form-group">
              <label className="form-label">Project Role</label>
              <select className="form-select" value={role} onChange={e => setRole(e.target.value)}>
                <option value="member">Member — Can create and manage their tasks</option>
                <option value="admin">Admin — Full project control</option>
              </select>
            </div>
          </div>
          <div className="modal-footer">
            <button type="button" className="btn btn-ghost" onClick={onClose}>Cancel</button>
            <button type="submit" className="btn btn-primary" disabled={loading}>
              {loading ? <span className="spinner"/> : 'Add Member'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
