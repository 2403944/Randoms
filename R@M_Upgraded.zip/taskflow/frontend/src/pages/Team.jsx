import { useState, useEffect } from 'react';
import { Users, Shield, UserCheck, Copy, Check } from 'lucide-react';
import api from '../utils/api';
import { useAuth } from '../context/AuthContext';
import { Avatar } from '../components/Avatar';

export default function Team() {
  const { user } = useAuth();
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    api.get('/auth/users').then(res => setUsers(res.data.users)).finally(() => setLoading(false));
  }, []);

  const copyLink = () => {
    navigator.clipboard.writeText(`${window.location.origin}/signup`);
    setCopied(true); setTimeout(() => setCopied(false), 2000);
  };

  if (loading) return <div className="loading-page"><div className="spinner" /></div>;
  const admins = users.filter(u => u.role === 'admin');
  const members = users.filter(u => u.role === 'member');

  return (
    <div>
      <div className="page-header">
        <div>
          <div className="page-eyebrow">Admin</div>
          <div className="page-title">Team Management</div>
          <div className="page-subtitle">{users.length} members in your workspace</div>
        </div>
      </div>

      {/* Stats row */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 14, marginBottom: 28 }}>
        {[
          { label: 'Total Members', value: users.length, color: 'var(--blue)', icon: <Users size={18}/> },
          { label: 'Admins', value: admins.length, color: 'var(--violet)', icon: <Shield size={18}/> },
          { label: 'Members', value: members.length, color: 'var(--emerald)', icon: <UserCheck size={18}/> },
        ].map((s, i) => (
          <div key={i} className="card" style={{ display: 'flex', alignItems: 'center', gap: 16, padding: 20 }}>
            <div style={{ width: 42, height: 42, borderRadius: 'var(--r-md)', background: `${s.color}15`, border: `1px solid ${s.color}25`, display: 'flex', alignItems: 'center', justifyContent: 'center', color: s.color }}>{s.icon}</div>
            <div>
              <div style={{ fontFamily: 'var(--font-display)', fontSize: 28, fontWeight: 800, letterSpacing: '-0.04em', lineHeight: 1 }}>{s.value}</div>
              <div style={{ fontSize: 12, color: 'var(--text-3)', marginTop: 2 }}>{s.label}</div>
            </div>
          </div>
        ))}
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 20 }}>
        <div className="card">
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 20 }}>
            <div style={{ width: 28, height: 28, borderRadius: 8, background: 'var(--blue-dim)', display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'var(--blue)' }}><Shield size={14}/></div>
            <div style={{ fontFamily: 'var(--font-display)', fontSize: 15, fontWeight: 700, letterSpacing: '-0.02em' }}>Administrators</div>
            <span style={{ marginLeft: 'auto', background: 'var(--blue-dim)', color: 'var(--blue-bright)', fontSize: 11, fontWeight: 700, padding: '2px 8px', borderRadius: 99, border: '1px solid rgba(64,112,255,0.2)' }}>{admins.length}</span>
          </div>
          {admins.map(u => (
            <div key={u.id} className="member-row">
              <Avatar avatarData={u.avatar} name={u.name} size="avatar-lg" />
              <div style={{ flex: 1 }}>
                <div style={{ fontWeight: 600, fontSize: 14, letterSpacing: '-0.01em' }}>{u.name}{u.id === user.id ? <span style={{ color: 'var(--blue-bright)', fontSize: 11, marginLeft: 6 }}>you</span> : ''}</div>
                <div style={{ fontSize: 12, color: 'var(--text-3)' }}>{u.email}</div>
              </div>
              <span className="role-badge admin">Admin</span>
            </div>
          ))}
        </div>

        <div className="card">
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 20 }}>
            <div style={{ width: 28, height: 28, borderRadius: 8, background: 'var(--emerald-dim)', display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'var(--emerald)' }}><UserCheck size={14}/></div>
            <div style={{ fontFamily: 'var(--font-display)', fontSize: 15, fontWeight: 700, letterSpacing: '-0.02em' }}>Members</div>
            <span style={{ marginLeft: 'auto', background: 'var(--emerald-dim)', color: 'var(--emerald)', fontSize: 11, fontWeight: 700, padding: '2px 8px', borderRadius: 99, border: '1px solid rgba(0,229,170,0.2)' }}>{members.length}</span>
          </div>
          {members.length === 0 ? (
            <div style={{ textAlign: 'center', padding: '32px 0', color: 'var(--text-3)', fontSize: 13 }}>
              No members yet — share the invite link below
            </div>
          ) : members.map(u => (
            <div key={u.id} className="member-row">
              <Avatar avatarData={u.avatar} name={u.name} size="avatar-lg" />
              <div style={{ flex: 1 }}>
                <div style={{ fontWeight: 600, fontSize: 14, letterSpacing: '-0.01em' }}>{u.name}{u.id === user.id ? <span style={{ color: 'var(--emerald)', fontSize: 11, marginLeft: 6 }}>you</span> : ''}</div>
                <div style={{ fontSize: 12, color: 'var(--text-3)' }}>{u.email}</div>
              </div>
              <span className="role-badge member">Member</span>
            </div>
          ))}
        </div>
      </div>

      {/* Invite link */}
      <div className="card" style={{ marginTop: 20 }}>
        <div style={{ fontFamily: 'var(--font-display)', fontSize: 15, fontWeight: 700, letterSpacing: '-0.02em', marginBottom: 6 }}>Invite Team Members</div>
        <div style={{ fontSize: 13, color: 'var(--text-2)', marginBottom: 16, lineHeight: 1.6 }}>
          Share this link with teammates. They create an account and you can add them to projects by their email.
        </div>
        <div style={{ display: 'flex', gap: 10, alignItems: 'center' }}>
          <div style={{ flex: 1, background: 'var(--bg-3)', border: '1px solid var(--border-2)', borderRadius: 'var(--r-md)', padding: '10px 14px', fontFamily: 'var(--font-mono)', fontSize: 13, color: 'var(--blue-bright)', letterSpacing: '-0.01em' }}>
            {window.location.origin}/signup
          </div>
          <button className="btn btn-secondary" onClick={copyLink}>
            {copied ? <><Check size={14} style={{ color: 'var(--emerald)' }} /> Copied!</> : <><Copy size={14} /> Copy Link</>}
          </button>
        </div>
      </div>
    </div>
  );
}
