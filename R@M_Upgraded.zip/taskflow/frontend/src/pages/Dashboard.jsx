import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { FolderKanban, CheckCircle2, Clock, AlertTriangle, Users, ArrowRight, Calendar, TrendingUp, Zap } from 'lucide-react';
import api from '../utils/api';
import { useAuth } from '../context/AuthContext';
import { Avatar, formatDate, isOverdue } from '../components/Avatar';

const priorityColor = { low: 'priority-low', medium: 'priority-medium', high: 'priority-high', critical: 'priority-critical' };
const statusColor = { todo: 'status-todo', in_progress: 'status-in_progress', review: 'status-review', done: 'status-done' };

export default function Dashboard() {
  const { user } = useAuth();
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api.get('/dashboard').then(res => setData(res.data)).finally(() => setLoading(false));
  }, []);

  if (loading) return <div className="loading-page"><div className="spinner" /><span>Loading dashboard…</span></div>;
  if (!data) return null;

  const { stats, recentTasks, myTasks } = data;
  const completionRate = stats.total_tasks > 0 ? Math.round((stats.completed_tasks / stats.total_tasks) * 100) : 0;
  const hour = new Date().getHours();
  const greeting = hour < 12 ? 'Good morning' : hour < 18 ? 'Good afternoon' : 'Good evening';

  return (
    <div>
      <div className="page-header">
        <div>
          <div className="page-eyebrow">Dashboard</div>
          <div className="page-title">{greeting}, {user.name.split(' ')[0]} ✦</div>
          <div className="page-subtitle">Here's your workspace overview for today</div>
        </div>
        <Link to="/projects" className="btn btn-primary" style={{ alignSelf: 'flex-start' }}>
          <FolderKanban size={14} /> View Projects
        </Link>
      </div>

      <div className="stats-grid">
        {[
          { label: 'Total Projects', value: stats.total_projects || 0, icon: <FolderKanban size={18}/>, color: 'blue' },
          { label: 'Completed Tasks', value: stats.completed_tasks || 0, icon: <CheckCircle2 size={18}/>, color: 'emerald' },
          { label: 'In Progress', value: stats.in_progress_tasks || 0, icon: <Clock size={18}/>, color: 'amber' },
          { label: 'Overdue', value: stats.overdue_tasks || 0, icon: <AlertTriangle size={18}/>, color: 'red' },
          ...(user.role === 'admin' ? [{ label: 'Team Members', value: stats.total_users || 0, icon: <Users size={18}/>, color: 'violet' }] : []),
        ].map((s, i) => (
          <div key={i} className={`stat-card ${s.color}`} style={{ animationDelay: `${i * 0.05}s` }}>
            <div className="stat-icon-wrap">{s.icon}</div>
            <div className="stat-value">{s.value}</div>
            <div className="stat-label">{s.label}</div>
          </div>
        ))}
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 20, marginBottom: 20 }}>
        {/* My Tasks */}
        <div className="card animate-in" style={{ animationDelay: '0.2s' }}>
          <div className="section-title">
            <span style={{ display: 'flex', alignItems: 'center', gap: 8 }}><Zap size={15} style={{ color: 'var(--amber)' }} /> My Pending Tasks</span>
            <Link to="/my-tasks" className="btn btn-ghost btn-sm" style={{ gap: 4, fontSize: 12 }}>All <ArrowRight size={12} /></Link>
          </div>
          {myTasks.length === 0 ? (
            <div style={{ textAlign: 'center', padding: '32px 0', color: 'var(--text-3)', fontSize: 13 }}>
              <CheckCircle2 size={28} style={{ margin: '0 auto 10px', display: 'block', opacity: 0.4 }} />
              All caught up! 🎉
            </div>
          ) : myTasks.map((task, i) => (
            <div key={task.id} style={{ display: 'flex', alignItems: 'flex-start', gap: 12, padding: '11px 0', borderBottom: i < myTasks.length-1 ? '1px solid var(--border-1)' : 'none' }}>
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: 13, fontWeight: 600, color: 'var(--text-1)', marginBottom: 4, letterSpacing: '-0.01em' }}>{task.title}</div>
                <div style={{ fontSize: 11, color: 'var(--text-3)', fontWeight: 500 }}>{task.project_name}</div>
              </div>
              <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'flex-end', gap: 4 }}>
                <span className={`priority ${priorityColor[task.priority]}`}>{task.priority}</span>
                {task.deadline && (
                  <span className={`deadline ${isOverdue(task.deadline) && task.status !== 'done' ? 'overdue' : ''}`}>
                    <Calendar size={10} /> {formatDate(task.deadline)}
                  </span>
                )}
              </div>
            </div>
          ))}
        </div>

        {/* Recent Activity */}
        <div className="card animate-in" style={{ animationDelay: '0.25s' }}>
          <div className="section-title">
            <span style={{ display: 'flex', alignItems: 'center', gap: 8 }}><TrendingUp size={15} style={{ color: 'var(--blue)' }} /> Recent Activity</span>
          </div>
          {recentTasks.length === 0 ? (
            <div style={{ textAlign: 'center', padding: '32px 0', color: 'var(--text-3)', fontSize: 13 }}>No activity yet</div>
          ) : recentTasks.slice(0, 7).map((task, i) => (
            <div key={task.id} style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '10px 0', borderBottom: i < 6 ? '1px solid var(--border-1)' : 'none' }}>
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: 13, fontWeight: 600, color: 'var(--text-1)', letterSpacing: '-0.01em' }}>{task.title}</div>
                <div style={{ fontSize: 11, color: 'var(--text-3)', marginTop: 2 }}>{task.project_name}</div>
              </div>
              <span className={`status-badge ${statusColor[task.status]}`}>{task.status.replace('_', ' ')}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Progress Bar */}
      <div className="card animate-in" style={{ animationDelay: '0.3s' }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 16 }}>
          <div>
            <div className="section-title" style={{ marginBottom: 2 }}>
              <span>Overall Completion Rate</span>
            </div>
            <div style={{ fontSize: 12, color: 'var(--text-3)' }}>{stats.completed_tasks || 0} of {stats.total_tasks || 0} tasks completed across all projects</div>
          </div>
          <div style={{ fontFamily: 'var(--font-display)', fontSize: 40, fontWeight: 800, letterSpacing: '-0.05em', color: completionRate > 60 ? 'var(--emerald)' : completionRate > 30 ? 'var(--amber)' : 'var(--blue)' }}>
            {completionRate}<span style={{ fontSize: 20, fontWeight: 600 }}>%</span>
          </div>
        </div>
        <div className="progress-bar" style={{ height: 6, marginBottom: 14 }}>
          <div className="progress-fill" style={{ width: `${completionRate}%` }} />
        </div>
        <div style={{ display: 'flex', gap: 24, fontSize: 12, color: 'var(--text-3)' }}>
          <span style={{ display: 'flex', alignItems: 'center', gap: 6 }}><span style={{ width: 8, height: 8, borderRadius: 2, background: 'var(--text-4)', display: 'inline-block' }} />{stats.todo_tasks || 0} Todo</span>
          <span style={{ display: 'flex', alignItems: 'center', gap: 6 }}><span style={{ width: 8, height: 8, borderRadius: 2, background: 'var(--blue)', display: 'inline-block' }} />{stats.in_progress_tasks || 0} In Progress</span>
          <span style={{ display: 'flex', alignItems: 'center', gap: 6 }}><span style={{ width: 8, height: 8, borderRadius: 2, background: 'var(--emerald)', display: 'inline-block' }} />{stats.completed_tasks || 0} Done</span>
          {stats.overdue_tasks > 0 && <span style={{ display: 'flex', alignItems: 'center', gap: 6, color: 'var(--red)' }}><span style={{ width: 8, height: 8, borderRadius: 2, background: 'var(--red)', display: 'inline-block' }} />{stats.overdue_tasks} Overdue</span>}
        </div>
      </div>
    </div>
  );
}
