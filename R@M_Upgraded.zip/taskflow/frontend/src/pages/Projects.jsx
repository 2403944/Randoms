import { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Plus, FolderKanban, Calendar, Users, CheckCircle2, Search, Layers } from 'lucide-react';
import api from '../utils/api';
import { formatDate } from '../components/Avatar';

const EMOJIS = ['🚀','⚡','🎯','💡','🔥','🌊','🎨','🛠️','📊','🎪'];

export default function Projects() {
  const [projects, setProjects] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [showModal, setShowModal] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    api.get('/projects').then(res => setProjects(res.data.projects)).finally(() => setLoading(false));
  }, []);

  const filtered = projects.filter(p => p.name.toLowerCase().includes(search.toLowerCase()));

  if (loading) return <div className="loading-page"><div className="spinner" /></div>;

  return (
    <div>
      <div className="page-header">
        <div>
          <div className="page-eyebrow">Projects</div>
          <div className="page-title">Your Workspace</div>
          <div className="page-subtitle">{projects.length} project{projects.length !== 1 ? 's' : ''} total</div>
        </div>
        <div style={{ display: 'flex', gap: 10, alignItems: 'center' }}>
          <div className="search-wrap">
            <Search size={14} />
            <input placeholder="Search projects…" value={search} onChange={e => setSearch(e.target.value)} />
          </div>
          <button className="btn btn-primary" onClick={() => setShowModal(true)}>
            <Plus size={14} /> New Project
          </button>
        </div>
      </div>

      {filtered.length === 0 ? (
        <div className="empty-state">
          <div className="empty-icon-wrap"><Layers size={28} /></div>
          <div className="empty-title">{search ? 'No projects found' : 'No projects yet'}</div>
          <div className="empty-text">{search ? 'Try a different search term' : 'Create your first project to get started'}</div>
          {!search && (
            <button className="btn btn-primary" style={{ margin: '0 auto', display: 'inline-flex' }} onClick={() => setShowModal(true)}>
              <Plus size={14} /> Create Project
            </button>
          )}
        </div>
      ) : (
        <div className="projects-grid">
          {filtered.map((p, i) => {
            const progress = p.task_count > 0 ? Math.round((p.done_count / p.task_count) * 100) : 0;
            const emoji = EMOJIS[p.id % EMOJIS.length];
            return (
              <Link key={p.id} to={`/projects/${p.id}`} className="project-card"
                style={{ animationDelay: `${i * 0.04}s`, animation: 'fadeUp 0.35s ease both' }}>
                <div className="project-card-header">
                  <div style={{ flex: 1 }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 6 }}>
                      <div className="project-icon">{emoji}</div>
                      <div>
                        <div className="project-name">{p.name}</div>
                        <span className={`project-status-badge status-${p.status}`}>{p.status}</span>
                      </div>
                    </div>
                    {p.description && <div className="project-desc">{p.description}</div>}
                  </div>
                </div>

                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', fontSize: 11, color: 'var(--text-3)', marginBottom: 6 }}>
                  <span>{p.done_count}/{p.task_count} tasks</span>
                  <span style={{ fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: 14,
                    color: progress === 100 ? 'var(--emerald)' : progress > 50 ? 'var(--blue-bright)' : 'var(--text-2)' }}>
                    {progress}%
                  </span>
                </div>
                <div className="progress-bar">
                  <div className="progress-fill" style={{ width: `${progress}%` }} />
                </div>

                <div className="project-meta">
                  <span className="project-meta-item"><Users size={11} /> {p.member_count} members</span>
                  <span className="project-meta-item"><CheckCircle2 size={11} /> {p.done_count} done</span>
                  {p.deadline && <span className="project-meta-item"><Calendar size={11} /> {formatDate(p.deadline)}</span>}
                  <span style={{ marginLeft: 'auto' }}>{p.owner_name}</span>
                </div>
              </Link>
            );
          })}
        </div>
      )}

      {showModal && (
        <NewProjectModal
          onClose={() => setShowModal(false)}
          onCreated={(p) => { setProjects([p, ...projects]); setShowModal(false); navigate(`/projects/${p.id}`); }}
        />
      )}
    </div>
  );
}

function NewProjectModal({ onClose, onCreated }) {
  const [form, setForm] = useState({ name: '', description: '', deadline: '' });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault(); setLoading(true); setError('');
    try {
      const res = await api.post('/projects', form);
      onCreated(res.data.project);
    } catch (err) { setError(err.response?.data?.error || 'Failed'); }
    finally { setLoading(false); }
  };

  return (
    <div className="modal-overlay" onClick={e => e.target === e.currentTarget && onClose()}>
      <div className="modal">
        <div className="modal-header">
          <div className="modal-title">New Project</div>
          <button className="btn btn-ghost btn-icon" onClick={onClose} style={{ fontSize: 18, color: 'var(--text-3)' }}>✕</button>
        </div>
        <form onSubmit={handleSubmit}>
          <div className="modal-body">
            {error && <div className="alert alert-error">{error}</div>}
            <div className="form-group">
              <label className="form-label">Project Name *</label>
              <input className="form-input" placeholder="e.g. Website Redesign 2025" value={form.name}
                onChange={e => setForm({ ...form, name: e.target.value })} required autoFocus />
            </div>
            <div className="form-group">
              <label className="form-label">Description</label>
              <textarea className="form-textarea" placeholder="What's this project about?" value={form.description}
                onChange={e => setForm({ ...form, description: e.target.value })} />
            </div>
            <div className="form-group">
              <label className="form-label">Deadline</label>
              <input className="form-input" type="date" value={form.deadline}
                onChange={e => setForm({ ...form, deadline: e.target.value })} />
            </div>
          </div>
          <div className="modal-footer">
            <button type="button" className="btn btn-ghost" onClick={onClose}>Cancel</button>
            <button type="submit" className="btn btn-primary" disabled={loading}>
              {loading ? <span className="spinner" /> : 'Create Project'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
