import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { ArrowRight, ShieldCheck, User } from 'lucide-react';

export default function Signup() {
  const [form, setForm] = useState({ name: '', email: '', password: '', role: 'member' });
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const { signup } = useAuth();
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError(''); setLoading(true);
    try {
      await signup(form.name, form.email, form.password, form.role);
      navigate('/dashboard');
    } catch (err) {
      setError(err.response?.data?.errors?.[0]?.msg || err.response?.data?.error || 'Signup failed');
    } finally { setLoading(false); }
  };

  return (
    <div className="auth-page">
      <div className="auth-bg-grid" />
      <div className="auth-glow" />
      <div className="auth-card">
        <div className="auth-logo">
          <div className="logo-mark" style={{ width: 38, height: 38, fontSize: 15 }}>TF</div>
          <span style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 20, letterSpacing: '-0.03em', color: 'var(--text-1)' }}>TaskFlow</span>
        </div>

        <div className="auth-title">Create account</div>
        <div className="auth-subtitle">Start collaborating with your team today</div>

        {error && <div className="alert alert-error">⚠️ {error}</div>}

        <form onSubmit={handleSubmit}>
          <div className="form-group">
            <label className="form-label">Full Name</label>
            <input className="form-input" type="text" placeholder="Jane Smith"
              value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} required />
          </div>
          <div className="form-group">
            <label className="form-label">Email address</label>
            <input className="form-input" type="email" placeholder="you@company.com"
              value={form.email} onChange={e => setForm({ ...form, email: e.target.value })} required />
          </div>
          <div className="form-group">
            <label className="form-label">Password</label>
            <input className="form-input" type="password" placeholder="Min. 6 characters"
              value={form.password} onChange={e => setForm({ ...form, password: e.target.value })} required minLength={6} />
          </div>

          <div className="form-group">
            <label className="form-label">Account Role</label>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
              {[
                { value: 'member', icon: <User size={16} />, label: 'Member', desc: 'Work on tasks' },
                { value: 'admin', icon: <ShieldCheck size={16} />, label: 'Admin', desc: 'Manage everything' },
              ].map(r => (
                <div key={r.value}
                  onClick={() => setForm({ ...form, role: r.value })}
                  style={{
                    padding: '12px 14px', borderRadius: 'var(--r-md)', cursor: 'pointer',
                    border: `1px solid ${form.role === r.value ? 'rgba(64,112,255,0.4)' : 'var(--border-2)'}`,
                    background: form.role === r.value ? 'var(--blue-dim)' : 'var(--bg-3)',
                    transition: 'all 0.15s',
                  }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 7, color: form.role === r.value ? 'var(--blue-bright)' : 'var(--text-2)', marginBottom: 3, fontWeight: 600 }}>
                    {r.icon} {r.label}
                  </div>
                  <div style={{ fontSize: 11, color: 'var(--text-3)' }}>{r.desc}</div>
                </div>
              ))}
            </div>
          </div>

          <button className="btn btn-primary w-full" type="submit" disabled={loading}
            style={{ justifyContent: 'center', height: 44, fontSize: 14, marginTop: 4 }}>
            {loading ? <span className="spinner" /> : <><span>Create Account</span><ArrowRight size={15} /></>}
          </button>
        </form>

        <div className="auth-switch">Already have an account? <Link to="/login">Sign in</Link></div>
      </div>
    </div>
  );
}
