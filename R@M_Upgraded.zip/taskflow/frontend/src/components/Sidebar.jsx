import { NavLink, useNavigate } from 'react-router-dom';
import { LayoutDashboard, FolderKanban, CheckSquare, Users, LogOut, Zap } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { Avatar } from './Avatar';

export default function Sidebar() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const handleLogout = () => { logout(); navigate('/login'); };

  return (
    <aside className="sidebar">
      <a href="/" className="logo">
        <div className="logo-mark">TF</div>
        <span className="logo-text">TaskFlow</span>
        <span className="logo-tag">Beta</span>
      </a>

      <nav className="nav-section" style={{ flex: 1 }}>
        <div className="nav-label">Workspace</div>
        <NavLink to="/dashboard" className={({ isActive }) => `nav-item ${isActive ? 'active' : ''}`}>
          <LayoutDashboard size={15} /> Dashboard
        </NavLink>
        <NavLink to="/projects" className={({ isActive }) => `nav-item ${isActive ? 'active' : ''}`}>
          <FolderKanban size={15} /> Projects
        </NavLink>
        <NavLink to="/my-tasks" className={({ isActive }) => `nav-item ${isActive ? 'active' : ''}`}>
          <CheckSquare size={15} /> My Tasks
        </NavLink>

        {user?.role === 'admin' && (
          <>
            <div className="nav-label" style={{ marginTop: 16 }}>Admin</div>
            <NavLink to="/team" className={({ isActive }) => `nav-item ${isActive ? 'active' : ''}`}>
              <Users size={15} /> Team
            </NavLink>
          </>
        )}
      </nav>

      <div className="sidebar-footer">
        <div className="user-card" style={{ marginBottom: 8 }}>
          <Avatar avatarData={user?.avatar} name={user?.name} />
          <div style={{ flex: 1, minWidth: 0 }}>
            <div className="user-name-text">{user?.name}</div>
            <div className="user-role-text">{user?.role}</div>
          </div>
          <span className={`role-badge ${user?.role}`}>{user?.role}</span>
        </div>
        <button className="nav-item" onClick={handleLogout} style={{ color: 'var(--red)' }}>
          <LogOut size={14} /> Sign out
        </button>
      </div>
    </aside>
  );
}
