import { useState, useEffect } from 'react';
import { Calendar, MessageSquare, Send, Trash2, X } from 'lucide-react';
import api from '../utils/api';
import { useAuth } from '../context/AuthContext';
import { Avatar, formatDate, relativeTime } from './Avatar';

const statusOptions = ['todo', 'in_progress', 'review', 'done'];
const priorityOptions = ['low', 'medium', 'high', 'critical'];

export default function TaskModal({ task, projectId, members, onClose, onUpdated, onDeleted, canManage }) {
  const { user } = useAuth();
  const [editing, setEditing] = useState(false);
  const [form, setForm] = useState({ ...task });
  const [comments, setComments] = useState([]);
  const [comment, setComment] = useState('');
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    api.get(`/projects/${projectId}/tasks/${task.id}/comments`)
      .then(res => setComments(res.data.comments));
  }, [task.id]);

  const handleStatusChange = async (status) => {
    try {
      const res = await api.put(`/projects/${projectId}/tasks/${task.id}`, { status });
      onUpdated(res.data.task);
      setForm({ ...form, status });
    } catch {}
  };

  const handleSave = async () => {
    setSaving(true);
    try {
      const res = await api.put(`/projects/${projectId}/tasks/${task.id}`, form);
      onUpdated(res.data.task);
      setEditing(false);
    } catch (err) {
      alert(err.response?.data?.error || 'Failed to update');
    } finally { setSaving(false); }
  };

  const handleDelete = async () => {
    if (!confirm('Delete this task?')) return;
    try {
      await api.delete(`/projects/${projectId}/tasks/${task.id}`);
      onDeleted(task.id);
    } catch {}
  };

  const handleComment = async (e) => {
    e.preventDefault();
    if (!comment.trim()) return;
    setLoading(true);
    try {
      const res = await api.post(`/projects/${projectId}/tasks/${task.id}/comments`, { content: comment });
      setComments([...comments, res.data.comment]);
      setComment('');
    } finally { setLoading(false); }
  };

  const isOverdue = task.deadline && new Date(task.deadline) < new Date() && task.status !== 'done';

  return (
    <div className="modal-overlay" onClick={e => e.target === e.currentTarget && onClose()}>
      <div className="modal modal-lg">
        <div className="modal-header">
          <div style={{ flex: 1, paddingRight: 12 }}>
            {editing ? (
              <input className="form-input" value={form.title}
                onChange={e => setForm({ ...form, title: e.target.value })}
                style={{ fontSize: 16, fontWeight: 700 }} />
            ) : (
              <div className="modal-title">{task.title}</div>
            )}
          </div>
          <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
            {canManage && !editing && (
              <button className="btn btn-secondary btn-sm" onClick={() => setEditing(true)}>Edit</button>
            )}
            {canManage && (
              <button className="btn btn-danger btn-sm" onClick={handleDelete}><Trash2 size={13} /></button>
            )}
            <button className="btn btn-ghost btn-icon" onClick={onClose}><X size={16} /></button>
          </div>
        </div>

        <div className="modal-body" style={{ display: 'grid', gridTemplateColumns: '1fr 260px', gap: 24 }}>
          {/* Main */}
          <div>
            <div style={{ marginBottom: 16 }}>
              <div className="form-label">Description</div>
              {editing ? (
                <textarea className="form-textarea" value={form.description || ''}
                  onChange={e => setForm({ ...form, description: e.target.value })}
                  placeholder="Add a description…" />
              ) : (
                <div style={{ fontSize: 14, color: task.description ? 'var(--text)' : 'var(--text-muted)', lineHeight: 1.6 }}>
                  {task.description || 'No description.'}
                </div>
              )}
            </div>

            {/* Status quick-select */}
            {!editing && (
              <div style={{ marginBottom: 20 }}>
                <div className="form-label">Status</div>
                <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
                  {statusOptions.map(s => (
                    <button key={s}
                      className={`status-badge status-${s}`}
                      style={{ cursor: 'pointer', border: form.status === s ? '2px solid currentColor' : '2px solid transparent', padding: '4px 10px' }}
                      onClick={() => handleStatusChange(s)}>
                      {s.replace('_', ' ')}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Comments */}
            <div>
              <div className="form-label" style={{ marginBottom: 12 }}>
                <MessageSquare size={13} style={{ display: 'inline', marginRight: 6 }} />
                Comments ({comments.length})
              </div>

              <div style={{ maxHeight: 280, overflowY: 'auto', marginBottom: 12 }}>
                {comments.map(c => (
                  <div key={c.id} className="comment">
                    <Avatar avatarData={c.avatar} name={c.name} />
                    <div className="comment-body">
                      <div className="comment-meta">{c.name} · {relativeTime(c.created_at)}</div>
                      <div className="comment-content">{c.content}</div>
                    </div>
                  </div>
                ))}
                {comments.length === 0 && <div style={{ fontSize: 13, color: 'var(--text-muted)' }}>No comments yet.</div>}
              </div>

              <form onSubmit={handleComment} style={{ display: 'flex', gap: 8 }}>
                <input className="form-input" placeholder="Write a comment…" value={comment}
                  onChange={e => setComment(e.target.value)} />
                <button type="submit" className="btn btn-primary" disabled={loading || !comment.trim()}>
                  <Send size={14} />
                </button>
              </form>
            </div>
          </div>

          {/* Sidebar */}
          <div style={{ borderLeft: '1px solid var(--border)', paddingLeft: 24 }}>
            {editing ? (
              <>
                <div className="form-group">
                  <label className="form-label">Priority</label>
                  <select className="form-select" value={form.priority} onChange={e => setForm({ ...form, priority: e.target.value })}>
                    {priorityOptions.map(p => <option key={p} value={p}>{p}</option>)}
                  </select>
                </div>
                <div className="form-group">
                  <label className="form-label">Assignee</label>
                  <select className="form-select" value={form.assignee_id || ''} onChange={e => setForm({ ...form, assignee_id: e.target.value || null })}>
                    <option value="">Unassigned</option>
                    {members.map(m => <option key={m.id} value={m.id}>{m.name}</option>)}
                  </select>
                </div>
                <div className="form-group">
                  <label className="form-label">Deadline</label>
                  <input className="form-input" type="date" value={form.deadline || ''} onChange={e => setForm({ ...form, deadline: e.target.value })} />
                </div>
                <div style={{ display: 'flex', gap: 8 }}>
                  <button className="btn btn-primary btn-sm" onClick={handleSave} disabled={saving}>
                    {saving ? <span className="spinner" /> : 'Save'}
                  </button>
                  <button className="btn btn-ghost btn-sm" onClick={() => { setEditing(false); setForm({ ...task }); }}>Cancel</button>
                </div>
              </>
            ) : (
              <>
                <div style={{ marginBottom: 16 }}>
                  <div className="form-label">Priority</div>
                  <span className={`priority priority-${task.priority}`}>{task.priority}</span>
                </div>
                <div style={{ marginBottom: 16 }}>
                  <div className="form-label">Status</div>
                  <span className={`status-badge status-${task.status}`}>{task.status.replace('_', ' ')}</span>
                </div>
                <div style={{ marginBottom: 16 }}>
                  <div className="form-label">Assignee</div>
                  {task.assignee_name ? (
                    <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                      <Avatar avatarData={task.assignee_avatar} name={task.assignee_name} />
                      <span style={{ fontSize: 13 }}>{task.assignee_name}</span>
                    </div>
                  ) : <span style={{ fontSize: 13, color: 'var(--text-muted)' }}>Unassigned</span>}
                </div>
                {task.deadline && (
                  <div style={{ marginBottom: 16 }}>
                    <div className="form-label">Deadline</div>
                    <span className={`deadline ${isOverdue ? 'overdue' : ''}`} style={{ fontSize: 13 }}>
                      <Calendar size={13} /> {formatDate(task.deadline)}
                      {isOverdue && ' ⚠️ Overdue'}
                    </span>
                  </div>
                )}
                <div style={{ marginBottom: 16 }}>
                  <div className="form-label">Created by</div>
                  <span style={{ fontSize: 13, color: 'var(--text-muted)' }}>{task.creator_name}</span>
                </div>
              </>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
