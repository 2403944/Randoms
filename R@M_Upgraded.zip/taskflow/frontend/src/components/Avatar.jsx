export function Avatar({ avatarData, name, size = '' }) {
  let initials = '??';
  let color = '#6366f1';

  try {
    if (avatarData) {
      const data = typeof avatarData === 'string' ? JSON.parse(avatarData) : avatarData;
      initials = data.initials || initials;
      color = data.color || color;
    } else if (name) {
      initials = name.split(' ').map(n => n[0]).join('').toUpperCase().slice(0, 2);
    }
  } catch {}

  return (
    <div
      className={`avatar ${size}`}
      style={{ background: color }}
      title={name}
    >
      {initials}
    </div>
  );
}

export function formatDate(dateStr) {
  if (!dateStr) return null;
  const d = new Date(dateStr);
  return d.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
}

export function isOverdue(dateStr) {
  if (!dateStr) return false;
  return new Date(dateStr) < new Date();
}

export function relativeTime(dateStr) {
  const date = new Date(dateStr);
  const now = new Date();
  const diff = now - date;
  const mins = Math.floor(diff / 60000);
  if (mins < 1) return 'just now';
  if (mins < 60) return `${mins}m ago`;
  const hrs = Math.floor(mins / 60);
  if (hrs < 24) return `${hrs}h ago`;
  const days = Math.floor(hrs / 24);
  if (days < 7) return `${days}d ago`;
  return formatDate(dateStr);
}
