import { NavLink, useNavigate } from 'react-router-dom';
import { LayoutDashboard, FolderKanban, CheckSquare, Users, LogOut, Settings } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { Avatar } from './Avatar';

export default function Sidebar() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  const handleLogout = () => { logout(); navigate('/login'); };

  return (
    <aside className="sidebar">
      <a href="/" className="logo">
        <div className="logo-mark">TF</div>
        <span className="logo-text">TaskFlow</span>
      </a>

      <nav className="nav-section" style={{ flex: 1 }}>
        <div className="nav-label">Menu</div>

        <NavLink to="/dashboard" className={({ isActive }) => `nav-item ${isActive ? 'active' : ''}`}>
          <LayoutDashboard size={16} />
          Dashboard
        </NavLink>

        <NavLink to="/projects" className={({ isActive }) => `nav-item ${isActive ? 'active' : ''}`}>
          <FolderKanban size={16} />
          Projects
        </NavLink>

        <NavLink to="/my-tasks" className={({ isActive }) => `nav-item ${isActive ? 'active' : ''}`}>
          <CheckSquare size={16} />
          My Tasks
        </NavLink>

        {user?.role === 'admin' && (
          <>
            <div className="nav-label" style={{ marginTop: 12 }}>Admin</div>
            <NavLink to="/team" className={({ isActive }) => `nav-item ${isActive ? 'active' : ''}`}>
              <Users size={16} />
              Team
            </NavLink>
          </>
        )}
      </nav>

      <div className="sidebar-footer">
        <div className="user-card" style={{ marginBottom: 8 }}>
          <Avatar avatarData={user?.avatar} name={user?.name} />
          <div className="user-info">
            <div className="user-name">{user?.name}</div>
            <div className="user-role">{user?.role}</div>
          </div>
        </div>
        <button className="nav-item" onClick={handleLogout} style={{ color: 'var(--danger)', width: '100%' }}>
          <LogOut size={15} />
          Sign out
        </button>
      </div>
    </aside>
  );
}
