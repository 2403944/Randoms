import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { FolderKanban, CheckCircle2, Clock, AlertTriangle, Users, ArrowRight, Calendar } from 'lucide-react';
import api from '../utils/api';
import { useAuth } from '../context/AuthContext';
import { Avatar, formatDate, isOverdue } from '../components/Avatar';

const priorityColor = { low: 'priority-low', medium: 'priority-medium', high: 'priority-high', critical: 'priority-critical' };
const statusColor = { todo: 'status-todo', in_progress: 'status-in_progress', review: 'status-review', done: 'status-done' };

export default function Dashboard() {
  const { user } = useAuth();
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api.get('/dashboard').then(res => setData(res.data)).finally(() => setLoading(false));
  }, []);

  if (loading) return <div className="loading-page"><div className="spinner" /><span>Loading dashboard…</span></div>;
  if (!data) return null;

  const { stats, recentTasks, myTasks } = data;
  const completionRate = stats.total_tasks > 0 ? Math.round((stats.completed_tasks / stats.total_tasks) * 100) : 0;

  return (
    <div>
      <div className="page-header">
        <div>
          <div className="page-title">
            Good {new Date().getHours() < 12 ? 'morning' : new Date().getHours() < 18 ? 'afternoon' : 'evening'}, {user.name.split(' ')[0]} 👋
          </div>
          <div className="page-subtitle">Here's what's happening in your workspace</div>
        </div>
        <Link to="/projects/new" className="btn btn-primary">
          <FolderKanban size={15} /> New Project
        </Link>
      </div>

      <div className="stats-grid">
        <div className="stat-card accent">
          <div className="stat-value">{stats.total_projects || 0}</div>
          <div className="stat-label">Total Projects</div>
          <FolderKanban size={28} className="stat-icon" />
        </div>
        <div className="stat-card success">
          <div className="stat-value">{stats.completed_tasks || 0}</div>
          <div className="stat-label">Completed Tasks</div>
          <CheckCircle2 size={28} className="stat-icon" />
        </div>
        <div className="stat-card warning">
          <div className="stat-value">{stats.in_progress_tasks || 0}</div>
          <div className="stat-label">In Progress</div>
          <Clock size={28} className="stat-icon" />
        </div>
        <div className="stat-card danger">
          <div className="stat-value">{stats.overdue_tasks || 0}</div>
          <div className="stat-label">Overdue</div>
          <AlertTriangle size={28} className="stat-icon" />
        </div>
        {user.role === 'admin' && (
          <div className="stat-card" style={{ borderTop: '2px solid var(--info)' }}>
            <div className="stat-value">{stats.total_users || 0}</div>
            <div className="stat-label">Team Members</div>
            <Users size={28} className="stat-icon" />
          </div>
        )}
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 20 }}>
        {/* My Tasks */}
        <div className="card">
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 16 }}>
            <div style={{ fontFamily: 'var(--font-display)', fontSize: 16, fontWeight: 700 }}>My Tasks</div>
            <Link to="/my-tasks" className="btn btn-ghost btn-sm" style={{ gap: 4 }}>
              View all <ArrowRight size={13} />
            </Link>
          </div>

          {myTasks.length === 0 ? (
            <div style={{ textAlign: 'center', padding: '32px 0', color: 'var(--text-muted)', fontSize: 13 }}>
              🎉 No pending tasks
            </div>
          ) : myTasks.map(task => (
            <div key={task.id} style={{ display: 'flex', alignItems: 'flex-start', gap: 10, padding: '10px 0', borderBottom: '1px solid var(--border)' }}>
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: 13, fontWeight: 600, marginBottom: 4 }}>{task.title}</div>
                <div style={{ fontSize: 11, color: 'var(--text-muted)' }}>{task.project_name}</div>
              </div>
              <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'flex-end', gap: 4 }}>
                <span className={`priority ${priorityColor[task.priority]}`}>{task.priority}</span>
                {task.deadline && (
                  <span className={`deadline ${isOverdue(task.deadline) && task.status !== 'done' ? 'overdue' : ''}`}>
                    <Calendar size={10} /> {formatDate(task.deadline)}
                  </span>
                )}
              </div>
            </div>
          ))}
        </div>

        {/* Recent Activity */}
        <div className="card">
          <div style={{ fontFamily: 'var(--font-display)', fontSize: 16, fontWeight: 700, marginBottom: 16 }}>
            Recent Activity
          </div>

          {recentTasks.length === 0 ? (
            <div style={{ textAlign: 'center', padding: '32px 0', color: 'var(--text-muted)', fontSize: 13 }}>
              No activity yet
            </div>
          ) : recentTasks.slice(0, 8).map(task => (
            <div key={task.id} style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '8px 0', borderBottom: '1px solid var(--border)' }}>
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: 13, fontWeight: 600 }}>{task.title}</div>
                <div style={{ fontSize: 11, color: 'var(--text-muted)' }}>{task.project_name}</div>
              </div>
              <span className={`status-badge ${statusColor[task.status]}`}>{task.status.replace('_', ' ')}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Completion Rate */}
      <div className="card" style={{ marginTop: 20 }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 12 }}>
          <div style={{ fontFamily: 'var(--font-display)', fontSize: 16, fontWeight: 700 }}>Overall Completion</div>
          <div style={{ fontFamily: 'var(--font-display)', fontSize: 24, fontWeight: 800, color: 'var(--accent)' }}>{completionRate}%</div>
        </div>
        <div className="progress-bar" style={{ height: 8 }}>
          <div className="progress-fill" style={{ width: `${completionRate}%` }} />
        </div>
        <div style={{ display: 'flex', gap: 20, marginTop: 12, fontSize: 12, color: 'var(--text-muted)' }}>
          <span>📋 {stats.todo_tasks || 0} todo</span>
          <span>⚡ {stats.in_progress_tasks || 0} in progress</span>
          <span>✅ {stats.completed_tasks || 0} done</span>
        </div>
      </div>
    </div>
  );
}
