import { useState, useEffect } from 'react';
import { Users } from 'lucide-react';
import api from '../utils/api';
import { useAuth } from '../context/AuthContext';
import { Avatar } from '../components/Avatar';

export default function Team() {
  const { user } = useAuth();
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api.get('/auth/users').then(res => setUsers(res.data.users)).finally(() => setLoading(false));
  }, []);

  if (loading) return <div className="loading-page"><div className="spinner" /></div>;

  const admins = users.filter(u => u.role === 'admin');
  const members = users.filter(u => u.role === 'member');

  return (
    <div>
      <div className="page-header">
        <div>
          <div className="page-title">Team</div>
          <div className="page-subtitle">{users.length} members in your workspace</div>
        </div>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 24 }}>
        <div className="card">
          <div style={{ fontFamily: 'var(--font-display)', fontSize: 15, fontWeight: 700, marginBottom: 16, color: 'var(--accent)' }}>
            Admins ({admins.length})
          </div>
          {admins.map(u => (
            <div key={u.id} className="member-row">
              <Avatar avatarData={u.avatar} name={u.name} size="avatar-lg" />
              <div style={{ flex: 1 }}>
                <div style={{ fontWeight: 600 }}>{u.name}{u.id === user.id ? ' (you)' : ''}</div>
                <div style={{ fontSize: 12, color: 'var(--text-muted)' }}>{u.email}</div>
              </div>
              <span className="role-badge admin">Admin</span>
            </div>
          ))}
          {admins.length === 0 && <div style={{ color: 'var(--text-muted)', fontSize: 13 }}>No admins</div>}
        </div>

        <div className="card">
          <div style={{ fontFamily: 'var(--font-display)', fontSize: 15, fontWeight: 700, marginBottom: 16, color: 'var(--success)' }}>
            Members ({members.length})
          </div>
          {members.map(u => (
            <div key={u.id} className="member-row">
              <Avatar avatarData={u.avatar} name={u.name} size="avatar-lg" />
              <div style={{ flex: 1 }}>
                <div style={{ fontWeight: 600 }}>{u.name}{u.id === user.id ? ' (you)' : ''}</div>
                <div style={{ fontSize: 12, color: 'var(--text-muted)' }}>{u.email}</div>
              </div>
              <span className="role-badge member">Member</span>
            </div>
          ))}
          {members.length === 0 && <div style={{ color: 'var(--text-muted)', fontSize: 13 }}>No members yet. Share the signup link!</div>}
        </div>
      </div>

      <div className="card" style={{ marginTop: 24 }}>
        <div style={{ fontFamily: 'var(--font-display)', fontSize: 15, fontWeight: 700, marginBottom: 12 }}>Invite Members</div>
        <div style={{ fontSize: 14, color: 'var(--text-muted)', lineHeight: 1.6 }}>
          Share your TaskFlow signup URL with teammates. They can create an account with the <strong>Member</strong> role,
          and you can then add them to projects by their email address.
        </div>
        <div style={{ marginTop: 12, background: 'var(--bg-elevated)', border: '1px solid var(--border-bright)', borderRadius: 8, padding: '10px 14px', fontFamily: 'monospace', fontSize: 13, color: 'var(--accent)' }}>
          {window.location.origin}/signup
        </div>
      </div>
    </div>
  );
}
