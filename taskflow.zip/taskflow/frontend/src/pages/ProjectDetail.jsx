import { useState, useEffect } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { Plus, UserPlus, Settings, ArrowLeft, Trash2 } from 'lucide-react';
import api from '../utils/api';
import { useAuth } from '../context/AuthContext';
import { Avatar, formatDate } from '../components/Avatar';
import TaskModal from '../components/TaskModal';

const COLS = [
  { key: 'todo', label: 'To Do', cls: 'col-todo' },
  { key: 'in_progress', label: 'In Progress', cls: 'col-progress' },
  { key: 'review', label: 'Review', cls: 'col-review' },
  { key: 'done', label: 'Done', cls: 'col-done' },
];

const priorityColors = { low: 'priority-low', medium: 'priority-medium', high: 'priority-high', critical: 'priority-critical' };

export default function ProjectDetail() {
  const { id } = useParams();
  const { user } = useAuth();
  const navigate = useNavigate();
  const [project, setProject] = useState(null);
  const [members, setMembers] = useState([]);
  const [tasks, setTasks] = useState([]);
  const [loading, setLoading] = useState(true);
  const [tab, setTab] = useState('board');
  const [selectedTask, setSelectedTask] = useState(null);
  const [showNewTask, setShowNewTask] = useState(false);
  const [showAddMember, setShowAddMember] = useState(false);
  const [newTaskStatus, setNewTaskStatus] = useState('todo');

  useEffect(() => {
    Promise.all([
      api.get(`/projects/${id}`),
      api.get(`/projects/${id}/tasks`),
    ]).then(([projRes, tasksRes]) => {
      setProject(projRes.data.project);
      setMembers(projRes.data.members);
      setTasks(tasksRes.data.tasks);
    }).finally(() => setLoading(false));
  }, [id]);

  const isProjectAdmin = user.role === 'admin' || project?.owner_id === user.id ||
    members.find(m => m.id === user.id)?.role === 'admin';

  const handleTaskUpdated = (updated) => {
    setTasks(tasks.map(t => t.id === updated.id ? updated : t));
    setSelectedTask(updated);
  };

  const handleTaskDeleted = (taskId) => {
    setTasks(tasks.filter(t => t.id !== taskId));
    setSelectedTask(null);
  };

  const handleDeleteProject = async () => {
    if (!confirm(`Delete project "${project.name}"? This cannot be undone.`)) return;
    await api.delete(`/projects/${id}`);
    navigate('/projects');
  };

  if (loading) return <div className="loading-page"><div className="spinner" /></div>;
  if (!project) return <div>Project not found</div>;

  const tasksByStatus = (status) => tasks.filter(t => t.status === status);
  const overdueTasks = tasks.filter(t => t.deadline && new Date(t.deadline) < new Date() && t.status !== 'done');

  return (
    <div>
      <div className="page-header">
        <div>
          <Link to="/projects" style={{ display: 'flex', alignItems: 'center', gap: 6, fontSize: 13, color: 'var(--text-muted)', textDecoration: 'none', marginBottom: 8 }}>
            <ArrowLeft size={14} /> All Projects
          </Link>
          <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
            <div className="page-title">{project.name}</div>
            <span className={`project-status-badge status-${project.status}`}>{project.status}</span>
          </div>
          {project.description && <div className="page-subtitle">{project.description}</div>}
        </div>
        <div style={{ display: 'flex', gap: 10 }}>
          {isProjectAdmin && (
            <>
              <button className="btn btn-secondary" onClick={() => setShowAddMember(true)}>
                <UserPlus size={15} /> Add Member
              </button>
              <button className="btn btn-secondary" onClick={() => setShowNewTask(true)}>
                <Plus size={15} /> New Task
              </button>
              <button className="btn btn-danger btn-icon" onClick={handleDeleteProject} title="Delete project">
                <Trash2 size={15} />
              </button>
            </>
          )}
          {!isProjectAdmin && (
            <button className="btn btn-primary" onClick={() => setShowNewTask(true)}>
              <Plus size={15} /> New Task
            </button>
          )}
        </div>
      </div>

      {/* Overdue warning */}
      {overdueTasks.length > 0 && (
        <div className="alert alert-error" style={{ marginBottom: 20 }}>
          ⚠️ {overdueTasks.length} overdue task{overdueTasks.length > 1 ? 's' : ''} need attention
        </div>
      )}

      {/* Tabs */}
      <div className="tabs">
        {['board', 'list', 'members'].map(t => (
          <button key={t} className={`tab ${tab === t ? 'active' : ''}`} onClick={() => setTab(t)}>
            {t.charAt(0).toUpperCase() + t.slice(1)}
            {t === 'members' && <span style={{ marginLeft: 6, fontSize: 11, background: 'var(--bg-elevated)', padding: '1px 6px', borderRadius: 99 }}>{members.length}</span>}
          </button>
        ))}
      </div>

      {/* Board view */}
      {tab === 'board' && (
        <div className="board">
          {COLS.map(col => {
            const colTasks = tasksByStatus(col.key);
            return (
              <div key={col.key} className={`board-col ${col.cls}`}>
                <div className="board-col-header">
                  <div className="board-col-dot" />
                  <div className="board-col-title">{col.label}</div>
                  <div className="board-col-count">{colTasks.length}</div>
                  <button className="btn btn-ghost btn-icon" style={{ padding: 4, marginLeft: 2 }}
                    onClick={() => { setNewTaskStatus(col.key); setShowNewTask(true); }}
                    title="Add task">
                    <Plus size={13} />
                  </button>
                </div>
                <div className="board-cards">
                  {colTasks.map(task => (
                    <div key={task.id} className="task-card" onClick={() => setSelectedTask(task)}>
                      <div className="task-card-title">{task.title}</div>
                      <div className="task-card-meta">
                        <span className={`priority ${priorityColors[task.priority]}`}>{task.priority}</span>
                        {task.assignee_name && (
                          <Avatar avatarData={task.assignee_avatar} name={task.assignee_name} size="avatar" style={{ width: 20, height: 20, fontSize: 9 }} />
                        )}
                        {task.deadline && (
                          <span className={`deadline ${new Date(task.deadline) < new Date() && task.status !== 'done' ? 'overdue' : ''}`}>
                            📅 {formatDate(task.deadline)}
                          </span>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* List view */}
      {tab === 'list' && (
        <div className="table-wrap">
          <table>
            <thead>
              <tr>
                <th>Task</th>
                <th>Status</th>
                <th>Priority</th>
                <th>Assignee</th>
                <th>Deadline</th>
              </tr>
            </thead>
            <tbody>
              {tasks.length === 0 ? (
                <tr><td colSpan={5} style={{ textAlign: 'center', color: 'var(--text-muted)', padding: 32 }}>No tasks yet</td></tr>
              ) : tasks.map(task => (
                <tr key={task.id} style={{ cursor: 'pointer' }} onClick={() => setSelectedTask(task)}>
                  <td>
                    <div style={{ fontWeight: 600 }}>{task.title}</div>
                    {task.description && <div style={{ fontSize: 12, color: 'var(--text-muted)', marginTop: 2 }}>{task.description.slice(0, 60)}…</div>}
                  </td>
                  <td><span className={`status-badge status-${task.status}`}>{task.status.replace('_', ' ')}</span></td>
                  <td><span className={`priority priority-${task.priority}`}>{task.priority}</span></td>
                  <td>
                    {task.assignee_name ? (
                      <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                        <Avatar avatarData={task.assignee_avatar} name={task.assignee_name} />
                        <span>{task.assignee_name}</span>
                      </div>
                    ) : <span style={{ color: 'var(--text-muted)' }}>—</span>}
                  </td>
                  <td>
                    {task.deadline ? (
                      <span className={`deadline ${new Date(task.deadline) < new Date() && task.status !== 'done' ? 'overdue' : ''}`}>
                        {formatDate(task.deadline)}
                      </span>
                    ) : '—'}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* Members tab */}
      {tab === 'members' && (
        <div className="card">
          {members.map(m => (
            <div key={m.id} className="member-row">
              <Avatar avatarData={m.avatar} name={m.name} size="avatar-lg" />
              <div style={{ flex: 1 }}>
                <div style={{ fontWeight: 600 }}>{m.name}</div>
                <div style={{ fontSize: 12, color: 'var(--text-muted)' }}>{m.email}</div>
              </div>
              <span className={`role-badge ${m.role}`}>{m.role}</span>
              {isProjectAdmin && m.id !== user.id && (
                <button className="btn btn-ghost btn-sm" style={{ color: 'var(--danger)' }}
                  onClick={async () => {
                    await api.delete(`/projects/${id}/members/${m.id}`);
                    setMembers(members.filter(x => x.id !== m.id));
                  }}>
                  Remove
                </button>
              )}
            </div>
          ))}
        </div>
      )}

      {/* Task modal */}
      {selectedTask && (
        <TaskModal
          task={selectedTask}
          projectId={id}
          members={members}
          onClose={() => setSelectedTask(null)}
          onUpdated={handleTaskUpdated}
          onDeleted={handleTaskDeleted}
          canManage={isProjectAdmin || selectedTask.creator_id === user.id || selectedTask.assignee_id === user.id}
        />
      )}

      {/* New task modal */}
      {showNewTask && (
        <NewTaskModal
          projectId={id}
          members={members}
          defaultStatus={newTaskStatus}
          onClose={() => setShowNewTask(false)}
          onCreated={(task) => { setTasks([...tasks, task]); setShowNewTask(false); }}
        />
      )}

      {/* Add member modal */}
      {showAddMember && (
        <AddMemberModal
          projectId={id}
          onClose={() => setShowAddMember(false)}
          onAdded={(m) => { setMembers([...members, m]); setShowAddMember(false); }}
        />
      )}
    </div>
  );
}

function NewTaskModal({ projectId, members, defaultStatus, onClose, onCreated }) {
  const [form, setForm] = useState({ title: '', description: '', priority: 'medium', status: defaultStatus, assignee_id: '', deadline: '' });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true); setError('');
    try {
      const payload = { ...form, assignee_id: form.assignee_id || undefined, deadline: form.deadline || undefined };
      const res = await api.post(`/projects/${projectId}/tasks`, payload);
      onCreated(res.data.task);
    } catch (err) {
      setError(err.response?.data?.error || 'Failed to create task');
    } finally { setLoading(false); }
  };

  return (
    <div className="modal-overlay" onClick={e => e.target === e.currentTarget && onClose()}>
      <div className="modal">
        <div className="modal-header">
          <div className="modal-title">New Task</div>
          <button className="btn btn-ghost btn-icon" onClick={onClose}><Plus size={16} style={{ transform: 'rotate(45deg)' }} /></button>
        </div>
        <form onSubmit={handleSubmit}>
          <div className="modal-body">
            {error && <div className="alert alert-error">{error}</div>}
            <div className="form-group">
              <label className="form-label">Title *</label>
              <input className="form-input" placeholder="Task title" value={form.title}
                onChange={e => setForm({ ...form, title: e.target.value })} required />
            </div>
            <div className="form-group">
              <label className="form-label">Description</label>
              <textarea className="form-textarea" placeholder="Details…" value={form.description}
                onChange={e => setForm({ ...form, description: e.target.value })} />
            </div>
            <div className="form-row">
              <div className="form-group">
                <label className="form-label">Priority</label>
                <select className="form-select" value={form.priority} onChange={e => setForm({ ...form, priority: e.target.value })}>
                  <option value="low">Low</option>
                  <option value="medium">Medium</option>
                  <option value="high">High</option>
                  <option value="critical">Critical</option>
                </select>
              </div>
              <div className="form-group">
                <label className="form-label">Status</label>
                <select className="form-select" value={form.status} onChange={e => setForm({ ...form, status: e.target.value })}>
                  <option value="todo">To Do</option>
                  <option value="in_progress">In Progress</option>
                  <option value="review">Review</option>
                  <option value="done">Done</option>
                </select>
              </div>
            </div>
            <div className="form-row">
              <div className="form-group">
                <label className="form-label">Assignee</label>
                <select className="form-select" value={form.assignee_id} onChange={e => setForm({ ...form, assignee_id: e.target.value })}>
                  <option value="">Unassigned</option>
                  {members.map(m => <option key={m.id} value={m.id}>{m.name}</option>)}
                </select>
              </div>
              <div className="form-group">
                <label className="form-label">Deadline</label>
                <input className="form-input" type="date" value={form.deadline}
                  onChange={e => setForm({ ...form, deadline: e.target.value })} />
              </div>
            </div>
          </div>
          <div className="modal-footer">
            <button type="button" className="btn btn-ghost" onClick={onClose}>Cancel</button>
            <button type="submit" className="btn btn-primary" disabled={loading}>
              {loading ? <span className="spinner" /> : 'Create Task'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

function AddMemberModal({ projectId, onClose, onAdded }) {
  const [email, setEmail] = useState('');
  const [role, setRole] = useState('member');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true); setError('');
    try {
      const res = await api.post(`/projects/${projectId}/members`, { email, role });
      onAdded({ ...res.data.user, role });
    } catch (err) {
      setError(err.response?.data?.error || 'Failed to add member');
    } finally { setLoading(false); }
  };

  return (
    <div className="modal-overlay" onClick={e => e.target === e.currentTarget && onClose()}>
      <div className="modal">
        <div className="modal-header">
          <div className="modal-title">Add Team Member</div>
          <button className="btn btn-ghost btn-icon" onClick={onClose}>✕</button>
        </div>
        <form onSubmit={handleSubmit}>
          <div className="modal-body">
            {error && <div className="alert alert-error">{error}</div>}
            <div className="form-group">
              <label className="form-label">Member Email</label>
              <input className="form-input" type="email" placeholder="teammate@example.com"
                value={email} onChange={e => setEmail(e.target.value)} required />
              <div style={{ fontSize: 11, color: 'var(--text-muted)', marginTop: 4 }}>
                They must already have a TaskFlow account
              </div>
            </div>
            <div className="form-group">
              <label className="form-label">Project Role</label>
              <select className="form-select" value={role} onChange={e => setRole(e.target.value)}>
                <option value="member">Member</option>
                <option value="admin">Admin</option>
              </select>
            </div>
          </div>
          <div className="modal-footer">
            <button type="button" className="btn btn-ghost" onClick={onClose}>Cancel</button>
            <button type="submit" className="btn btn-primary" disabled={loading}>
              {loading ? <span className="spinner" /> : 'Add Member'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
