import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Calendar, Filter } from 'lucide-react';
import api from '../utils/api';
import { useAuth } from '../context/AuthContext';
import { Avatar, formatDate } from '../components/Avatar';

const priorityColors = { low: 'priority-low', medium: 'priority-medium', high: 'priority-high', critical: 'priority-critical' };
const statusColors = { todo: 'status-todo', in_progress: 'status-in_progress', review: 'status-review', done: 'status-done' };

export default function MyTasks() {
  const { user } = useAuth();
  const [allTasks, setAllTasks] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState('active'); // all, active, overdue, done

  useEffect(() => {
    // Fetch all projects then all tasks assigned to me
    api.get('/projects').then(async res => {
      const projects = res.data.projects;
      const taskPromises = projects.map(p => api.get(`/projects/${p.id}/tasks`).then(r => r.data.tasks.map(t => ({ ...t, project_name: p.name, project_id: p.id }))));
      const allTaskArrays = await Promise.all(taskPromises);
      const flat = allTaskArrays.flat().filter(t => t.assignee_id === user.id || t.creator_id === user.id);
      setAllTasks(flat);
    }).finally(() => setLoading(false));
  }, []);

  const today = new Date();
  const filtered = allTasks.filter(t => {
    if (filter === 'active') return t.status !== 'done';
    if (filter === 'overdue') return t.deadline && new Date(t.deadline) < today && t.status !== 'done';
    if (filter === 'done') return t.status === 'done';
    return true;
  });

  if (loading) return <div className="loading-page"><div className="spinner" /></div>;

  const counts = {
    all: allTasks.length,
    active: allTasks.filter(t => t.status !== 'done').length,
    overdue: allTasks.filter(t => t.deadline && new Date(t.deadline) < today && t.status !== 'done').length,
    done: allTasks.filter(t => t.status === 'done').length,
  };

  return (
    <div>
      <div className="page-header">
        <div>
          <div className="page-title">My Tasks</div>
          <div className="page-subtitle">All tasks assigned to you</div>
        </div>
      </div>

      <div className="tabs">
        {[['active', 'Active'], ['overdue', 'Overdue'], ['done', 'Done'], ['all', 'All']].map(([key, label]) => (
          <button key={key} className={`tab ${filter === key ? 'active' : ''}`} onClick={() => setFilter(key)}>
            {label}
            <span style={{ marginLeft: 6, fontSize: 11, background: 'var(--bg-elevated)', padding: '1px 6px', borderRadius: 99,
              color: key === 'overdue' && counts.overdue > 0 ? 'var(--danger)' : undefined }}>
              {counts[key]}
            </span>
          </button>
        ))}
      </div>

      {filtered.length === 0 ? (
        <div className="empty-state">
          <div className="empty-title">No tasks here</div>
          <div className="empty-text">{filter === 'overdue' ? "You're all caught up! 🎉" : "Nothing to show in this category"}</div>
        </div>
      ) : (
        <div className="table-wrap">
          <table>
            <thead>
              <tr>
                <th>Task</th>
                <th>Project</th>
                <th>Status</th>
                <th>Priority</th>
                <th>Deadline</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map(task => {
                const overdue = task.deadline && new Date(task.deadline) < today && task.status !== 'done';
                return (
                  <tr key={`${task.project_id}-${task.id}`}>
                    <td>
                      <div style={{ fontWeight: 600 }}>{task.title}</div>
                      {task.description && <div style={{ fontSize: 12, color: 'var(--text-muted)', marginTop: 2 }}>{task.description.slice(0, 60)}</div>}
                    </td>
                    <td>
                      <Link to={`/projects/${task.project_id}`} style={{ color: 'var(--accent)', textDecoration: 'none', fontSize: 13 }}>
                        {task.project_name}
                      </Link>
                    </td>
                    <td><span className={`status-badge ${statusColors[task.status]}`}>{task.status.replace('_', ' ')}</span></td>
                    <td><span className={`priority ${priorityColors[task.priority]}`}>{task.priority}</span></td>
                    <td>
                      {task.deadline ? (
                        <span className={`deadline ${overdue ? 'overdue' : ''}`}>
                          <Calendar size={11} /> {formatDate(task.deadline)}
                          {overdue && ' ⚠️'}
                        </span>
                      ) : <span style={{ color: 'var(--text-muted)' }}>—</span>}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
