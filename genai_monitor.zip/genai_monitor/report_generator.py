"""
Main ReportGenerator class - FULLY SELF-CONTAINED.
Uses data_paths.py for all file locations.
"""
import json
import pandas as pd
from datetime import datetime

try:
    from loguru import logger
except ImportError:
    import logging
    logger = logging.getLogger(__name__)

from config import get_default_config
from data_paths import METRICS_TEMPLATE_PATH, EVAL_RESULTS_PATH, AGENT_AUGMENTATIONS_PATH
from utils import (find_column, safe_numeric_conversion, normalize_text, text_equal, clean_text, normalize_query_match)
from tabs.metrics_summary import generate_metrics_summary_table
from tabs.data_assurance import create_test_coverage_sunburst, generate_augmented_data_table, get_coverage_edit_data
from tabs.model_quality_assurance import (generate_interactive_details_table, create_metrics_bar_chart, create_overall_pie_chart, create_score_comparison_chart, create_disaggregated_table, load_recovery_loop_global)
from tabs.secondary_llm import generate_secondary_llm_table


class ReportGenerator:
    def __init__(self, config=None):
        logger.info('Initializing ReportGenerator')
        self.config = config or get_default_config()
        self.report_timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        self.metric_details_excel_path = EVAL_RESULTS_PATH

    def _get_chart_layout(self, theme):
        return {'font': {'family': theme['font_family'], 'size': 12}, 'plot_bgcolor': 'rgba(0,0,0,0)', 'paper_bgcolor': 'rgba(0,0,0,0)', 'height': self.config['chart_height'], 'margin': dict(l=60, r=60, t=80, b=100), 'xaxis': {'showgrid': True, 'gridcolor': theme['border_color'], 'tickangle': -45, 'tickfont': {'size': 10}}, 'yaxis': {'showgrid': True, 'gridcolor': theme['border_color'], 'tickfont': {'size': 10}}}

    def _calculate_status(self, df, metrics, thresholds):
        try:
            df_copy = df.copy()
            for metric in metrics:
                if metric not in df_copy.columns: continue
                status_col = f"{metric}_status"; reason_col = f"{metric}-reason"; threshold = thresholds.get(metric)
                if threshold is None: df_copy[status_col] = "Unknown"; continue
                if reason_col in df_copy.columns:
                    df_copy[status_col] = df_copy.apply(lambda row, m=metric, rc=reason_col, th=threshold: self._determine_status_with_reason(row, m, rc, th), axis=1)
                else:
                    df_copy[status_col] = df_copy[metric].apply(lambda x, m=metric, th=threshold: self._determine_status_simple(x, m, th))
            return df_copy
        except Exception as e: logger.error(f"Error calculating status: {e}"); return df

    def _determine_status_with_reason(self, row, metric, reason_col, threshold):
        reason = str(row.get(reason_col, "")).strip().upper()
        if reason == "NA": return "Skipped"
        score = safe_numeric_conversion(row[metric])
        if pd.isna(score): return "Failed"
        if metric in self.config['reverse_metrics']: return "Passed" if score <= threshold else "Failed"
        return "Passed" if score >= threshold else "Failed"

    def _determine_status_simple(self, value, metric, threshold):
        score = safe_numeric_conversion(value)
        if pd.isna(score): return "Failed"
        if metric in self.config['reverse_metrics']: return "Passed" if score <= threshold else "Failed"
        return "Passed" if score >= threshold else "Failed"

    def _prepare_modal_data(self, df, metrics, thresholds):
        try:
            modal_data = {}; metric_sheets = {}
            try:
                if self.metric_details_excel_path.exists():
                    xls = pd.ExcelFile(self.metric_details_excel_path)
                    for sheet in xls.sheet_names:
                        try: metric_sheets[sheet] = pd.read_excel(xls, sheet_name=sheet)
                        except: continue
            except Exception as e: logger.warning(f"Unable to read metric details excel: {e}")
            normalized_sheet_map = {str(s).strip().lower(): s for s in metric_sheets.keys()}
            for idx, row in df.iterrows():
                modal_data[idx] = {'query': clean_text(row.get('Query', 'N/A')), 'response': clean_text(row.get('Response', 'N/A')), 'timestamp': self.report_timestamp, 'metrics': {}}
                modal_data[idx]["metric_fields"] = {}
                for metric in metrics:
                    norm_metric = str(metric).strip().lower()
                    if norm_metric in normalized_sheet_map:
                        sheet_name = normalized_sheet_map[norm_metric]; metric_df = metric_sheets.get(sheet_name)
                        if isinstance(metric_df, pd.DataFrame):
                            query_col = find_column(metric_df, ['Query','query','Question']); found_entry = {}
                            if query_col and query_col in metric_df.columns:
                                metric_df[query_col] = metric_df[query_col].ffill(); details_query = normalize_text(row.get('Query', ''))
                                mask = metric_df[query_col].apply(lambda x: normalize_text(x) == details_query); matched = metric_df[mask]
                                if not matched.empty:
                                    found_entry = matched.iloc[0].replace({pd.NA: None}).to_dict() if len(matched)==1 else [r.replace({pd.NA: None}).to_dict() for _, r in matched.iterrows()]
                                else:
                                    mask2 = metric_df[query_col].apply(lambda x: text_equal(x, details_query)); matched2 = metric_df[mask2]
                                    if not matched2.empty: found_entry = matched2.iloc[0].replace({pd.NA: None}).to_dict() if len(matched2)==1 else [r.replace({pd.NA: None}).to_dict() for _, r in matched2.iterrows()]
                            modal_data[idx]["metric_fields"][str(metric).strip()] = found_entry
                        else: modal_data[idx]["metric_fields"][metric] = {}
                    else: modal_data[idx]["metric_fields"][metric] = {}
                for metric in metrics:
                    ms = str(metric).strip(); mn = normalize_text(ms)
                    md = {'score': clean_text(row.get(metric, 'N/A')), 'threshold': str(thresholds.get(metric, 'N/A')), 'status': clean_text(row.get(f"{metric}_status", 'Unknown')), 'additional_fields': {}}
                    for col in row.index:
                        cn = normalize_text(str(col).strip())
                        if cn == mn or cn.endswith("status"): continue
                        if cn.startswith(mn):
                            fn = cn.replace(mn,"").strip(" _-"); fv = clean_text(row.get(col, ''))
                            if fv != 'N/A': md['additional_fields'][fn] = fv
                    modal_data[idx]['metrics'][ms] = md
            return modal_data
        except Exception as e: logger.error(f"Error preparing modal data: {e}"); return {}

    def _create_modern_charts(self, summary_df, overall_df, metrics_df, metrics_col, score_col, threshold_col):
        try:
            charts = {}; layout_fn = self._get_chart_layout
            charts['metrics'] = create_metrics_bar_chart(summary_df, self.config, layout_fn)
            charts['overall'] = create_overall_pie_chart(overall_df, self.config, layout_fn)
            charts['comparison'] = create_score_comparison_chart(metrics_df, metrics_col, score_col, threshold_col, self.config, layout_fn)
            charts['coverage'] = create_test_coverage_sunburst(excel_path=METRICS_TEMPLATE_PATH, sheet_name='Test data coverage')
            charts['augmentation'] = generate_augmented_data_table(excel_path=AGENT_AUGMENTATIONS_PATH, sheet_name='Sheet1')
            charts['disaggregated'] = create_disaggregated_table(METRICS_TEMPLATE_PATH)
            return charts
        except Exception as e: logger.error(f"Error creating charts: {e}"); return {}

    def generate_report(self, metrics_df, details_df, summary_df, overall_df):
        try:
            logger.info("Starting report generation")
            if any(df.empty for df in [metrics_df, details_df, summary_df, overall_df]):
                return self._generate_error_report("One or more input DataFrames are empty")
            mc = find_column(metrics_df, ['Metrics','Metric','metric']); tc = find_column(metrics_df, ['Threshold_Value','Threshold','threshold']); sc = find_column(metrics_df, ['aggregate_score','score','Score'])
            if not all([mc, tc, sc]): return self._generate_error_report("Required columns not found")
            all_metrics = [m for m in metrics_df[mc].dropna().astype(str).tolist() if m.strip().lower() != 'knowledge retention']
            thresholds = {k: v for k, v in zip(metrics_df[mc], metrics_df[tc]) if str(k).strip().lower() != 'knowledge retention'}
            details_df = self._calculate_status(details_df, all_metrics, thresholds)
            charts = self._create_modern_charts(summary_df, overall_df, metrics_df, mc, sc, tc)
            modal_data = self._prepare_modal_data(details_df, all_metrics, thresholds)
            from templates.html_report import generate_modern_html
            return generate_modern_html(config=self.config, report_timestamp=self.report_timestamp, metrics_df=metrics_df, details_df=details_df, all_metrics=all_metrics, charts=charts, modal_data=modal_data, metric_details_excel_path=self.metric_details_excel_path)
        except Exception as e: return self._generate_error_report(f"Error: {e}")

    def _generate_error_report(self, msg):
        return f"<!DOCTYPE html><html><body style='font-family:Arial;padding:40px;text-align:center;'><h1>Report Generation Error</h1><div style='color:#dc3545;margin:20px;'>{msg}</div></body></html>"
