"""Flask route blueprints."""
from flask import Flask
from genai_monitor.routes.main_routes import main_bp
from genai_monitor.routes.dataset_routes import dataset_bp
from genai_monitor.routes.augmentation_routes import augmentation_bp
from genai_monitor.routes.evaluation_routes import evaluation_bp


def register_blueprints(app: Flask):
    app.register_blueprint(main_bp)
    app.register_blueprint(dataset_bp)
    app.register_blueprint(augmentation_bp)
    app.register_blueprint(evaluation_bp)
