"""Main routes - demo report page and run comparison."""
import pandas as pd
from flask import Blueprint, request, jsonify
from genai_monitor.data_paths import METRICS_TEMPLATE_PATH
from genai_monitor.config import get_default_config

main_bp = Blueprint('main', __name__)


@main_bp.route("/")
def demo_report():
    try:
        from report_generator import ReportGenerator
        fp = str(METRICS_TEMPLATE_PATH)
        metrics_df = pd.read_excel(fp, sheet_name='Metrics Interpretability')
        details_df = pd.read_excel(fp, sheet_name='Test Data')
        summary_df = pd.read_excel(fp, sheet_name='Metrics_wise Pass-Fail')
        overall_df = pd.read_excel(fp, sheet_name='Overall Summary')
        rg = ReportGenerator()
        html = rg.generate_report(metrics_df, details_df, summary_df, overall_df)
        return html
    except Exception as e:
        return f"<h1>Error</h1><pre>{e}</pre>", 500


@main_bp.route("/compare-runs", methods=["POST"])
def compare_runs():
    try:
        from tabs.model_quality_assurance import create_run_comparison_chart
        pf = request.files.get("previous_run")
        cf = request.files.get("current_run")
        if not pf or not cf:
            return "<div><b>Upload both files</b></div>"
        config = get_default_config()
        return create_run_comparison_chart(pd.read_excel(pf), pd.read_excel(cf), config["theme"])
    except Exception as e:
        return f"<div><b>Error: {e}</b></div>"


@main_bp.route("/update-coverage", methods=["POST"])
def update_coverage():
    try:
        payload = request.get_json()
        updates = payload.get("updates", {})
        excel_path = METRICS_TEMPLATE_PATH
        df = pd.read_excel(excel_path, sheet_name='Test data coverage')
        if "expected_record_count" not in df.columns:
            df["expected_record_count"] = None
        df["topic"] = df["topic"].astype(str).str.strip().str.upper()
        df["sub_topic"] = df["sub_topic"].astype(str).str.strip().str.title()
        df["sub_subtopic"] = df["sub_subtopic"].astype(str).str.strip().replace({"nan": None, "None": None, "": None})
        agg = df.groupby(["topic", "sub_topic", "sub_subtopic"], dropna=False).agg(count=("query", lambda x: x.notna().sum())).reset_index()
        for ri_str, cols in updates.items():
            ri = int(ri_str)
            if ri >= len(agg): continue
            ar = agg.iloc[ri]
            nv = cols.get("expected_record_count", "")
            nv = int(nv) if str(nv).strip().isdigit() else None
            mask = ((df["topic"] == ar["topic"]) & (df["sub_topic"] == ar["sub_topic"]) & (df["sub_subtopic"].fillna("-") == (ar["sub_subtopic"] if pd.notna(ar["sub_subtopic"]) else "-")))
            df.loc[mask, "expected_record_count"] = nv
        from openpyxl import load_workbook
        wb = load_workbook(excel_path)
        ws_name = 'Test data coverage'
        if ws_name in wb.sheetnames: del wb[ws_name]
        ws = wb.create_sheet(ws_name)
        for ci, col in enumerate(df.columns, 1): ws.cell(row=1, column=ci, value=col)
        for ri, row in enumerate(df.itertuples(index=False), 2):
            for ci, val in enumerate(row, 1): ws.cell(row=ri, column=ci, value=val)
        wb.save(excel_path)
        return jsonify({"success": True})
    except Exception as e:
        return jsonify({"success": False, "error": str(e)})
