"""Augmentation routes - perform augmentation, agentic augmentation, coverage check."""
import json
from collections import defaultdict
from flask import Blueprint, request, jsonify
from genai_monitor.pipeline_store import pipeline_store
from genai_monitor.llm_client import call_azure_openai, parallel_llm_calls
from genai_monitor.prompts import (
    AUGMENTATION_PROMPTS, AGENTIC_AUGMENTATION_SYSTEM_MSG,
    COVERAGE_CHECK_SYSTEM_MSG, VALID_COVERAGE_SUBTOPICS
)

try:
    from loguru import logger
except ImportError:
    import logging
    logger = logging.getLogger(__name__)

augmentation_bp = Blueprint('augmentation', __name__)


@augmentation_bp.route("/api/perform-augmentation", methods=["POST"])
def api_perform_augmentation():
    try:
        payload = request.get_json()
        input_indices = payload.get('input_indices', [])
        techniques = payload.get('techniques', [])
        variations = payload.get('variations', {})
        if not input_indices or not techniques:
            return jsonify({"success": False, "error": "Select inputs and techniques."})
        dataset = pipeline_store.get('uploaded_dataset')
        if not dataset:
            return jsonify({"success": False, "error": "No dataset uploaded."})
        tasks = []
        task_meta = []
        for idx in input_indices:
            if idx < 0 or idx >= len(dataset):
                continue
            row = dataset[idx]
            oi = row['input']; eo = row['expected_output']; tid = row.get('tc_id', f'TC{str(idx+1).zfill(3)}')
            for tech in techniques:
                if isinstance(tech, str):
                    tn = tech; td = AUGMENTATION_PROMPTS.get(tech, ""); ic = False; ct = "normal"; fs = []
                else:
                    tn = tech.get('name', ''); td = tech.get('description', ''); ic = tech.get('is_custom', False)
                    ct = tech.get('custom_type', 'normal'); fs = tech.get('few_shots', [])
                if not tn:
                    continue
                nv = max(1, min(int(variations.get(tn, 1)), 10))
                if tn in AUGMENTATION_PROMPTS and not ic:
                    bpt = AUGMENTATION_PROMPTS[tn]
                elif td:
                    bpt = td + "\n\nApply this transformation to the following text. Return ONLY the transformed text.\n\nText: {text}"
                else:
                    bpt = "Apply the '" + tn + "' augmentation technique. Return ONLY the transformed text.\n\nText: {text}"
                sm = "You are an advanced agentic text augmentation assistant." if ic and ct == 'agentic' else "You are a helpful text augmentation assistant."
                fsb = ""
                if fs:
                    fsb = "\n\nExamples:\n"
                    for fi, f in enumerate(fs):
                        fsi = f.get('input', '').strip(); fso = f.get('output', '').strip()
                        if fsi:
                            fsb += f"\nExample {fi+1}:\nInput: {fsi}\nOutput: {fso}\n"
                for vn in range(1, nv + 1):
                    prompt = bpt.format(text=oi)
                    if fsb:
                        prompt = fsb + "\nNow apply the same transformation:\n\n" + prompt
                    if nv > 1:
                        prompt += f"\n\n(Generate variation #{vn}.)"
                    task_id = f"{tid}_{tn}_{vn}"
                    tasks.append({'id': task_id, 'prompt': prompt, 'system_message': sm})
                    task_meta.append({'id': task_id, 'tc_id': tid, 'original_input': oi, 'technique': tn, 'variation_num': vn, 'expected_output': eo})
        if not tasks:
            return jsonify({"success": False, "error": "No valid tasks generated."})
        logger.info(f"Running {len(tasks)} augmentation tasks in parallel")
        llm_results = parallel_llm_calls(tasks)
        result_map = {r['id']: r for r in llm_results}
        results = []; errors = []
        for meta in task_meta:
            llm_r = result_map.get(meta['id'], {})
            if llm_r.get('error'):
                errors.append(f"{meta['tc_id']}/{meta['technique']}(v{meta['variation_num']}): {llm_r['error']}")
                at = f"[ERROR: {llm_r['error']}]"
            else:
                at = llm_r.get('result', '').strip()
                if not at:
                    at = "[EMPTY RESPONSE]"
            results.append({"tc_id": meta['tc_id'], "original_input": meta['original_input'], "technique": meta['technique'], "variation_num": meta['variation_num'], "augmented_input": at, "expected_output": meta['expected_output']})
        pipeline_store['augmented_rows'] = results
        resp = {"success": True, "results": results, "total": len(results)}
        if errors:
            resp["warnings"] = errors
        return jsonify(resp)
    except Exception as e:
        return jsonify({"success": False, "error": str(e)})


@augmentation_bp.route("/api/agentic-augmentation", methods=["POST"])
def api_agentic_augmentation():
    try:
        payload = request.get_json()
        agent_name = payload.get('agent_name', '').strip()
        agent_spec = payload.get('agent_spec', '').strip()
        inputs = payload.get('inputs', [])
        if not agent_name or not agent_spec:
            return jsonify({"success": False, "error": "Agent Name and Specification are required."})
        if not inputs:
            return jsonify({"success": False, "error": "At least one input is required."})
        system_msg = AGENTIC_AUGMENTATION_SYSTEM_MSG
        tasks = []
        for i, inp_text in enumerate(inputs):
            prompt = f"## Agent Specification:\n{agent_spec}\n\n## Original Input Query:\n{inp_text}\n\nGenerate the 3 natural-language variations as a JSON object."
            tasks.append({'id': f"agentic_{i}", 'prompt': prompt, 'system_message': system_msg, 'input_text': inp_text, 'input_idx': i})
        logger.info(f"Running {len(tasks)} agentic tasks in parallel")
        llm_results = parallel_llm_calls(tasks)
        results = []; errors = []
        for llm_r in llm_results:
            inp_text = llm_r.get('input_text', '')
            i = llm_r.get('input_idx', 0)
            if llm_r.get('error'):
                errors.append(f"Input {i+1}: {llm_r['error']}")
                for ct in ["Positive", "Negative", "Edge"]:
                    results.append({"agent_name": agent_name, "original_input": inp_text, "case_type": ct, "augmented_input": f"[ERROR: {llm_r['error']}]"})
                continue
            try:
                raw = llm_r.get('result', '').strip()
                cleaned = raw
                if cleaned.startswith("```"):
                    cleaned = cleaned.split("\n", 1)[-1] if "\n" in cleaned else cleaned[3:]
                    if cleaned.endswith("```"):
                        cleaned = cleaned[:-3]
                    cleaned = cleaned.strip()
                parsed = json.loads(cleaned)
                for ct in ["Positive", "Negative", "Edge"]:
                    at = parsed.get(ct.lower(), parsed.get(ct, ""))
                    if not at:
                        at = f"[No {ct} variation generated]"
                    results.append({"agent_name": agent_name, "original_input": inp_text, "case_type": ct, "augmented_input": str(at).strip()})
            except Exception as e:
                errors.append(f"Input {i+1}: {e}")
                for ct in ["Positive", "Negative", "Edge"]:
                    results.append({"agent_name": agent_name, "original_input": inp_text, "case_type": ct, "augmented_input": f"[ERROR: {e}]"})
        pipeline_store['agentic_results'] = pipeline_store.get('agentic_results', []) + results
        resp = {"success": True, "results": results, "total": len(results)}
        if errors:
            resp["warnings"] = errors
        return jsonify(resp)
    except Exception as e:
        return jsonify({"success": False, "error": str(e)})


@augmentation_bp.route("/api/coverage-check", methods=["POST"])
def api_coverage_check():
    try:
        inputs = request.get_json().get('inputs', [])
        if not inputs:
            return jsonify({"success": False, "error": "No inputs."})
        plan = pipeline_store.get('coverage_plan', [])
        pc = ""
        if plan:
            lines = [f"Topic: {p.get('topic','')}, Sub-topic: {p.get('sub_topic','')}" + (f", Sub-sub-topic: {p.get('sub_subtopic','')}" if p.get('sub_subtopic', '').strip() else "") for p in plan]
            pc = "Known categories:\n" + "\n".join(lines) + "\n\n"
        sm = COVERAGE_CHECK_SYSTEM_MSG + pc + 'Respond ONLY with a JSON array: [{"topic":"SLA or ANALYTICS","sub_topic":"...","sub_subtopic":"..."}]'
        all_c = []; bs = 20
        batch_tasks = []
        for s in range(0, len(inputs), bs):
            e = min(s + bs, len(inputs))
            bt = [f'{i-s+1}. """{inputs[i].get("text","")[:300]}"""' for i in range(s, e)]
            bp = f"Classify {len(bt)} texts:\n\n" + "\n".join(bt)
            batch_tasks.append({'id': f"batch_{s}", 'prompt': bp, 'system_message': sm, 'start': s, 'end': e})
        batch_results = parallel_llm_calls(batch_tasks, max_workers=3)
        for br in batch_results:
            s = br.get('start', 0); e = br.get('end', 0)
            if br.get('error'):
                all_c.extend([{"topic": "", "sub_topic": "", "sub_subtopic": ""} for _ in range(s, e)])
                continue
            try:
                cl = br.get('result', '').strip()
                if cl.startswith("```"):
                    cl = cl.split("\n", 1)[-1] if "\n" in cl else cl[3:]
                if cl.endswith("```"):
                    cl = cl[:-3]
                p = json.loads(cl.strip())
                if isinstance(p, list):
                    all_c.extend(p)
                else:
                    all_c.append(p)
            except:
                all_c.extend([{"topic": "", "sub_topic": "", "sub_subtopic": ""} for _ in range(s, e)])
        while len(all_c) < len(inputs):
            all_c.append({"topic": "", "sub_topic": "", "sub_subtopic": ""})
        for c in all_c:
            t = str(c.get("topic", "")).strip().upper()
            c["topic"] = "SLA" if "SLA" in t else ("ANALYTICS" if "ANALYTIC" in t else (t if t in VALID_COVERAGE_SUBTOPICS else "SLA"))
            raw_sub = str(c.get("sub_topic", "")).strip()
            allowed = VALID_COVERAGE_SUBTOPICS.get(c["topic"], [])
            matched = next((a for a in allowed if a.lower() == raw_sub.lower()), None)
            if not matched:
                matched = next((a for a in allowed if raw_sub.lower() in a.lower() or a.lower() in raw_sub.lower()), None)
            c["sub_topic"] = matched if matched else (allowed[0] if allowed else raw_sub)
            c["sub_subtopic"] = str(c.get("sub_subtopic", "")).strip()
        pipeline_store['coverage_classifications'] = all_c
        return jsonify({"success": True, "classifications": all_c[:len(inputs)]})
    except Exception as e:
        return jsonify({"success": False, "error": str(e)})


@augmentation_bp.route("/api/get-coverage-actuals", methods=["GET"])
def api_get_coverage_actuals():
    try:
        cl = pipeline_store.get('coverage_classifications', [])
        if not cl:
            return jsonify({"success": False, "error": "No coverage data."})
        total = len(cl); sc = {}; sd = {}
        for c in cl:
            t = str(c.get("topic", "")).strip().upper(); s = str(c.get("sub_topic", "")).strip().lower(); ss = str(c.get("sub_subtopic", "")).strip().lower()
            if not t or not s:
                continue
            k = f"{t}||{s}"; sc[k] = sc.get(k, 0) + 1
            if ss:
                if k not in sd:
                    sd[k] = {}
                sd[k][ss] = sd[k].get(ss, 0) + 1
        actuals = {k: round((v / total) * 100, 1) for k, v in sc.items()}
        for pk, subs in sd.items():
            for ss, cnt in subs.items():
                actuals[f"{pk}||{ss}"] = round((cnt / total) * 100, 1)
        return jsonify({"success": True, "actuals": actuals})
    except Exception as e:
        return jsonify({"success": False, "error": str(e)})


@augmentation_bp.route("/api/get-coverage-summary", methods=["GET"])
def api_get_coverage_summary():
    try:
        classifications = pipeline_store.get('coverage_classifications', [])
        if not classifications:
            return jsonify({"success": False, "error": "No coverage classifications found. Run augmentation and coverage check first."})
        total = len(classifications)
        summary = defaultdict(lambda: defaultdict(lambda: defaultdict(int)))
        for c in classifications:
            topic = str(c.get('topic', '') or 'Unknown').strip().upper()
            sub_topic = str(c.get('sub_topic', '') or 'Unknown').strip().title()
            sub_subtopic = str(c.get('sub_subtopic', '') or '').strip()
            if not topic:
                topic = 'UNKNOWN'
            if not sub_topic:
                sub_topic = 'Unknown'
            summary[topic][sub_topic][sub_subtopic] += 1
        rows = []
        for topic in sorted(summary.keys()):
            for sub_topic in sorted(summary[topic].keys()):
                sub_subtopics = summary[topic][sub_topic]
                if list(sub_subtopics.keys()) == ['']:
                    count = sub_subtopics['']
                    rows.append({'topic': topic, 'sub_topic': sub_topic, 'sub_subtopic': '', 'count': count, 'percentage': round((count / total) * 100, 1)})
                else:
                    for sub_subtopic in sorted(sub_subtopics.keys()):
                        count = sub_subtopics[sub_subtopic]
                        rows.append({'topic': topic, 'sub_topic': sub_topic, 'sub_subtopic': sub_subtopic or '', 'count': count, 'percentage': round((count / total) * 100, 1)})
        return jsonify({"success": True, "rows": rows, "total": total, "plan": pipeline_store.get('coverage_plan', [])})
    except Exception as e:
        return jsonify({"success": False, "error": str(e)})
