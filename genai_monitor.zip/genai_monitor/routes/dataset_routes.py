"""Dataset routes - upload, save, get datasets and golden datasets."""
import pandas as pd
from flask import Blueprint, request, jsonify
from genai_monitor.pipeline_store import pipeline_store

dataset_bp = Blueprint('dataset', __name__)


@dataset_bp.route("/api/upload-dataset", methods=["POST"])
def api_upload_dataset():
    try:
        file = request.files.get('file')
        if not file:
            return jsonify({"success": False, "error": "No file uploaded"})
        fn = file.filename.lower()
        if fn.endswith('.csv'):
            df = pd.read_csv(file)
        elif fn.endswith(('.xlsx', '.xls')):
            df = pd.read_excel(file)
        else:
            return jsonify({"success": False, "error": "Unsupported format"})
        df.columns = [str(c).strip().lower() for c in df.columns]
        ic = oc = None
        for c in df.columns:
            if c in ('input', 'query', 'question'):
                ic = c
            if c in ('expected output', 'expected_output', 'output', 'expected'):
                oc = c
        if not ic:
            return jsonify({"success": False, "error": "Could not find 'input' column"})
        if not oc:
            return jsonify({"success": False, "error": "Could not find 'expected output' column"})
        rows = []
        for i, (_, row) in enumerate(df.iterrows()):
            inp = str(row[ic]) if pd.notna(row[ic]) else ""
            out = str(row[oc]) if pd.notna(row[oc]) else ""
            if inp.strip():
                rows.append({"tc_id": f"TC{str(i+1).zfill(3)}", "input": inp.strip(), "expected_output": out.strip()})
        if not rows:
            return jsonify({"success": False, "error": "No valid rows"})
        pipeline_store['uploaded_dataset'] = rows
        return jsonify({"success": True, "rows": rows, "count": len(rows)})
    except Exception as e:
        return jsonify({"success": False, "error": str(e)})


@dataset_bp.route("/api/save-coverage-plan", methods=["POST"])
def api_save_coverage_plan():
    try:
        plan = request.get_json().get('plan', [])
        total = sum(p.get('percentage', 0) for p in plan)
        if abs(total - 100) > 0.5:
            return jsonify({"success": False, "error": f"Percentages sum to {total:.1f}%"})
        pipeline_store['coverage_plan'] = plan
        return jsonify({"success": True})
    except Exception as e:
        return jsonify({"success": False, "error": str(e)})


@dataset_bp.route("/api/get-coverage-plan", methods=["GET"])
def api_get_coverage_plan():
    return jsonify({"success": True, "plan": pipeline_store.get('coverage_plan', [])})


@dataset_bp.route("/api/save-golden-dataset", methods=["POST"])
def api_save_golden_dataset():
    try:
        payload = request.get_json()
        results = payload.get('results', [])
        agentic_results = payload.get('agentic_results', [])
        if not results and not agentic_results:
            return jsonify({"success": False, "error": "No results to save."})
        pipeline_store['golden_dataset'] = results
        if agentic_results:
            pipeline_store['golden_dataset_agentic'] = agentic_results
        return jsonify({"success": True})
    except Exception as e:
        return jsonify({"success": False, "error": str(e)})


@dataset_bp.route("/api/get-golden-dataset", methods=["GET"])
def api_get_golden_dataset():
    try:
        golden = pipeline_store.get('golden_dataset', [])
        agentic = pipeline_store.get('golden_dataset_agentic', [])
        return jsonify({"success": True, "rows": golden, "agentic_rows": agentic})
    except Exception as e:
        return jsonify({"success": False, "error": str(e)})


@dataset_bp.route("/api/upload-bias-data", methods=["POST"])
def api_upload_bias_data():
    try:
        file = request.files.get('file')
        if not file:
            return jsonify({"success": False, "error": "No file uploaded"})
        fn = file.filename.lower()
        if fn.endswith('.csv'):
            df = pd.read_csv(file)
        elif fn.endswith(('.xlsx', '.xls')):
            try:
                df = pd.read_excel(file, sheet_name='Bias Review')
            except Exception:
                return jsonify({"success": False, "error": "Could not find sheet named 'Bias Evaluation' in the uploaded file."})
        else:
            return jsonify({"success": False, "error": "Unsupported format"})
        df.columns = [str(c).strip() for c in df.columns]
        result_col = next((c for c in df.columns if c.strip().lower() in ('result', 'overall bias result', 'overall bias result(pass/fail)', 'overall result')), None)
        if not result_col:
            return jsonify({"success": False, "error": "Could not find 'Result' or 'Overall Bias Result' column in uploaded file."})
        rows = []
        for _, row in df.iterrows():
            record = {}
            for col in df.columns:
                val = row[col]
                record[col] = "" if pd.isna(val) else str(val).strip()
            rows.append(record)
        pipeline_store['bias_data'] = {'rows': rows, 'result_col': result_col, 'columns': list(df.columns)}
        pass_count = sum(1 for r in rows if r.get(result_col, '').strip().lower() == 'pass')
        fail_count = len(rows) - pass_count
        return jsonify({"success": True, "rows": rows, "columns": list(df.columns), "result_col": result_col, "pass_count": pass_count, "fail_count": fail_count, "total": len(rows)})
    except Exception as e:
        return jsonify({"success": False, "error": str(e)})


@dataset_bp.route("/api/upload-explainability-data", methods=["POST"])
def api_upload_explainability_data():
    try:
        file = request.files.get('file')
        if not file:
            return jsonify({"success": False, "error": "No file uploaded"})
        fn = file.filename.lower()
        if fn.endswith('.csv'):
            df = pd.read_csv(file)
        elif fn.endswith(('.xlsx', '.xls')):
            try:
                df = pd.read_excel(file, sheet_name='Explainability Review')
            except Exception:
                return jsonify({"success": False, "error": "Could not find sheet named 'Explainability Dataset' in the uploaded file."})
        else:
            return jsonify({"success": False, "error": "Unsupported format"})
        df.columns = [str(c).strip() for c in df.columns]
        result_col = next((c for c in df.columns if c.strip().lower() in ('result', 'assurance test result', 'assurance test result(pass/fail)', 'overall result')), None)
        if not result_col:
            return jsonify({"success": False, "error": "Could not find 'Result' or 'Assurance Test Result' column in uploaded file."})
        rows = []
        for _, row in df.iterrows():
            record = {}
            for col in df.columns:
                val = row[col]
                record[col] = "" if pd.isna(val) else str(val).strip()
            rows.append(record)
        pipeline_store['explainability_data'] = {'rows': rows, 'result_col': result_col, 'columns': list(df.columns)}
        pass_count = sum(1 for r in rows if r.get(result_col, '').strip().lower() == 'pass')
        fail_count = len(rows) - pass_count
        return jsonify({"success": True, "rows": rows, "columns": list(df.columns), "result_col": result_col, "pass_count": pass_count, "fail_count": fail_count, "total": len(rows)})
    except Exception as e:
        return jsonify({"success": False, "error": str(e)})


@dataset_bp.route("/api/parse-agentic-bulk", methods=["POST"])
def api_parse_agentic_bulk():
    try:
        file = request.files.get('file')
        if not file:
            return jsonify({"success": False, "error": "No file uploaded"})
        fn = file.filename.lower()
        if fn.endswith('.csv'):
            df = pd.read_csv(file)
        elif fn.endswith(('.xlsx', '.xls')):
            df = pd.read_excel(file)
        else:
            return jsonify({"success": False, "error": "Unsupported format. Use .csv, .xlsx, or .xls"})
        df.columns = [str(c).strip().lower() for c in df.columns]
        agent_col = spec_col = input_col = None
        for c in df.columns:
            cl = c.replace("_", " ").strip()
            if cl in ('agent name', 'agent', 'agentname', 'name'):
                agent_col = c
            elif cl in ('spec', 'specification', 'agent spec', 'agent specification', 'system prompt'):
                spec_col = c
            elif cl in ('input', 'query', 'question', 'inputs'):
                input_col = c
        if not agent_col:
            return jsonify({"success": False, "error": "Could not find 'Agent Name' column. Expected: Agent Name, SPEC, Input"})
        if not spec_col:
            return jsonify({"success": False, "error": "Could not find 'SPEC' column. Expected: Agent Name, SPEC, Input"})
        if not input_col:
            return jsonify({"success": False, "error": "Could not find 'Input' column. Expected: Agent Name, SPEC, Input"})
        grouped = {}
        total_inputs = 0
        for _, row in df.iterrows():
            an = str(row.get(agent_col, '')).strip()
            sp = str(row.get(spec_col, '')).strip()
            inp = str(row.get(input_col, '')).strip()
            if not an or an.lower() == 'nan' or not sp or sp.lower() == 'nan':
                continue
            if not inp or inp.lower() == 'nan':
                continue
            key = f"{an}|||{sp}"
            if key not in grouped:
                grouped[key] = {"agent_name": an, "spec": sp, "inputs": []}
            grouped[key]["inputs"].append(inp)
            total_inputs += 1
        if not grouped:
            return jsonify({"success": False, "error": "No valid rows found. Ensure Agent Name, SPEC, and Input columns have data."})
        configs = list(grouped.values())
        return jsonify({"success": True, "configs": configs, "total_configs": len(configs), "total_inputs": total_inputs})
    except Exception as e:
        return jsonify({"success": False, "error": str(e)})
