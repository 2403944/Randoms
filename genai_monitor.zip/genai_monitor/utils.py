"""Shared utility functions used across tabs and report generation."""
import re
import unicodedata
import difflib
import pandas as pd


def highlight_diff(base, augmented):
    if pd.isna(base) or pd.isna(augmented):
        return augmented
    base_words = str(base).split()
    aug_words = str(augmented).split()
    diff = list(difflib.ndiff(base_words, aug_words))
    tokens = []
    for token in diff:
        if token.startswith("+ "):
            tokens.append((token[2:], True))
        elif token.startswith("  "):
            tokens.append((token[2:], False))
    result = []
    i = 0
    while i < len(tokens):
        word, is_added = tokens[i]
        if is_added:
            group = []
            while i < len(tokens) and tokens[i][1]:
                group.append(tokens[i][0])
                i += 1
            result.append(f"<span class='diff-added'>{' '.join(group)}</span>")
        else:
            result.append(word)
            i += 1
    return " ".join(result)


def normalize_query_match(text):
    if not text:
        return ""
    text = str(text)
    text = unicodedata.normalize("NFKD", text)
    text = text.lower()
    text = re.sub(r"[^\w\s]", "", text)
    text = re.sub(r"\s+", " ", text).strip()
    return text


def normalize_text(text):
    if text is None:
        return ""
    text = str(text)
    text = unicodedata.normalize("NFKD", text)
    text = text.lower()
    text = re.sub(r"[^\w\s]", "", text)
    text = re.sub(r"\s+", " ", text).strip()
    return text


def text_equal(a, b):
    return normalize_text(a) == normalize_text(b)


def find_column(df, possible_names):
    try:
        for name in possible_names:
            if name in df.columns:
                return name
        return df.columns[0] if len(df.columns) > 0 else None
    except Exception:
        return None


def safe_numeric_conversion(value):
    try:
        return pd.to_numeric(value, errors='coerce')
    except Exception:
        return float('nan')


def format_percentage(value, total):
    if total == 0:
        return "0%"
    return f"{(value/total)*100:.1f}%"


def truncate_text(text, max_length=100):
    text = str(text).strip()
    if len(text) <= max_length:
        return text
    return text[:max_length - 3] + "..."


def clean_text(text):
    if pd.isna(text) or text is None:
        return 'N/A'
    text = str(text).strip()
    if not text or text.lower() in ['nan', 'none', '']:
        return 'N/A'
    return text.replace('\\n', '\n').replace('\n', '<br>')
