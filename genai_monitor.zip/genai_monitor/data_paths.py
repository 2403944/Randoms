"""
Single source of truth for all data file paths.
All Excel/data files live in the data/ subfolder.
.env stays in the project root (genai_monitor/).
"""
from pathlib import Path

# Project root = genai_monitor/
PROJECT_ROOT = Path(__file__).resolve().parent

# Data folder = genai_monitor/data/
DATA_DIR = PROJECT_ROOT / "data"

# Excel file paths
METRICS_TEMPLATE_PATH = DATA_DIR / "Metrics_template02.xlsx"
EVAL_RESULTS_PATH = DATA_DIR / "final_eval_results01.xlsx"
AGENT_AUGMENTATIONS_PATH = DATA_DIR / "agent_query_augmentations.xlsx"
AUGMENTATIONS_EXCEL_PATH = DATA_DIR / "Augmentations 2.xlsx"

# .env stays in project root
ENV_PATH = PROJECT_ROOT / ".env"
