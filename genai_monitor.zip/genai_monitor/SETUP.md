# GenAI Monitor - Complete Setup Guide

## Quick Start (4 steps)

### Step 1: Run all 6 build scripts
```bash
python build_part1.py   # Core files + Routes + app.py
python build_part2.py   # All 5 tab files
python build_part3.py   # CSS + JS templates + report_generator.py
python build_part4.py   # Trustworthy JS files
python build_part5.py   # Pipeline JS (largest)
python build_part6.py   # HTML report assembly + final setup
```

### Step 2: Copy your original file (ONE file needed)
```bash
cp your_original_file.py genai_monitor/report_generator_original.py
```

### Step 3: Copy data files into genai_monitor/
```bash
cp Metrics_template02.xlsx genai_monitor/
cp final_eval_results01.xlsx genai_monitor/        # optional
cp agent_query_augmentations.xlsx genai_monitor/   # optional
cp "Augmentations 2.xlsx" genai_monitor/           # optional
cp .env genai_monitor/                             # for Azure OpenAI
```

### Step 4: Run
```bash
cd genai_monitor
python run_all.py
```

## What runs from separated files (Parts 1-5):
- ✅ All Flask routes (4 route files)
- ✅ All 5 tab generators
- ✅ All prompts (centralized in prompts.py)
- ✅ Azure OpenAI client with retry/parallel
- ✅ All utility functions
- ✅ Pipeline store
- ✅ Configuration
- ✅ Techniques loader
- ✅ Report generator orchestrator
- ✅ All CSS styles
- ✅ Pipeline JavaScript
- ✅ Trustworthy JS (usecase, bias, explain, trust)
- ✅ Disaggregated JS
- ✅ Upload runs JS

## What bridges to the original (Part 6):
- 🔗 `_generate_modern_html()` - the master HTML assembly (~1000 lines)
- 🔗 `_generate_evaluations_wizard_html()` - evaluations wizard (~400 lines)

These are single massive f-strings with deeply nested Python/JS/HTML
interpolation that cannot be safely split across build scripts.

## Project Structure
```
genai_monitor/
├── app.py                          # Flask entry point
├── run_all.py                      # Setup checker + launcher
├── config.py                       # Configuration defaults
├── prompts.py                      # ALL prompts (centralized)
├── llm_client.py                   # Azure OpenAI client
├── pipeline_store.py               # Global in-memory store
├── utils.py                        # Shared utilities
├── techniques_loader.py            # Augmentation technique loader
├── report_generator.py             # Main orchestrator (NEW)
├── report_generator_original.py    # Original file (for HTML assembly)
│
├── routes/
│   ├── __init__.py                 # Blueprint registration
│   ├── main_routes.py              # / and /compare-runs
│   ├── dataset_routes.py           # Dataset CRUD APIs
│   ├── augmentation_routes.py      # Augmentation + coverage APIs
│   └── evaluation_routes.py        # Bias, trust, explainability APIs
│
├── tabs/
│   ├── __init__.py
│   ├── metrics_summary.py          # Tab 1: Metrics Summary
│   ├── data_assurance.py           # Tab 2: Data Assurance
│   ├── model_quality_assurance.py  # Tab 3: Model Quality Assurance
│   ├── mqa_evaluations_wizard.py   # Tab 3: Evaluations wizard bridge
│   ├── trustworthy_assurance.py    # Tab 4: Trustworthy Assurance
│   └── secondary_llm.py           # Tab 5: Secondary LLM
│
├── templates/
│   ├── __init__.py
│   ├── css_styles.py               # Complete CSS stylesheet
│   ├── html_modal.py               # Detail modal HTML
│   ├── html_report.py              # Master HTML assembly (bridge)
│   ├── js_pipeline.py              # Pipeline wizard JS
│   ├── js_disaggregated.py         # Disaggregated view JS
│   ├── js_upload_runs.py           # Run comparison JS
│   ├── js_tw_usecase.py            # TW usecase assessment JS
│   ├── js_tw_bias.py               # TW bias evaluation JS
│   ├── js_tw_explain_trust.py      # TW explainability + trust JS
│   └── js_evaluations_wizard.py    # Evaluations wizard bridge
│
├── Metrics_template02.xlsx         # Your data files
├── final_eval_results01.xlsx
├── agent_query_augmentations.xlsx
├── Augmentations 2.xlsx
└── .env                            # Azure OpenAI credentials
```
