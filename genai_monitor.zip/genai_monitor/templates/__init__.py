"""Template generators for CSS, JS, and HTML."""
