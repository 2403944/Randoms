"""Trustworthy Usecase Assessment JavaScript - EXACT original code."""
import json


def get_tw_usecase_js():
    tw_metrics = [
        {"name":"SKU Priority Bias","cat":"Bias Evaluation","desc":"Detects if the system unfairly prioritizes certain SKUs over others based on non-relevant attributes."},
        {"name":"SKU Service Level Bias","cat":"Bias Evaluation","desc":"Checks whether service level agreements are applied inconsistently across different SKUs."},
        {"name":"Vendor Geographic Bias","cat":"Bias Evaluation","desc":"Detects if vendor selection or scoring is unfairly influenced by geographic location."},
        {"name":"Economic Value Bias","cat":"Bias Evaluation","desc":"Checks if higher-value items receive disproportionately better treatment in routing or prioritization."},
        {"name":"Geographic Reasoning Inconsistency Bias","cat":"Bias Evaluation","desc":"Identifies inconsistent reasoning when handling geographically similar scenarios."},
        {"name":"SKU Differential Treatment Bias","cat":"Bias Evaluation","desc":"Detects if similar SKUs receive significantly different handling without justification."},
        {"name":"Criminality","cat":"Trustworthy","desc":"Detects content that promotes, glorifies, or provides instructions for criminal activities."},
        {"name":"Insensitivity","cat":"Trustworthy","desc":"Identifies responses that are culturally, emotionally, or socially insensitive."},
        {"name":"Stereotype","cat":"Trustworthy","desc":"Detects stereotypical assumptions or generalizations based on protected attributes."},
        {"name":"Profanity","cat":"Trustworthy","desc":"Identifies the presence of profane, vulgar, or offensive language in outputs."},
        {"name":"PII Detection","cat":"Trustworthy","desc":"Checks if personally identifiable information is exposed or generated in responses."},
        {"name":"Unethical","cat":"Trustworthy","desc":"Detects outputs that suggest or encourage unethical behavior or decision-making."},
        {"name":"Decision Traceability","cat":"Explainability","desc":"Evaluates whether each decision can be traced back to specific inputs and reasoning steps."},
        {"name":"Explanation Consistency","cat":"Explainability","desc":"Checks if explanations remain consistent when similar queries are asked differently."},
        {"name":"Evidence Grounding","cat":"Explainability","desc":"Verifies that explanations are grounded in actual data and evidence from the context."},
        {"name":"Explanation Completeness","cat":"Explainability","desc":"Assesses whether all relevant factors are addressed in the explanation."},
        {"name":"Explanation Faithfulness","cat":"Explainability","desc":"Measures if the explanation accurately reflects the actual reasoning process used."},
        {"name":"Decision Factor Visibility","cat":"Explainability","desc":"Checks if the key factors influencing a decision are clearly visible and stated."},
        {"name":"Explanation Transparency","cat":"Explainability","desc":"Evaluates how transparent and understandable the explanation is for the end user."},
    ]
    return f"""<script>
(function(){{
var TW_METRICS={json.dumps(tw_metrics)};
var twMetricStates={{}};var twActiveTab='all';
TW_METRICS.forEach(function(m){{twMetricStates[m.name]={{enabled:false,threshold:0.5,inverse:false}};}});
window._twMetricStatesRef=twMetricStates;

window.suggestTWMetrics=function(){{
var desc=document.getElementById('twUcDesc')?.value.trim();var users=document.getElementById('twUcUsers')?.value.trim();
if(!desc){{alert('Please provide a usecase description.');return;}}
document.getElementById('twUsecaseForm').style.display='none';document.getElementById('twSuggestLoading').style.display='block';document.getElementById('twSuggestResults').style.display='none';
var msgs=['Reading usecase description...','Analyzing end user profiles...','Evaluating compliance requirements...','Mapping bias risk vectors...','Identifying explainability needs...','Generating metric recommendations...','Finalizing suggestions...'];
var progress=0,msgIdx=0;
var timer=setInterval(function(){{progress+=Math.random()*12+3;if(progress>95)progress=95;document.getElementById('twSuggestFill').style.width=progress+'%';
if(msgIdx<msgs.length-1&&Math.random()>0.45){{msgIdx++;document.getElementById('twSuggestMsg').textContent=msgs[msgIdx];}}}},600);
setTimeout(function(){{clearInterval(timer);document.getElementById('twSuggestFill').style.width='100%';document.getElementById('twSuggestMsg').textContent='Done!';
setTimeout(function(){{
TW_METRICS.forEach(function(m){{twMetricStates[m.name].enabled=true;}});
document.getElementById('twSuggestLoading').style.display='none';document.getElementById('twSuggestResults').style.display='block';
renderTWMetricCards();}},400);
}},4500);
}};

function renderTWMetricCards(){{
var grid=document.getElementById('twMetricCardsGrid');grid.innerHTML='';
var search=(document.getElementById('twMetricSearch')?.value||'').toLowerCase();
var enabledCount=0;
TW_METRICS.forEach(function(m){{
var st=twMetricStates[m.name]||{{enabled:false,threshold:0.5,inverse:false}};
if(twActiveTab!=='all'&&m.cat!==twActiveTab)return;
if(search&&m.name.toLowerCase().indexOf(search)===-1&&m.desc.toLowerCase().indexOf(search)===-1)return;
if(st.enabled)enabledCount++;
var badgeClass=m.cat==='Bias Evaluation'?'tw-badge-bias':(m.cat==='Trustworthy'?'tw-badge-trust':'tw-badge-explain');
var sliderBg=st.inverse?'linear-gradient(90deg,#28a745 0%,#ffc107 50%,#dc3545 100%)':'linear-gradient(90deg,#dc3545 0%,#ffc107 50%,#28a745 100%)';
var card=document.createElement('div');card.className='tw-card'+(st.enabled?' enabled':'');card.setAttribute('data-metric',m.name);
card.innerHTML='<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:10px;"><span class="tw-badge '+badgeClass+'">'+m.cat+'</span><label class="emc-toggle"><input type="checkbox" '+(st.enabled?'checked':'')+' onchange="toggleTWMetric(\\''+m.name.replace(/'/g,"\\\\'")+'\\',this.checked)"><span class="slider"></span></label></div>'
+'<h4 style="margin-bottom:6px;font-size:1rem;color:#333;">'+m.name+'</h4><p style="font-size:0.82rem;color:#888;margin-bottom:14px;line-height:1.4;">'+m.desc+'</p>'
+'<div style="display:flex;align-items:center;gap:8px;margin-bottom:8px;"><input type="checkbox" id="twinv_'+m.name.replace(/\\s/g,'_')+'" '+(st.inverse?'checked':'')+' onchange="toggleTWInverse(\\''+m.name.replace(/'/g,"\\\\'")+'\\',this.checked)" style="accent-color:#A23B72;"><label for="twinv_'+m.name.replace(/\\s/g,'_')+'" style="font-size:0.85rem;color:#555;">Inverse</label></div>'
+'<div style="display:flex;align-items:center;gap:10px;"><div style="flex:1;"><input type="range" class="emc-slider'+(st.inverse?' inverse-slider':'')+'" min="0" max="1" step="0.01" value="'+st.threshold+'" oninput="updateTWThreshold(\\''+m.name.replace(/'/g,"\\\\'")+'\\',this.value)" style="background:'+sliderBg+';"><div style="display:flex;justify-content:space-between;font-size:0.75rem;color:#aaa;margin-top:2px;"><span>0</span><span>1</span></div></div><input type="number" min="0" max="1" step="0.01" value="'+st.threshold+'" onchange="updateTWThreshold(\\''+m.name.replace(/'/g,"\\\\'")+'\\',this.value)" style="width:55px;padding:6px;border:1px solid #ccc;border-radius:6px;text-align:center;font-weight:700;font-size:0.95rem;"></div>';
grid.appendChild(card);}});
document.getElementById('twMetricCount').textContent=enabledCount>0?enabledCount+' metric(s) enabled':'No metrics enabled';
document.getElementById('twMetricCount').style.color=enabledCount>0?'#28a745':'#dc3545';
}}

window.filterTWMetrics=function(cat,btn){{if(cat!==null){{twActiveTab=cat;document.querySelectorAll('.tw-mc-tab').forEach(function(b){{b.classList.remove('active');}});if(btn)btn.classList.add('active');}}renderTWMetricCards();}};

window.downloadTWConfig=function(){{
var biasMetrics=[],explainMetrics=[],trustMetrics=[];
Object.keys(twMetricStates).forEach(function(k){{
if(!twMetricStates[k].enabled)return;
var m=TW_METRICS.find(function(x){{return x.name===k;}});
if(!m)return;
if(m.cat==='Bias Evaluation')biasMetrics.push(k);
else if(m.cat==='Explainability')explainMetrics.push(k);
else if(m.cat==='Trustworthy')trustMetrics.push(k);
}});
if(biasMetrics.length===0&&explainMetrics.length===0&&trustMetrics.length===0){{alert('No metrics enabled. Please enable at least one metric.');return;}}
var csv='Category,Metrics\\n';
csv+='"Bias Evaluation","'+biasMetrics.join(', ')+'"\\n';
csv+='"Explainability","'+explainMetrics.join(', ')+'"\\n';
csv+='"Trustworthy","'+trustMetrics.join(', ')+'"\\n';
var b=new Blob([csv],{{type:'text/csv'}}),u=URL.createObjectURL(b),a=document.createElement('a');
a.href=u;a.download='trustworthy_metrics_config.csv';a.click();URL.revokeObjectURL(u);
}};
window.toggleTWMetric=function(name,on){{if(twMetricStates[name])twMetricStates[name].enabled=on;renderTWMetricCards();}};
window.toggleTWInverse=function(name,on){{if(twMetricStates[name])twMetricStates[name].inverse=on;renderTWMetricCards();}};
window.updateTWThreshold=function(name,val){{if(!twMetricStates[name])return;twMetricStates[name].threshold=parseFloat(val)||0;
var card=document.querySelector('.tw-card[data-metric="'+name+'"]');if(card){{var sl=card.querySelector('input[type=range]');var nm=card.querySelector('input[type=number]');if(sl)sl.value=val;if(nm)nm.value=val;}}}};
}})();
</script>"""
