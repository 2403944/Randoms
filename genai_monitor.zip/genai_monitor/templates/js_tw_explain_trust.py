"""Trustworthy Explainability + Trust Metric Evaluation JavaScript.

Fully working: upload, config, evaluation table with em-dash reason extraction, analytics charts."""


def get_tw_explain_trust_eval_js():

    return """
<script>

(function(){

// =====================================================

// ================= EXPLAINABILITY ====================

// =====================================================

var twExplainData=[];

var twExplainConfigMetrics=[];

var twExplainEvalData=[];

// ---- Tab Switch ----

window.showTWExplainSubTab=function(tab){

    ['twExplainUpload','twExplainResults','twExplainAnalytics'].forEach(function(id){

        var el=document.getElementById(id);

        if(el) el.style.display=(id===tab?'block':'none');

    });

    ['twExplain-btn-upload','twExplain-btn-results','twExplain-btn-analytics'].forEach(function(bid){

        var btn=document.getElementById(bid);

        if(btn){btn.style.borderBottomColor='transparent';btn.style.color='#718096';}

    });

    var activeBtn=null;

    if(tab==='twExplainUpload') activeBtn=document.getElementById('twExplain-btn-upload');

    else if(tab==='twExplainResults') activeBtn=document.getElementById('twExplain-btn-results');

    else if(tab==='twExplainAnalytics') activeBtn=document.getElementById('twExplain-btn-analytics');

    if(activeBtn){activeBtn.style.borderBottomColor='#00897b';activeBtn.style.color='#00897b';}

    if(tab==='twExplainAnalytics'){

        try{renderTWExplainAnalytics();}catch(e){console.error(e);}

    }

};

// ---- File Handlers ----

window.twExplainHandleDrop=function(e){

    e.preventDefault();

    if(e.dataTransfer.files.length>0) twExplainProcessFile(e.dataTransfer.files[0]);

};

window.twExplainHandleUpload=function(inp){

    if(inp && inp.files && inp.files.length>0) twExplainProcessFile(inp.files[0]);

};

window.twExplainHandleConfigDrop=function(e){

    e.preventDefault();

    if(e.dataTransfer.files.length>0) twExplainProcessConfig(e.dataTransfer.files[0]);

};

window.twExplainHandleConfigUpload=function(inp){

    if(inp && inp.files && inp.files.length>0) twExplainProcessConfig(inp.files[0]);

};

// ---- Config Process ----

function twExplainProcessConfig(file){

    try{

        var st=document.getElementById('twExplainConfigStatus');

        var reader=new FileReader();

        reader.onload=function(e){

            var lines=e.target.result.split('\\n').filter(function(l){return l.trim();});

            twExplainConfigMetrics=[];

            lines.forEach(function(line,idx){

                if(idx===0 && line.toLowerCase().indexOf('category')!==-1) return;

                var parts=line.split(',');

                if(parts.length>=2){

                    var cat=parts[0].replace(/"/g,'').trim();

                    var metrics=parts.slice(1).join(',').replace(/"/g,'').trim();

                    if(cat==='Explainability' && metrics){

                        twExplainConfigMetrics=metrics.split(',').map(function(m){return m.trim();}).filter(function(m){return m;});

                    }

                }

            });

            if(st){

                st.innerHTML=twExplainConfigMetrics.length>0

                    ? '<span style="color:#28a745;font-weight:600;">&#10003; '+twExplainConfigMetrics.length+' explainability metrics loaded</span>'

                    : '<span style="color:#F18F01;font-weight:600;">&#9888; No explainability metrics found in config. Using defaults.</span>';

            }

            twExplainCheckReady();

        };

        reader.readAsText(file);

    }catch(e){console.error("Explain config error:",e);}

}

// ---- File Upload (via API) ----

function twExplainProcessFile(file){

    var st=document.getElementById('twExplainUploadStatus');

    try{

        var nm=file.name.toLowerCase();

        if(!nm.endsWith('.csv')&&!nm.endsWith('.xlsx')&&!nm.endsWith('.xls')){

            if(st) st.innerHTML='<span style="color:#dc3545;">Unsupported format</span>';

            return;

        }

        if(st) st.innerHTML='<span class="spinner"></span> Uploading...';

        var fd=new FormData();

        fd.append('file',file);

        fetch('/api/upload-explainability-data',{method:'POST',body:fd})

        .then(function(r){return r.json();})

        .then(function(d){

            if(d.success){

                twExplainData=d.rows;

                twExplainData._result_col=d.result_col;

                twExplainData._columns=d.columns;

                if(st) st.innerHTML='<span style="color:#28a745;font-weight:600;">&#10003; '+d.total+' rows uploaded | Result column: <strong>'+xEsc(d.result_col)+'</strong></span>';

                var pv=document.getElementById('twExplainPreview');

                if(pv){

                    pv.style.display='block';

                    pv.innerHTML='<div style="padding:12px 16px;background:#e0f2f1;border:1px solid #b2dfdb;border-radius:8px;color:#00897b;font-weight:600;">&#10003; '+d.total+' rows uploaded successfully.</div>';

                }

                twExplainCheckReady();

            }else{

                if(st) st.innerHTML='<span style="color:#dc3545;">&#10007; '+(d.error||'Failed')+'</span>';

            }

        })

        .catch(function(e){

            if(st) st.innerHTML='<span style="color:#dc3545;">&#10007; '+e+'</span>';

        });

    }catch(e){

        console.error("Explain upload error:",e);

        if(st) st.innerHTML='<span style="color:#dc3545;">&#10007; '+e+'</span>';

    }

}

function twExplainCheckReady(){

    var btn=document.getElementById('twExplainEvalBtn');

    if(btn) btn.disabled=twExplainData.length===0;

}

// ---- Run Evaluation ----

window.twExplainRunEval=function(){

    if(!twExplainData||twExplainData.length===0){alert('Please upload a dataset first.');return;}

    showTWExplainSubTab('twExplainResults');

    var loading=document.getElementById('twExplainEvalLoading');

    var results=document.getElementById('twExplainEvalResultsContent');

    if(loading) loading.style.display='block';

    if(results) results.innerHTML='';

    var msgs=['Loading evaluation data...','Reading Result column...','Computing pass/fail counts...','Preparing metrics summary...','Rendering results...'];

    var msgIdx=0;var progress=0;

    var timer=setInterval(function(){

        progress+=Math.random()*18+8;

        if(progress>92) progress=92;

        var fillEl=document.getElementById('twExplainEvalFill');

        if(fillEl) fillEl.style.width=progress+'%';

        if(msgIdx<msgs.length-1 && Math.random()>0.4){

            msgIdx++;

            var msgEl=document.getElementById('twExplainEvalMsg');

            if(msgEl) msgEl.textContent=msgs[msgIdx];

        }

    },500);

    setTimeout(function(){

        clearInterval(timer);

        var fillEl=document.getElementById('twExplainEvalFill');

        if(fillEl) fillEl.style.width='100%';

        var msgEl=document.getElementById('twExplainEvalMsg');

        if(msgEl) msgEl.textContent='Done!';

        if(loading) loading.style.display='none';

        var resultCol=twExplainData._result_col||'Result';

        var columns=twExplainData._columns||[];

        var rows=twExplainData;

        /* Find audit columns (columns containing 'audit' in name, excluding the result column) */

        var auditCols=columns.filter(function(c){

            return c.trim().toLowerCase().indexOf('audit')!==-1 && c!==resultCol;

        });

        twExplainEvalData=rows.map(function(r){

            var res=(r[resultCol]||'').trim().toLowerCase();

            var auditResults={};

            auditCols.forEach(function(col){

                var val=(r[col]||'').trim().toLowerCase();

                auditResults[col]=val.indexOf('pass')===0?'Pass':'Fail';

            });

            return {

                result: res.indexOf('pass')===0?'Pass':'Fail',

                audit_results: auditResults,

                raw: r

            };

        });

        twExplainEvalData._auditCols=auditCols;

        var passCount=twExplainEvalData.filter(function(r){return r.result==='Pass';}).length;

        var failCount=twExplainEvalData.length-passCount;

        /* Summary cards */

        var h='<div style="display:flex;gap:16px;margin-bottom:20px;flex-wrap:wrap;">';

        h+='<div style="padding:14px 24px;background:#e8f5e9;border-radius:10px;text-align:center;"><div style="font-size:1.5rem;font-weight:700;color:#28a745;">'+passCount+'</div><div style="font-size:0.82rem;color:#2e7d32;font-weight:600;">Overall Passed</div></div>';

        h+='<div style="padding:14px 24px;background:#ffebee;border-radius:10px;text-align:center;"><div style="font-size:1.5rem;font-weight:700;color:#dc3545;">'+failCount+'</div><div style="font-size:0.82rem;color:#c62828;font-weight:600;">Overall Failed</div></div>';

        h+='<div style="padding:14px 24px;background:#e0f2f1;border-radius:10px;text-align:center;"><div style="font-size:1.5rem;font-weight:700;color:#00897b;">'+(passCount/(twExplainEvalData.length||1)*100).toFixed(1)+'%</div><div style="font-size:0.82rem;color:#00897b;font-weight:600;">Overall Pass Rate</div></div>';

        h+='</div>';

        /* Full data table with all columns */

        h+='<div class="table-container" style="max-height:500px;">';

        h+='<table class="modern-table"><thead><tr>';

        columns.forEach(function(c){

            var cl=c.trim().toLowerCase();

            var isStatus=cl.indexOf('audit')!==-1||cl.indexOf('assurance test result')!==-1||c===resultCol;

            var al=isStatus?' style="text-align:center;"':'';

            h+='<th'+al+'>'+xEsc(c)+'</th>';

        });

        h+='</tr></thead><tbody>';

        rows.forEach(function(r){

            h+='<tr>';

            columns.forEach(function(c){

                var val=r[c]||'';

                var cl=c.trim().toLowerCase();

                var isOverallResult=c===resultCol||cl.indexOf('assurance test result')!==-1;

                var isAuditCol=cl.indexOf('audit')!==-1&&!isOverallResult;

                if(isOverallResult){

                    var isPass=val.trim().toLowerCase().indexOf('pass')===0;

                    var sc=isPass?'#28a745':'#dc3545';

                    var lb=isPass?'Pass':'Fail';

                    h+='<td style="text-align:center;"><span style="padding:4px 12px;border-radius:12px;font-size:0.8rem;font-weight:700;color:white;background:'+sc+';">'+lb+'</span></td>';

                }else if(isAuditCol){

                    var trimmed=val.trim();

                    var isPass2=trimmed.toLowerCase().indexOf('pass')===0;

                    var sc2=isPass2?'#28a745':'#dc3545';

                    var lb2=isPass2?'Pass':'Fail';

                    var reason=extractReason(trimmed);

                    h+='<td><span style="padding:3px 10px;border-radius:12px;font-size:0.78rem;font-weight:700;color:white;background:'+sc2+';margin-right:8px;">'+lb2+'</span>';

                    if(reason) h+='<span style="font-size:0.82rem;color:#555;">'+xEsc(reason)+'</span>';

                    h+='</td>';

                }else{

                    h+='<td>'+xEsc(val).substring(0,150)+'</td>';

                }

            });

            h+='</tr>';

        });

        h+='</tbody></table></div>';

        if(results) results.innerHTML=h;

    }, 3000);

};

// ---- Download ----

window.twExplainDownloadResults=function(){

    if(twExplainEvalData.length===0){alert('No results yet.');return;}

    var columns=twExplainData._columns||[];

    var rows=twExplainData;

    var csv=columns.join(',')+' \\n';

    rows.forEach(function(r){

        var line=columns.map(function(c){return '"'+xCe(r[c]||'')+'"';}).join(',');

        csv+=line+'\\n';

    });

    var b=new Blob([csv],{type:'text/csv'});

    var u=URL.createObjectURL(b);

    var a=document.createElement('a');

    a.href=u;a.download='explainability_evaluation_results.csv';a.click();

    URL.revokeObjectURL(u);

};

// ---- Analytics (Plotly) ----

function renderTWExplainAnalytics(){

    if(twExplainEvalData.length===0){

        var emptyEl=document.getElementById('twExplainAnalyticsEmpty');

        var contentEl=document.getElementById('twExplainAnalyticsContent');

        if(emptyEl) emptyEl.style.display='block';

        if(contentEl) contentEl.style.display='none';

        return;

    }

    var emptyEl2=document.getElementById('twExplainAnalyticsEmpty');

    var contentEl2=document.getElementById('twExplainAnalyticsContent');

    if(emptyEl2) emptyEl2.style.display='none';

    if(contentEl2) contentEl2.style.display='block';

    var auditCols=twExplainEvalData._auditCols||[];

    var auditMap={};

    auditCols.forEach(function(col){

        var shortName=col.replace(/audit/gi,'').trim();

        if(!shortName) shortName=col;

        auditMap[shortName]={pass:0,fail:0,col:col};

        twExplainEvalData.forEach(function(r){

            if(r.audit_results&&r.audit_results[col]==='Pass') auditMap[shortName].pass++;

            else auditMap[shortName].fail++;

        });

    });

    var overallPass=twExplainEvalData.filter(function(r){return r.result==='Pass';}).length;

    var overallFail=twExplainEvalData.length-overallPass;

    auditMap['Overall']={pass:overallPass,fail:overallFail};

    var labels=Object.keys(auditMap);

    var passVals=labels.map(function(l){return auditMap[l].pass;});

    var failVals=labels.map(function(l){return auditMap[l].fail;});

    try{

        Plotly.newPlot('twExplainPassFailChart',[

            {x:labels,y:passVals,name:'Pass',type:'bar',marker:{color:'#28a745'}},

            {x:labels,y:failVals,name:'Fail',type:'bar',marker:{color:'#dc3545'}}

        ],{

            barmode:'group',

            margin:{t:30,b:120,l:50,r:20},

            xaxis:{tickangle:-30,title:'Explainability Audit Type'},

            yaxis:{title:'Count'},

            legend:{orientation:'h',y:1.1},

            plot_bgcolor:'rgba(0,0,0,0)',

            paper_bgcolor:'rgba(0,0,0,0)'

        },{displayModeBar:false,responsive:true});

    }catch(e){console.error('Explain bar chart error:',e);}

    var donutLabels=labels.filter(function(l){return l!=='Overall';});

    var donutVals=donutLabels.map(function(l){return auditMap[l].pass;});

    var donutColors=['#00897b','#26a69a','#4db6ac','#80cbc4','#b2dfdb','#e0f2f1'];

    try{

        Plotly.newPlot('twExplainSpreadChart',[{

            labels:donutLabels,

            values:donutVals,

            type:'pie',

            hole:0.4,

            marker:{colors:donutColors.slice(0,donutLabels.length)},

            textinfo:'percent',

            texttemplate:'%{percent}',

            hovertemplate:'<b>%{label}</b><br>Pass: %{value}<br>%{percent}<extra></extra>',

            textfont:{size:13,color:'white'}

        }],{

            margin:{t:30,b:30,l:30,r:30},

            showlegend:true,

            legend:{orientation:'h',y:-0.1},

            annotations:[{text:'Pass<br>Distribution',x:0.5,y:0.5,font:{size:13,color:'#555'},showarrow:false}],

            plot_bgcolor:'rgba(0,0,0,0)',

            paper_bgcolor:'rgba(0,0,0,0)'

        },{displayModeBar:false,responsive:true});

    }catch(e){console.error('Explain donut chart error:',e);}

}


// =====================================================

// ================= TRUST METRIC ======================

// =====================================================

var twTrustData=[];

var twTrustConfigMetrics=[];

var twTrustEvalData=[];

// ---- Tab Switch ----

window.showTWTrustSubTab=function(tab){

    ['twTrustUpload','twTrustResults','twTrustAnalytics'].forEach(function(id){

        var el=document.getElementById(id);

        if(el) el.style.display=(id===tab?'block':'none');

    });

    ['twTrust-btn-upload','twTrust-btn-results','twTrust-btn-analytics'].forEach(function(bid){

        var btn=document.getElementById(bid);

        if(btn){btn.style.borderBottomColor='transparent';btn.style.color='#718096';}

    });

    var activeBtn=null;

    if(tab==='twTrustUpload') activeBtn=document.getElementById('twTrust-btn-upload');

    else if(tab==='twTrustResults') activeBtn=document.getElementById('twTrust-btn-results');

    else if(tab==='twTrustAnalytics') activeBtn=document.getElementById('twTrust-btn-analytics');

    if(activeBtn){activeBtn.style.borderBottomColor='#5c6bc0';activeBtn.style.color='#5c6bc0';}

    if(tab==='twTrustAnalytics'){

        try{renderTWTrustAnalytics();}catch(e){console.error(e);}

    }

};

// ---- File Handlers ----

window.twTrustHandleDrop=function(e){

    e.preventDefault();

    if(e.dataTransfer.files.length>0) twTrustProcessFile(e.dataTransfer.files[0]);

};

window.twTrustHandleUpload=function(inp){

    if(inp && inp.files && inp.files.length>0) twTrustProcessFile(inp.files[0]);

};

window.twTrustHandleConfigDrop=function(e){

    e.preventDefault();

    if(e.dataTransfer.files.length>0) twTrustProcessConfig(e.dataTransfer.files[0]);

};

window.twTrustHandleConfigUpload=function(inp){

    if(inp && inp.files && inp.files.length>0) twTrustProcessConfig(inp.files[0]);

};

// ---- Config Process ----

function twTrustProcessConfig(file){

    try{

        var st=document.getElementById('twTrustConfigStatus');

        var reader=new FileReader();

        reader.onload=function(e){

            var lines=e.target.result.split('\\n').filter(function(l){return l.trim();});

            twTrustConfigMetrics=[];

            lines.forEach(function(line,idx){

                if(idx===0 && line.toLowerCase().indexOf('category')!==-1) return;

                var parts=line.split(',');

                if(parts.length>=2){

                    var cat=parts[0].replace(/"/g,'').trim();

                    var metrics=parts.slice(1).join(',').replace(/"/g,'').trim();

                    if(cat==='Trustworthy' && metrics){

                        twTrustConfigMetrics=metrics.split(',').map(function(m){return m.trim();}).filter(function(m){return m;});

                    }

                }

            });

            if(st){

                st.innerHTML=twTrustConfigMetrics.length>0

                    ? '<span style="color:#28a745;font-weight:600;">&#10003; '+twTrustConfigMetrics.length+' trust metrics loaded</span>'

                    : '<span style="color:#F18F01;font-weight:600;">&#9888; No trust metrics found in config. Using defaults.</span>';

            }

            twTrustCheckReady();

        };

        reader.readAsText(file);

    }catch(e){console.error("Trust config error:",e);}

}

// ---- File Upload (via API) ----

function twTrustProcessFile(file){

    var st=document.getElementById('twTrustUploadStatus');

    try{

        var nm=file.name.toLowerCase();

        if(!nm.endsWith('.csv')&&!nm.endsWith('.xlsx')&&!nm.endsWith('.xls')){

            if(st) st.innerHTML='<span style="color:#dc3545;">Unsupported format</span>';

            return;

        }

        if(st) st.innerHTML='<span class="spinner"></span> Uploading...';

        var fd=new FormData();

        fd.append('file',file);

        fetch('/api/upload-dataset',{method:'POST',body:fd})

        .then(function(r){return r.json();})

        .then(function(d){

            if(d.success){

                twTrustData=d.rows;

                if(st) st.innerHTML='<span style="color:#28a745;font-weight:600;">&#10003; '+d.rows.length+' rows uploaded</span>';

                var pv=document.getElementById('twTrustPreview');

                if(pv){

                    pv.style.display='block';

                    pv.innerHTML='<div style="padding:12px 16px;background:#e8eaf6;border:1px solid #c5cae9;border-radius:8px;color:#5c6bc0;font-weight:600;">&#10003; '+d.rows.length+' rows uploaded successfully.</div>';

                }

                twTrustCheckReady();

            }else{

                if(st) st.innerHTML='<span style="color:#dc3545;">&#10007; '+(d.error||'Failed')+'</span>';

            }

        })

        .catch(function(e){

            if(st) st.innerHTML='<span style="color:#dc3545;">&#10007; '+e+'</span>';

        });

    }catch(e){

        console.error("Trust upload error:",e);

        if(st) st.innerHTML='<span style="color:#dc3545;">&#10007; '+e+'</span>';

    }

}

function twTrustCheckReady(){

    var btn=document.getElementById('twTrustEvalBtn');

    if(btn) btn.disabled=twTrustData.length===0;

}

// ---- Run Evaluation (calls /api/trust-evaluation) ----

window.twTrustRunEval=function(){

    if(twTrustData.length===0){alert('Please upload a dataset first.');return;}

    showTWTrustSubTab('twTrustResults');

    var loading=document.getElementById('twTrustEvalLoading');

    var results=document.getElementById('twTrustEvalResultsContent');

    if(loading) loading.style.display='block';

    if(results) results.innerHTML='';

    var metrics=twTrustConfigMetrics.length>0

        ? twTrustConfigMetrics

        : ['Criminality','Insensitivity','Stereotype','Profanity','PII Detection','Unethical'];

    var progress=0,msgIdx=0;

    var msgs=['Initializing...','Loading '+twTrustData.length+' test cases...','Running '+metrics.length+' trust metrics...','Scanning for PII...','Checking for stereotypes...','Detecting profanity...','Compiling results...'];

    var timer=setInterval(function(){

        progress+=Math.random()*10+3;

        if(progress>92) progress=92;

        var fillEl=document.getElementById('twTrustEvalFill');

        if(fillEl) fillEl.style.width=progress+'%';

        if(msgIdx<msgs.length-1 && Math.random()>0.4){

            msgIdx++;

            var msgEl=document.getElementById('twTrustEvalMsg');

            if(msgEl) msgEl.textContent=msgs[msgIdx];

        }

    },600);

    fetch('/api/trust-evaluation',{

        method:'POST',

        headers:{'Content-Type':'application/json'},

        body:JSON.stringify({rows:twTrustData, metrics:metrics})

    })

    .then(function(r){return r.json();})

    .then(function(d){

        clearInterval(timer);

        var fillEl=document.getElementById('twTrustEvalFill');

        if(fillEl) fillEl.style.width='100%';

        if(loading) loading.style.display='none';

        if(!d.success){

            if(results) results.innerHTML='<div style="color:#dc3545;padding:16px;font-weight:600;">&#10007; '+xEsc(d.error)+'</div>';

            return;

        }

        twTrustEvalData=d.results;

        var passCount=twTrustEvalData.filter(function(r){return r.result==='Pass';}).length;

        var failCount=twTrustEvalData.length-passCount;

        var h='<div style="display:flex;gap:16px;margin-bottom:20px;">';

        h+='<div style="padding:14px 24px;background:#e8f5e9;border-radius:10px;text-align:center;"><div style="font-size:1.5rem;font-weight:700;color:#28a745;">'+passCount+'</div><div style="font-size:0.82rem;color:#2e7d32;font-weight:600;">Passed</div></div>';

        h+='<div style="padding:14px 24px;background:#ffebee;border-radius:10px;text-align:center;"><div style="font-size:1.5rem;font-weight:700;color:#dc3545;">'+failCount+'</div><div style="font-size:0.82rem;color:#c62828;font-weight:600;">Failed</div></div>';

        h+='<div style="padding:14px 24px;background:#e8eaf6;border-radius:10px;text-align:center;"><div style="font-size:1.5rem;font-weight:700;color:#5c6bc0;">'+(passCount/(twTrustEvalData.length||1)*100).toFixed(1)+'%</div><div style="font-size:0.82rem;color:#5c6bc0;font-weight:600;">Pass Rate</div></div></div>';

        h+='<div class="table-container" style="max-height:500px;"><table class="modern-table"><thead><tr>';

        h+='<th>TC ID</th><th>Input</th><th>Expected Output</th><th>Metric</th><th style="text-align:center;">Score</th><th style="text-align:center;">Result</th><th>Explanation</th>';

        h+='</tr></thead><tbody>';

        twTrustEvalData.forEach(function(r){

            var sc=r.result==='Pass'?'#28a745':'#dc3545';

            h+='<tr>';

            h+='<td style="font-weight:700;color:#5c6bc0;">'+xEsc(r.tc_id)+'</td>';

            h+='<td style="max-width:250px;">'+xEsc(r.input).substring(0,120)+'</td>';

            h+='<td style="max-width:200px;">'+xEsc(r.expected_output).substring(0,100)+'</td>';

            h+='<td><span style="background:#e8eaf6;color:#5c6bc0;padding:4px 10px;border-radius:8px;font-size:0.8rem;font-weight:600;">'+xEsc(r.metric)+'</span></td>';

            h+='<td style="text-align:center;font-weight:700;color:'+sc+';">'+r.score.toFixed(2)+'</td>';

            h+='<td style="text-align:center;"><span style="padding:4px 12px;border-radius:12px;font-size:0.8rem;font-weight:700;color:white;background:'+sc+';">'+(r.result==='Pass'?'Pass':'Fail')+'</span></td>';

            h+='<td style="font-size:0.82rem;color:#555;max-width:300px;">'+xEsc(r.explanation)+'</td>';

            h+='</tr>';

        });

        h+='</tbody></table></div>';

        if(results) results.innerHTML=h;

    })

    .catch(function(e){

        clearInterval(timer);

        if(loading) loading.style.display='none';

        if(results) results.innerHTML='<div style="color:#dc3545;padding:16px;font-weight:600;">&#10007; Request failed: '+xEsc(String(e))+'</div>';

    });

};

// ---- Download ----

window.twTrustDownloadResults=function(){

    if(twTrustEvalData.length===0){alert('No results yet.');return;}

    var csv='TC ID,Input,Expected Output,Metric,Score,Result,Explanation\\n';

    twTrustEvalData.forEach(function(r){

        csv+='"'+xCe(r.tc_id)+'","'+xCe(r.input)+'","'+xCe(r.expected_output)+'","'+xCe(r.metric)+'","'+r.score.toFixed(2)+'","'+xCe(r.result)+'","'+xCe(r.explanation)+'"\\n';

    });

    var b=new Blob([csv],{type:'text/csv'});

    var u=URL.createObjectURL(b);

    var a=document.createElement('a');

    a.href=u;a.download='trust_metric_evaluation_results.csv';a.click();

    URL.revokeObjectURL(u);

};

// ---- Analytics (Plotly) ----

function renderTWTrustAnalytics(){

    if(twTrustEvalData.length===0){

        var emptyEl=document.getElementById('twTrustAnalyticsEmpty');

        var contentEl=document.getElementById('twTrustAnalyticsContent');

        if(emptyEl) emptyEl.style.display='block';

        if(contentEl) contentEl.style.display='none';

        return;

    }

    var emptyEl2=document.getElementById('twTrustAnalyticsEmpty');

    var contentEl2=document.getElementById('twTrustAnalyticsContent');

    if(emptyEl2) emptyEl2.style.display='none';

    if(contentEl2) contentEl2.style.display='block';

    var metricMap={};

    twTrustEvalData.forEach(function(r){

        if(!metricMap[r.metric]) metricMap[r.metric]={pass:0,fail:0,scores:[]};

        if(r.result==='Pass') metricMap[r.metric].pass++;

        else metricMap[r.metric].fail++;

        metricMap[r.metric].scores.push(r.score);

    });

    var mLabels=Object.keys(metricMap);

    var passVals=mLabels.map(function(m){return metricMap[m].pass;});

    var failVals=mLabels.map(function(m){return metricMap[m].fail;});

    try{

        Plotly.newPlot('twTrustPassFailChart',[

            {x:mLabels,y:passVals,name:'Pass',type:'bar',marker:{color:'#28a745'}},

            {x:mLabels,y:failVals,name:'Fail',type:'bar',marker:{color:'#dc3545'}}

        ],{

            barmode:'group',

            margin:{t:30,b:100,l:50,r:20},

            xaxis:{tickangle:-30},

            yaxis:{title:'Count'},

            legend:{orientation:'h',y:1.1},

            plot_bgcolor:'rgba(0,0,0,0)',

            paper_bgcolor:'rgba(0,0,0,0)'

        },{displayModeBar:false,responsive:true});

    }catch(e){console.error('Trust bar chart error:',e);}

    var donutVals=mLabels.map(function(m){return metricMap[m].pass;});

    var donutColors=['#5c6bc0','#7986cb','#9fa8da','#c5cae9','#3f51b5','#1a237e','#283593','#303f9f'];

    try{

        Plotly.newPlot('twTrustSpreadChart',[{

            labels:mLabels,

            values:donutVals,

            type:'pie',

            hole:0.4,

            marker:{colors:donutColors.slice(0,mLabels.length)},

            textinfo:'percent',

            texttemplate:'%{percent}',

            hovertemplate:'<b>%{label}</b><br>Pass: %{value}<br>%{percent}<extra></extra>',

            textfont:{size:13,color:'white'}

        }],{

            margin:{t:30,b:30,l:30,r:30},

            showlegend:true,

            legend:{orientation:'h',y:-0.1},

            annotations:[{text:'Pass<br>Distribution',x:0.5,y:0.5,font:{size:13,color:'#555'},showarrow:false}],

            plot_bgcolor:'rgba(0,0,0,0)',

            paper_bgcolor:'rgba(0,0,0,0)'

        },{displayModeBar:false,responsive:true});

    }catch(e){console.error('Trust donut chart error:',e);}

}


// =====================================================

// ================= SHARED UTILITIES ==================

// =====================================================

/* Extract reason after em-dash, en-dash, or regular dash separators */

function extractReason(trimmed){

    var reason='';

    var separators=[' \\u2014 ',' \\u2013 ','\\u2014','\\u2013',' --- ',' -- ',' - '];

    var dashIdx=-1;var sepLen=1;

    for(var si=0;si<separators.length;si++){

        var idx=trimmed.indexOf(separators[si]);

        if(idx!==-1){dashIdx=idx;sepLen=separators[si].length;break;}

    }

    if(dashIdx!==-1) reason=trimmed.substring(dashIdx+sepLen).trim();

    return reason;

}

function xEsc(s){

    if(s===null||s===undefined) return '';

    return String(s)

        .replace(/&/g,'&amp;')

        .replace(/</g,'&lt;')

        .replace(/>/g,'&gt;')

        .replace(/"/g,'&quot;');

}

function xCe(s){

    if(!s) return '';

    return String(s).replace(/"/g,'""');

}

})();
</script>

"""
