"""Trustworthy Bias Evaluation JavaScript - fully working grouping, evaluation, analytics."""


def get_tw_bias_eval_js():

    return """
<script>

(function(){

// ================= STATE =================

var twBiasData=[];

var twBiasGroups=[];

var twBiasEvalData=[];

var twBiasConfigMetrics=[];

// ================= TAB SWITCH =================

window.showTWBiasSubTab=function(tab){

    ['twBiasUpload','twBiasResults','twBiasAnalytics'].forEach(function(id){

        var el=document.getElementById(id);

        if(el) el.style.display = (id===tab ? 'block':'none');

    });

    var gs=document.getElementById('twBiasGroupingSection');

    if(gs) gs.style.display = (tab==='twBiasUpload' ? 'block':'none');

    ['twBias-btn-upload','twBias-btn-results','twBias-btn-analytics'].forEach(function(bid){

        var btn=document.getElementById(bid);

        if(btn){btn.style.borderBottomColor='transparent';btn.style.color='#718096';}

    });

    var activeBtn=null;

    if(tab==='twBiasUpload') activeBtn=document.getElementById('twBias-btn-upload');

    else if(tab==='twBiasResults') activeBtn=document.getElementById('twBias-btn-results');

    else if(tab==='twBiasAnalytics') activeBtn=document.getElementById('twBias-btn-analytics');

    if(activeBtn){activeBtn.style.borderBottomColor='#e65100';activeBtn.style.color='#e65100';}

    if(tab==='twBiasAnalytics'){

        try { renderTWBiasAnalytics(); } catch(e){ console.error(e); }

    }

};

// ================= FILE HANDLERS =================

window.twBiasHandleDrop=function(e){

    e.preventDefault();

    if(e.dataTransfer.files.length>0) twBiasProcessFile(e.dataTransfer.files[0]);

};

window.twBiasHandleUpload=function(inp){

    if(inp && inp.files && inp.files.length>0) twBiasProcessFile(inp.files[0]);

};

window.twBiasHandleConfigDrop=function(e){

    e.preventDefault();

    if(e.dataTransfer.files.length>0) twBiasProcessConfig(e.dataTransfer.files[0]);

};

window.twBiasHandleConfigUpload=function(inp){

    if(inp && inp.files && inp.files.length>0) twBiasProcessConfig(inp.files[0]);

};

// ================= GROUPING BUTTON =================

window.twBiasStartGrouping=function(){

    if(twBiasData.length===0){

        alert('Please upload a dataset first.');

        return;

    }

    var sec=document.getElementById('twBiasGroupingSection');

    if(sec) sec.style.display='block';

    twBiasRunGrouping();

};

// ================= CONFIG PROCESS =================

function twBiasProcessConfig(file){

    try{

        var st=document.getElementById('twBiasConfigStatus');

        var reader=new FileReader();

        reader.onload=function(e){

            var lines=e.target.result.split('\\n').filter(function(l){return l.trim();});

            twBiasConfigMetrics=[];

            lines.forEach(function(line,idx){

                if(idx===0 && line.toLowerCase().indexOf('category')!==-1) return;

                var parts=line.split(',');

                if(parts.length>=2){

                    var cat=parts[0].replace(/"/g,'').trim();

                    var metrics=parts.slice(1).join(',').replace(/"/g,'').trim();

                    if(cat==='Bias Evaluation' && metrics){

                        twBiasConfigMetrics = metrics.split(',').map(function(m){return m.trim();}).filter(function(m){return m;});

                    }

                }

            });

            if(st){

                st.innerHTML = twBiasConfigMetrics.length>0

                    ? '<span style="color:#28a745;font-weight:600;">&#10003; ' + twBiasConfigMetrics.length + ' bias metrics loaded</span>'

                    : '<span style="color:#F18F01;font-weight:600;">&#9888; No bias metrics found in config. Using defaults.</span>';

            }

        };

        reader.readAsText(file);

    }catch(e){

        console.error("Config error:", e);

    }

}

// ================= FILE UPLOAD (via API) =================

function twBiasProcessFile(file){

    var st=document.getElementById('twBiasUploadStatus');

    try{

        var nm=file.name.toLowerCase();

        if(!nm.endsWith('.csv')&&!nm.endsWith('.xlsx')&&!nm.endsWith('.xls')){

            if(st) st.innerHTML='<span style="color:#dc3545;">Unsupported format</span>';

            return;

        }

        if(st) st.innerHTML='<span class="spinner"></span> Uploading...';

        var fd=new FormData();

        fd.append('file',file);

        fetch('/api/upload-bias-data',{method:'POST',body:fd})

        .then(function(r){return r.json();})

        .then(function(d){

            if(d.success){

                twBiasData=d.rows;

                twBiasData._result_col=d.result_col;

                twBiasData._columns=d.columns;

                if(st) st.innerHTML='<span style="color:#28a745;font-weight:600;">&#10003; '+d.total+' rows uploaded successfully.</span>';

                var pv=document.getElementById('twBiasPreview');

                if(pv){

                    pv.style.display='block';

                    pv.innerHTML='<div style="padding:12px 16px;background:#fff3e0;border:1px solid #ffe0b2;border-radius:8px;color:#e65100;font-weight:600;">&#10003; '+d.total+' rows uploaded successfully.</div>';

                }

                var groupBtn=document.getElementById('twBiasGroupBtn');

                if(groupBtn) groupBtn.disabled=false;

                var evalBtn=document.getElementById('twBiasEvalBtnUpload');

                if(evalBtn) evalBtn.disabled=false;

            }else{

                if(st) st.innerHTML='<span style="color:#dc3545;">&#10007; '+(d.error||'Failed')+'</span>';

            }

        })

        .catch(function(e){

            if(st) st.innerHTML='<span style="color:#dc3545;">&#10007; '+e+'</span>';

        });

    }catch(e){

        console.error("Upload error:", e);

        if(st) st.innerHTML='<span style="color:#dc3545;">&#10007; '+e+'</span>';

    }

}

// ================= GROUPING (calls /api/bias-grouping) =================

function twBiasRunGrouping(){

    var loading=document.getElementById('twBiasGroupLoading');

    var results=document.getElementById('twBiasGroupResults');

    if(loading) loading.style.display='block';

    if(results) results.innerHTML='';

    var criteria='';

    var criteriaEl=document.getElementById('twBiasGroupCriteria');

    if(criteriaEl) criteria=criteriaEl.value.trim();

    var msgEl=document.getElementById('twBiasGroupMsg');

    if(msgEl) msgEl.textContent='Sending queries to LLM for semantic analysis...';

    var cols=twBiasData._columns||[];

    var tcCol=cols.find(function(c){var n=c.trim().toLowerCase();return n==='tc id'||n==='tc_id'||n==='tcid'||n==='id';});

    var inputCol=cols.find(function(c){var n=c.trim().toLowerCase();return n==='input query'||n==='input'||n==='query'||n==='question';});

    if(!tcCol) tcCol=cols[0]||'TC ID';

    if(!inputCol) inputCol=cols[1]||'Input Query';

    var inputsPayload=twBiasData.map(function(row){

        return {tc_id:row[tcCol]||'', input:row[inputCol]||''};

    });

    fetch('/api/bias-grouping',{

        method:'POST',

        headers:{'Content-Type':'application/json'},

        body:JSON.stringify({inputs:inputsPayload, criteria:criteria})

    })

    .then(function(r){return r.json();})

    .then(function(d){

        if(loading) loading.style.display='none';

        if(!d.success){

            var errHtml='<div style="border:2px solid #dc3545;border-radius:10px;padding:20px;background:#fff5f5;">';

            errHtml+='<div style="font-weight:700;color:#dc3545;font-size:1rem;margin-bottom:10px;">&#10007; Azure OpenAI Error</div>';

            errHtml+='<div style="background:#1e1e1e;color:#f8f8f2;padding:14px;border-radius:8px;font-family:monospace;font-size:0.82rem;white-space:pre-wrap;word-break:break-word;">';

            errHtml+=twEsc(d.error||'Unknown error');

            errHtml+='</div>';

            if(d.raw_response){

                errHtml+='<div style="margin-top:12px;"><strong style="color:#555;font-size:0.82rem;">Raw LLM Response:</strong>';

                errHtml+='<div style="background:#f5f5f5;padding:10px;border-radius:6px;font-family:monospace;font-size:0.78rem;white-space:pre-wrap;margin-top:4px;">'+twEsc(d.raw_response)+'</div></div>';

            }

            errHtml+='</div>';

            if(results) results.innerHTML=errHtml;

            return;

        }

        var colorPalette=['#e65100','#1565C0','#2e7d32','#7b1fa2','#00838f','#ad1457','#4527a0','#00695c','#558b2f','#6d4c41'];

        twBiasGroups=[];

        d.groups.forEach(function(g,gi){

            var color=colorPalette[gi%colorPalette.length];

            var indices=[];

            g.tc_ids.forEach(function(tc){

                var idx=twBiasData.findIndex(function(r){return r[tcCol]===tc;});

                if(idx!==-1) indices.push(idx);

            });

            twBiasGroups.push({

                id:'G'+(gi+1),

                tcIds:g.tc_ids,

                indices:indices,

                bias:g.group_name,

                reasoning:g.reasoning,

                color:color,

                count:g.count

            });

        });

        var individuals=d.individuals||[];

        var h='';

        if(twBiasGroups.length>0){

            h+='<h4 style="color:#333;margin-bottom:16px;">Identified Bias Groups ('+twBiasGroups.length+')</h4>';

            h+='<div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(340px,1fr));gap:14px;margin-bottom:24px;">';

            twBiasGroups.forEach(function(g){

                h+='<div style="border:2px solid '+g.color+';border-radius:12px;padding:16px;background:white;">';

                h+='<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:8px;">';

                h+='<span style="font-weight:700;font-size:1.0rem;color:'+g.color+';">'+g.id+': '+twEsc(g.bias)+'</span>';

                h+='<span style="background:'+g.color+';color:white;padding:3px 10px;border-radius:12px;font-size:0.78rem;font-weight:700;">'+g.count+' queries</span>';

                h+='</div>';

                if(g.reasoning){

                    h+='<div style="font-size:0.8rem;color:#555;margin-bottom:10px;padding:8px;background:#f9f9f9;border-radius:6px;border-left:3px solid '+g.color+';">';

                    h+='<strong>Why:</strong> '+twEsc(g.reasoning);

                    h+='</div>';

                }

                h+='<div style="display:flex;flex-wrap:wrap;gap:6px;margin-bottom:10px;">';

                g.tcIds.forEach(function(tc){

                    h+='<span style="background:#f0f0f0;padding:4px 10px;border-radius:6px;font-size:0.82rem;font-weight:600;color:#333;">'+twEsc(tc)+'</span>';

                });

                h+='</div>';

                var samples=g.indices.slice(0,2);

                samples.forEach(function(idx){

                    var sampleText=twBiasData[idx][inputCol]||twBiasData[idx].input||'';

                    h+='<div style="background:#fafbfc;padding:8px 10px;border-radius:6px;margin-bottom:4px;font-size:0.8rem;color:#555;border-left:3px solid '+g.color+';">';

                    h+=twEsc(sampleText).substring(0,150);

                    h+='</div>';

                });

                if(g.indices.length>2) h+='<div style="font-size:0.78rem;color:#888;margin-top:4px;">...and '+(g.indices.length-2)+' more</div>';

                h+='</div>';

            });

            h+='</div>';

        }

        if(individuals.length>0){

            h+='<h4 style="color:#333;margin-bottom:12px;">Individual Queries ('+individuals.length+')</h4>';

            h+='<div style="display:flex;flex-wrap:wrap;gap:8px;margin-bottom:16px;">';

            individuals.forEach(function(ind){

                h+='<div style="border:1px solid #e2e8f0;border-radius:8px;padding:10px 14px;background:#fafbfc;max-width:340px;">';

                h+='<span style="font-weight:700;color:#555;font-size:0.85rem;">'+twEsc(ind.tc_id)+'</span>';

                h+='<div style="font-size:0.78rem;color:#888;margin-top:4px;">'+twEsc(ind.input).substring(0,100)+'</div>';

                h+='</div>';

            });

            h+='</div>';

        }

        h+='<div style="background:#f0f4ff;border:1px solid #c5cae9;border-radius:8px;padding:14px;margin-top:8px;">';

        h+='<span style="font-weight:600;color:#333;">Summary:</span> ';

        h+='<span style="color:#555;">'+twBiasGroups.length+' bias group(s) identified across '+twBiasData.length+' queries. '+individuals.length+' individual query/queries.</span>';

        if(criteria){

            h+='<br><span style="font-size:0.82rem;color:#7b1fa2;margin-top:4px;display:inline-block;">Grouping criteria applied: &quot;'+twEsc(criteria)+'&quot;</span>';

        }

        h+='</div>';

        if(results) results.innerHTML=h;

    })

    .catch(function(e){

        if(loading) loading.style.display='none';

        if(results) results.innerHTML='<div style="color:#dc3545;padding:16px;font-weight:600;">&#10007; Request failed: '+twEsc(String(e))+'</div>';

    });

}

// ================= EVALUATION (renders uploaded data table) =================

window.twBiasRunEval=function(){

    if(!twBiasData||twBiasData.length===0){alert('Please upload a dataset first.');return;}

    showTWBiasSubTab('twBiasResults');

    var loading=document.getElementById('twBiasEvalLoading');

    var results=document.getElementById('twBiasEvalResults');

    if(loading) loading.style.display='block';

    if(results) results.innerHTML='';

    var msgs=['Loading bias evaluation data...','Reading Bias Category column...','Computing pass/fail counts...','Preparing metrics summary...','Rendering results...'];

    var msgIdx=0;var progress=0;

    var timer=setInterval(function(){

        progress+=Math.random()*18+8;

        if(progress>92) progress=92;

        var fillEl=document.getElementById('twBiasEvalFill');

        if(fillEl) fillEl.style.width=progress+'%';

        if(msgIdx<msgs.length-1 && Math.random()>0.4){

            msgIdx++;

            var msgEl=document.getElementById('twBiasEvalMsg');

            if(msgEl) msgEl.textContent=msgs[msgIdx];

        }

    },500);

    setTimeout(function(){

        clearInterval(timer);

        var fillEl=document.getElementById('twBiasEvalFill');

        if(fillEl) fillEl.style.width='100%';

        var msgEl=document.getElementById('twBiasEvalMsg');

        if(msgEl) msgEl.textContent='Done!';

        if(loading) loading.style.display='none';

        var resultCol=twBiasData._result_col||'Result';

        var columns=twBiasData._columns||[];

        var rows=twBiasData;

        /* Find bias audit columns */

        var biasAuditCols=columns.filter(function(c){return c.trim().toLowerCase().indexOf('bias audit')!==-1;});

        twBiasEvalData=rows.map(function(r){

            var res=(r[resultCol]||'').trim().toLowerCase();

            var auditResults={};

            biasAuditCols.forEach(function(col){

                var val=(r[col]||'').trim().toLowerCase();

                auditResults[col] = val.indexOf('pass')===0 ? 'Pass' : 'Fail';

            });

            return {

                result: res.indexOf('pass')===0 ? 'Pass' : 'Fail',

                audit_results: auditResults,

                raw: r

            };

        });

        twBiasEvalData._biasAuditCols=biasAuditCols;

        var passCount=twBiasEvalData.filter(function(r){return r.result==='Pass';}).length;

        var failCount=twBiasEvalData.length-passCount;

        /* Summary cards */

        var h='<div style="display:flex;gap:16px;margin-bottom:20px;flex-wrap:wrap;">';

        h+='<div style="padding:14px 24px;background:#e8f5e9;border-radius:10px;text-align:center;"><div style="font-size:1.5rem;font-weight:700;color:#28a745;">'+passCount+'</div><div style="font-size:0.82rem;color:#2e7d32;font-weight:600;">Overall Passed</div></div>';

        h+='<div style="padding:14px 24px;background:#ffebee;border-radius:10px;text-align:center;"><div style="font-size:1.5rem;font-weight:700;color:#dc3545;">'+failCount+'</div><div style="font-size:0.82rem;color:#c62828;font-weight:600;">Overall Failed</div></div>';

        h+='<div style="padding:14px 24px;background:#fff3e0;border-radius:10px;text-align:center;"><div style="font-size:1.5rem;font-weight:700;color:#e65100;">'+(passCount/(twBiasEvalData.length||1)*100).toFixed(1)+'%</div><div style="font-size:0.82rem;color:#e65100;font-weight:600;">Overall Pass Rate</div></div>';

        h+='</div>';

        /* Full data table with all columns */

        h+='<div class="table-container" style="max-height:500px;">';

        h+='<table class="modern-table"><thead><tr>';

        columns.forEach(function(c){

            var cl=c.trim().toLowerCase();

            var isStatus = cl.indexOf('bias audit')!==-1 || cl.indexOf('bias result')!==-1 || cl==='result';

            var al = isStatus ? ' style="text-align:center;"' : '';

            h+='<th'+al+'>'+twEsc(c)+'</th>';

        });

        h+='</tr></thead><tbody>';

        rows.forEach(function(r){

            h+='<tr>';

            columns.forEach(function(c){

                var val=r[c]||'';

                var cl=c.trim().toLowerCase();

                var isOverallResult = c===resultCol || cl.indexOf('bias result')!==-1;

                var isAuditCol = cl.indexOf('bias audit')!==-1;

                if(isOverallResult){

                    var isPass=val.trim().toLowerCase().indexOf('pass')===0;

                    var sc=isPass?'#28a745':'#dc3545';

                    var lb=isPass?'Pass':'Fail';

                    h+='<td style="text-align:center;"><span style="padding:4px 12px;border-radius:12px;font-size:0.8rem;font-weight:700;color:white;background:'+sc+';">'+lb+'</span></td>';

                }else if(isAuditCol){

                    var trimmed=val.trim();

                    var isPass2=trimmed.toLowerCase().indexOf('pass')===0;

                    var sc2=isPass2?'#28a745':'#dc3545';

                    var lb2=isPass2?'Pass':'Fail';

                    var reason='';

                    var separators=[' \\u2014 ',' \\u2013 ','\\u2014','\\u2013',' --- ',' -- ',' - '];

                    var dashIdx=-1;var sepLen=1;

                    for(var si=0;si<separators.length;si++){

                        var idx=trimmed.indexOf(separators[si]);

                        if(idx!==-1){dashIdx=idx;sepLen=separators[si].length;break;}

                    }

                    if(dashIdx!==-1) reason=trimmed.substring(dashIdx+sepLen).trim();

                    h+='<td><span style="padding:3px 10px;border-radius:12px;font-size:0.78rem;font-weight:700;color:white;background:'+sc2+';margin-right:8px;">'+lb2+'</span>';

                    if(reason) h+='<span style="font-size:0.82rem;color:#555;">'+twEsc(reason)+'</span>';

                    h+='</td>';

                }else{

                    h+='<td>'+twEsc(val).substring(0,150)+'</td>';

                }

            });

            h+='</tr>';

        });

        h+='</tbody></table></div>';

        if(results) results.innerHTML=h;

    }, 3000);

};

// ================= DOWNLOAD =================

window.twBiasDownloadResults=function(){

    if(twBiasEvalData.length===0){alert('No evaluation results yet.');return;}

    var columns=twBiasData._columns||[];

    var rows=twBiasData;

    var csv=columns.join(',')+' \\n';

    rows.forEach(function(r){

        var line=columns.map(function(c){return '"'+twCe(r[c]||'')+'"';}).join(',');

        csv+=line+'\\n';

    });

    var b=new Blob([csv],{type:'text/csv'});

    var u=URL.createObjectURL(b);

    var a=document.createElement('a');

    a.href=u;a.download='bias_evaluation_results.csv';a.click();

    URL.revokeObjectURL(u);

};

// ================= ANALYTICS (Plotly charts) =================

function renderTWBiasAnalytics(){

    if(twBiasEvalData.length===0){

        var emptyEl=document.getElementById('twBiasAnalyticsEmpty');

        var contentEl=document.getElementById('twBiasAnalyticsContent');

        if(emptyEl) emptyEl.style.display='block';

        if(contentEl) contentEl.style.display='none';

        return;

    }

    var emptyEl2=document.getElementById('twBiasAnalyticsEmpty');

    var contentEl2=document.getElementById('twBiasAnalyticsContent');

    if(emptyEl2) emptyEl2.style.display='none';

    if(contentEl2) contentEl2.style.display='block';

    var biasAuditCols=twBiasEvalData._biasAuditCols||[];

    /* Group pass/fail per bias audit column */

    var auditMap={};

    biasAuditCols.forEach(function(col){

        var shortName=col.replace(/bias audit/gi,'').trim();

        if(!shortName) shortName=col;

        auditMap[shortName]={pass:0,fail:0,col:col};

        twBiasEvalData.forEach(function(r){

            if(r.audit_results && r.audit_results[col]==='Pass') auditMap[shortName].pass++;

            else auditMap[shortName].fail++;

        });

    });

    /* Add Overall */

    var overallPass=twBiasEvalData.filter(function(r){return r.result==='Pass';}).length;

    var overallFail=twBiasEvalData.length-overallPass;

    auditMap['Overall']={pass:overallPass,fail:overallFail};

    var labels=Object.keys(auditMap);

    var passVals=labels.map(function(l){return auditMap[l].pass;});

    var failVals=labels.map(function(l){return auditMap[l].fail;});

    /* Pass/Fail bar chart */

    try{

        Plotly.newPlot('twBiasPassFailChart',[

            {x:labels,y:passVals,name:'Pass',type:'bar',marker:{color:'#28a745'}},

            {x:labels,y:failVals,name:'Fail',type:'bar',marker:{color:'#dc3545'}}

        ],{

            barmode:'group',

            margin:{t:30,b:120,l:50,r:20},

            xaxis:{tickangle:-30,title:'Bias Audit Type'},

            yaxis:{title:'Count'},

            legend:{orientation:'h',y:1.1},

            plot_bgcolor:'rgba(0,0,0,0)',

            paper_bgcolor:'rgba(0,0,0,0)'

        },{displayModeBar:false,responsive:true});

    }catch(e){console.error('Bar chart error:',e);}

    /* Donut chart */

    var donutLabels=labels.filter(function(l){return l!=='Overall';});

    var donutVals=donutLabels.map(function(l){return auditMap[l].pass;});

    var donutColors=['#2E86AB','#A23B72','#F18F01','#28a745','#6c757d','#17a2b8','#e65100','#7b1fa2'];

    try{

        Plotly.newPlot('twBiasSpreadChart',[{

            labels:donutLabels,

            values:donutVals,

            type:'pie',

            hole:0.4,

            marker:{colors:donutColors.slice(0,donutLabels.length)},

            textinfo:'percent',

            texttemplate:'%{percent}',

            hovertemplate:'<b>%{label}</b><br>Pass: %{value}<br>%{percent}<extra></extra>',

            textfont:{size:13,color:'white'}

        }],{

            margin:{t:30,b:30,l:30,r:30},

            showlegend:true,

            legend:{orientation:'h',y:-0.1},

            annotations:[{text:'Pass<br>Distribution',x:0.5,y:0.5,font:{size:13,color:'#555'},showarrow:false}],

            plot_bgcolor:'rgba(0,0,0,0)',

            paper_bgcolor:'rgba(0,0,0,0)'

        },{displayModeBar:false,responsive:true});

    }catch(e){console.error('Donut chart error:',e);}

}

// ================= SAFE ESCAPE =================

function twEsc(s){

    if(s===null||s===undefined) return '';

    return String(s)

        .replace(/&/g,'&amp;')

        .replace(/</g,'&lt;')

        .replace(/>/g,'&gt;')

        .replace(/"/g,'&quot;');

}

function twCe(s){

    if(!s) return '';

    return String(s).replace(/"/g,'""');

}

})();
</script>

"""
