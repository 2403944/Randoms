"""Upload runs comparison JavaScript."""


def get_upload_runs_js():
    return """<script>function uploadRuns(){var pf=document.getElementById("prevRun").files[0];var cf=document.getElementById("currRun").files[0];if(!pf||!cf){alert("Please upload both files");return;}var fd=new FormData();fd.append("previous_run",pf);fd.append("current_run",cf);fetch("/compare-runs",{method:"POST",body:fd}).then(function(r){return r.text();}).then(function(h){var c=document.getElementById("runComparisonResult");if(!c)return;c.innerHTML=h;Array.from(c.querySelectorAll("script")).forEach(function(os){var ns=document.createElement("script");if(os.src){ns.src=os.src;ns.async=false;}else{ns.textContent=os.innerHTML;}document.body.appendChild(ns);document.body.removeChild(ns);});}).catch(function(){document.getElementById("runComparisonResult").innerHTML="<b>Error comparing runs</b>";});}</script>"""
