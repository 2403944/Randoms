"""Tab modules for each main section of the report."""
