"""Data Assurance tab - coverage sunburst, augmentation pipeline, golden dataset."""
import json
import pandas as pd
import plotly.express as px
import plotly.offline as plot

try:
    from loguru import logger
except ImportError:
    import logging
    logger = logging.getLogger(__name__)

from genai_monitor.utils import highlight_diff
from genai_monitor.data_paths import METRICS_TEMPLATE_PATH


def create_test_coverage_sunburst(excel_path, sheet_name):
    try:
        df = pd.read_excel(excel_path, sheet_name=sheet_name)
        df["topic"] = df["topic"].astype(str).str.strip().str.upper()
        df["sub_topic"] = df["sub_topic"].astype(str).str.strip().str.title()
        df["sub_subtopic"] = df["sub_subtopic"].astype(str).str.strip().replace({"": None, "nan": None, "None": None})
        has_expected = "expected_record_count" in df.columns
        agg_cols = {"count": ("query", lambda x: x.notna().sum())}
        if has_expected:
            agg_cols["expected"] = ("expected_record_count", "sum")
        sunburst_df = df.groupby(["topic", "sub_topic", "sub_subtopic"], dropna=False).agg(**agg_cols).reset_index()
        table_rows = ""
        for _, row in sunburst_df.iterrows():
            actual = int(row["count"])
            sub_sub = row["sub_subtopic"] if pd.notna(row["sub_subtopic"]) else "-"
            expected_val = int(row["expected"]) if has_expected and pd.notna(row.get("expected")) else "-"
            table_rows += f"<tr><td>{row['topic']}</td><td>{row['sub_topic']}</td><td>{sub_sub}</td><td>{expected_val}</td><td>{actual}</td></tr>"
        table_html = f'<div style="width:100%;margin-bottom:32px;"><div class="table-container" style="width:100%;max-width:100%;overflow-x:auto;"><table class="modern-table" style="width:100%;"><thead><tr><th>Topic</th><th>Sub Topic</th><th>Sub Subtopic</th><th>Expected Record Count</th><th>Actual Record Count</th></tr></thead><tbody>{table_rows}</tbody></table></div></div>'
        fig = px.sunburst(sunburst_df, path=["topic", "sub_topic", "sub_subtopic"], values="count", color="topic", branchvalues="total", maxdepth=2)
        fig.update_traces(texttemplate="<b>%{label}</b><br>Count: %{value}<br>%{percentRoot:.0%}", hovertemplate="<b>%{label}</b><br>Count: %{value}<br>%{percentRoot:.0%}<extra></extra>", textfont=dict(size=14))
        fig.update_layout(sunburstcolorway=px.colors.qualitative.Pastel, margin=dict(t=60, l=20, r=20, b=20))
        chart_html = plot.plot(fig, output_type="div", include_plotlyjs=False)
        return table_html + f'<div style="display:flex;justify-content:center;width:100%;"><div style="width:fit-content;">{chart_html}</div></div>'
    except Exception as e:
        return "<div class='text-center p-3'><b>Error loading test coverage</b></div>"


def generate_augmented_data_table(excel_path, sheet_name):
    try:
        df = pd.read_excel(excel_path, sheet_name=sheet_name)
        if df.empty:
            return "<div class='text-center p-3'>No augmentation data available</div>"
        df.columns = [str(c).strip() for c in df.columns]
        base_col = aug_col = case_col = None
        for c in df.columns:
            nm = c.lower()
            if "base" in nm and "query" in nm: base_col = c
            if "augmented" in nm: aug_col = c
            if nm.strip() == "case": case_col = c
        display_cols = [c for c in df.columns if case_col is None or c != case_col]
        case_styles = {"P": ("P", "#1565C0", "#E3F2FD"), "N": ("N", "#B71C1C", "#FFEBEE"), "E": ("E", "#1B5E20", "#E8F5E9")}
        html = ['<div class="table-container"><table class="modern-table"><thead><tr>']
        for col in display_cols:
            html.append(f'<th>{col.replace("_", " ").title()}</th>')
        html.append('</tr></thead><tbody>')
        for _, row in df.iterrows():
            html.append('<tr>')
            bq = str(row[base_col]) if base_col and pd.notna(row.get(base_col)) else ""
            aq = str(row[aug_col]) if aug_col and pd.notna(row.get(aug_col)) else ""
            badge = ""
            if case_col and pd.notna(row.get(case_col)):
                raw = str(row[case_col]).strip().lower()
                key = "P" if raw.startswith("p") else ("N" if raw.startswith("n") else ("E" if raw.startswith("e") else ""))
                if key in case_styles:
                    lb, fg, bg = case_styles[key]
                    badge = f"<span style='display:inline-block;padding:2px 8px;border-radius:4px;font-size:0.75rem;font-weight:800;background:{bg};color:{fg};border:1px solid {fg};'>{lb}</span>"
            for col in display_cols:
                val = row.get(col, "")
                if col == aug_col:
                    dh = highlight_diff(bq, aq)
                    if badge:
                        cc = f"<div style='position:relative;min-height:24px;'><div style='position:absolute;top:0;right:0;'>{badge}</div><div style='padding-right:36px;'>{dh}</div></div>"
                    else:
                        cc = dh
                    html.append(f'<td>{cc}</td>')
                else:
                    html.append(f'<td>{"N/A" if pd.isna(val) else str(val)}</td>')
            html.append('</tr>')
        html.append('</tbody></table></div>')
        return '\n'.join(html)
    except Exception as e:
        return f"<div class='alert alert-error'>Error: {e}</div>"


def get_coverage_edit_data():
    try:
        excel_path = METRICS_TEMPLATE_PATH
        df = pd.read_excel(excel_path, sheet_name='Test data coverage')
        df["topic"] = df["topic"].astype(str).str.strip().str.upper()
        df["sub_topic"] = df["sub_topic"].astype(str).str.strip().str.title()
        df["sub_subtopic"] = df["sub_subtopic"].astype(str).str.strip().replace({"nan": None, "None": None, "": None})
        has_expected = "expected_record_count" in df.columns
        agg_cols = {"count": ("query", lambda x: x.notna().sum())}
        if has_expected:
            agg_cols["expected_record_count"] = ("expected_record_count", "first")
        agg = df.groupby(["topic", "sub_topic", "sub_subtopic"], dropna=False).agg(**agg_cols).reset_index()
        rows = []
        for _, row in agg.iterrows():
            rows.append({
                "topic": row["topic"], "sub_topic": row["sub_topic"],
                "sub_subtopic": row["sub_subtopic"] if pd.notna(row["sub_subtopic"]) else "-",
                "expected_record_count": int(row["expected_record_count"]) if has_expected and pd.notna(row.get("expected_record_count")) else "",
                "actual_record_count": int(row["count"]),
            })
        return rows
    except Exception:
        return []


def generate_augmentation_pipeline_html():
    return """<div>
<div class="wizard-steps" id="wizardSteps"><div class="wizard-step active" onclick="goToWizardStep(1)"><div class="wizard-step-num">1</div><div class="wizard-step-label">Dataset Upload</div></div><div class="wizard-connector" id="wconn1"></div><div class="wizard-step" onclick="goToWizardStep(2)"><div class="wizard-step-num">2</div><div class="wizard-step-label">Data Coverage</div></div><div class="wizard-connector" id="wconn2"></div><div class="wizard-step" onclick="goToWizardStep(3)"><div class="wizard-step-num">3</div><div class="wizard-step-label">Perform Augmentation</div></div><div class="wizard-connector" id="wconn3"></div><div class="wizard-step" onclick="goToWizardStep(4)"><div class="wizard-step-num">4</div><div class="wizard-step-label">Review & Download</div></div></div>
<div class="wizard-body" id="wizStep1" style="display:block;"><div class="card"><div class="card-header"><h3>Upload Your Dataset</h3></div><div class="card-content"><p style="color:#555;margin-bottom:16px;">Upload a CSV or Excel file containing two columns: <strong>input</strong> and <strong>Expected output</strong>.</p><div class="upload-zone" id="uploadZone" onclick="document.getElementById('datasetFile').click();" ondragover="event.preventDefault();this.classList.add('dragover');" ondragleave="this.classList.remove('dragover');" ondrop="event.preventDefault();this.classList.remove('dragover');handleFileDrop(event);"><div style="font-size:1.1rem;font-weight:600;color:#333;">Click or drag &amp; drop your file here</div><div style="font-size:0.85rem;color:#888;margin-top:6px;">Supports .csv, .xlsx, .xls</div></div><input type="file" id="datasetFile" accept=".csv,.xlsx,.xls" style="display:none;" onchange="handleFileUpload(this)"><div id="uploadStatus" style="margin-top:12px;"></div><div id="uploadPreview" class="preview-table" style="display:none;margin-top:16px;"></div></div></div><div class="wizard-actions"><div></div><button class="btn btn-primary" id="step1Next" disabled onclick="goToWizardStep(2)">Next &#8594;</button></div></div>
<div class="wizard-body" id="wizStep2" style="display:none;"><div class="card"><div class="card-header"><h3>Define Data Coverage Distribution</h3></div><div class="card-content"><p style="color:#555;margin-bottom:16px;">Specify the expected percentage for each topic / sub-topic / sub-sub-topic. Percentages must sum to <strong>100%</strong>.</p><div id="coverageRows"></div><button class="btn btn-secondary" onclick="addCoverageRow()" style="margin-top:10px;">+ Add Row</button><div class="coverage-total" id="coverageTotalDisplay">Total: 0%</div><div id="coverageSaveStatus" style="margin-top:10px;"></div></div></div><div class="wizard-actions"><button class="btn btn-secondary" onclick="goToWizardStep(1)">&#8592; Back</button><button class="btn btn-primary" id="step2Next" disabled onclick="saveCoveragePlan()">Save & Next &#8594;</button></div></div>
<div class="wizard-body" id="wizStep3" style="display:none;"><div class="card"><div class="card-header"><h3>Perform Augmentation</h3></div><div class="card-content">
<div style="margin-bottom:20px;"><div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:8px;"><label style="font-weight:600;">Select Input Rows</label><label style="display:flex;align-items:center;gap:6px;cursor:pointer;font-weight:600;font-size:0.85rem;color:#555;"><input type="checkbox" id="selectAllInputs" onchange="toggleAllInputs(this.checked)" style="accent-color:#2E86AB;width:16px;height:16px;cursor:pointer;">Select All</label></div><div class="aug-multi-select" id="inputSelectBox" onclick="toggleAugDropdown('inputDropdown')"><div class="chips" id="inputChips"></div><div style="font-size:0.85rem;color:#aaa;padding:4px;" id="inputPlaceholder">Click to select inputs...</div><div class="dropdown" id="inputDropdown"></div></div></div>
<div style="margin-bottom:20px;"><label style="font-weight:600;display:block;margin-bottom:12px;font-size:1.05rem;">Augmentation Techniques</label><div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:12px;margin-bottom:16px;"><div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap;"><div style="display:flex;gap:4px;border:2px solid #e2e8f0;border-radius:14px;overflow:hidden;padding:3px;" id="augTechTabs"><button class="aug-tech-tab active" onclick="filterAugTechs('all',this)">All</button></div><label style="display:flex;align-items:center;gap:6px;cursor:pointer;font-weight:600;font-size:0.85rem;color:#555;white-space:nowrap;margin-left:8px;"><input type="checkbox" id="augTechSelectAll" onchange="toggleAllAugTechs(this.checked)" style="accent-color:#2E86AB;width:16px;height:16px;cursor:pointer;">Select All</label></div><input type="text" id="augTechSearch" placeholder="Search techniques..." oninput="filterAugTechs(null,null)" style="padding:8px 14px;border:1px solid #ccc;border-radius:50px;width:220px;font-size:0.88rem;"></div><div id="augTechGrid" style="display:grid;grid-template-columns:repeat(auto-fill,minmax(190px,1fr));gap:8px;max-height:340px;overflow-y:auto;padding:4px;margin-bottom:12px;"></div><div id="augTechCount" style="font-size:0.85rem;font-weight:600;color:#555;margin-bottom:8px;"></div><div class="chips" id="techChips" style="margin-bottom:8px;"></div><div id="variationCountsArea" style="margin-top:14px;"></div></div>
<div style="display:flex;align-items:center;gap:16px;flex-wrap:wrap;">
<button class="btn btn-primary" id="augmentBtn" onclick="performAugmentation()" disabled>Run Augmentation</button>
<button class="btn btn-secondary" onclick="openCustomAugModal()" style="border:2px solid #A23B72;color:#A23B72;font-weight:700;">Custom Augmentation</button>
<div id="agenticConfigBadge" style="display:none;padding:6px 14px;background:#f8f0fc;border:1px solid #e2d0f0;border-radius:8px;font-size:0.85rem;color:#A23B72;font-weight:600;"><span id="agenticBadgeCount">agentic config(s) saved</span> <span onclick="agenticConfigs=[];this.parentElement.style.display='none';" style="cursor:pointer;margin-left:8px;color:#dc3545;">&#10005;</span></div>
</div>
<div id="augProgress" class="aug-progress" style="display:none;"><div class="aug-progress-bar"><div class="aug-progress-fill" id="augProgressFill" style="width:0%"></div></div><div class="aug-progress-text" id="augProgressText">Processing...</div></div>
<div id="augPreviewToggle" style="display:none;margin-top:16px;margin-bottom:10px;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:10px;"><div style="display:inline-flex;border:2px solid #e2e8f0;border-radius:8px;overflow:hidden;"><button id="toggleRaw" onclick="setPreviewMode('raw')" style="padding:8px 20px;border:none;cursor:pointer;font-weight:600;font-size:0.88rem;background:#2E86AB;color:white;">RAW</button><button id="toggleDiff" onclick="setPreviewMode('diff')" style="padding:8px 20px;border:none;cursor:pointer;font-weight:600;font-size:0.88rem;background:white;color:#555;">Diff Mode</button></div><select id="augResultTypeSelect" onchange="renderAugResultPreview()" style="padding:8px 14px;border:2px solid #A23B72;border-radius:8px;font-size:0.88rem;font-weight:600;color:#A23B72;cursor:pointer;background:white;"><option value="nonagentic">Non-Agentic Results</option><option value="agentic">Agentic Results</option></select></div>
<div id="augResultPreview"></div>
</div></div><div class="wizard-actions"><button class="btn btn-secondary" onclick="goToWizardStep(2)">&#8592; Back</button><button class="btn btn-primary" id="step3Next" disabled onclick="goToWizardStep(4)">Review Results &#8594;</button></div></div>
<div class="wizard-body" id="wizStep4" style="display:none;"><div class="card"><div class="card-header" style="display:flex;justify-content:space-between;align-items:center;"><h3>&#10004; Review Augmented Dataset</h3><div style="display:flex;gap:10px;align-items:center;"><div id="goldenSaveStatus" style="font-size:0.9rem;"></div><select id="reviewTypeSelect" onchange="renderReviewTable()" style="padding:6px 12px;border:2px solid #A23B72;border-radius:6px;font-size:0.82rem;font-weight:600;color:#A23B72;cursor:pointer;background:white;"><option value="nonagentic">Non-Agentic</option><option value="agentic">Agentic</option></select><button class="btn btn-success" onclick="downloadAugmented()">&#11015; Download CSV</button><button class="btn btn-primary" onclick="saveAsGolden()">&#128190; Save as Golden Dataset</button></div></div><div class="card-content"><div id="reviewTable" style="max-height:500px;overflow:auto;"></div></div></div><div class="wizard-actions"><button class="btn btn-secondary" onclick="goToWizardStep(3)">&#8592; Back</button><div></div></div></div>
</div>"""


def generate_golden_dataset_html():
    return """
        <div class="card">
            <div class="card-header" style="display:flex;justify-content:space-between;align-items:center;">
                <h3>Golden Dataset</h3>
                <div style="display:flex;gap:10px;align-items:center;">
                    <select id="goldenViewSelect" onchange="loadGoldenDataset()" style="padding:6px 12px;border:2px solid rgba(255,255,255,0.5);border-radius:6px;font-size:0.82rem;font-weight:600;color:white;cursor:pointer;background:rgba(255,255,255,0.15);">
                        <option value="nonagentic" style="color:#333;">Non-Agentic</option>
                        <option value="agentic" style="color:#333;">Agentic</option>
                        <option value="evaluation" style="color:#333;">Evaluation Dataset</option>
                    </select>
                    <button class="btn btn-success" onclick="downloadGoldenDataset()" style="background:rgba(255,255,255,0.2);border:1px solid rgba(255,255,255,0.5);color:white;padding:6px 16px;border-radius:6px;cursor:pointer;font-weight:600;">&#11015; Download</button>
                </div>
            </div>
            <div class="card-content">
                <div id="goldenDatasetTable"><p style="color:#888;text-align:center;padding:40px;">No golden dataset available yet. Complete the Augmentation Pipeline to generate one.</p></div>
            </div>
        </div>"""
