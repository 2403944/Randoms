"""Model Quality Assurance - Evaluations Wizard HTML generator. Fully self-contained."""


def generate_evaluations_wizard_html(all_metrics):
    from genai_monitor.templates.js_evaluations_wizard import get_evaluations_wizard_html
    return get_evaluations_wizard_html(all_metrics)
