"""Model Quality Assurance tab - charts, details table, disaggregated view, recovery loop."""
import json
import pandas as pd
from pathlib import Path
import plotly.graph_objects as go
import plotly.offline as plot

try:
    from loguru import logger
except ImportError:
    import logging
    logger = logging.getLogger(__name__)

from genai_monitor.utils import find_column, safe_numeric_conversion, truncate_text, normalize_query_match, normalize_text, text_equal


def create_metrics_bar_chart(summary_df, config, layout_fn):
    try:
        theme = config['theme']
        mc = find_column(summary_df, ['Metrics', 'Metric'])
        pc = find_column(summary_df, ["Passed"])
        fc = find_column(summary_df, ["Failed"])
        metrics = summary_df[mc].astype(str).tolist()
        failed = summary_df[fc].fillna(0).tolist()
        passed = summary_df[pc].fillna(0).tolist()
        fig = go.Figure()
        fig.add_bar(x=metrics, y=failed, name='Failed', marker_color=config['status_colors']['Failed'])
        fig.add_bar(x=metrics, y=passed, name='Passed', marker_color=config['status_colors']['Passed'])
        fig.update_layout(barmode='group', title='Metrics Performance Overview', xaxis_title='Metrics', yaxis_title='Number of Test Cases', bargap=0.25, bargroupgap=0.05, width=len(metrics) * 140, legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="center", x=0.5), **layout_fn(theme))
        fig.update_yaxes(autorange=True)
        return plot.plot(fig, output_type='div', include_plotlyjs=False)
    except Exception as e:
        return f"<div>Error creating metrics chart: {e}</div>"


def create_overall_pie_chart(overall_df, config, layout_fn):
    try:
        theme = config['theme']
        passed = int(overall_df[[c for c in overall_df.columns if 'passed' in c.lower()][0]].sum())
        failed = int(overall_df[[c for c in overall_df.columns if 'failed' in c.lower()][0]].sum())
        labels, values, colors = [], [], []
        if passed > 0:
            labels.append(f"Passed ({passed})"); values.append(passed); colors.append(config['status_colors']['passed'])
        if failed > 0:
            labels.append(f"Failed ({failed})"); values.append(failed); colors.append(config['status_colors']['failed'])
        total = sum(values)
        fig = go.Figure(data=[go.Pie(labels=labels, values=values, hole=0.4, marker=dict(colors=colors), textinfo="label+percent", hoverinfo="label+percent+value")])
        fig.update_layout(title="Overall Performance Distribution", **layout_fn(theme), annotations=[dict(text=f"Total<br>{total}", x=0.5, y=0.5, font_size=16, showarrow=False)])
        return plot.plot(fig, output_type='div', include_plotlyjs=False)
    except Exception as e:
        return f"<div>Error creating overall chart: {e}</div>"


def create_score_comparison_chart(metrics_df, metrics_col, score_col, threshold_col, config, layout_fn):
    try:
        theme = config['theme']
        metrics = metrics_df[metrics_col].tolist()
        scores = [safe_numeric_conversion(x) for x in metrics_df[score_col].tolist()]
        thresholds = [safe_numeric_conversion(x) for x in metrics_df[threshold_col].tolist()]
        bar_colors = []
        for score, threshold, metric in zip(scores, thresholds, metrics):
            if pd.isna(score) or pd.isna(threshold):
                bar_colors.append(theme['border_color']); continue
            if metric in config['reverse_metrics']:
                color = config['status_colors']['passed'] if score <= threshold else config['status_colors']['failed']
            else:
                color = config['status_colors']['passed'] if score >= threshold else config['status_colors']['failed']
            bar_colors.append(color)
        fig = go.Figure()
        fig.add_trace(go.Bar(x=metrics, y=scores, name='Actual Score', marker_color=bar_colors, hovertemplate="<b>%{x}</b><br>Score: %{y:.3f}<extra></extra>", opacity=0.8))
        fig.add_trace(go.Scatter(x=metrics, y=thresholds, mode='lines+markers', name='Threshold', line=dict(color=theme['accent_color'], width=3, dash='dash'), marker=dict(size=8, color=theme['accent_color']), hovertemplate="<b>%{x}</b><br>Threshold: %{y:.3f}<extra></extra>"))
        fig.update_layout(**layout_fn(theme), title="Score vs Threshold Comparison", xaxis_title="Metrics", yaxis_title="Score", bargap=0.25, width=len(metrics) * 140, legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="center", x=0.5))
        fig.update_yaxes(range=[0, 1.1])
        return plot.plot(fig, output_type='div', include_plotlyjs=False)
    except Exception as e:
        return f"<div>Error creating comparison chart: {e}</div>"


def create_run_comparison_chart(prev_df, curr_df, theme):
    try:
        if prev_df.empty or curr_df.empty:
            return "<div class='text-center p-3'><b>No data available</b></div>"
        def fe(df, c):
            for x in c:
                if x in df.columns:
                    return x
            return None
        mc_p = fe(prev_df, ["Metric", "Metrics", "metric"]); sc_p = fe(prev_df, ["Score", "aggregate_score", "score"])
        mc_c = fe(curr_df, ["Metric", "Metrics", "metric"]); sc_c = fe(curr_df, ["Score", "aggregate_score", "score"])
        if not all([mc_p, sc_p, mc_c, sc_c]):
            return "<div class='text-center p-3'><b>No data available</b></div>"
        prev_df = prev_df[[mc_p, sc_p]].rename(columns={mc_p: "Metric", sc_p: "Previous"})
        curr_df = curr_df[[mc_c, sc_c]].rename(columns={mc_c: "Metric", sc_c: "Current"})
        merged = pd.merge(prev_df, curr_df, on="Metric", how="inner")
        if merged.empty:
            return "<div class='text-center p-3'><b>No data available</b></div>"
        fig = go.Figure()
        fig.add_bar(x=merged["Metric"], y=pd.to_numeric(merged["Previous"], errors="coerce"), name="Previous Run", marker_color=theme["secondary_color"])
        fig.add_bar(x=merged["Metric"], y=pd.to_numeric(merged["Current"], errors="coerce"), name="Current Run", marker_color=theme["primary_color"])
        fig.update_layout(barmode="group", title="Run Comparison", xaxis_title="Metrics", yaxis_title="Score")
        return plot.plot(fig, output_type="div", include_plotlyjs=False)
    except Exception:
        return "<div class='text-center p-3'><b>No data available</b></div>"


def create_disaggregated_table(excel_path):
    try:
        df = pd.read_excel(excel_path, sheet_name="Disaggregated View", header=None)
        agg_scores = {}
        for col in range(2, len(df.columns)):
            metric = str(df.iloc[0, col]).strip()
            val = df.iloc[1, col]
            if metric and metric.lower() != "nan":
                try:
                    agg_scores[metric] = float(val)
                except (ValueError, TypeError):
                    agg_scores[metric] = None
        parsed = []
        i = 0
        while i < len(df):
            cell = str(df.iloc[i, 2]).strip().lower()
            if cell == "topic":
                if i + 4 >= len(df):
                    i += 1; continue
                topic = str(df.iloc[i + 1, 2]).strip()
                sub_topic = str(df.iloc[i + 1, 3]).strip()
                pass_row = df.iloc[i + 2]; fail_row = df.iloc[i + 3]
                metrics_data = {}
                for col in range(4, len(df.columns)):
                    mn = str(df.iloc[i, col]).strip()
                    if not mn or mn.lower() == "nan":
                        continue
                    try:
                        pm = int(str(pass_row[col]).split()[0]); fm = int(str(fail_row[col]).split()[0])
                    except (ValueError, IndexError):
                        continue
                    metrics_data[mn] = {"passed": pm, "failed": fm, "aggregate_score": agg_scores.get(mn)}
                parsed.append({"topic": topic, "sub_topic": sub_topic, "metrics": metrics_data})
                i += 5
            else:
                i += 1
        return f"""<div class="card-header"><h3>Disaggregated Analysis</h3></div><div class="card-content"><label>Topic</label><br><select id="topicSelect"></select><br><br><label>Sub-topic</label><br><div id="subTopicWrapper" class="multi-select"><div id="selectedSubTopics" class="chips"></div><input id="subTopicInput" placeholder="Select sub-topics" readonly/><div id="subTopicDropdown" class="dropdown"></div></div><br><br><div class="chart-scroll"><div id="disaggChart"></div></div></div><script>const DISAGG_DATA = {json.dumps(parsed)};</script>"""
    except Exception:
        return "<div class='text-center p-3'><b>Error loading disaggregated data</b></div>"


def load_recovery_loop_global(metric_details_excel_path):
    try:
        if not metric_details_excel_path.exists():
            return []
        xls = pd.ExcelFile(metric_details_excel_path)
        match = next((s for s in xls.sheet_names if s.strip().lower() == 'recovery loop global'), None)
        if not match:
            return []
        df = pd.read_excel(xls, sheet_name=match)
        if df.empty:
            return []
        return [{str(k): (None if pd.isna(v) else v) for k, v in row.items()} for _, row in df.iterrows()]
    except Exception:
        return []


def generate_interactive_details_table(df, metrics):
    try:
        if df.empty:
            return "<div class='text-center p-3'>No details data available</div>"
        html = ['<div class="table-container"><table class="details-table"><thead><tr>']
        html.append('<th style="position:sticky;left:0;z-index:11;min-width:50px;text-align:center;background:linear-gradient(135deg,#2E86AB 0%,#A23B72 100%);">#</th>')
        html.append('<th>TC ID</th><th>Question</th><th>Response</th>')
        for metric in metrics:
            html.append(f'<th class="text-center">{metric.replace("_", " ").title()}</th>')
        html.append('</tr></thead><tbody id="tableBody"></tbody></table></div>')
        html.append(_generate_pagination_controls())
        html.append(_generate_table_javascript(df, metrics))
        return '\n'.join(html)
    except Exception as e:
        return f"<div class='alert alert-error'>Error: {e}</div>"


def _generate_pagination_controls():
    return '<div class="pagination-container"><div class="pagination-controls"><select id="rowsPerPage" class="rows-selector" onchange="changeRowsPerPage()"><option value="10">10 rows/page</option><option value="25">25</option><option value="50">50</option><option value="100">100</option></select></div><div class="pagination-controls" id="paginationButtons"></div><div class="page-info"><span id="pageInfo">Page 1 of 1</span></div></div>'


def _generate_table_javascript(df, metrics):
    try:
        td = []
        for idx, row in df.iterrows():
            qs = str(row.get('Query', 'N/A')).replace('\\n', '<br>').replace('\n', '<br>')
            rs = truncate_text(str(row.get('Response', 'N/A')), 100).replace('\\n', '<br>').replace('\n', '<br>')
            ti = str(row.get('TC ID', 'N/A'))
            mc = {}
            for m in metrics:
                st = row.get(f"{m}_status", 'Unknown')
                sc = row.get(m, 'N/A')
                fs = f'{sc:.2f}' if pd.notna(sc) and isinstance(sc, (int, float)) else ('NAE')
                cc = 'status-warning' if pd.isna(sc) else ('status-passed' if str(st).lower() == 'passed' else ('status-failed' if str(st).lower() == 'failed' else ('status-skipped' if str(st).lower() == 'skipped' else 'status-unknown')))
                mc[m.strip()] = {'value': fs, 'status': st, 'class': cc, 'clickable': fs != 'NAE'}
            td.append({'index': int(idx), 'tc_id': ti, 'query': qs, 'response': rs, 'metrics': mc})
        return f"""<script>let currentPage=1,rowsPerPage=10,totalRows=0;let allTableData={json.dumps(td)};let allMetrics={json.dumps(metrics)};function initializeTable(){{totalRows=allTableData.length;displayPage();}}function displayPage(){{const si=(currentPage-1)*rowsPerPage;const ei=Math.min(si+rowsPerPage,totalRows);const tb=document.getElementById('tableBody');if(!tb)return;let h='';for(let i=si;i<ei;i++){{const rd=allTableData[i];const rn=(currentPage-1)*rowsPerPage+(i-si)+1;h+='<tr>';h+=`<td style="position:sticky;left:0;z-index:5;background:#f8f9fa;text-align:center;font-weight:700;color:#555;border-right:2px solid #dee2e6;min-width:50px;">${{rn}}</td>`;h+=`<td>${{rd.tc_id}}</td><td>${{rd.query}}</td><td>${{rd.response}}</td>`;allMetrics.forEach(m=>{{const md=rd.metrics[m]||{{value:"NAE",class:"status-skipped",clickable:false}};if(md.clickable)h+=`<td class="text-center"><span class="status-cell ${{md.class}}" onclick="openModal(${{rd.index}},'${{m}}')">${{md.value}}</span></td>`;else h+=`<td class="text-center"><span class="status-cell status-warning" title="Not Applicable for Execution">NAE</span></td>`;}});h+='</tr>';}}tb.innerHTML=h;updatePaginationInfo();}}function updatePaginationInfo(){{const tp=Math.ceil(totalRows/rowsPerPage);const el=document.getElementById('pageInfo');if(el)el.textContent=`Page ${{currentPage}} of ${{tp}}`;const c=document.getElementById('paginationButtons');if(c)c.innerHTML=`<button class="page-btn" onclick="previousPage()" ${{currentPage===1?"disabled":""}}>Prev</button><span class="page-btn disabled">${{currentPage}} / ${{tp}}</span><button class="page-btn" onclick="nextPage()" ${{currentPage===tp?"disabled":""}}>Next</button>`;}}function nextPage(){{if(currentPage<Math.ceil(totalRows/rowsPerPage)){{currentPage++;displayPage();}}}}function previousPage(){{if(currentPage>1){{currentPage--;displayPage();}}}}function changeRowsPerPage(){{const s=document.getElementById('rowsPerPage');if(s){{rowsPerPage=parseInt(s.value);currentPage=1;displayPage();}}}}document.addEventListener('DOMContentLoaded',initializeTable);</script>"""
    except Exception as e:
        return f"<script>console.error('Error: {e}');</script>"
