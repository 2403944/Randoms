"""Metrics Summary tab - generates the metrics summary table."""
import pandas as pd
from genai_monitor.utils import find_column, safe_numeric_conversion


def get_score_cell_class(row, score_col, threshold_col, metrics_col, config):
    try:
        if not all([score_col, threshold_col, metrics_col]):
            return ''
        score = safe_numeric_conversion(row.get(score_col))
        threshold = safe_numeric_conversion(row.get(threshold_col))
        metric = row.get(metrics_col, '')
        if pd.isna(score) or pd.isna(threshold):
            return ''
        if metric in config['reverse_metrics']:
            if score > threshold:
                return 'below-threshold'
        else:
            if score < threshold:
                return 'below-threshold'
        if abs(score - threshold) < 0.001:
            return 'equal-threshold'
        return ''
    except Exception:
        return ''


def generate_metrics_summary_table(df, config):
    try:
        if df.empty:
            return "<div class='text-center p-3'>No metrics data available</div>"
        threshold_col = find_column(df, ['Threshold_Value', 'Threshold'])
        score_col = find_column(df, ['aggregate_score', 'score', 'Score'])
        metrics_col = find_column(df, ['Metrics', 'Metric'])
        html = ['<div class="table-container"><table class="modern-table"><thead><tr>']
        for col in df.columns:
            html.append(f'<th>{col.replace("_", " ").title()}</th>')
        html.append('</tr></thead><tbody>')
        for _, row in df.iterrows():
            html.append('<tr>')
            for col in df.columns:
                value = row[col]
                if isinstance(value, (int, float)) and not pd.isna(value):
                    value = f'{value:.2f}' if col in [threshold_col, score_col] else (f'{value:.2f}' if value != int(value) else str(int(value)))
                if pd.isna(value) or value is None:
                    value = 'N/A'
                else:
                    value = str(value).replace('\n', '<br>').replace('\r', '')
                cell_class = ''
                if col == score_col and threshold_col and score_col:
                    cell_class = get_score_cell_class(row, score_col, threshold_col, metrics_col, config)
                if cell_class:
                    html.append(f'<td class="metric-score"><span class="{cell_class}">{value}</span></td>')
                else:
                    html.append(f'<td class="metric-score">{value}</td>')
            html.append('</tr>')
        html.append('</tbody></table></div>')
        return '\n'.join(html)
    except Exception as e:
        return f"<div class='alert alert-error'>Error generating table: {e}</div>"
