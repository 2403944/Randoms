"""Secondary LLM tab - secondary LLM comparison table."""
import json
import pandas as pd

try:
    from loguru import logger
except ImportError:
    import logging
    logger = logging.getLogger(__name__)

from genai_monitor.utils import find_column, truncate_text, normalize_query_match
from genai_monitor.data_paths import METRICS_TEMPLATE_PATH


def generate_secondary_llm_table(df, metrics):
    try:
        if df.empty:
            return "<div class='text-center p-3'>No details data available</div>"
        html = ['<div class="table-container"><table class="details-table"><thead><tr>']
        html.append('<th style="position:sticky;left:0;z-index:11;min-width:50px;text-align:center;background:linear-gradient(135deg,#2E86AB 0%,#A23B72 100%);">#</th>')
        html.append('<th>Question</th><th>Response</th>')
        for m in metrics:
            html.append(f'<th>Primary_{m}</th><th>Secondary_{m}</th>')
        html.append('</tr></thead><tbody id="secondaryTableBody"></tbody></table></div>')
        html.append(_generate_secondary_pagination_controls())
        html.append(_generate_secondary_llm_javascript(df, metrics))
        return "\n".join(html)
    except Exception as e:
        return f"<div class='alert alert-error'>Error: {e}</div>"


def _generate_secondary_pagination_controls():
    return '<div class="pagination-container"><div class="pagination-controls"><select id="secondaryRowsPerPage" class="rows-selector" onchange="secondaryChangeRowsPerPage()"><option value="10">10 rows/page</option><option value="25">25</option><option value="50">50</option><option value="100">100</option></select></div><div class="pagination-controls" id="secondaryPaginationButtons"></div><div class="page-info"><span id="secondaryPageInfo">Page 1 of 1</span></div></div>'


def _generate_secondary_llm_javascript(df, metrics):
    try:
        td = []
        for idx, row in df.iterrows():
            qs = str(row.get('Query', 'N/A')).replace('\\n', '<br>').replace('\n', '<br>')
            rs = truncate_text(str(row.get('Response', 'N/A')), 100).replace('\\n', '<br>').replace('\n', '<br>')
            qk = normalize_query_match(qs)
            mc = {}
            for m in metrics:
                st = row.get(f"{m}_status", 'Unknown')
                sc = row.get(m, 'N/A')
                fs = f'{sc:.2f}' if pd.notna(sc) and isinstance(sc, (int, float)) else (str(sc) if sc != 'N/A' else 'N/A')
                cc = 'status-warning' if pd.isna(sc) else ('status-passed' if str(st).lower() == 'passed' else ('status-failed' if str(st).lower() == 'failed' else ('status-skipped' if str(st).lower() == 'skipped' else 'status-unknown')))
                mc[m.strip()] = {'value': fs, 'status': st, 'class': cc, 'clickable': True}
            td.append({'index': int(idx), 'query': qs, 'query_key': qk, 'response': rs, 'metrics': mc})

        smm = {}
        try:
            fp = METRICS_TEMPLATE_PATH
            if fp.exists():
                xls = pd.ExcelFile(fp)
                if "Secondary LLM" in xls.sheet_names:
                    sdf = pd.read_excel(xls, sheet_name="Secondary LLM")
                    sdf = sdf.rename(columns=lambda c: str(c).strip())
                    for _, sr in sdf.iterrows():
                        en = str(sr.get("Eval_Name", "")).strip()
                        qv = str(sr.get("Query", "")).strip()
                        if not en: continue
                        mk = en.strip().lower(); qk2 = normalize_query_match(qv)
                        meta = {}
                        for col in sdf.columns:
                            if str(col).strip().lower() in ("eval_name", "trace_id"): continue
                            val = sr.get(col); meta[col] = None if pd.isna(val) else val
                        existing = smm.setdefault(mk, {}).setdefault(qk2, [])
                        if meta.get("Few_Shot_Example"): existing.insert(0, meta)
                        else: existing.append(meta)
        except Exception as e:
            logger.warning(f"Unable to read Secondary LLM sheet: {e}")

        return f"""<script>let secondaryCurrentPage=1,secondaryRowsPerPage=10;const secondaryTableData={json.dumps(td)};const secondaryMetaMap={json.dumps(smm)};let allSecondaryMetrics={json.dumps(metrics)};function renderSecondaryTable(){{const tb=document.getElementById("secondaryTableBody");if(!tb)return;const s=(secondaryCurrentPage-1)*secondaryRowsPerPage;const e=Math.min(s+secondaryRowsPerPage,secondaryTableData.length);let h="";for(let i=s;i<e;i++){{const r=secondaryTableData[i];const rn=(secondaryCurrentPage-1)*secondaryRowsPerPage+(i-s)+1;h+="<tr>";h+=`<td style="position:sticky;left:0;z-index:5;background:#f8f9fa;text-align:center;font-weight:700;color:#555;border-right:2px solid #dee2e6;min-width:50px;">${{rn}}</td>`;h+=`<td>${{r.query}}</td><td>${{r.response}}</td>`;allSecondaryMetrics.forEach(m=>{{const md=r.metrics[m]||{{value:"N/A",class:"status-skipped",clickable:false}};if(md.clickable)h+=`<td class="text-center"><span class="status-cell ${{md.class}}" onclick="openModal(${{r.index}},'${{m}}')">${{md.value}}</span></td>`;else h+=`<td class="text-center"><span class="status-cell status-skipped">N/A</span></td>`;const mm=secondaryMetaMap[m.toLowerCase()]||{{}};const ml=mm[r.query_key]||[];const mt=ml.length>0?ml[0]:null;const et=(mt&&mt.Error_Type!=null&&mt.Error_Type!=="")?String(mt.Error_Type):"none";const bc=et.toLowerCase()!=="none"?"status-failed":"status-passed";const bl=et.toLowerCase()!=="none"?et:"No Violation";h+=`<td class="text-center"><button class="status-cell ${{bc}}" onclick="openSecondaryModal(${{i}},'${{escapeHtml(m)}}')" style="border:none;padding:8px 10px;border-radius:8px;">${{bl}}</button></td>`;}});h+="</tr>";}}tb.innerHTML=h;const tp=Math.ceil(secondaryTableData.length/secondaryRowsPerPage);document.getElementById("secondaryPageInfo").innerText=`Page ${{secondaryCurrentPage}} of ${{tp}}`;const c=document.getElementById("secondaryPaginationButtons");if(c)c.innerHTML=`<button class="page-btn" onclick="secondaryPreviousPage()" ${{secondaryCurrentPage===1?"disabled":""}}>Prev</button><span class="page-btn disabled">${{secondaryCurrentPage}} / ${{tp}}</span><button class="page-btn" onclick="secondaryNextPage()" ${{secondaryCurrentPage===tp?"disabled":""}}>Next</button>`;}}function secondaryNextPage(){{if(secondaryCurrentPage<Math.ceil(secondaryTableData.length/secondaryRowsPerPage)){{secondaryCurrentPage++;renderSecondaryTable();}}}}function secondaryPreviousPage(){{if(secondaryCurrentPage>1){{secondaryCurrentPage--;renderSecondaryTable();}}}}function secondaryChangeRowsPerPage(){{const s=document.getElementById("secondaryRowsPerPage");secondaryRowsPerPage=parseInt(s.value);secondaryCurrentPage=1;renderSecondaryTable();}}function openSecondaryModal(ri,mn){{const modal=document.getElementById('detailModal');if(!modal)return;modal.querySelectorAll('.modal-left .modal-section').forEach(s=>s.style.display='none');const col=modal.querySelector('.collapsible-section');if(col)col.style.display='none';document.getElementById("scoreReasonBlock").style.display="none";document.getElementById("metricContainer").style.display="none";document.getElementById("secondaryContainer").style.display="block";document.getElementById("rcaContainer").style.display="none";document.getElementById("tracebackFields").innerHTML="";document.getElementById("metricSheetFields").innerHTML="";document.getElementById("rcaContainer").innerHTML="";document.getElementById('modalTitle').textContent=mn+' - Secondary LLM Details';document.getElementById('modalSubtitle').textContent='';const ct=document.getElementById('secondaryContainer');ct.innerHTML='';const r=secondaryTableData[ri];const qk=r.query_key;const mm=secondaryMetaMap[mn.toLowerCase()]||{{}};const ml=mm[qk]||[];if(ml.length===0){{const sec=document.createElement('div');sec.className='modal-section';sec.innerHTML='<h4>No metadata</h4><p>N/A</p>';ct.appendChild(sec);}}else{{ml.forEach((mt,idx)=>{{const keys=Object.keys(mt||{{}}).filter(k=>k&&k.toLowerCase()!=='eval_name'&&k.toLowerCase()!=='trace_id');if(keys.length===0){{const sec=document.createElement('div');sec.className='modal-section';sec.innerHTML=`<h4>Row ${{idx+1}}</h4><p>N/A</p>`;ct.appendChild(sec);}}else{{keys.forEach(k=>{{let v=mt[k];const sec=document.createElement('div');sec.className='modal-section';const hd=document.createElement('h4');hd.textContent=String(k).replace(/_/g,' ');sec.appendChild(hd);const cn=document.createElement('div');if(v===null||v===undefined)cn.innerHTML='<p>N/A</p>';else if(typeof v==='object')cn.innerHTML=`<pre>${{escapeHtml(JSON.stringify(v,null,2)).replace(/\\n/g,"<br>")}}</pre>`;else cn.innerHTML=`<p>${{escapeHtml(String(v)).replace(/\\n/g,"<br>")}}</p>`;sec.appendChild(cn);ct.appendChild(sec);}});}}}});}}modal.style.display='block';}}document.addEventListener("DOMContentLoaded",renderSecondaryTable);</script>"""
    except Exception as e:
        return f"<script>console.error('Error: {e}');</script>"
