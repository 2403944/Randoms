"""Trustworthy Assurance tab - trustworthy table with pagination."""
import json
import pandas as pd
from genai_monitor.data_paths import DATA_DIR

try:
    from loguru import logger
except ImportError:
    import logging
    logger = logging.getLogger(__name__)


def generate_trustworthy_table(excel_file, sheet_name, table_id, auto_render=False):
    try:
        excel_path = DATA_DIR / excel_file
        df = pd.read_excel(excel_path, sheet_name=sheet_name)
        if df.empty:
            return "<div class='text-center p-3'>No data available</div>"
        columns = list(df.columns)
        rows = []
        for _, row in df.iterrows():
            cells = []
            for col in columns:
                val = row[col]
                if pd.isna(val) or val is None:
                    cells.append("N/A")
                else:
                    sv = str(val).strip()
                    if str(col).strip().lower() == "result":
                        if sv.lower() == "pass":
                            cells.append("<span style='display:inline-flex;align-items:center;gap:5px;background:#28a745;color:white;padding:4px 12px;border-radius:20px;font-size:0.82rem;font-weight:700;'>&#10003; Pass</span>")
                        elif sv.lower() == "fail":
                            cells.append("<span style='display:inline-flex;align-items:center;gap:5px;background:#dc3545;color:white;padding:4px 12px;border-radius:20px;font-size:0.82rem;font-weight:700;'>&#10007; Fail</span>")
                        else:
                            cells.append(sv)
                    else:
                        cells.append(sv.replace('\n', '<br>').replace('\r', '').replace("'", "&#39;"))
            rows.append(cells)
        rj = json.dumps(rows)
        cl = json.dumps([str(c).strip().lower() for c in columns])
        tid = f"{table_id}Body"; rid = f"{table_id}Rpp"; pid = f"{table_id}PgBtns"; iid = f"{table_id}PgInfo"
        rfn = f"render{table_id[0].upper()}{table_id[1:]}"
        ajs = f'document.addEventListener("DOMContentLoaded", function() {{ render(); }});' if auto_render else ''
        html = ['<div class="table-container"><table class="details-table"><thead><tr>']
        for col in columns:
            al = ' style="text-align:center;"' if str(col).strip().lower() == "result" else ''
            html.append(f'<th{al}>{str(col).replace("_", " ").title()}</th>')
        html.append(f'</tr></thead><tbody id="{tid}"></tbody></table></div>')
        html.append(f'<div class="pagination-container"><div class="pagination-controls"><select id="{rid}" class="rows-selector"><option value="10">10 rows/page</option><option value="25">25</option><option value="50">50</option><option value="100">100</option></select></div><div class="pagination-controls" id="{pid}"></div><div class="page-info"><span id="{iid}">Page 1 of 1</span></div></div>')
        html.append(f"""<script>(function(){{var rows={rj};var colsLower={cl};var curPage=1;function getRpp(){{var el=document.getElementById('{rid}');return el?parseInt(el.value):10;}}function render(){{var rpp=getRpp(),total=rows.length;var tp=Math.max(1,Math.ceil(total/rpp));if(curPage>tp)curPage=tp;var s=(curPage-1)*rpp,e=Math.min(s+rpp,total);var tbody=document.getElementById('{tid}');if(!tbody)return;var h='';for(var i=s;i<e;i++){{h+='<tr>';for(var ci=0;ci<rows[i].length;ci++){{var ir=colsLower[ci]==='result';var ts=ir?' style="text-align:center;"':'';h+='<td'+ts+'>'+rows[i][ci]+'</td>';}}h+='</tr>';}}tbody.innerHTML=h;var info=document.getElementById('{iid}');if(info)info.textContent='Page '+curPage+' of '+tp;var pb=document.getElementById('{pid}');if(pb){{pb.innerHTML='<button class="page-btn" id="{table_id}Prev">Prev</button><span class="page-btn disabled">'+curPage+' / '+tp+'</span><button class="page-btn" id="{table_id}Next">Next</button>';var pv=document.getElementById('{table_id}Prev');var nx=document.getElementById('{table_id}Next');if(curPage<=1)pv.disabled=true;if(curPage>=tp)nx.disabled=true;pv.addEventListener('click',function(){{if(curPage>1){{curPage--;render();}}}});nx.addEventListener('click',function(){{if(curPage<tp){{curPage++;render();}}}});}}}}var rEl=document.getElementById('{rid}');if(rEl)rEl.addEventListener('change',function(){{curPage=1;render();}});window['{rfn}']=render;{ajs}}})();</script>""")
        return '\n'.join(html)
    except Exception as e:
        return f"<div class='text-center p-3'><b>Error loading {sheet_name}: {e}</b></div>"
