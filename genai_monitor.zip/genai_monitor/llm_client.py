"""Azure OpenAI LLM client with retry logic, rate limiting, and parallel execution."""
import os
import json
import time
import threading
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    pass

try:
    from loguru import logger
except ImportError:
    import logging
    logger = logging.getLogger(__name__)

import requests as http_requests

_rate_lock = threading.Lock()
_last_call_time = [0.0]
_MIN_CALL_INTERVAL = 0.3
_MAX_WORKERS = 20


def call_azure_openai(prompt: str, system_message: str = "You are a helpful text augmentation assistant.", max_retries: int = 4) -> str:
    env_path = Path(__file__).parent / ".env"
    load_dotenv(dotenv_path=env_path)
    api_key = os.getenv("AZURE_OPENAI_API_KEY")
    endpoint = os.getenv("AZURE_OPENAI_ENDPOINT")
    api_version = os.getenv("AZURE_OPENAI_API_VERSION")
    deployment = os.getenv("AZURE_OPENAI_LLM_DEPLOYMENT")

    if not api_key:
        raise ValueError("MISSING CREDENTIAL: AZURE_OPENAI_API_KEY is not set in environment variables.")
    if not endpoint:
        raise ValueError("MISSING CREDENTIAL: AZURE_OPENAI_ENDPOINT is not set in environment variables.")

    url = f"{endpoint.rstrip('/')}/openai/deployments/{deployment}/chat/completions?api-version={api_version}"
    headers = {"Content-Type": "application/json", "api-key": api_key}
    payload = {
        "messages": [
            {"role": "system", "content": system_message},
            {"role": "user", "content": prompt}
        ],
        "temperature": 1,
        "max_completion_tokens": 100000
    }

    last_error = None
    for attempt in range(max_retries + 1):
        try:
            logger.info(f"Azure OpenAI attempt {attempt+1}/{max_retries+1}")
            resp = http_requests.post(url, headers=headers, json=payload, timeout=120)

            if resp.status_code != 200:
                try:
                    err_body = resp.json()
                    err_code = err_body.get("error", {}).get("code", "unknown_code")
                    err_msg = err_body.get("error", {}).get("message", resp.text)
                except Exception:
                    err_code = "parse_failed"
                    err_msg = resp.text
                last_error = f"HTTP {resp.status_code} from Azure | Code: {err_code} | Message: {err_msg} | Deployment: {deployment} | URL: {url}"
                logger.warning(f"Attempt {attempt+1} failed: {last_error}")
                if resp.status_code == 429:
                    retry_after = None
                    try:
                        retry_after = int(resp.headers.get("Retry-After", 0))
                    except (ValueError, TypeError):
                        retry_after = None
                    wait_time = retry_after if retry_after and retry_after > 0 else min(2 ** (attempt + 1), 60)
                    logger.warning(f"Rate limited (429). Waiting {wait_time}s before retry...")
                    time.sleep(wait_time)
                elif resp.status_code in (500, 502, 503, 504):
                    wait_time = min(2 ** (attempt + 1), 30)
                    logger.warning(f"Server error ({resp.status_code}). Waiting {wait_time}s before retry...")
                    time.sleep(wait_time)
                continue

            data = resp.json()
            choices = data.get("choices", [])
            if not choices:
                last_error = f"Azure returned 200 OK but 'choices' array is empty. Full response: {json.dumps(data)}"
                logger.warning(f"Attempt {attempt+1}: {last_error}")
                continue

            choice = choices[0]
            finish_reason = choice.get("finish_reason", "")

            if finish_reason == "content_filter":
                filter_results = choice.get("content_filter_results", {})
                triggered = [k for k, v in filter_results.items() if isinstance(v, dict) and v.get("filtered")]
                last_error = f"Response blocked by Azure content filter. Triggered filters: {triggered if triggered else 'unknown'}. Full filter results: {json.dumps(filter_results)}"
                logger.warning(f"Attempt {attempt+1}: {last_error}")
                continue

            message = choice.get("message", {})
            content = message.get("content", "")

            if content is None:
                filter_results = choice.get("content_filter_results", {})
                last_error = f"Azure returned null content. finish_reason='{finish_reason}'. Content filter results: {json.dumps(filter_results)}"
                logger.warning(f"Attempt {attempt+1}: {last_error}")
                continue

            content = content.strip()
            if not content:
                last_error = f"Azure returned 200 OK with empty string content. finish_reason='{finish_reason}'. Usage: {json.dumps(data.get('usage', {}))}"
                logger.warning(f"Attempt {attempt+1}: {last_error}")
                continue

            logger.info(f"Azure OpenAI success on attempt {attempt+1}. Tokens used: {data.get('usage', {})}")
            return content

        except http_requests.exceptions.Timeout:
            last_error = f"Request timed out after 120s. Deployment: {deployment} | URL: {url}"
            logger.warning(f"Attempt {attempt+1}: {last_error}")
        except http_requests.exceptions.ConnectionError as e:
            last_error = f"Connection error. URL: {url} | Detail: {str(e)}"
            logger.warning(f"Attempt {attempt+1}: {last_error}")
        except http_requests.exceptions.RequestException as e:
            last_error = f"HTTP request failed. Type: {type(e).__name__} | Detail: {str(e)}"
            logger.warning(f"Attempt {attempt+1}: {last_error}")
        except Exception as e:
            last_error = f"Unexpected error. Type: {type(e).__name__} | Detail: {str(e)}"
            logger.warning(f"Attempt {attempt+1}: {last_error}")

    raise ValueError(f"All {max_retries + 1} attempt(s) failed. Last error: {last_error}")


def call_azure_openai_throttled(prompt: str, system_message: str = "You are a helpful text augmentation assistant.", max_retries: int = 4) -> str:
    with _rate_lock:
        now = time.time()
        elapsed = now - _last_call_time[0]
        if elapsed < _MIN_CALL_INTERVAL:
            time.sleep(_MIN_CALL_INTERVAL - elapsed)
        _last_call_time[0] = time.time()
    return call_azure_openai(prompt, system_message=system_message, max_retries=max_retries)


def parallel_llm_calls(tasks, max_workers=None):
    workers = max_workers or _MAX_WORKERS
    results = []

    def _execute(task):
        try:
            content = call_azure_openai_throttled(
                task['prompt'],
                system_message=task.get('system_message', 'You are a helpful text augmentation assistant.')
            )
            return {**task, 'result': content, 'error': None}
        except Exception as e:
            return {**task, 'result': None, 'error': str(e)}

    with ThreadPoolExecutor(max_workers=workers) as executor:
        futures = {executor.submit(_execute, t): t for t in tasks}
        for future in as_completed(futures):
            results.append(future.result())

    task_order = {t['id']: i for i, t in enumerate(tasks)}
    results.sort(key=lambda r: task_order.get(r['id'], 0))
    return results
