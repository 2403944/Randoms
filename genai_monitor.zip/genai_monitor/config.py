"""Configuration defaults for the GenAI Monitor report."""


def get_default_config():
    return {
        'title': 'GenAI Model Monitoring Report',
        'subtitle': 'LLM-as-a-Judge Assurance Pipeline',
        'description': 'Advanced monitoring pipeline that evaluates GenAI model outputs against predefined criteria, ensuring quality, safety, and alignment with project requirements.',
        'theme': {
            'primary_color': '#2E86AB', 'secondary_color': '#A23B72',
            'accent_color': '#F18F01', 'success_color': '#28a745',
            'danger_color': '#dc3545', 'warning_color': '#ffc107',
            'info_color': '#17a2b8', 'light_bg': '#f8f9fa',
            'dark_bg': '#343a40', 'border_color': '#dee2e6',
            'font_family': "'Segoe UI', Tahoma, Geneva, Verdana, sans-serif",
        },
        'status_colors': {
            'Passed': '#28a745', 'Failed': '#dc3545', 'Skipped': '#6c757d',
            'passed': '#28a745', 'failed': '#dc3545', 'skipped': '#6c757d',
        },
        'reverse_metrics': ['Hallucination CoVe'],
        'chart_height': 450,
    }
