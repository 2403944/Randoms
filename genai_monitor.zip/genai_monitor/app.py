"""
GenAI Monitor - Flask Application Entry Point
Run with: python app.py
"""
import sys
import os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from flask import Flask
from routes import register_blueprints


def create_app():
    app = Flask(__name__)
    register_blueprints(app)
    return app


app = create_app()

if __name__ == "__main__":
    app.run(debug=True)
