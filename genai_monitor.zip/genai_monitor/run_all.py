#!/usr/bin/env python3
"""GenAI Monitor - Quick Start. Verifies setup and starts the app."""
import os, sys

def check_setup():
    errors, warnings = [], []
    if not os.path.exists("data"):
        errors.append("data/ folder not found!\n  Fix: mkdir data && copy your Excel files into it")
    else:
        if not os.path.exists("data/Metrics_template02.xlsx"):
            errors.append("data/Metrics_template02.xlsx not found (required)")
        for f in ["data/final_eval_results01.xlsx","data/agent_query_augmentations.xlsx","data/Augmentations 2.xlsx"]:
            if not os.path.exists(f): warnings.append(f"{f} not found (optional)")
    if not os.path.exists(".env"): warnings.append(".env not found (needed for Azure OpenAI)")
    missing = []
    for dep in ['flask','pandas','plotly','openpyxl','requests']:
        try: __import__(dep)
        except ImportError: missing.append(dep)
    if missing: errors.append(f"Missing packages: {', '.join(missing)}\n  Fix: pip install {' '.join(missing)}")
    return errors, warnings

def main():
    print("="*60); print("GenAI Monitor - Setup Check"); print("="*60)
    errors, warnings = check_setup()
    if warnings:
        print(f"\nWARNINGS ({len(warnings)}):")
        for w in warnings: print(f"  - {w}")
    if errors:
        print(f"\nERRORS ({len(errors)}):")
        for e in errors: print(f"  - {e}")
        print("\nFix errors and try again."); sys.exit(1)
    print("\nAll checks passed! Starting Flask server...")
    print("="*60)
    from app import app
    app.run(debug=False, host="0.0.0.0", port=5000)

if __name__ == "__main__": main()
