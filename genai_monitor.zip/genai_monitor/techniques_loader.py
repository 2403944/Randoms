"""Loads augmentation techniques from Excel file or falls back to defaults."""
import pandas as pd
from data_paths import AUGMENTATIONS_EXCEL_PATH
from prompts import AUGMENTATION_PROMPTS

try:
    from loguru import logger
except ImportError:
    import logging
    logger = logging.getLogger(__name__)


def load_augmentation_techniques_from_excel():
    techniques_path = AUGMENTATIONS_EXCEL_PATH
    result = []
    try:
        if not techniques_path.exists():
            for name, prompt in AUGMENTATION_PROMPTS.items():
                result.append({"category": "General", "sub_category": "Text Transformation", "name": name, "description": prompt.split("\n\nText:")[0]})
            return result
        xls = pd.ExcelFile(techniques_path)
        for sheet_name in xls.sheet_names:
            category = str(sheet_name).strip()
            try:
                df = pd.read_excel(xls, sheet_name=sheet_name)
                df.columns = [str(c).strip() for c in df.columns]
                sub_cat_col = name_col = desc_col = None
                for c in df.columns:
                    cl = c.lower().replace("_", " ").strip()
                    if "sub" in cl and "cat" in cl:
                        sub_cat_col = c
                    elif cl in ("name", "technique", "technique name"):
                        name_col = c
                    elif "desc" in cl:
                        desc_col = c
                if not name_col:
                    remaining = [c for c in df.columns if c != sub_cat_col and c != desc_col]
                    name_col = remaining[0] if remaining else None
                for _, row in df.iterrows():
                    name = str(row.get(name_col, "")).strip() if name_col else ""
                    if not name or name.lower() == "nan":
                        continue
                    sub_cat = str(row.get(sub_cat_col, "")).strip() if sub_cat_col else ""
                    if not sub_cat or sub_cat.lower() == "nan":
                        sub_cat = "General"
                    desc = str(row.get(desc_col, "")).strip() if desc_col else ""
                    if desc.lower() == "nan":
                        desc = ""
                    result.append({"category": category, "sub_category": sub_cat, "name": name, "description": desc})
            except Exception as e:
                logger.error(f"Error reading sheet '{sheet_name}': {e}")
        if not result:
            for name, prompt in AUGMENTATION_PROMPTS.items():
                result.append({"category": "General", "sub_category": "Text Transformation", "name": name, "description": prompt.split("\n\nText:")[0]})
    except Exception as e:
        logger.error(f"Error loading augmentation techniques: {e}")
        for name, prompt in AUGMENTATION_PROMPTS.items():
            result.append({"category": "General", "sub_category": "Text Transformation", "name": name, "description": prompt.split("\n\nText:")[0]})
    return result


ALL_AUGMENTATION_TECHNIQUES = load_augmentation_techniques_from_excel()
