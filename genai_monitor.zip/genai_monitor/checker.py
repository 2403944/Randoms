import os
from pathlib import Path
from dotenv import load_dotenv
from openai import AzureOpenAI

def check_azure_openai():
    # Always resolve path relative to this script
    env_path = Path(__file__).parent / ".env"
    load_dotenv(dotenv_path=env_path)

    api_key = os.getenv("AZURE_OPENAI_API_KEY")
    endpoint = os.getenv("AZURE_OPENAI_ENDPOINT")
    api_version = os.getenv("AZURE_OPENAI_API_VERSION")
    deployment = os.getenv("AZURE_OPENAI_LLM_DEPLOYMENT")

    print("Checking environment variables...")
    for key, value in {
        "AZURE_OPENAI_API_KEY": api_key,
        "AZURE_OPENAI_ENDPOINT": endpoint,
        "AZURE_OPENAI_API_VERSION": api_version,
        "AZURE_OPENAI_LLM_DEPLOYMENT": deployment,
    }.items():
        if value:
            print(f"{key} is accessible: {value[:6]}...")
        else:
            print(f"{key} is MISSING!")

    if all([api_key, endpoint, api_version, deployment]):
        try:
            client = AzureOpenAI(
                api_key=api_key,
                api_version=api_version,
                azure_endpoint=endpoint,
            )

            response = client.chat.completions.create(
                model=deployment,
                messages=[{"role": "user", "content": "Hello Azure OpenAI!"}],
                max_tokens=20,
            )
            print("Test call succeeded. Response:")
            print(response.choices[0].message.content)
        except Exception as e:
            print("Test call failed:", str(e))

if __name__ == "__main__":
    check_azure_openai()
