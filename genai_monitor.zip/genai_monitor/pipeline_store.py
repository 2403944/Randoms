"""Global in-memory pipeline store shared across all modules."""

pipeline_store = {
    'uploaded_dataset': None,
    'coverage_plan': [],
    'augmented_rows': [],
    'golden_dataset': None,
    'golden_dataset_agentic': None,
    'coverage_classifications': [],
    'agentic_results': [],
}
