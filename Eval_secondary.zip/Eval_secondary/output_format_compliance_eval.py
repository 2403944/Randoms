from langsmith import Client
from langchain_openai import AzureChatOpenAI
from uuid import UUID
import json
import os
from datetime import datetime

# ============================================================
# CONFIG
# ============================================================

os.environ["LANGSMITH_API_KEY"] = "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"

client = Client(api_key=os.environ["LANGSMITH_API_KEY"])

endpoint = os.getenv("AZURE_OPENAI_ENDPOINT")
api_version = os.getenv("AZURE_OPENAI_API_VERSION")
api_key = os.getenv("AZURE_OPENAI_API_KEY")

llm = AzureChatOpenAI(
    azure_endpoint=endpoint,
    openai_api_version=api_version,
    openai_api_key=api_key,
    model="gpt-5",
    temperature=0
)

# ============================================================
# TARGET SPANS
# ============================================================

TARGET_SPAN_NAMES = {
    "PydanticOutputParser",
}

# ============================================================
# JSON SAFE SERIALIZER
# ============================================================

def uuid_serializer(obj):
    if isinstance(obj, UUID):
        return str(obj)
    raise TypeError(f"Object of type {obj.__class__.__name__} is not JSON serializable")

# ============================================================
# DETERMINISTIC PRE-CHECK
# ============================================================

def is_empty_output(span_outputs: dict) -> bool:
    if not span_outputs:
        return True
    output_val = span_outputs.get("output")
    if output_val is None:
        return True
    if isinstance(output_val, dict) and len(output_val) == 0:
        return True
    return False


# ============================================================
# SAFE JSON PARSER
# ============================================================

def safe_json_load(raw: str):
    raw = raw.strip()
    if raw.startswith("```"):
        raw = raw.strip("`").strip()
        if raw.lower().startswith("json"):
            raw = raw[4:].strip()
    decoder = json.JSONDecoder()
    obj, _ = decoder.raw_decode(raw)
    return obj


# ============================================================
# EVAL PROMPT
# ============================================================

OUTPUT_FORMAT_COMPLIANCE_EVAL_PROMPT = {
    "meta_instruction": (
        "Follow the analysis internally but output ONLY the final JSON object "
        "that conforms exactly to the output_structure_mandate."
    ),
    "metric_name": "PydanticOutputParser — JSON Format Compliance",
    "role": (
        "You are an Output Format Compliance Auditor specializing in PydanticOutputParser spans. "
        "Each span has already been confirmed to have non-empty span_outputs. "
        "Evaluate each span independently, then provide an overall summary. "
        "You MUST NOT invent data or infer beyond the provided spans."
    ),
    "goal": (
        "For each PydanticOutputParser span, determine whether span_outputs contains a well-formed, "
        "valid JSON object — free of extra prose, markdown artifacts, or structural issues. "
        "NOTE: All spans provided here have non-empty outputs. You only need to assign PASS or FAIL. "
        "Do NOT assign SKIP — that has already been handled before this call."
    ),
    "rubric": {
        "PASS": (
            "span_outputs is a clean, well-formed JSON object with no extra prose, "
            "no markdown fences, and no structural corruption."
        ),
        "FAIL": (
            "span_outputs is malformed JSON, contains extra text or markdown outside the "
            "JSON structure, is an unexpected type (e.g. plain string or array when an "
            "object is expected), or is structurally corrupted."
        )
    },
    "what_to_check": [
        "Check if span_outputs is a clean, well-formed JSON object.",
        "Verify there is no stray text, markdown fences, or prose mixed into the output.",
        "Verify the output is a JSON object (dict), not a raw string or unexpected type.",
        "Do NOT check for errors, exceptions, or span execution status.",
        "Do NOT assign SKIP — all spans here have non-empty outputs."
    ],
    "analysis_approach": [
        "Iterate through each span independently.",
        "Inspect span_outputs for a clean, well-formed JSON object.",
        "Check for stray text, markdown artifacts, or structural issues in the output.",
        "Assign PASS or FAIL based solely on JSON format correctness.",
        "After evaluating all spans, provide a concise overall summary."
    ],
    "output_structure_mandate": {
        "type": "object",
        "properties": {
            "per_span_results": {
                "type": "array",
                "items": {
                    "type": "object",
                    "properties": {
                        "span_id":   {"type": "string"},
                        "span_name": {"type": "string"},
                        "json_output_accuracy": {
                            "type": "string",
                            "description": "PASS | FAIL"
                        },
                        "failure_reason": {
                            "type": "string",
                            "description": "Empty string if PASS. Specific JSON format issue if FAIL."
                        }
                    },
                    "required": ["span_id", "span_name", "json_output_accuracy", "failure_reason"]
                }
            },
            "overall_reason": {"type": "string"}
        },
        "required": ["per_span_results", "overall_reason"]
    }
}


# ============================================================
# RUN OUTPUT FORMAT COMPLIANCE EVAL
# ============================================================

def run_output_format_compliance_eval(trace_id: str, scenario: str, llm_client) -> dict:
    """
    Run output format compliance evaluation on a trace.
    
    Args:
        trace_id: LangSmith trace ID
        scenario: The query/scenario string
        llm_client: Azure OpenAI client
    
    Returns:
        dict with evaluation results
    """
    try:
        # ============================================================
        # FETCH SPANS
        # ============================================================

        spans = list(client.list_runs(trace_id=trace_id))

        filtered_spans = [
            span for span in spans
            if span.name in TARGET_SPAN_NAMES
        ]

        filtered_spans_sorted = sorted(
            filtered_spans,
            key=lambda span: span.start_time or 0
        )

        # ============================================================
        # DETERMINISTIC PRE-CHECK
        # ============================================================

        skip_spans = []
        eval_spans = []

        for span in filtered_spans_sorted:
            outputs = span.outputs or {}
            if is_empty_output(outputs):
                skip_spans.append(span)
            else:
                eval_spans.append(span)

        total_spans_count   = len(filtered_spans_sorted)
        llm_evaluated_count = len(eval_spans)
        pre_skip_count      = len(skip_spans)

        print(f"Total spans       : {total_spans_count}")
        print(f"  → To evaluate   : {llm_evaluated_count}")
        print(f"  → Pre-SKIP      : {pre_skip_count}  (empty outputs — not sent to LLM)")

        # ============================================================
        # BUILD PAYLOAD
        # ============================================================

        payload = {
            "spans": [
                {
                    "span_id":      str(span.id),
                    "span_name":    span.name,
                    "span_inputs":  span.inputs or {},
                    "span_outputs": span.outputs or {}
                }
                for span in eval_spans
            ]
        }

        # ============================================================
        # LLM CALL
        # ============================================================

        llm_per_span_results = []
        llm_overall_reason   = "No spans required LLM evaluation."

        if eval_spans:
            messages = [
                ("system", json.dumps(OUTPUT_FORMAT_COMPLIANCE_EVAL_PROMPT, indent=2)),
                ("human",  json.dumps(payload, indent=2, default=uuid_serializer))
            ]

            response = llm_client.invoke(messages)
            parsed_eval = safe_json_load(response.content)

            llm_per_span_results = parsed_eval.get("per_span_results", [])
            llm_overall_reason   = parsed_eval.get("overall_reason", "")

        # ============================================================
        # MERGE: LLM results + deterministic SKIP results
        # ============================================================

        skip_results = [
            {
                "span_id":              str(span.id),
                "span_name":            span.name,
                "json_output_accuracy": "SKIP",
                "failure_reason":       ""
            }
            for span in skip_spans
        ]

        span_id_to_result = {}
        for r in llm_per_span_results:
            span_id_to_result[r["span_id"]] = r
        for r in skip_results:
            span_id_to_result[r["span_id"]] = r

        all_results_ordered = [
            span_id_to_result[str(span.id)]
            for span in filtered_spans_sorted
            if str(span.id) in span_id_to_result
        ]

        # ============================================================
        # DETERMINISTIC SCORE
        # ============================================================

        evaluated_results = [
            r for r in all_results_ordered
            if r.get("json_output_accuracy") in ("PASS", "FAIL")
        ]

        skipped_results_list = [
            r for r in all_results_ordered
            if r.get("json_output_accuracy") == "SKIP"
        ]

        total_count   = len(evaluated_results)
        pass_count    = sum(1 for r in evaluated_results if r.get("json_output_accuracy") == "PASS")
        fail_count    = total_count - pass_count
        skip_count    = len(skipped_results_list)
        overall_score = round(pass_count / total_count, 2) if total_count > 0 else 0.0

        # ============================================================
        # FINAL EVAL OBJECT
        # ============================================================

        # Build span lookup for traceback
        _span_data_lookup = {
            str(span.id): {
                "span_inputs":  span.inputs or {},
                "span_outputs": span.outputs or {}
            }
            for span in filtered_spans_sorted
        }

        # Build traceback: one entry per span, verdict + input content + inputs + outputs
        _traceback = []
        for result in all_results_ordered:
            sid       = result["span_id"]
            verdict   = result["json_output_accuracy"]
            span_data = _span_data_lookup.get(sid, {})
            _traceback.append({
                "span_inputs":  span_data.get("span_inputs", {}),
                "span_outputs": span_data.get("span_outputs", {}),
            })

        output_format_compliance_eval_result = {
            "eval_name": "output_format_compliance",
            "eval_type": "hybrid",
            "trace_id":  trace_id,
            "eval_prompt": json.dumps(OUTPUT_FORMAT_COMPLIANCE_EVAL_PROMPT, indent=2),
            "eval_inputs": {
                "spans": [
                    {
                        "span_id":             str(span.id),
                        "span_name":           span.name,
                        "span_input_content":  (span.inputs or {}).get("input", {}).get("content", ""),
                        "span_inputs":         span.inputs or {},
                        "span_outputs":        span.outputs or {}
                    }
                    for span in filtered_spans_sorted
                ],
                "total_spans":    total_spans_count,
                "llm_evaluated":  llm_evaluated_count,
                "pre_skipped":    pre_skip_count,
            },
            "eval_output": {
                "per_span_results": all_results_ordered,
                "overall_reason":   llm_overall_reason
            },
            "traceback": _traceback,
            "analytics": {
                "total_spans":    total_spans_count,
                "llm_evaluated":  llm_evaluated_count,
                "pre_skipped":    pre_skip_count,
                "pass_count":     pass_count,
                "fail_count":     fail_count,
                "skip_count":     skip_count,
                "overall_score":  overall_score
            },
            "metadata": {
                "model":       "gpt-5",
                "temperature": 0,
                "timestamp":   datetime.now().isoformat()
            }
        }

        print("\n===== PYDANTIC OUTPUT FORMAT COMPLIANCE EVAL =====")
        print(json.dumps(output_format_compliance_eval_result, indent=2, default=uuid_serializer))

        return output_format_compliance_eval_result

    except Exception as e:
        return {
            "eval_name": "output_format_compliance",
            "eval_type": "hybrid",
            "trace_id": trace_id,
            "status": "failed",
            "error": str(e)
        }


# ============================================================
# EXCEL DUMP FUNCTION
# ============================================================

def dump_output_format_compliance_to_excel(
    *,
    trace_id: str,
    query: str,
    eval_result: dict,
    excel_path: str = "final_eval_results.xlsx",
):
    """
    Dump output format compliance evaluation results to Excel sheet.

    Args:
        trace_id: The trace ID
        query: The query string
        eval_result: The evaluation result dict from run_output_format_compliance_eval
        excel_path: Path to Excel file
    """
    try:
        from utils import get_or_create_workbook, get_or_create_sheet

        # ============================================================
        # CONFIG
        # ============================================================

        SHEET_NAME = "Output Format Compliance"
        HEADERS = [
            "Query",
            "Overall Score",
            "Total Spans",
            "LLM Evaluated",
            "Pre-Skipped",
            "Pass Count",
            "Fail Count",
            "Skip Count",
            "Per Span Results",
            "Overall Reason",
            "Status"
        ]

        # ============================================================
        # LOAD OR CREATE WORKBOOK/SHEET
        # ============================================================

        wb = get_or_create_workbook(excel_path)
        sheet = get_or_create_sheet(wb, SHEET_NAME, HEADERS)

        # ============================================================
        # EXTRACT VALUES
        # ============================================================

        if eval_result.get("status") == "failed":
            overall_score = ""
            total_spans = ""
            llm_evaluated = ""
            pre_skipped = ""
            pass_count = ""
            fail_count = ""
            skip_count = ""
            per_span_results = ""
            overall_reason = eval_result.get("error", "Unknown error")
            status = "failed"
        else:
            analytics = eval_result.get("analytics", {})
            overall_score = analytics.get("overall_score", "")
            total_spans = analytics.get("total_spans", "")
            llm_evaluated = analytics.get("llm_evaluated", "")
            pre_skipped = analytics.get("pre_skipped", "")
            pass_count = analytics.get("pass_count", "")
            fail_count = analytics.get("fail_count", "")
            skip_count = analytics.get("skip_count", "")
            
            eval_output = eval_result.get("eval_output", {})
            per_span_results = json.dumps(eval_output.get("per_span_results", []), indent=2, default=str)
            overall_reason = eval_output.get("overall_reason", "")
            status = "success"

        # ============================================================
        # APPEND ROW
        # ============================================================

        sheet.append([
            query,
            overall_score,
            total_spans,
            llm_evaluated,
            pre_skipped,
            pass_count,
            fail_count,
            skip_count,
            per_span_results,
            overall_reason,
            status
        ])

        # ============================================================
        # SAVE
        # ============================================================

        wb.save(excel_path)

        print("Output Format Compliance evaluation saved successfully.")

    except Exception as e:
        print(f"❌ Error dumping Output Format Compliance to Excel: {e}")
