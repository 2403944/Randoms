"""
LangSmith Trace Evaluation with Async/Await
Evaluates multiple traces from an Excel file using all eval metrics.

OUTPUT ROUTING:
  - Detailed_Log.xlsx      → one sheet per eval (create if missing, append if exists)
  - Metrics_template.xlsx  → 'Secondary LLM' sheet (critique/secondary LLM outputs)
                           → 'Test Data' sheet    (per-query overall score + reason)
  - report.html            → generated at the end by report_html.py
"""

import os
import asyncio
import threading
import time
import zipfile
import tiktoken
from xml.etree import ElementTree as ET
from datetime import datetime
from pathlib import Path
from dotenv import load_dotenv
load_dotenv()
from langchain_openai import AzureChatOpenAI
from openpyxl import load_workbook, Workbook
from tqdm.asyncio import tqdm
from token_tracker import track_tokens_used, count_tokens, get_token_stats

# Import evaluation modules
from parameter_extraction_eval         import run_parameter_extraction_eval,      dump_parameter_eval_to_excel
from tool_call_accuracy_eval           import run_tool_call_accuracy_eval,        dump_tool_call_eval_to_excel
from trajectory_eval                   import run_trajectory_eval,                dump_trajectory_eval_to_excel
from refusal_eval                      import run_refusal_detection_eval,         dump_refusal_eval_to_excel
from plan_accuracy_eval                import run_plan_accuracy_eval,             dump_plan_accuracy_eval_to_excel
from summary_accuracy_eval             import run_summary_accuracy_eval,          dump_summary_accuracy_eval_to_excel
from hallucination_cove_eval           import run_hallucination_cove_eval,        dump_hallucination_cove_eval_to_excel
from agent_goal_accomplishment_eval    import run_agent_goal_accomplishment_eval, dump_agent_goal_accomplishment_to_excel
from context_filter_accuracy_eval      import run_context_filter_accuracy_eval,   dump_context_filter_accuracy_to_excel
from helpfulness_eval                  import run_helpfulness_eval,               dump_helpfulness_eval_to_excel
from coherence_eval                    import run_coherence_eval,                 dump_coherence_eval_to_excel
from convergence_eval                  import run_convergence_eval,               dump_convergence_eval_to_excel
from output_format_compliance_eval     import run_output_format_compliance_eval,  dump_output_format_compliance_to_excel
from confidence_score_accuracy_eval    import run_confidence_score_accuracy_eval, dump_confidence_score_accuracy_to_excel
from tool_call_error_detection_eval    import run_tool_call_error_detection_eval, dump_tool_call_error_detection_to_excel
from universal_critique_judge_eval     import run_universal_critique_judge,       dump_universal_critique_judge_to_excel
from Recovery_loop_eval                import run_recovery_loop_eval,             dump_recovery_loop_eval_to_excel

# Ensure environment variables are set from .env
os.environ["LANGSMITH_API_KEY"] = os.getenv("LANGSMITH_API_KEY")

# ============================================================
# OUTPUT FILE PATHS
# ============================================================
DETAILED_LOG_EXCEL     = "Detailed_Log.xlsx"
METRICS_TEMPLATE_EXCEL = "Metrics_template.xlsx"
FINAL_EVAL_EXCEL       = "final_eval_results.xlsx"
HTML_REPORT_OUTPUT     = "report.html"

# ============================================================
# PER-FILE WRITE LOCKS
# ============================================================
_EXCEL_LOCKS: dict = {}
_EXCEL_LOCKS_MUTEX = threading.Lock()

def _get_lock(excel_path: str) -> threading.Lock:
    key = str(Path(excel_path).resolve())
    with _EXCEL_LOCKS_MUTEX:
        if key not in _EXCEL_LOCKS:
            _EXCEL_LOCKS[key] = threading.Lock()
        return _EXCEL_LOCKS[key]

# ============================================================
# EVAL NAME → DETAILED LOG SHEET NAME MAPPING
# ============================================================
EVAL_SHEET_MAP = {
    "parameter_extraction_accuracy": "Parameter Extraction Accuracy",
    "tool_call_accuracy":            "Tool Call Accuracy",
    "trajectory_match":              "Trajectory",
    "refusal_detection":             "Refusal",
    "supervisor_plan_accuracy":      "Plan Accuracy",
    "summary_accuracy":              "Output vs Context Accuracy",
    "hallucination_cove":            "Hallucination CoVe",
    "agent_goal_accomplishment":     "Goal Accomplishment",
    "context_filter_accuracy":       "Context Filter accuracy",
    "helpfulness":                   "Helpfulness",
    "coherence":                     "Coherence",
    "convergence":                   "Convergence",
    "output_format_compliance":      "Output format Check",
    "confidence_score_accuracy":     "Confidence score accuracy",
    "tool_call_error_detection":     "Tool Call Error",
    "recovery_loop_eval":            "Recovery Loops",
}

_VALID_SHEET_NAMES: set = set(EVAL_SHEET_MAP.values())

STRAY_SHEET_MAP: dict = {
    "Supervisor Plan Accuracy":    "Plan Accuracy",
    "Summary Accuracy":            "Output vs Context Accuracy",
    "Agent Goal Accomplishment":   "Goal Accomplishment",
    "Context Filter Accuracy1":    "Context Filter Accuracy",
    "Output Format Compliance":    "Output format Check",
    "Confidence Score Accuracy1":  "Confidence score Accuracy",
    "Tool Call Error Detection":   "Tool Call Error",
    "Universal Critique Judge":    "Secondary LLM",
    "Recovery Loops":              "Recovery Loops",
}

# ============================================================
# TEST DATA SHEET — column header definitions
# ============================================================
TEST_DATA_METRIC_COLS = [
    ("Parameter Extraction Accuracy",  "Parameter Extraction Accuracy-reason"),
    ("Tool Call Accuracy",             "Tool Call Accuracy-reason"),
    ("Trajectory",                     "Trajectory-reason"),
    ("Refusal",                        "Refusal-reason"),
    ("Output vs Context Accuracy",     "Output vs Context Accuracy-reason"),
    ("Hallucination CoVe",             "Hallucination CoVe-reason"),
    ("Goal Accomplishment",            "Goal Accomplishment-reason"),
    ("Helpfulness",                    "Helpfulness-reason"),
    ("Convergence",                    "Convergence-reason"),
    ("Output format Check",            "Output format Check-reason"),
    ("Coherence",                      "Coherence-reason"),
    ("Confidence score accuracy",      "Confidence score accuracy-reason"),
    ("Tool Call Error",                "Tool Call Error-reason"),
    ("Context Filter Accuracy",        "Context Filter Accuracy-reason"),
    ("Plan Accuracy",                  "Plan Accuracy-reason"),
    ("Recovery Loop",                  "Recovery Loop-reason"),
]

TEST_DATA_FULL_HEADERS = (
    ["Query", "Response"]
    + [col for pair in TEST_DATA_METRIC_COLS for col in pair]
)

# ============================================================
# LOAD TRACE IDs AND SCENARIOS FROM EXCEL
# ============================================================
INPUT_EXCEL_PATH = "input_scenarios.xlsx"
SHEET_NAME       = "Sheet1"


def load_scenarios_from_excel(excel_path: str):
    if not Path(excel_path).exists():
        raise FileNotFoundError(f"Excel file not found: {excel_path}")
    wb     = load_workbook(excel_path)
    sheet  = wb[SHEET_NAME]
    scenarios = []
    for row in sheet.iter_rows(min_row=2, values_only=True):
        if row[0] and row[1]:
            scenarios.append({"trace_id": str(row[0]), "scenario": str(row[1])})
    return scenarios


# ============================================================
# HELPERS
# ============================================================
def _get(d, *keys):
    for k in keys:
        d = (d or {}).get(k)
    return d


def count_tokens_tiktoken(text: str) -> int:
    try:
        encoding = tiktoken.get_encoding("cl100k_base")
        return len(encoding.encode(text))
    except Exception:
        return 0


def invoke_and_track_tokens(llm, prompt, eval_name: str = "unknown", scenario: str = None):
    response = llm.invoke(prompt)
    if hasattr(response, 'content'):
        response_tokens = count_tokens(response.content)
        track_tokens_used(response_tokens, query=scenario, eval_name=eval_name)
    return response


def _ensure_sheet(excel_path: str, sheet_name: str, headers: list = None):
    path = Path(excel_path)
    if path.exists():
        wb = load_workbook(excel_path)
    else:
        wb = Workbook()
        if "Sheet" in wb.sheetnames:
            del wb["Sheet"]

    target_key = sheet_name.strip().lower()
    matched_name = None
    for existing in wb.sheetnames:
        if existing.strip().lower() == target_key:
            matched_name = existing
            break

    if matched_name is None:
        ws = wb.create_sheet(sheet_name)
        if headers:
            ws.append(headers)
    else:
        ws = wb[matched_name]

    return wb, ws


def _get_sheet_names(file_path: str) -> set:
    path = Path(file_path)
    if not path.exists():
        return set()
    try:
        with zipfile.ZipFile(file_path, 'r') as zf:
            with zf.open('xl/workbook.xml') as f:
                tree = ET.parse(f)
        ns = {'ns': 'http://schemas.openxmlformats.org/spreadsheetml/2006/main'}
        return {s.get('name') for s in tree.findall('.//ns:sheet', ns)}
    except Exception:
        return set()


def _dump_with_sheet_guard(file_path: str, expected_sheet: str, dump_fn, **kwargs):
    with _get_lock(file_path):
        if kwargs:
            dump_fn(**kwargs)
        else:
            dump_fn()

        if not Path(file_path).exists():
            return

        wb = load_workbook(file_path)
        try:
            changed = False
            existing = {name.strip().lower(): name for name in wb.sheetnames}
            expected_key = expected_sheet.strip().lower()

            for stray_name in list(wb.sheetnames):
                if stray_name.strip().lower() == expected_key:
                    continue
                if stray_name in _VALID_SHEET_NAMES:
                    continue
                correct_name = STRAY_SHEET_MAP.get(stray_name)
                if not correct_name:
                    continue

                real_target = existing.get(correct_name.strip().lower())
                stray_ws    = wb[stray_name]

                if real_target:
                    target_ws = wb[real_target]
                    for row in stray_ws.iter_rows(values_only=True):
                        if any(cell is not None for cell in row):
                            target_ws.append(list(row))
                    del wb[stray_name]
                    print(f"    [GUARD] Merged stray sheet '{stray_name}' → '{real_target}' in {Path(file_path).name}")
                else:
                    stray_ws.title = correct_name
                    existing[correct_name.strip().lower()] = correct_name
                    print(f"    [GUARD] Renamed stray sheet '{stray_name}' → '{correct_name}' in {Path(file_path).name}")
                changed = True

            if changed:
                wb.save(file_path)
        finally:
            try:
                wb.close()
            except Exception:
                pass


def _delete_query_rows(ws, query: str, query_col: int = 1):
    rows_to_delete = [
        row_idx
        for row_idx in range(2, ws.max_row + 1)
        if ws.cell(row_idx, query_col).value == query
    ]
    for row_idx in reversed(rows_to_delete):
        ws.delete_rows(row_idx)
    return len(rows_to_delete)


def _clear_query_from_sheet(excel_path: str, sheet_name: str, query: str):
    if not Path(excel_path).exists():
        return
    with _get_lock(excel_path):
        wb = load_workbook(excel_path)
        try:
            target_key = sheet_name.strip().lower()
            matched = next(
                (s for s in wb.sheetnames if s.strip().lower() == target_key),
                None
            )
            if matched is None:
                return
            ws      = wb[matched]
            removed = _delete_query_rows(ws, query, query_col=1)
            if removed:
                wb.save(excel_path)
                print(f"    [CLEAN] Removed {removed} stale row(s) for query in '{matched}'")
        finally:
            try:
                wb.close()
            except Exception:
                pass


# ============================================================
# WEIGHTED EVAL SCORE CALCULATOR
# ============================================================
import random

METRIC_WEIGHTS = {
    "Parameter Extraction Accuracy": 0.058,
    "Tool Call Accuracy":            0.078,
    "Trajectory":                    0.078,
    "Refusal":                       0.049,
    "Plan Accuracy":                 0.245,
    "Output vs Context Accuracy":    0.078,
    "Hallucination CoVe":            0.078,
    "Goal Accomplishment":           0.059,
    "Context Filter Accuracy":       0.059,
    "Helpfulness":                   0.039,
    "Coherence":                     0.039,
    "Convergence":                   0.039,
    "Output format Check":           0.029,
    "Confidence score accuracy":     0.029,
    "Tool Call Error":               0.020,
    "Recovery Loop":                 0.023,
}


def compute_weighted_score(scores_and_reasons: dict):
    total_weight = sum(METRIC_WEIGHTS.values())
    if round(total_weight, 5) != 1.0:
        raise ValueError(f"Weights must sum to 1.0 (current={total_weight})")

    weighted_total = 0.0
    breakdown = {}
    count = 0

    for metric, weight in METRIC_WEIGHTS.items():
        metric_data = scores_and_reasons.get(metric, {})
        score = metric_data.get("score")
        if score is None:
            continue
        try:
            score = float(score)
            score = max(0.0, min(1.0, score))
            count += 1
        except (ValueError, TypeError):
            score = 0.0

        weighted_score = score * weight
        weighted_total += weighted_score
        breakdown[metric] = {
            "score": round(score, 4),
            "weight": weight,
            "weighted_contribution": round(weighted_score, 4)
        }

    return {
        "score": round(weighted_total, 4),
        "breakdown": breakdown,
        "reason": f"Weighted average of {count} metrics. Breakdown: {breakdown}"
    }


def dump_weighted_scores_to_sheet(query: str, scores_and_reasons: dict, excel_path: str = FINAL_EVAL_EXCEL):
    sheet_name = "Weighted Scores"
    headers = ["Query"] + list(METRIC_WEIGHTS.keys()) + ["Total Score"]

    with _get_lock(excel_path):
        wb, ws = _ensure_sheet(excel_path, sheet_name, headers=headers)

        header_to_col = {}
        for col_idx in range(1, ws.max_column + 1):
            val = ws.cell(1, col_idx).value
            if val:
                header_to_col[val] = col_idx

        next_col = ws.max_column + 1
        for header in headers:
            if header not in header_to_col:
                ws.cell(1, next_col).value = header
                header_to_col[header] = next_col
                next_col += 1

        target_row = None
        for row_idx in range(2, ws.max_row + 1):
            if ws.cell(row_idx, 1).value == query:
                target_row = row_idx
                break

        if target_row is None:
            target_row = ws.max_row + 1

        ws.cell(target_row, header_to_col["Query"]).value = query

        for metric_name in METRIC_WEIGHTS.keys():
            if metric_name in header_to_col:
                metric_data = scores_and_reasons.get(metric_name, {})
                score = metric_data.get("score")
                if score is not None:
                    ws.cell(target_row, header_to_col[metric_name]).value = score

        if "Total Score" in header_to_col and "__WEIGHTED_SCORE__" in scores_and_reasons:
            total_score = scores_and_reasons.get("__WEIGHTED_SCORE__", {}).get("score")
            if total_score is not None:
                ws.cell(target_row, header_to_col["Total Score"]).value = total_score

        wb.save(excel_path)


# ============================================================
# UPDATE TEST DATA SHEET
# ============================================================
def update_test_data_sheet(query: str, response: str, scores_and_reasons: dict, excel_path: str = METRICS_TEMPLATE_EXCEL):
    sheet_name = "Test Data"

    with _get_lock(excel_path):
        wb, ws = _ensure_sheet(excel_path, sheet_name, headers=TEST_DATA_FULL_HEADERS)

        header_to_col = {}
        for col_idx in range(1, ws.max_column + 1):
            val = ws.cell(1, col_idx).value
            if val:
                header_to_col[val] = col_idx

        next_col = ws.max_column + 1
        for header in TEST_DATA_FULL_HEADERS:
            if header not in header_to_col:
                ws.cell(1, next_col).value = header
                header_to_col[header]      = next_col
                next_col += 1

        target_row = None
        for row_idx in range(2, ws.max_row + 1):
            if ws.cell(row_idx, 1).value == query:
                target_row = row_idx
                break

        if target_row is None:
            target_row = ws.max_row + 1
            print(f"    [TEST DATA] New row → row {target_row} for query")
        else:
            print(f"    [TEST DATA] Replacing existing row {target_row} for query")
            for col_idx in range(1, ws.max_column + 1):
                cell_header = ws.cell(1, col_idx).value
                if cell_header not in ("Query", "Response", None):
                    ws.cell(target_row, col_idx).value = None

        ws.cell(target_row, header_to_col["Query"]).value    = query
        ws.cell(target_row, header_to_col["Response"]).value = response or ""

        for score_col, reason_col in TEST_DATA_METRIC_COLS:
            metric_data = scores_and_reasons.get(score_col, {})
            score  = metric_data.get("score")
            reason = metric_data.get("reason")
            if score_col in header_to_col and score is not None:
                ws.cell(target_row, header_to_col[score_col]).value  = score
            if reason_col in header_to_col and reason is not None:
                ws.cell(target_row, header_to_col[reason_col]).value = reason

        wb.save(excel_path)


# ============================================================
# EXTRACT OVERALL SCORE + REASON FROM EACH EVAL RESULT
# ============================================================
def extract_scores_and_reasons(
    param_result, tool_result, traj_result, refusal_result,
    plan_result, summary_result, cove_result, goal_result,
    filter_result, helpfulness_result, coherence_result,
    convergence_result, format_result, confidence_result,
    error_detect_result, recovery_loop_result,
) -> dict:
    return {
        "Parameter Extraction Accuracy": {
            "score":  _get(param_result,       "score"),
            "reason": _get(param_result,       "overall_reason")
                      or _get(param_result,    "eval_output", "overall_reason"),
        },
        "Tool Call Accuracy": {
            "score":  _get(tool_result,        "score"),
            "reason": _get(tool_result,        "overall_reason")
                      or _get(tool_result,     "eval_output", "overall_reason"),
        },
        "Trajectory": {
            "score":  _get(traj_result,        "eval_output", "final_score"),
            "reason": _get(traj_result,        "eval_output", "overall_reason")
                      or _get(traj_result,     "overall_reason"),
        },
        "Refusal": {
            "score":  _get(refusal_result,     "eval_output", "score"),
            "reason": _get(refusal_result,     "eval_output", "overall_reason")
                      or _get(refusal_result,  "overall_reason"),
        },
        "Output vs Context Accuracy": {
            "score":  _get(summary_result,     "eval_output", "output_vs_context_accuracy_score"),
            "reason": _get(summary_result,     "eval_output", "overall_reason")
                      or _get(summary_result,  "overall_reason"),
        },
        "Hallucination CoVe": {
            "score":  _get(cove_result,        "eval_output", "score"),
            "reason": _get(cove_result,        "eval_output", "overall_reason")
                      or _get(cove_result,     "overall_reason"),
        },
        "Goal Accomplishment": {
            "score":  _get(goal_result,        "eval_output", "verdict"),
            "reason": _get(goal_result,        "eval_output", "overall_reason")
                      or _get(goal_result,     "overall_reason"),
        },
        "Helpfulness": {
            "score":  _get(helpfulness_result, "overall_summary", "overall_score"),
            "reason": _get(helpfulness_result, "overall_summary", "overall_reason")
                      or _get(helpfulness_result, "overall_reason"),
        },
        "Convergence": {
            "score":  _get(convergence_result, "score"),
            "reason": _get(convergence_result, "eval_output", "overall_reason")
                      or _get(convergence_result, "eval_output", "reasoning"),
        },
        "Output format Check": {
            "score":  _get(format_result,      "score"),
            "reason": _get(format_result,      "overall_reason"),
        },
        "Coherence": {
            "score":  _get(coherence_result,   "overall_summary", "overall_score"),
            "reason": _get(coherence_result,   "overall_summary", "overall_reason")
                      or _get(coherence_result, "overall_reason"),
        },
        "Confidence score accuracy": {
            "score":  _get(confidence_result,  "overall_score"),
            "reason": _get(confidence_result,  "overall_reason"),
        },
        "Tool Call Error": {
            "score":  _get(error_detect_result, "overall_score"),
            "reason": _get(error_detect_result, "overall_reason"),
        },
        "Context Filter Accuracy": {
            "score":  _get(filter_result,      "score"),
            "reason": _get(filter_result,      "eval_output", "overall_reason")
                      or _get(filter_result,   "overall_reason"),
        },
        "Plan Accuracy": {
            "score":  _get(plan_result,        "eval_output", "score"),
            "reason": _get(plan_result,        "eval_output", "overall_reason")
                      or _get(plan_result,     "overall_reason"),
        },
        "Recovery Loop": {
            "score":  _get(recovery_loop_result, "eval_output", "recovery_score"),
            "reason": _get(recovery_loop_result, "eval_output", "reason"),
        },
    }


# ============================================================
# ASYNC WORKER — process one trace
# ============================================================
async def process_single_trace(
    scenario_data: dict,
    llm_client: AzureChatOpenAI,
    deterministic_llm: AzureChatOpenAI,
    output_excel: str = "final_eval_results.xlsx",
):
    trace_id = scenario_data.get("trace_id")
    scenario = scenario_data.get("scenario")
    print(f"  Processing trace: {trace_id}")

    loop = asyncio.get_event_loop()

    def _safe(result):
        if isinstance(result, BaseException):
            print(f"  [WARN] Eval raised exception for trace {trace_id}: {result}")
            return {}
        return result if isinstance(result, dict) else {}

    # ------------------------------------------------------------------
    # 1. Run all evals concurrently (knowledge_retention removed)
    # ------------------------------------------------------------------
    raw = await asyncio.gather(
        loop.run_in_executor(None, run_parameter_extraction_eval,      trace_id, scenario, llm_client),
        loop.run_in_executor(None, run_tool_call_accuracy_eval,        trace_id, scenario, llm_client),
        loop.run_in_executor(None, run_trajectory_eval,                trace_id, scenario, deterministic_llm),
        loop.run_in_executor(None, run_refusal_detection_eval,         trace_id, scenario, llm_client),
        loop.run_in_executor(None, run_plan_accuracy_eval,             trace_id, scenario, llm_client),
        loop.run_in_executor(None, run_summary_accuracy_eval,          trace_id, scenario, llm_client),
        loop.run_in_executor(None, run_hallucination_cove_eval,        trace_id, scenario, llm_client),
        loop.run_in_executor(None, run_agent_goal_accomplishment_eval, trace_id, scenario, llm_client),
        loop.run_in_executor(None, run_context_filter_accuracy_eval,   trace_id, scenario, deterministic_llm),
        loop.run_in_executor(None, run_helpfulness_eval,               trace_id, scenario, llm_client),
        loop.run_in_executor(None, run_coherence_eval,                 trace_id, scenario, llm_client),
        loop.run_in_executor(None, run_convergence_eval,               trace_id, scenario),
        loop.run_in_executor(None, run_output_format_compliance_eval,  trace_id, scenario, deterministic_llm),
        loop.run_in_executor(None, run_confidence_score_accuracy_eval, trace_id, scenario, deterministic_llm),
        loop.run_in_executor(None, run_tool_call_error_detection_eval, trace_id, scenario, deterministic_llm),
        loop.run_in_executor(None, run_recovery_loop_eval,             trace_id, scenario, llm_client),
        return_exceptions=True,
    )

    (
        param_result,
        tool_result,
        traj_result,
        refusal_result,
        plan_result,
        summary_result,
        cove_result,
        goal_result,
        filter_result,
        helpfulness_result,
        coherence_result,
        convergence_result,
        format_result,
        confidence_result,
        error_detect_result,
        recovery_loop_result,
    ) = [_safe(r) for r in raw]

    # ------------------------------------------------------------------
    # 2. Dump detailed rows → Detailed_Log.xlsx
    # ------------------------------------------------------------------
    import utils  # noqa

    def _replace_and_dump(sheet_name, has_result, dump_fn, **kwargs):
        if not has_result:
            return
        _clear_query_from_sheet(DETAILED_LOG_EXCEL, sheet_name, scenario)
        _dump_with_sheet_guard(DETAILED_LOG_EXCEL, sheet_name, dump_fn, **kwargs)

    _replace_and_dump(
        EVAL_SHEET_MAP["parameter_extraction_accuracy"], bool(param_result),
        dump_parameter_eval_to_excel,
        trace_id=trace_id, query=scenario, eval_result=param_result, excel_path=DETAILED_LOG_EXCEL,
    )
    _replace_and_dump(
        EVAL_SHEET_MAP["tool_call_accuracy"], bool(tool_result),
        dump_tool_call_eval_to_excel,
        trace_id=trace_id, query=scenario, eval_result=tool_result, excel_path=DETAILED_LOG_EXCEL,
    )
    _replace_and_dump(
        EVAL_SHEET_MAP["trajectory_match"], bool(traj_result),
        dump_trajectory_eval_to_excel,
        trace_id=trace_id, query=scenario, eval_result=traj_result, excel_path=DETAILED_LOG_EXCEL,
    )
    _replace_and_dump(
        EVAL_SHEET_MAP["refusal_detection"], bool(refusal_result),
        dump_refusal_eval_to_excel,
        trace_id=trace_id, query=scenario, eval_result=refusal_result, excel_path=DETAILED_LOG_EXCEL,
    )
    _replace_and_dump(
        EVAL_SHEET_MAP["supervisor_plan_accuracy"], bool(plan_result),
        dump_plan_accuracy_eval_to_excel,
        trace_id=trace_id, query=scenario, eval_result=plan_result, excel_path=DETAILED_LOG_EXCEL,
    )
    _replace_and_dump(
        EVAL_SHEET_MAP["summary_accuracy"], bool(summary_result),
        dump_summary_accuracy_eval_to_excel,
        trace_id=trace_id, query=scenario, eval_result=summary_result, excel_path=DETAILED_LOG_EXCEL,
    )
    _replace_and_dump(
        EVAL_SHEET_MAP["hallucination_cove"], bool(cove_result),
        dump_hallucination_cove_eval_to_excel,
        trace_id=trace_id, query=scenario, eval_result=cove_result, excel_path=DETAILED_LOG_EXCEL,
    )
    _replace_and_dump(
        EVAL_SHEET_MAP["agent_goal_accomplishment"], bool(goal_result),
        dump_agent_goal_accomplishment_to_excel,
        trace_id=trace_id, query=scenario, eval_result=goal_result, excel_path=DETAILED_LOG_EXCEL,
    )
    _replace_and_dump(
        EVAL_SHEET_MAP["context_filter_accuracy"], bool(filter_result),
        dump_context_filter_accuracy_to_excel,
        trace_id=trace_id, query=scenario, eval_result=filter_result, excel_path=DETAILED_LOG_EXCEL,
    )
    _replace_and_dump(
        EVAL_SHEET_MAP["helpfulness"], bool(helpfulness_result),
        dump_helpfulness_eval_to_excel,
        trace_id=trace_id, query=scenario, eval_result=helpfulness_result, excel_path=DETAILED_LOG_EXCEL,
    )
    _replace_and_dump(
        EVAL_SHEET_MAP["coherence"], bool(coherence_result),
        dump_coherence_eval_to_excel,
        trace_id=trace_id, query=scenario, eval_result=coherence_result, excel_path=DETAILED_LOG_EXCEL,
    )
    _replace_and_dump(
        EVAL_SHEET_MAP["convergence"], bool(convergence_result),
        dump_convergence_eval_to_excel,
        trace_id=trace_id, query=scenario, eval_result=convergence_result, excel_path=DETAILED_LOG_EXCEL,
    )
    _replace_and_dump(
        EVAL_SHEET_MAP["output_format_compliance"], bool(format_result),
        dump_output_format_compliance_to_excel,
        trace_id=trace_id, query=scenario, eval_result=format_result, excel_path=DETAILED_LOG_EXCEL,
    )
    if confidence_result:
        _clear_query_from_sheet(DETAILED_LOG_EXCEL, EVAL_SHEET_MAP["confidence_score_accuracy"], scenario)
        _dump_with_sheet_guard(
            DETAILED_LOG_EXCEL, EVAL_SHEET_MAP["confidence_score_accuracy"],
            dump_confidence_score_accuracy_to_excel,
            eval_result=confidence_result, output_excel=DETAILED_LOG_EXCEL, utils=utils,
        )
    if error_detect_result:
        _clear_query_from_sheet(DETAILED_LOG_EXCEL, EVAL_SHEET_MAP["tool_call_error_detection"], scenario)
        _dump_with_sheet_guard(
            DETAILED_LOG_EXCEL, EVAL_SHEET_MAP["tool_call_error_detection"],
            dump_tool_call_error_detection_to_excel,
            eval_result=error_detect_result, output_excel=DETAILED_LOG_EXCEL, utils=utils,
        )
    if recovery_loop_result:
        _clear_query_from_sheet(DETAILED_LOG_EXCEL, EVAL_SHEET_MAP["recovery_loop_eval"], scenario)
        _dump_with_sheet_guard(
            DETAILED_LOG_EXCEL, EVAL_SHEET_MAP["recovery_loop_eval"],
            dump_recovery_loop_eval_to_excel,
            trace_id=trace_id, query=scenario,
            eval_result=recovery_loop_result, excel_path=DETAILED_LOG_EXCEL,
        )

    # ------------------------------------------------------------------
    # 2b. Also dump everything to output_excel (final_eval_results.xlsx)
    # ------------------------------------------------------------------
    def _replace_and_dump_final(sheet_name, has_result, dump_fn, **kwargs):
        if not has_result:
            return
        _clear_query_from_sheet(output_excel, sheet_name, scenario)
        _dump_with_sheet_guard(output_excel, sheet_name, dump_fn, **kwargs)

    _replace_and_dump_final(
        EVAL_SHEET_MAP["parameter_extraction_accuracy"], bool(param_result),
        dump_parameter_eval_to_excel,
        trace_id=trace_id, query=scenario, eval_result=param_result, excel_path=output_excel,
    )
    _replace_and_dump_final(
        EVAL_SHEET_MAP["tool_call_accuracy"], bool(tool_result),
        dump_tool_call_eval_to_excel,
        trace_id=trace_id, query=scenario, eval_result=tool_result, excel_path=output_excel,
    )
    _replace_and_dump_final(
        EVAL_SHEET_MAP["trajectory_match"], bool(traj_result),
        dump_trajectory_eval_to_excel,
        trace_id=trace_id, query=scenario, eval_result=traj_result, excel_path=output_excel,
    )
    _replace_and_dump_final(
        EVAL_SHEET_MAP["refusal_detection"], bool(refusal_result),
        dump_refusal_eval_to_excel,
        trace_id=trace_id, query=scenario, eval_result=refusal_result, excel_path=output_excel,
    )
    _replace_and_dump_final(
        EVAL_SHEET_MAP["supervisor_plan_accuracy"], bool(plan_result),
        dump_plan_accuracy_eval_to_excel,
        trace_id=trace_id, query=scenario, eval_result=plan_result, excel_path=output_excel,
    )
    _replace_and_dump_final(
        EVAL_SHEET_MAP["summary_accuracy"], bool(summary_result),
        dump_summary_accuracy_eval_to_excel,
        trace_id=trace_id, query=scenario, eval_result=summary_result, excel_path=output_excel,
    )
    _replace_and_dump_final(
        EVAL_SHEET_MAP["hallucination_cove"], bool(cove_result),
        dump_hallucination_cove_eval_to_excel,
        trace_id=trace_id, query=scenario, eval_result=cove_result, excel_path=output_excel,
    )
    _replace_and_dump_final(
        EVAL_SHEET_MAP["agent_goal_accomplishment"], bool(goal_result),
        dump_agent_goal_accomplishment_to_excel,
        trace_id=trace_id, query=scenario, eval_result=goal_result, excel_path=output_excel,
    )
    _replace_and_dump_final(
        EVAL_SHEET_MAP["context_filter_accuracy"], bool(filter_result),
        dump_context_filter_accuracy_to_excel,
        trace_id=trace_id, query=scenario, eval_result=filter_result, excel_path=output_excel,
    )
    _replace_and_dump_final(
        EVAL_SHEET_MAP["helpfulness"], bool(helpfulness_result),
        dump_helpfulness_eval_to_excel,
        trace_id=trace_id, query=scenario, eval_result=helpfulness_result, excel_path=output_excel,
    )
    _replace_and_dump_final(
        EVAL_SHEET_MAP["coherence"], bool(coherence_result),
        dump_coherence_eval_to_excel,
        trace_id=trace_id, query=scenario, eval_result=coherence_result, excel_path=output_excel,
    )
    _replace_and_dump_final(
        EVAL_SHEET_MAP["convergence"], bool(convergence_result),
        dump_convergence_eval_to_excel,
        trace_id=trace_id, query=scenario, eval_result=convergence_result, excel_path=output_excel,
    )
    _replace_and_dump_final(
        EVAL_SHEET_MAP["output_format_compliance"], bool(format_result),
        dump_output_format_compliance_to_excel,
        trace_id=trace_id, query=scenario, eval_result=format_result, excel_path=output_excel,
    )
    if confidence_result:
        _clear_query_from_sheet(output_excel, EVAL_SHEET_MAP["confidence_score_accuracy"], scenario)
        _dump_with_sheet_guard(
            output_excel, EVAL_SHEET_MAP["confidence_score_accuracy"],
            dump_confidence_score_accuracy_to_excel,
            eval_result=confidence_result, output_excel=output_excel, utils=utils,
        )
    if error_detect_result:
        _clear_query_from_sheet(output_excel, EVAL_SHEET_MAP["tool_call_error_detection"], scenario)
        _dump_with_sheet_guard(
            output_excel, EVAL_SHEET_MAP["tool_call_error_detection"],
            dump_tool_call_error_detection_to_excel,
            eval_result=error_detect_result, output_excel=output_excel, utils=utils,
        )
    if recovery_loop_result:
        _clear_query_from_sheet(output_excel, EVAL_SHEET_MAP["recovery_loop_eval"], scenario)
        _dump_with_sheet_guard(
            output_excel, EVAL_SHEET_MAP["recovery_loop_eval"],
            dump_recovery_loop_eval_to_excel,
            trace_id=trace_id, query=scenario,
            eval_result=recovery_loop_result, excel_path=output_excel,
        )

    # ------------------------------------------------------------------
    # 3. Update Test Data sheet → Metrics_template.xlsx
    # ------------------------------------------------------------------
    response_text = (
        _get(summary_result,  "eval_output", "actual_output")
        or _get(cove_result,  "eval_output", "actual_output")
        or _get(goal_result,  "eval_output", "actual_output")
        or ""
    )

    scores_and_reasons = extract_scores_and_reasons(
        param_result, tool_result, traj_result, refusal_result,
        plan_result, summary_result, cove_result, goal_result,
        filter_result, helpfulness_result, coherence_result,
        convergence_result, format_result, confidence_result,
        error_detect_result, recovery_loop_result,
    )

    update_test_data_sheet(
        query=scenario, response=response_text,
        scores_and_reasons=scores_and_reasons, excel_path=METRICS_TEMPLATE_EXCEL,
    )
    update_test_data_sheet(
        query=scenario, response=response_text,
        scores_and_reasons=scores_and_reasons, excel_path=FINAL_EVAL_EXCEL,
    )

    weighted_score_result = compute_weighted_score(scores_and_reasons)
    scores_and_reasons["__WEIGHTED_SCORE__"] = weighted_score_result
    dump_weighted_scores_to_sheet(
        query=scenario, scores_and_reasons=scores_and_reasons, excel_path=FINAL_EVAL_EXCEL,
    )

    # ------------------------------------------------------------------
    # 4. Return summary dict
    # ------------------------------------------------------------------
    return {
        "trace_id":  trace_id,
        "scenario":  scenario,

        "param_status":          param_result.get("status"),
        "param_score":           param_result.get("score"),
        "tool_status":           tool_result.get("status"),
        "tool_score":            tool_result.get("score"),
        "traj_status":           traj_result.get("status"),
        "traj_score":            _get(traj_result,        "eval_output", "final_score"),
        "refusal_status":        refusal_result.get("status"),
        "refusal_score":         _get(refusal_result,     "eval_output", "score"),
        "plan_status":           plan_result.get("status"),
        "plan_score":            _get(plan_result,        "eval_output", "score"),
        "summary_status":        summary_result.get("status"),
        "summary_score":         _get(summary_result,     "eval_output", "output_vs_context_accuracy_score"),
        "cove_status":           cove_result.get("status"),
        "cove_score":            _get(cove_result,        "eval_output", "score"),
        "goal_status":           goal_result.get("status"),
        "goal_score":            _get(goal_result,        "eval_output", "verdict"),
        "filter_status":         filter_result.get("status"),
        "filter_score":          filter_result.get("score"),
        "helpfulness_status":    helpfulness_result.get("status"),
        "helpfulness_score":     _get(helpfulness_result, "overall_summary", "overall_score"),
        "coherence_status":      coherence_result.get("status"),
        "coherence_score":       _get(coherence_result,   "overall_summary", "overall_score"),
        "convergence_status":    convergence_result.get("status"),
        "convergence_score":     convergence_result.get("score"),
        "format_status":         format_result.get("status"),
        "format_score":          format_result.get("score"),
        "confidence_status":     confidence_result.get("status"),
        "confidence_score":      confidence_result.get("overall_score"),
        "error_detect_status":   error_detect_result.get("status"),
        "error_detect_score":    error_detect_result.get("overall_score"),
        "recovery_loop_status":  recovery_loop_result.get("status"),
        "recovery_loop_score":   _get(recovery_loop_result, "eval_output", "numeric_score"),

        "eval_results": {
            "param":         param_result,
            "tool":          tool_result,
            "trajectory":    traj_result,
            "refusal":       refusal_result,
            "plan":          plan_result,
            "summary":       summary_result,
            "cove":          cove_result,
            "goal":          goal_result,
            "filter":        filter_result,
            "helpfulness":   helpfulness_result,
            "coherence":     coherence_result,
            "convergence":   convergence_result,
            "format":        format_result,
            "confidence":    confidence_result,
            "error_detect":  error_detect_result,
            "recovery_loop": recovery_loop_result,
        },
    }


# ============================================================
# ASYNC CRITIQUE JUDGE RUNNER
# ============================================================
async def run_critique_for_result(result: dict, critique_llm: AzureChatOpenAI, output_excel: str = "final_eval_results.xlsx"):
    import utils  # noqa

    trace_id          = result.get("trace_id")
    scenario          = result.get("scenario")
    eval_results_dict = result.get("eval_results", {})

    eval_mapping = {
        "param":         "parameter_extraction_accuracy",
        "tool":          "tool_call_accuracy",
        "trajectory":    "trajectory_match",
        "refusal":       "refusal_detection",
        "plan":          "supervisor_plan_accuracy",
        "summary":       "summary_accuracy",
        "cove":          "hallucination_cove",
        "goal":          "agent_goal_accomplishment",
        "filter":        "context_filter_accuracy",
        "helpfulness":   "helpfulness",
        "coherence":     "coherence",
        "convergence":   "convergence",
        "format":        "output_format_compliance",
        "confidence":    "confidence_score_accuracy",
        "error_detect":  "tool_call_error_detection",
        "recovery_loop": "recovery_loop_eval",
    }

    eval_records = []
    for key, eval_name in eval_mapping.items():
        eval_result = eval_results_dict.get(key, {})
        if eval_result and eval_result.get("status") in ("success", "completed"):
            eval_records.append({
                "eval_name":   eval_name,
                "eval_type":   eval_result.get("eval_type", "hybrid"),
                "trace_id":    trace_id,
                "scenario":    scenario,
                "eval_prompt": eval_result.get("eval_prompt", ""),
                "eval_inputs": eval_result.get("eval_inputs", {}),
                "eval_output": eval_result.get("eval_output", {}),
            })

    if not eval_records:
        return None

    loop = asyncio.get_event_loop()
    critique_result = await loop.run_in_executor(
        None, run_universal_critique_judge, eval_records, critique_llm
    )

    _clear_query_from_sheet(METRICS_TEMPLATE_EXCEL, "Secondary LLM", scenario)
    _dump_with_sheet_guard(
        METRICS_TEMPLATE_EXCEL, "Secondary LLM",
        lambda: dump_universal_critique_judge_to_excel(critique_result, METRICS_TEMPLATE_EXCEL, utils),
    )
    _dump_with_sheet_guard(
        output_excel, "Secondary LLM",
        lambda: dump_universal_critique_judge_to_excel(critique_result, output_excel, utils),
    )

    status = critique_result.get("status")
    if status == "completed":
        print(f"  [OK] Critique done for trace {trace_id} ({len(eval_records)} evals)")
    else:
        print(f"  [ERROR] Critique failed for trace {trace_id}")

    return critique_result


# ============================================================
# MAIN ASYNC ORCHESTRATOR
# ============================================================
async def run_async_evaluation(
    scenarios: list,
    llm_client: AzureChatOpenAI,
    deterministic_llm: AzureChatOpenAI,
    critique_llm: AzureChatOpenAI,
    semaphore_limit: int = 4,
    output_excel: str = "final_eval_results.xlsx",
):
    if not scenarios:
        print("No scenarios to process.")
        return []

    print(f"\n[INFO] Starting async evaluation (concurrency={semaphore_limit})")
    print(f"[INFO] Total traces: {len(scenarios)}")
    print(f"[INFO] Full eval results   → {output_excel}")
    print(f"[INFO] Detailed log        → {DETAILED_LOG_EXCEL}")
    print(f"[INFO] Metrics/Test Data   → {METRICS_TEMPLATE_EXCEL}")
    print(f"[INFO] HTML report         → {HTML_REPORT_OUTPUT}\n")

    semaphore = asyncio.Semaphore(semaphore_limit)

    async def guarded_process(scenario_data):
        async with semaphore:
            return await process_single_trace(
                scenario_data, llm_client, deterministic_llm, output_excel
            )

    tasks          = [guarded_process(s) for s in scenarios]
    results        = []
    critique_tasks = []

    for coro in tqdm(asyncio.as_completed(tasks), total=len(tasks), desc="Traces"):
        result = await coro
        results.append(result)
        query = result.get("scenario", "Unknown")
        token_stats  = get_token_stats()
        query_tokens = token_stats.get("per_query", {}).get(query, 0)
        if query_tokens > 0:
            print(f"  ✓ Query complete: {query} [{query_tokens:,} tokens]")

    print(f"\n[OK] All {len(results)} traces evaluated.")
    print(f"     Detailed log saved → {DETAILED_LOG_EXCEL}")
    print(f"     Test Data updated  → {METRICS_TEMPLATE_EXCEL} / 'Test Data'")

    metrics = [
        ("PARAMETER EXTRACTION ACCURACY", "param_status",        "param_score",        "success"),
        ("TOOL CALL ACCURACY",            "tool_status",         "tool_score",          "success"),
        ("TRAJECTORY MATCH",              "traj_status",         "traj_score",          "success"),
        ("REFUSAL DETECTION",             "refusal_status",      "refusal_score",       "success"),
        ("SUPERVISOR PLAN ACCURACY",      "plan_status",         "plan_score",          "success"),
        ("SUMMARY ACCURACY",              "summary_status",      "summary_score",       "success"),
        ("HALLUCINATION CoVe",            "cove_status",         "cove_score",          "success"),
        ("AGENT GOAL ACCOMPLISHMENT",     "goal_status",         "goal_score",          "success"),
        ("CONTEXT FILTER ACCURACY",       "filter_status",       "filter_score",        "success"),
        ("HELPFULNESS",                   "helpfulness_status",  "helpfulness_score",   "success"),
        ("COHERENCE",                     "coherence_status",    "coherence_score",     "success"),
        ("CONVERGENCE",                   "convergence_status",  "convergence_score",   "success"),
        ("OUTPUT FORMAT COMPLIANCE",      "format_status",       "format_score",        "success"),
        ("CONFIDENCE SCORE ACCURACY",     "confidence_status",   "confidence_score",    "completed"),
        ("TOOL CALL ERROR DETECTION",     "error_detect_status", "error_detect_score",  "completed"),
        ("RECOVERY LOOP",                 "recovery_loop_status","recovery_loop_score", "completed"),
    ]

    def _stats(results, status_key, score_key, ok_status="success"):
        successful = [r for r in results if r.get(status_key) == ok_status]
        avg = sum(r.get(score_key) or 0 for r in successful) / max(len(successful), 1)
        return len(successful), len(results) - len(successful), avg

    print("\n" + "=" * 60)
    print("EVALUATION SUMMARY")
    print("=" * 60)
    for label, status_key, score_key, ok_status in metrics:
        ok, fail, avg = _stats(results, status_key, score_key, ok_status)
        print(f"\n  {label}")
        print(f"    Successful: {ok}/{len(results)}  |  Failed: {fail}/{len(results)}  |  Avg Score: {avg:.4f}")

    for result in results:
        if result and "eval_results" in result:
            critique_tasks.append(run_critique_for_result(result, critique_llm, output_excel))

    if critique_tasks:
        print(f"\n{'='*60}")
        print("RUNNING UNIVERSAL CRITIQUE JUDGE (Secondary LLM)")
        print(f"{'='*60}")
        critique_results = await asyncio.gather(*critique_tasks, return_exceptions=True)
        ok_c   = sum(1 for r in critique_results if isinstance(r, dict) and r.get("status") == "completed")
        fail_c = len(critique_results) - ok_c
        print(f"  Critiqued: {ok_c}/{len(critique_results)}  |  Failed: {fail_c}")
        print(f"  Critique output saved → {METRICS_TEMPLATE_EXCEL} / 'Secondary LLM'")

        token_stats = get_token_stats()
        secondary_llm_tokens = token_stats.get("per_eval", {}).get("universal_critique_judge", 0)
        if secondary_llm_tokens > 0:
            print(f"  [TOKENS] Secondary LLM (Critique): {secondary_llm_tokens:,} tokens")

    print(f"\n{'='*60}")
    print("GENERATING HTML REPORT")
    print(f"{'='*60}")
    try:
        import pandas as pd
        from report_gen import ReportGenerator

        metrics_df = pd.read_excel(METRICS_TEMPLATE_EXCEL, sheet_name="Metrics Interpretability")
        details_df = pd.read_excel(METRICS_TEMPLATE_EXCEL, sheet_name="Test Data")
        summary_df = pd.read_excel(METRICS_TEMPLATE_EXCEL, sheet_name="Metrics_wise Pass-Fail")
        overall_df = pd.read_excel(METRICS_TEMPLATE_EXCEL, sheet_name="Overall Summary")

        generator    = ReportGenerator()
        html_content = generator.generate_report(metrics_df, details_df, summary_df, overall_df)

        with open(HTML_REPORT_OUTPUT, "w", encoding="utf-8") as f:
            f.write(html_content)
        print(f"  [OK] HTML report generated → {HTML_REPORT_OUTPUT}")

        try:
            from flask import Flask, send_file
            import webbrowser

            _flask_app  = Flask(__name__)
            _html_path  = str(Path(HTML_REPORT_OUTPUT).resolve())
            _flask_port = 5000

            @_flask_app.route("/")
            def _serve_report():
                return send_file(_html_path)

            def _run_flask():
                import logging
                log = logging.getLogger("werkzeug")
                log.setLevel(logging.ERROR)
                _flask_app.run(host="127.0.0.1", port=_flask_port, debug=False, use_reloader=False)

            _server_thread = threading.Thread(target=_run_flask, daemon=True)
            _server_thread.start()
            time.sleep(0.5)

            _url = f"http://127.0.0.1:{_flask_port}"
            print(f"\n  ╔══════════════════════════════════════════╗")
            print(f"  ║  📊 Report live at: {_url}  ║")
            print(f"  ╚══════════════════════════════════════════╝")
            print(f"  Press Ctrl+C to stop the server.\n")
            webbrowser.open(_url)

            try:
                while True:
                    time.sleep(1)
            except KeyboardInterrupt:
                print("\n  [OK] Server stopped.")

        except ImportError:
            print("  [INFO] Flask not installed — skipping local server. Open report.html directly.")
    except ImportError:
        print("  [WARN] report_gen.py not found — skipping HTML generation.")
    except Exception as exc:
        print(f"  [ERROR] HTML generation failed: {exc}")

    print(f"\n{'='*60}")
    print("ALL DONE")
    print(f"  Detailed eval data  : {DETAILED_LOG_EXCEL}")
    print(f"  Full eval results   : {output_excel}")
    print(f"  Metrics / Critique  : {METRICS_TEMPLATE_EXCEL}")
    print(f"  HTML Report         : {HTML_REPORT_OUTPUT}")
    print(f"{'='*60}")

    print(f"\n{'='*60}")
    print("TOKEN USAGE SUMMARY (from LLM calls)")
    print(f"{'='*60}")

    token_stats  = get_token_stats()
    total_tokens = token_stats.get("total", 0)
    per_query    = token_stats.get("per_query", {})
    per_eval     = token_stats.get("per_eval", {})

    print(f"\n  Overall Total: {total_tokens:,} tokens")

    if per_query:
        print(f"\n  Per-Query Breakdown ({len(per_query)} queries):")
        for query, tokens in sorted(per_query.items(), key=lambda x: x[1], reverse=True):
            print(f"    - {query}: {tokens:,} tokens")

    if per_eval:
        print(f"\n  Per-Eval Module Breakdown:")
        for eval_name, tokens in sorted(per_eval.items(), key=lambda x: x[1], reverse=True):
            print(f"    - {eval_name}: {tokens:,} tokens")

    print(f"\n{'='*60}\n")

    return results


# ============================================================
# MAIN ENTRY POINT
# ============================================================
if __name__ == "__main__":
    api_key     = os.getenv("AZURE_OPENAI_API_KEY")
    endpoint    = os.getenv("AZURE_OPENAI_ENDPOINT")
    api_version = os.getenv("AZURE_OPENAI_API_VERSION")
    deployment  = os.getenv("AZURE_OPENAI_LLM_DEPLOYMENT")

    def make_llm(temperature: float) -> AzureChatOpenAI:
        return AzureChatOpenAI(
            openai_api_key=api_key,
            azure_endpoint=endpoint,
            openai_api_version=api_version,
            deployment_name=deployment,
            model="gpt-5",
            temperature=temperature,
        )

    llm_client        = make_llm(temperature=1)
    deterministic_llm = make_llm(temperature=0)
    critique_llm      = make_llm(temperature=1)

    print("[OK] Azure OpenAI clients initialized.")

    try:
        scenarios = load_scenarios_from_excel(INPUT_EXCEL_PATH)
        print(f"[OK] Loaded {len(scenarios)} scenarios from {INPUT_EXCEL_PATH}")
    except FileNotFoundError as exc:
        print(f"[WARN] {exc}")
        print("Please ensure 'input_scenarios.xlsx' exists in the current directory.")
        scenarios = []

    if scenarios:
        asyncio.run(run_async_evaluation(
            scenarios=scenarios,
            llm_client=llm_client,
            deterministic_llm=deterministic_llm,
            critique_llm=critique_llm,
            semaphore_limit=4,
            output_excel="final_eval_results.xlsx",
        ))
    else:
        print("[ERROR] No scenarios loaded. Please check input_scenarios.xlsx.")