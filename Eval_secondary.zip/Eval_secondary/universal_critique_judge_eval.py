# ============================================================
# UNIVERSAL CRITIQUE JUDGE — BATCH MODE (SINGLE CELL)
# ============================================================

import json
from typing import Dict, Any, List
from langchain_openai import AzureChatOpenAI


# ============================================================
# LLM CONFIG (CRITIQUE JUDGE)
# ============================================================

# Note: critique_llm is passed as a parameter to run_universal_critique_judge function
# It should be initialized in main.py with proper Azure credentials


# ============================================================
# ERROR TYPE CANONICAL SET
# ============================================================

ERROR_TYPES = {
    "none",
    "Hallucinated_Content",
    "Omitted_Required_Element",
    "Misinterpretation_of_Input",
    "Verdict_Reasoning_Misalignment",
    "Internal_System_Error"
}


# ============================================================
# CRITIQUE PROMPT BUILDER
# ============================================================

def build_critique_prompt(eval_record: Dict[str, Any]) -> str:
    return f"""
**Situation**
You are auditing a PRIMARY EVALUATOR's adherence to its own evaluation prompt. The PRIMARY EVALUATOR has been given an evaluation prompt, evaluation inputs extracted from LangSmith trace data, and has produced an evaluation output. Your role is to verify procedural compliance—not to re-evaluate the underlying AI system or introduce new criteria.

**Task**
The assistant should:
1. Verify that the PRIMARY EVALUATOR applied all mandatory evaluation logic and criteria explicitly stated in its evaluation prompt.
2. Confirm that all reasoning claims in the evaluation output are grounded strictly in the provided evaluation inputs.
3. Ensure the final verdict logically follows from the evaluator's own reasoning.
4. Classify any procedural violation into exactly one error category from the predefined list.
5. Return structured JSON output with no additional commentary.

**Objective**
Ensure strict procedural compliance of the PRIMARY EVALUATOR against its own rulebook. If the evaluator followed its own evaluation logic consistently, the evaluation is correct—even if the verdict seems wrong. If a violation exists, identify it precisely and demonstrate the error using only real content from the provided inputs, outputs, and prompts.

**Knowledge**
The assistant must NOT:
- Re-evaluate the AI system or decide what the correct task answer should have been.
- Introduce new criteria, strengthen or weaken the rubric, or apply outside knowledge.
- Penalize JSON format, schema structure, output wrapping, triple backticks, or any output formatting unless explicitly required as an evaluation logic rule in the evaluation prompt.
- Flag minor value differences such as case sensitivity, spacing, or capitalization unless the primary evaluation prompt explicitly requires exact case matching as an evaluation rule.
- Generate error demonstrations using hypothetical, fabricated, or invented examples.
- Create artificial scenarios or missing evidence.

The assistant MUST:
- Quote exact fragments from EVALUATION INPUTS, EVALUATION OUTPUT, and EVALUATION PROMPT when demonstrating errors.
- Treat the EVALUATION PROMPT as the authoritative rulebook and EVALUATION INPUTS as the only allowed evidence.
- Determine if the evaluator ignored required evaluation criteria, applied unauthorized criteria, or produced a verdict that doesn't logically follow from its reasoning.
- Focus only on whether the evaluation logic and judgment were correctly applied — not on output format, schema compliance, or value formatting.
- If the primary evaluator applied semantic matching correctly (e.g., "food" and "Food" are semantically the same), treat this as compliant and do NOT flag it as an error.

**Error Categories (Select Exactly One)**
- **none**: The evaluator fully followed its own evaluation logic and rules. No error demonstration should be generated.
- **Hallucinated_Content**: The evaluator introduced claims not grounded in inputs or not defined in its prompt.
- **Omitted_Required_Element**: The evaluator failed to apply or analyze a mandatory evaluation criteria or logic rule from its prompt. Do NOT use this for JSON format, schema structure, output wrapping, or any formatting violations — only flag when a required evaluation judgment or logic criterion was skipped.
- **Misinterpretation_of_Input**: The evaluator incorrectly interpreted or misread the evaluation inputs.
- **Verdict_Reasoning_Misalignment**: The evaluator's verdict does not logically follow from its own reasoning.

============================================================
EVALUATION NAME
============================================================
{eval_record.get("eval_name", "")}

============================================================
EVALUATION TYPE
============================================================
{eval_record.get("eval_type", "")}

============================================================
EVALUATION PROMPT (RULEBOOK)
============================================================
{eval_record.get("eval_prompt", "")}

============================================================
EVALUATION INPUTS (ONLY SOURCE OF TRUTH)
============================================================
{json.dumps(eval_record.get("eval_inputs", {}), indent=2, default=str)}

============================================================
EVALUATION OUTPUT (PRIMARY EVALUATOR OUTPUT)
============================================================
{json.dumps(eval_record.get("eval_output", {}), indent=2, default=str)}

FEW-SHOT ERROR INSTRUCTION RULES (APPLY ONLY WHEN error_status = "fail")
------------------------------------------------------------

When an error is identified:

1. The field "few_shot_example" is REQUIRED.
2. It MUST contain both "positive_scenario" and "negative_scenario".
3. If error_type = "none" → DO NOT generate few_shot_example.
4. All error types → both scenarios MUST use statement-based examples. positive_scenario describes what SHOULD have happened. negative_scenario describes what actually went wrong.
5. positive_scenario and negative_scenario MUST be direct contrasts — positive shows correct evaluation behavior, negative shows the opposite incorrect behavior.
6. All generated scenarios MUST quote exact fragments from the provided EVALUATION PROMPT, INPUTS, or OUTPUT.
7. Do NOT fabricate content when generating real examples.
8. The SAMPLE examples below are structural references only. They must NOT be copied verbatim in real evaluations.


------------------------------------------------------------
OUTPUT FORMAT
------------------------------------------------------------

If no error is found:

{{
  "error_status": "pass",
  "error_type": "none",
  "reason": "Concise explanation referencing evaluator rule compliance"
}}

If an error is identified:

{{
  "error_status": "fail",
  "error_type": "[one category only]",
  "reason": "Concise explanation referencing exact quoted violations",
  "few_shot_example": {{
    "positive_scenario": "Statement describing what the evaluator should have done based on the evaluation logic.",
    "negative_scenario": "Statement describing what the evaluator actually did wrong."
  }}
}}

------------------------------------------------------------
SAMPLE FEW-SHOT EXAMPLES (FORMAT REFERENCE ONLY)
------------------------------------------------------------

Example 1 — Omitted_Required_Element (Statement Type)

{{
  "error_status": "fail",
  "error_type": "Omitted_Required_Element",
  "reason": "The evaluator failed to apply the required criterion of assessing whether the response moves the user closer to their goal.",
  "few_shot_example": {{
    "positive_scenario": "The evaluator assesses whether the assistant's turn moves the user closer to their goal, referencing the rule: 'Rate the helpfulness of the assistant's turn using this scale.'",
    "negative_scenario": "The evaluator scored the turn without assessing goal progression, skipping the core evaluation criterion entirely."
  }}
}}

------------------------------------------------------------

Example 2 — Hallucinated_Content (Statement Type)

{{
  "error_status": "fail",
  "error_type": "Hallucinated_Content",
  "reason": "The evaluator referenced criteria not defined in the evaluation prompt.",
  "few_shot_example": {{
    "positive_scenario": "Reasoning is restricted strictly to rules in the evaluation prompt: 'The response must include at least one direct quote from the input.'",
    "negative_scenario": "Tone was marked as unprofessional, although tone assessment is not mentioned anywhere in the evaluation prompt."
  }}
}}

------------------------------------------------------------

Example 3 — Verdict_Reasoning_Misalignment (Statement Type)

{{
  "error_status": "fail",
  "error_type": "Verdict_Reasoning_Misalignment",
  "reason": "The evaluator concluded 'pass' despite explicitly stating a required rule was violated.",
  "few_shot_example": {{
    "positive_scenario": "The response does not contain the required citation, violating the mandatory citation rule — verdict is 'fail'.",
    "negative_scenario": "The response does not contain the required citation, violating the mandatory citation rule — verdict is 'pass'."
  }}
}}

------------------------------------------------------------

Example 4 — Misinterpretation_of_Input (Statement Type)

{{
  "error_status": "fail",
  "error_type": "Misinterpretation_of_Input",
  "reason": "The evaluator incorrectly relied on label position instead of applying the explicit rule defined in the evaluation prompt.",
  "few_shot_example": {{
    "positive_scenario": "Sentiment is classified based strictly on textual meaning — the phrase 'This is awesome!' is correctly identified as positive from its content.",
    "negative_scenario": "Sentiment was determined as Positive because the label appeared before the sentence, ignoring the actual textual content."
  }}
}}

------------------------------------------------------------

Example 5 — Hallucinated_Content (Pattern Assumption Case)

{{
  "error_status": "fail",
  "error_type": "Hallucinated_Content",
  "reason": "The evaluator assumed structural consistency based on previous examples, which is not defined as a rule in the evaluation prompt.",
  "few_shot_example": {{
    "positive_scenario": "Only explicitly defined evaluation criteria from the evaluation prompt are applied — no assumptions are inferred from prior examples.",
    "negative_scenario": "This output was expected to follow the same format as earlier examples, even though no such rule exists in the prompt."
  }}
}}

------------------------------------------------------------
Return JSON only. No markdown, commentary, or explanation.
"""


# ============================================================
# SINGLE CRITIQUE EXECUTION
# ============================================================

def run_critique_judge(eval_record: Dict[str, Any], critique_llm) -> Dict[str, Any]:
    """
    Run critique judge on a single evaluation record.
    
    Args:
        eval_record: The evaluation record to critique
        critique_llm: Azure OpenAI client for the critique LLM
    
    Returns:
        dict with critique results
    """
    prompt = build_critique_prompt(eval_record)

    response = critique_llm.invoke(prompt)
    raw = response.content if hasattr(response, "content") else str(response)

    try:
        critique = json.loads(raw)
    except Exception:
        critique = {
            "error_status": "fail",
            "error_type": "Internal_System_Error",
            "reason": f"Critique judge returned invalid JSON: {raw}"
        }

    # Safety clamp: enforce valid error_type
    if critique.get("error_type") not in ERROR_TYPES:
        critique["error_type"] = "Internal_System_Error"
        critique["error_status"] = "fail"
        critique["reason"] = critique.get("reason", "") + " (Invalid error_type returned by critique judge.)"

    return {
        "eval_name": eval_record.get("eval_name"),
        "critique": critique
    }


# ============================================================
# BATCH CRITIQUE RUNNER
# ============================================================

def run_universal_critique_judge(
    eval_records: List[Dict[str, Any]],
    critique_llm
) -> List[Dict[str, Any]]:
    """
    Run critique judge on all evaluation records.
    
    Args:
        eval_records: List of evaluation records to critique
        critique_llm: Azure OpenAI client for the critique LLM
    
    Returns:
        List of critique results
    """
    results = []

    for i, eval_record in enumerate(eval_records, 1):
        print(
            f"\n===== CRITIQUING EVAL {i}/{len(eval_records)}: "
            f"{eval_record.get('eval_name')} ====="
        )

        critique_result = run_critique_judge(eval_record, critique_llm)
        results.append(critique_result)

        print(json.dumps(critique_result, indent=2))

    return results


# ============================================================
# EXCEL DUMP FUNCTION
# ============================================================

def dump_universal_critique_judge_to_excel(
    critique_results: List[Dict[str, Any]],
    excel_path: str = "final_eval_results.xlsx",
    utils = None
):
    """
    Dump universal critique judge results to Excel sheet.

    Args:
        critique_results: List of critique results from run_universal_critique_judge
        excel_path: Path to Excel file
        utils: Utility module (optional)
    """
    try:
        from utils import get_or_create_workbook, get_or_create_sheet

        # ============================================================
        # CONFIG
        # ============================================================

        SHEET_NAME = "Universal Critique Judge"
        HEADERS = [
            "Eval Name",
            "Error Status",
            "Error Type",
            "Reason",
            "Few Shot Example"
        ]

        # ============================================================
        # LOAD OR CREATE WORKBOOK/SHEET
        # ============================================================

        wb = get_or_create_workbook(excel_path)
        ws = get_or_create_sheet(wb, SHEET_NAME, HEADERS)

        # ============================================================
        # EXTRACT VALUES AND APPEND ROWS
        # ============================================================

        for result in critique_results:
            eval_name = result.get("eval_name", "")
            critique = result.get("critique", {})
            
            error_status = critique.get("error_status", "")
            error_type = critique.get("error_type", "")
            reason = critique.get("reason", "")
            few_shot_example = json.dumps(critique.get("few_shot_example", {}), indent=2, default=str)

            ws.append([
                eval_name,
                error_status,
                error_type,
                reason,
                few_shot_example
            ])

        # ============================================================
        # SAVE
        # ============================================================

        wb.save(excel_path)

        print("Universal Critique Judge results saved successfully.")

    except Exception as e:
        print(f"❌ Error dumping Universal Critique Judge to Excel: {e}")
