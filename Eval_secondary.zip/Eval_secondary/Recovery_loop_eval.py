"""
Recovery Loop Evaluation Module
Evaluates agent goal accomplishment per span and detects recovery loops
when a failed agent is retried and succeeds within the same parent context.
"""

import os
import json
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime
from typing import List, Dict, Any
from langsmith import Client
from langchain_openai import AzureChatOpenAI
from openpyxl import Workbook, load_workbook
from pathlib import Path
from token_tracker import track_tokens_used, count_tokens


# ============================================================
# AGENT SPECS
# ============================================================
AGENT_SPECS = [
    {
        "agent_name": "Supervisor Process",
        "responsibilities": [
            "Route correctly between agents based on workflow phases",
            "Act strictly as orchestration router and never as logistics planner",
            "Collect and validate all mandatory shipment fields from user conversation",
            "Enforce confirmation gate before moving to ContextBuilder",
            "Maintain HumanConversation state whenever waiting for user input",
            "Trigger Analytics workflow for analytical queries and handle clarifications",
            "Reinvoke ContextBuilder when distance or weather context is missing or invalid",
            "Pass complete shipment schema to TaskPlanner after context validation",
            "Reconcile Compliance and Optimization outputs and present plans persuasively",
            "Allow user selection of rejected or non-compliant plans without blocking",
            "Handle execution phase including reconfirmation, email validation, and Execute routing",
            "Normalize conversational flow without exposing internal orchestration details",
        ],
        "input_contract": {
            "state.messages": "Full ordered conversation history including prior agent outputs",
            "last_agent_output": "Latest message from ContextBuilder, TaskPlanner, Compliance, Optimization, Analytics, or Execute",
            "user_intent": "Natural language shipping or analytics request",
            "mandatory_fields": [
                "item_name", "item_type", "weight", "number_of_boxes",
                "box_height", "box_width", "box_length",
                "delivery_date", "base_location", "target_location",
            ],
        },
        "output_contract": {
            "allowed_output_shapes": [
                {
                    "next": "One of HumanConversation, Analytics, ContextBuilder, TaskPlanner, Execute, FINISH",
                    "reply_to_user": "Natural conversational response aligned with workflow phase",
                    "note_for_agent": "Single concise internal instruction (optional for HumanConversation)",
                    "reason": "Detailed justification describing routing decision logic",
                },
                {
                    "output": {
                        "next": "One of HumanConversation, Analytics, ContextBuilder, TaskPlanner, Execute, FINISH",
                        "reply_to_user": "Natural conversational response aligned with workflow phase",
                        "note_for_agent": "Single concise internal instruction (optional for HumanConversation)",
                        "reason": "Detailed justification describing routing decision logic",
                    }
                },
            ],
            "execution_note": "Supervisor responses MAY be wrapped inside a top-level 'output' object. This is execution-safe.",
        },
        "assumptions": [
            "Supervisor does not possess planning, pricing, or vendor knowledge",
            "Downstream agents follow their own contracts and schemas",
            "Conversation memory is reliable and ordered",
            "User intent remains authoritative and should not be altered",
            "Non-compliant plans can still be executed if selected by user",
            "HumanConversation represents waiting state rather than processing state",
        ],
        "forbidden_actions": [
            "Generating shipping plans, vendor lists, or cost estimates",
            "Skipping confirmation gate when mandatory fields are present",
            "Blocking user-selected rejected plans",
            "Exposing internal orchestration or routing logic to the user",
            "Proceeding to ContextBuilder before explicit user confirmation",
            "Ignoring missing or invalid context returned from ContextBuilder",
        ],
    },
    {
        "agent_name": "Context Builder Agent",
        "responsibilities": [
            "Fetch vendor information for the provided base_location using Fetch Vendors Tool",
            "Fetch vendor order history for the provided base_location using Fetch Performance History tool",
            "Retrieve distance between base_location and target_location using Web Search Tool",
            "Retrieve weather information for the shipping route using Web Search Tool",
            "Identify events or holidays affecting delivery_date using Web Search Tool",
            "Aggregate all retrieved information into a one-line JSON summary",
        ],
        "input_contract": {
            "base_location": "string provided by Supervisor",
            "target_location": "string provided by Supervisor",
            "delivery_date": "date string provided by Supervisor",
        },
        "output_contract": {
            "summary_json": "One-line proper JSON containing vendors, order_history, distance, weather, and event information",
        },
        "assumptions": [
            "Supervisor provides valid base_location, target_location, and delivery_date",
            "Tools return usable structured or textual information",
            "Web search queries must follow exact phrasing defined in the prompt",
            "Agent may call multiple tools sequentially to gather context",
        ],
        "forbidden_actions": [
            "Calling Web Search Tool more than 15 times",
            "Calling Fetch Vendors Tool more than twice",
            "Calling Fetch Performance History tool more than twice",
        ],
    },
    {
        "agent_name": "Context Builder Summarization Process",
        "responsibilities": [
            "Extract distance information between base and target location from provided message",
            "Extract overall route weather condition from the provided information",
            "Identify any shipping-impacting event or holiday relevant to the delivery date",
            "Ignore vendor details and order history while summarizing context",
            "Normalize extracted values into the required structured JSON schema",
            "Return only distance, weather, and event fields in strict schema format",
        ],
        "input_contract": {
            "vendors": "Contextual vendor information that must be ignored during summarization",
            "order_history": "Historical order data that must be ignored during summarization",
            "distance": "Distance between source and destination locations within the message",
            "weather": "Overall weather condition across the shipping route",
            "event": "Potential seasonal event or holiday affecting logistics cost or operations",
        },
        "output_contract": {
            "allowed_output_shapes": [
                {
                    "distance": "String — numeric distance value in kilometers",
                    "weather": "String — one of [sunny, cloudy, rainy, snowy, windy, foggy, stormy, thunderstorm]",
                    "event": "String — single event/holiday name or 'No Event' if none exists",
                },
                {
                    "output": {
                        "distance": "String — numeric distance value in kilometers",
                        "weather": "String — one of [sunny, cloudy, rainy, snowy, windy, foggy, stormy, thunderstorm]",
                        "event": "String — single event/holiday name or 'No Event'",
                    }
                },
            ],
            "execution_note": "Responses MAY be wrapped inside a top-level 'output' object. This is execution-safe.",
        },
        "assumptions": [
            "Input message contains contextual logistics information including distance, weather, or event data",
            "Weather must be normalized into one of the predefined categories",
            "Event should be reduced to a single relevant name or defaulted to 'No Event'",
            "Distance value should be returned as a string containing only the numeric km value",
        ],
        "forbidden_actions": [
            "Including vendor or order history data in the output",
            "Adding fields beyond distance, weather, and event (except permitted 'output' wrapper)",
            "Returning explanations, markdown, or additional text beyond the JSON schema",
            "Using weather categories outside the predefined allowed list",
        ],
    },
    {
        "agent_name": "TaskPlanner Process",
        "responsibilities": [
            "Extract structured shipment fields from Supervisor instructions",
            "Normalize shipment attributes into schema-compliant string values",
            "Preserve original user intent without modification",
            "Map shipment data into routing_memory-compatible structure",
            "Produce a single valid JSON object matching the required schema",
        ],
        "input_contract": {
            "shipment_description": "Structured instruction from Supervisor containing all mandatory shipment fields",
            "note_for_agent": "Supervisor-provided normalized shipment details",
            "state.messages": "Conversation context already validated by Supervisor",
        },
        "output_contract": {
            "output": {
                "item_name": "String",
                "weight": "Numeric string (kg per box)",
                "base_location": "Allowed warehouse base",
                "target_location": "Destination city",
                "item_type": "Fragile | Frozen | Food | Normal",
                "box_height": "Numeric string (cm)",
                "box_width": "Numeric string (cm)",
                "box_length": "Numeric string (cm)",
                "no_of_boxes": "Numeric string",
                "delivery_date": "YYYY-MM-DD string",
            }
        },
        "assumptions": [
            "Supervisor has already collected and validated mandatory fields",
            "Input contains authoritative user data that must not be altered",
            "Numeric fields must be represented strictly as numeric strings",
            "Locations are already normalized by Supervisor",
            "Agent should not infer values not explicitly provided",
        ],
        "forbidden_actions": [
            "Inferring or guessing missing shipment fields",
            "Changing or reinterpreting user-provided values",
            "Adding units or extra formatting to numeric fields",
            "Returning empty or placeholder values when valid input exists",
            "Producing explanations or text outside the JSON schema",
            "Generating planning logic, vendor selection, or routing decisions",
        ],
    },
    {
        "agent_name": "Forecast process",
        "responsibilities": [
            "Map weather conditions into numeric weather_cost using defined policy",
            "Map event descriptions into numeric event_cost using keyword rules",
            "Compute total_extra by invoking Calculate Extra Charges Tool",
            "Invoke delivery cost tool using vendor IDs and computed extra charges",
            "Invoke delivery time tool to obtain estimated delivery dates",
            "Invoke forecast confidence tool using calculated outputs",
            "Execute tool calls strictly in the required order",
            "Produce a machine-friendly forecast result JSON",
        ],
        "input_contract": {
            "vendor_id_1": "Integer vendor identifier",
            "vendor_id_2": "Integer or empty string",
            "weather": "One of allowed weather values",
            "event": "Event name or 'No Event'",
            "delivery_type": "full | partial",
            "context_memory.json": "Environmental and vendor routing context",
            "routing_memory.json": "Candidate routing combinations",
        },
        "output_contract": {
            "forecast_results": {
                "vendor_id_1": "Integer",
                "vendor_id_2": "Integer or empty string",
                "weather": "String",
                "event": "String",
                "weather_cost": "Integer [0-50]",
                "event_cost": "Integer [0-50]",
                "total_extra": "Integer",
                "estimated_cost": "Number",
                "estimated_date_1": "YYYY-MM-DD",
                "estimated_date_2": "YYYY-MM-DD or empty string",
                "confidence": "Float",
            },
            "error": "Optional short error message when tool failure occurs",
        },
        "assumptions": [
            "Weather values always belong to the allowed enumeration",
            "Event classification keywords determine cost levels",
            "Tools return deterministic outputs",
            "Vendor IDs are already validated upstream",
            "Routing combinations are precomputed before Forecast executes",
        ],
        "forbidden_actions": [
            "Skipping or reordering tool calls",
            "Inventing estimated cost, dates, or confidence values",
            "Producing analysis text outside the JSON response",
            "Using weather/event mappings outside defined policy",
            "Returning multiple JSON objects",
            "Executing tools more than once per routing combo",
        ],
    },
    {
        "agent_name": "Optimization Process",
        "responsibilities": [
            "Identify the best plan where rank_overall equals 1",
            "Generate a concise explanation (1–2 sentences) for every candidate plan",
            "Preserve all candidate ranking and scoring information semantically",
            "Produce a user-facing summary highlighting the best options",
            "Return a structured optimization output strictly matching schema",
        ],
        "input_contract": {
            "optimization_candidates": "Array of ranked routing plans",
            "forecast_results": "Forecasted delivery estimates and cost outputs",
            "context_memory.json": "Distance, weather, and event context",
        },
        "output_contract": {
            "output": {
                "agent": "Optimization",
                "best_plan_id": "String where rank_overall == 1",
                "candidates": "Array of OptimizationCandidate objects with explanations added",
                "summary_for_user": "Natural-language summary describing best options",
            }
        },
        "assumptions": [
            "Candidates already contain ranking fields such as rank_overall",
            "Utility and ranking scores are computed upstream",
            "Optimization does not calculate costs or forecasts itself",
            "Every candidate requires an explanation regardless of ranking",
        ],
        "forbidden_actions": [
            "Re-ranking candidates or recomputing utility scores",
            "Returning partial candidate arrays",
            "Producing text outside the JSON structure",
            "Skipping explanation generation for any candidate",
        ],
    },
    {
        "agent_name": "Compliance Process",
        "responsibilities": [
            "Generate a concise compliance summary for the supervisor",
            "Provide a 3–6 sentence explanation of compliance outcome",
            "Summarize plan approval or rejection context for downstream routing",
            "Return a machine-readable JSON response strictly matching schema",
        ],
        "input_contract": {
            "optimization_output": "Ranked candidate plans with compliance context",
            "forecast_results": "Delivery estimates and risk indicators",
            "context_memory.json": "Weather, distance, and event information",
        },
        "output_contract": {
            "allowed_output_shapes": [
                {"compliance_output": {"summary_for_supervisor": "Short compliance explanation (3–6 sentences)"}},
                {"output": {"summary_for_supervisor": "Short compliance explanation (3–6 sentences)"}},
            ],
            "execution_note": "Compliance responses MAY be wrapped inside a top-level 'output' object. This is execution-safe.",
        },
        "assumptions": [
            "Optimization has already ranked candidates",
            "Compliance logic or checks are performed prior to this summarization step",
            "Supervisor will use this summary to present or reconcile plans",
        ],
        "forbidden_actions": [
            "Generating vendor plans or modifying optimization rankings",
            "Producing text outside the JSON object",
            "Performing routing decisions meant for Supervisor",
        ],
    },
    {
        "agent_name": "Execute Tool Calling Process",
        "responsibilities": [
            "Fetch plan information using the provided plan_id",
            "Determine whether delivery is Full or Partial based on plan summary",
            "Save confirmed order to database and extract order_id",
            "Compose structured HTML confirmation email",
            "Call Send Mail Tool to complete fulfillment cycle",
            "Return final execution confirmation JSON",
        ],
        "input_contract": {
            "plan_id": "Non-empty string identifying selected plan",
            "useremailid": "Valid email address string",
        },
        "output_contract": {
            "status": "ok",
            "plan_id": "String",
            "order_id": "Generated order identifier",
            "useremail": "Email used for confirmation",
        },
        "assumptions": [
            "Plan information tool returns structured delivery details",
            "Order save tool returns a valid order_id",
            "Email tool accepts HTML content and completes delivery",
        ],
        "forbidden_actions": [
            "Stopping after generating email text without calling send_mail tool",
            "Skipping save_confirmed_order step",
            "Returning explanations or extra text outside JSON",
            "Modifying plan details instead of using fetched information",
        ],
    },
    {
        "agent_name": "Execute Process",
        "responsibilities": [
            "Extract PLAN_ID exactly as selected by the user from the incoming message",
            "Extract USER_EMAIL exactly as confirmed by the user",
            "Summarize the request by mapping extracted values into the required JSON schema",
            "Return only the structured JSON containing PLAN_ID and USER_EMAIL",
            "Ensure output conforms to allowed schema shapes without additional narrative text",
        ],
        "input_contract": {
            "PLAN_ID": "String representing the exact selected plan identifier from conversation context",
            "USER_EMAIL": "Confirmed user email address string extracted from message",
        },
        "output_contract": {
            "allowed_output_shapes": [
                {
                    "PLAN_ID": "String — exact plan identifier selected by the user",
                    "USER_EMAIL": "String — confirmed user email address",
                },
                {
                    "output": {
                        "PLAN_ID": "String — exact plan identifier selected by the user",
                        "USER_EMAIL": "String — confirmed user email address",
                    }
                },
            ],
            "execution_note": "The result MAY be wrapped inside a top-level 'output' field. This is execution-safe.",
        },
        "assumptions": [
            "Incoming messages contain both plan selection information and a valid email address",
            "PLAN_ID and USER_EMAIL appear explicitly in the conversation context",
            "The agent acts only as a summarizer and does not modify values",
        ],
        "forbidden_actions": [
            "Generating explanations or additional text outside the JSON schema",
            "Altering or inferring PLAN_ID or USER_EMAIL values",
            "Adding fields beyond PLAN_ID and USER_EMAIL (except permitted 'output' wrapper)",
            "Returning multiple unrelated objects or narrative content",
        ],
    },
    {
        "agent_name": "Analytics",
        "responsibilities": [
            "Answer analytical questions using database tools",
            "Select the correct analytics tool based on user intent",
            "Ask for clarification when location or query context is ambiguous",
            "Return concise summaries of retrieved analytical data",
        ],
        "input_contract": {
            "user_query": "Natural language analytical question from user",
            "conversation_context": "Prior messages used to infer missing details when possible",
        },
        "output_contract": {
            "analytics_response": "Concise natural language summary of tool results or clarification question",
        },
        "assumptions": [
            "Database tools return structured and accurate data",
            "Supervisor provides properly routed analytical queries",
            "Conversation context may contain missing parameters like location",
        ],
        "forbidden_actions": [
            "Using analytics_vendors_find for general location listing",
            "Guessing missing parameters such as city or vendor",
            "Calling incorrect tools for the question type",
            "Returning raw database outputs without summarization",
        ],
    },
]


## main code
# ============================================================
# EXCEL HEADERS — matches notebook logger HEADERS exactly
# ============================================================
SHEET_NAME_RECOVERY = "Recovery Loops"

RECOVERY_HEADERS = [
    "Query",
    # GOAL columns
    "Agent Name",
    "Agent Run ID",
    "Goal Failed",
    "Goal Reason",
    # RECOVERY columns
    "Agent Name",
    "Failed Span ID",
    "Recovery Detected",
    "Recovered Span ID",
    "Attempts Taken for Recovery",
    "Recovery Reason",
    # SCORE
    "Recovery Score"
]


# ============================================================
# GOAL PROMPT BUILDER
# ============================================================
def build_goal_eval_prompt(agent_spec: Dict, span: Dict) -> str:
    return f"""
You are performing **AGENT GOAL ACCOMPLISHMENT EVALUATION**.

ROLE:
You are an AI evaluation system that determines whether an agent
successfully fulfilled its operational responsibilities during execution.

PRIMARY OBJECTIVE:
Evaluate semantic success based strictly on:
- agent RESPONSIBILITIES
- INPUT CONTRACT
- OUTPUT CONTRACT
- ASSUMPTIONS
- FORBIDDEN_ACTIONS
- observed INPUTS and OUTPUTS

You MUST judge accomplishment relative to the agent's role.
Some agents transform data, while others perform orchestration or routing.
Evaluate ONLY what this specific agent is responsible for.


CORE EVALUATION PRINCIPLES
- Judge semantic behavior, NOT stylistic quality.
- Formatting aesthetics do NOT matter.
- HOWEVER: Output Contract discipline IS part of semantic behaviour.
- If the agent produces content outside its defined OUTPUT CONTRACT,
  this is considered an operational failure.
- Do NOT assume hidden workflow logic.
- Do NOT introduce domain knowledge.


CRITICAL EXECUTION CONTRACT RULES (STRICT)

The following are considered SEMANTIC FAILURES even if routing logic is correct:

1. Output contains reasoning text, analysis, or internal thoughts
   that are NOT part of the OUTPUT CONTRACT fields.

2. Output includes explanations before or after the structured response.

3. Agent leaks orchestration reasoning or hidden planning steps.

4. Output violates STRICT OUTPUT FORMAT instructions provided
   in the system prompt (e.g., extra text outside JSON).

5. Downstream execution would fail because OUTPUTS do not strictly
   conform to the OUTPUT CONTRACT fields.

If ANY of the above occur:
→ verdict MUST be 0.0


Transformation vs Routing Rules:

If the agent is primarily a ROUTER / ORCHESTRATOR:
- Evaluate correctness of decision-making and next-step selection.
- Evaluate adherence to workflow gating rules.
- STRICTLY verify that routing output contains ONLY allowed fields.
- Presence of reasoning leakage or extra narrative text indicates failure.

If the agent is primarily a TRANSFORMATION agent:
- Outputs must demonstrate meaningful processing or transformation.
- Placeholder outputs, copied schemas, or empty values indicate failure.


Failure Indicators:
- Output contains placeholders or empty fields where responsibilities require action.
- Output copies input structure without semantic change.
- Forbidden actions appear in OUTPUTS.
- Required routing decision missing or inconsistent with responsibilities.
- Output includes reasoning traces or content not defined in OUTPUT CONTRACT.
- Output breaks execution safety or strict response boundaries.


AGENT CONTRACT
RESPONSIBILITIES:
{json.dumps(agent_spec.get("responsibilities", []), indent=2)}

INPUT CONTRACT:
{json.dumps(agent_spec.get("input_contract", {}), indent=2)}

OUTPUT CONTRACT:
{json.dumps(agent_spec.get("output_contract", {}), indent=2)}

ASSUMPTIONS:
{json.dumps(agent_spec.get("assumptions", []), indent=2)}

FORBIDDEN_ACTIONS:
{json.dumps(agent_spec.get("forbidden_actions", []), indent=2)}


ACTUAL EXECUTION
INPUTS:
{json.dumps(span["inputs"], indent=2)}

OUTPUTS:
{json.dumps(span["outputs"], indent=2)}


EVALUATION FRAMEWORK
STEP 1: Infer the agent's operational role from RESPONSIBILITIES.
STEP 2: Check whether OUTPUTS satisfy OUTPUT CONTRACT fields.
STEP 3: Validate EXECUTION CONTRACT discipline.
STEP 4: Evaluate responsibility fulfillment.
STEP 5: Check FORBIDDEN_ACTIONS. If violated → verdict MUST be 0.0.
STEP 6: Assess accomplishment level:
  1.0 → Full accomplishment
  0.5 → Partial accomplishment
  0.0 → Failure or execution contract violated
STEP 7: Set goal_failed:
  true if verdict < 1.0
  false only if full accomplishment is achieved.


FEW SHOT EXAMPLES

Example SUCCESS — Routing Agent:
Responsibilities: ["Route to next agent"]
Output: {{"next":"ContextBuilder","reason":"All fields confirmed"}}
Return: {{"verdict":1.0,"goal_failed":false,"reason":"Agent performed correct routing."}}

Example FAILURE — Execution Contract Violation:
Output: "We need to analyze the workflow first..." {{"next":"TaskPlanner"}}
Return: {{"verdict":0.0,"goal_failed":true,"reason":"Agent leaked internal reasoning outside OUTPUT CONTRACT."}}

Example FAILURE — Placeholder Output:
Output: {{"item_name":"","weight":""}}
Return: {{"verdict":0.0,"goal_failed":true,"reason":"Agent returned empty placeholders instead of transforming data."}}

Example PARTIAL:
Return: {{"verdict":0.5,"goal_failed":true,"reason":"Agent partially fulfilled routing but output contract was incomplete."}}


OUTPUT FORMAT
Return ONLY JSON:

{{
  "verdict": number,
  "goal_failed": boolean,
  "reason": "2-3 line operational reasoning referencing responsibilities"
}}
""".strip()


# ============================================================
# GOAL EVALUATION PER SPAN
# ============================================================
def evaluate_span(span: Dict, llm: AzureChatOpenAI) -> Dict:
    """Evaluate goal accomplishment for a single agent span."""
    agent_spec = next(
        (spec for spec in AGENT_SPECS if spec["agent_name"] == span["agent_name"]),
        None,
    )

    if not agent_spec:
        return None

    try:
        prompt     = build_goal_eval_prompt(agent_spec, span)
        response = llm.invoke(prompt)
        tokens = count_tokens(response.content)
        track_tokens_used(tokens, eval_name="recovery_loop")
        evaluation = json.loads(response.content)

        return {
            "agent_name":  span["agent_name"],
            "run_id":      span["run_id"],
            "goal_failed": evaluation["goal_failed"],
            "reason":      evaluation["reason"],
        }

    except Exception as e:
        print(f"  [WARN] Goal eval failed for {span['agent_name']}: {e}")
        return None


# ============================================================
# RECOVERY LOOP SCORING
# ============================================================
def compute_recovery_loop_score(recovery_loops: List[Dict]) -> Dict[str, Any]:
    """Score recovery loops: Pass only if all failed agents recovered."""
    if not recovery_loops:
        return {
            "numeric_score": 1.0,
            "reason": "No recovery loops detected."
        }

    for loop in recovery_loops:
        if not loop.get("recovery_detected", False):
            return {
                "numeric_score": 0.0,
                "reason": "At least one failed agent did not recover."
            }

    return {
        "numeric_score": 1.0,
        "reason": "All failed agents recovered successfully."
    }


# ============================================================
# MAIN EVALUATION PIPELINE
# ============================================================
def run_recovery_loop_eval(
    trace_id: str,
    scenario: str,
    llm_client: AzureChatOpenAI,
) -> Dict[str, Any]:
    """
    Full recovery loop evaluation pipeline.

    Args:
        trace_id:   LangSmith trace ID
        scenario:   Query/scenario text
        llm_client: Azure OpenAI client (temperature=1)

    Returns:
        Evaluation result dictionary compatible with main.py
    """
    try:
        langsmith_client = Client(api_key=os.environ["LANGSMITH_API_KEY"])

        spans      = list(langsmith_client.list_runs(trace_id=trace_id))
        spans      = sorted(spans, key=lambda s: s.start_time or 0)
        run_lookup = {}

        execution_trace = []

        for s in spans:
            run_id    = str(s.id)
            parent_id = str(s.parent_run_id) if s.parent_run_id else None
            run_type  = getattr(s, "run_type", None)

            run_lookup[run_id] = {
                "name":     s.name,
                "inputs":   s.inputs  or {},
                "outputs":  s.outputs or {},
                "parent":   parent_id,
                "run_type": run_type,
            }

            if run_type == "chain":
                execution_trace.append({
                    "agent_name": s.name,
                    "run_id":     run_id,
                    "inputs":     s.inputs  or {},
                    "outputs":    s.outputs or {},
                })

        goal_eval_results = []

        with ThreadPoolExecutor(max_workers=6) as executor:
            futures = {
                executor.submit(evaluate_span, span, llm_client): span
                for span in execution_trace
            }
            for f in as_completed(futures):
                result = f.result()
                if result:
                    goal_eval_results.append(result)

        span_order_index = {str(s.id): i for i, s in enumerate(spans)}

        failed_agents = sorted(
            [r for r in goal_eval_results if r["goal_failed"]],
            key=lambda x: span_order_index.get(x["run_id"], 999999),
        )

        goal_lookup              = {r["run_id"]: r for r in goal_eval_results}
        processed_failure_groups = set()
        recovery_loops           = []

        for fail in failed_agents:
            failed_span_id    = fail["run_id"]
            failed_agent_name = fail["agent_name"]
            immediate_parent  = run_lookup.get(failed_span_id, {}).get("parent")

            if not immediate_parent:
                continue

            group_key = (immediate_parent, failed_agent_name)
            if group_key in processed_failure_groups:
                continue
            processed_failure_groups.add(group_key)

            siblings = sorted(
                [
                    {"run_id": rid, "agent_name": data["name"]}
                    for rid, data in run_lookup.items()
                    if data.get("parent") == immediate_parent
                    and data["name"] == failed_agent_name
                ],
                key=lambda x: span_order_index.get(x["run_id"], 999999),
            )

            failure_index = None
            success_index = None

            for idx, sib in enumerate(siblings):
                rid     = sib["run_id"]
                verdict = goal_lookup.get(rid)

                if not verdict:
                    continue

                if rid == failed_span_id:
                    failure_index = idx
                elif failure_index is not None and not verdict["goal_failed"]:
                    success_index = idx
                    break

            if failure_index is not None and success_index is not None:
                # Build recovery_reason from goal results
                attempt_reasons = []
                for idx in range(failure_index, success_index + 1):
                    attempt_run_id = siblings[idx]["run_id"]
                    goal_info = goal_lookup.get(attempt_run_id, {})
                    reason = goal_info.get("reason", "")
                    status = "failed" if goal_info.get("goal_failed") else "succeeded"
                    if reason:
                        attempt_reasons.append(f"Attempt {idx - failure_index + 1} {status}: {reason}")
                    else:
                        attempt_reasons.append(f"Attempt {idx - failure_index + 1} {status}")
                
                recovery_reason = " → ".join(attempt_reasons) if attempt_reasons else ""
                
                recovery_loops.append({
                    "agent_name":              failed_agent_name,
                    "parent_agent":            run_lookup[immediate_parent]["name"],
                    "failed_span_id":          failed_span_id,
                    "recovered_span_id":       siblings[success_index]["run_id"],
                    "recovery_detected":       True,
                    "attempts_until_recovery": success_index - failure_index + 1,
                    "recovery_reason":         recovery_reason,
                })
            else:
                # Build reason for all attempts even when no recovery occurred
                attempt_reasons = []
                start = failure_index if failure_index is not None else 0
                for idx in range(start, len(siblings)):
                    attempt_run_id = siblings[idx]["run_id"]
                    goal_info = goal_lookup.get(attempt_run_id, {})
                    reason = goal_info.get("reason", "")
                    status = "failed" if goal_info.get("goal_failed", True) else "succeeded"
                    if reason:
                        attempt_reasons.append(f"Attempt {idx - start + 1} {status}: {reason}")
                    else:
                        attempt_reasons.append(f"Attempt {idx - start + 1} {status}")

                no_recovery_reason = " → ".join(attempt_reasons) if attempt_reasons else ""

                recovery_loops.append({
                    "agent_name":              failed_agent_name,
                    "parent_agent":            run_lookup.get(immediate_parent, {}).get("name", ""),
                    "failed_span_id":          failed_span_id,
                    "recovered_span_id":       "N/A",
                    "recovery_detected":       False,
                    "attempts_until_recovery": 0,
                    "recovery_reason":         no_recovery_reason,
                })

        recovery_metric = compute_recovery_loop_score(recovery_loops)

        return {
            "eval_name":  "recovery_loop_eval",
            "eval_type":  "hybrid",
            "trace_id":   trace_id,
            "scenario":   scenario,
            "status":     "success",
            "error":      None,
            "eval_inputs": {
                "total_agents_evaluated": len(goal_eval_results),
            },
            "eval_output": {
                "goal_eval_results": goal_eval_results,
                "recovery_loops":    recovery_loops,
                "recovery_score":    recovery_metric["numeric_score"],
                "reason":            recovery_metric["reason"],
            },
            "metadata": {
                "model":       "gpt-5",
                "temperature": 1,
                "timestamp":   datetime.utcnow().isoformat(),
            },
        }

    except Exception as e:
        return {
            "eval_name":  "recovery_loop_eval",
            "eval_type":  "hybrid",
            "trace_id":   trace_id,
            "scenario":   scenario,
            "status":     "failed",
            "error":      str(e),
            "eval_inputs":  {},
            "eval_output":  {},
            "metadata": {
                "model":     "gpt-5",
                "timestamp": datetime.utcnow().isoformat(),
            },
        }


# ============================================================
# EXCEL DUMP — aligned with notebook logger
# ============================================================

# ============================================================
# WORKBOOK HELPERS
# ============================================================
def get_or_create_workbook(path: str):
    if Path(path).exists():
        return load_workbook(path)

    wb = Workbook()
    wb.remove(wb.active)
    return wb


def get_or_create_sheet(wb, name):
    if name in wb.sheetnames:
        return wb[name]

    sheet = wb.create_sheet(name)
    sheet.append(RECOVERY_HEADERS)
    return sheet


def safe(v):
    return "" if v is None else v


# ============================================================
# MAIN LOGGER
# ============================================================
def dump_recovery_loop_eval_to_excel(
    *,
    trace_id: str,
    query: str,
    eval_result: dict,
    excel_path: str = "final_eval_results.xlsx",
):

    wb = get_or_create_workbook(excel_path)
    sheet = get_or_create_sheet(wb, SHEET_NAME_RECOVERY)

    eval_output = eval_result.get("eval_output", {})

    goal_results = eval_output.get("goal_eval_results", [])
    recovery_loops = eval_output.get("recovery_loops", [])

    # ✅ Use numeric_score from eval — ALWAYS available
    numeric_score = eval_output.get("recovery_score")

    max_len = max(len(goal_results), len(recovery_loops), 1)

    for i in range(max_len):

        goal = goal_results[i] if i < len(goal_results) else {}
        recovery = recovery_loops[i] if i < len(recovery_loops) else {}

        # ✅ FIXED: Always use numeric_score for ALL rows, not just when recovery exists
        row_score = numeric_score

        sheet.append([
            safe(query),

            # ---------------- GOAL ----------------
            safe(goal.get("agent_name")),
            safe(goal.get("run_id")),
            safe(goal.get("goal_failed")),
            safe(goal.get("reason")),

            # ---------------- RECOVERY ----------------
            safe(recovery.get("agent_name")),
            safe(recovery.get("failed_span_id")),
            safe(recovery.get("recovery_detected")),
            safe(recovery.get("recovered_span_id")),
            safe(recovery.get("attempts_until_recovery")),
            safe(recovery.get("recovery_reason")),   # ✅ NOW INCLUDED

            # ---------------- SCORE ----------------
            safe(row_score),
        ])

    wb.save(excel_path)
