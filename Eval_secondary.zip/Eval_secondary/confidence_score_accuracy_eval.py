"""
Confidence Score Accuracy Evaluation Module
============================================

Purpose:
  Verify whether confidence scores produced by the system are mathematically correct
  by recomputing them according to the authoritative calculation logic.

Evaluation Logic:
  1. Extract confidence calculation inputs from forecast confidence spans
  2. Recompute confidence using deterministic formula
  3. Compare computed vs actual confidence (±0.01 tolerance)
  4. Per-span: PASS/FAIL with score (1.0/0.0)
  5. Overall: score = passed / total

Span Target:
  "Calculate Forecast Confidence Tool"

Temperature Strategy:
  temperature=0 (deterministic, pure verification)
"""

import json
import ast
from uuid import UUID
from datetime import datetime
from langsmith import Client
from langchain_openai import AzureChatOpenAI


# ============================================================
# UUID SERIALIZER FOR JSON
# ============================================================

def uuid_serializer(obj):
    """Convert UUID objects to strings for JSON serialization."""
    if isinstance(obj, UUID):
        return str(obj)
    raise TypeError(f"Object of type {obj.__class__.__name__} is not JSON serializable")


# ============================================================
# JSON SAFE PARSER
# ============================================================

def safe_json_load(raw: str):
    """
    Parse JSON from raw LLM output with markdown cleanup.
    
    Handles:
    - Markdown code blocks (```json ... ```)
    - Nested JSON extraction
    """
    raw = raw.strip()
    if raw.startswith("```"):
        raw = raw.strip("`").strip()
        if raw.lower().startswith("json"):
            raw = raw[4:].strip()

    start, end = raw.find("{"), raw.rfind("}")
    if start == -1 or end == -1:
        raise ValueError(f"Non-JSON output:\n{raw}")

    return json.loads(raw[start:end + 1])


# ============================================================
# CONFIDENCE CALCULATION LOGIC (AUTHORITATIVE)
# ============================================================

def compute_confidence(
    extra_charges,
    total_estimated_cost,
    estimated_date_1,
    estimated_date_2,
    delivery_date,
):
    """
    Recompute confidence score using the authoritative formula.
    
    Formula:
      delay(d) = max((date(d) - date(delivery_date)).days, 0) or 0 if empty
      extra_risk = min(float(extra_charges) / 100, 1)
      cost_risk = min(float(total_estimated_cost) / 10000, 1)
      delay_risk = min((delay(date_1) + delay(date_2)) / 20, 1)
      multi_risk = 0.3 if date_2 present else 0
      confidence = 1 - (0.25*extra_risk + 0.25*cost_risk + 0.35*delay_risk + 0.15*multi_risk)
      final = round(clamp(confidence, 0, 1), 2)
    """
    try:
        # Parse delivery date
        from datetime import datetime as dt
        delivery_dt = dt.strptime(delivery_date, "%Y-%m-%d")

        # Compute delay for date fields
        def delay(date_str):
            if not date_str or date_str == "":
                return 0
            try:
                date_dt = dt.strptime(date_str, "%Y-%m-%d")
                return max((date_dt - delivery_dt).days, 0)
            except Exception:
                return 0

        # Compute risk components
        delay_1 = delay(estimated_date_1)
        delay_2 = delay(estimated_date_2)

        extra_risk = min(float(extra_charges or 0) / 100, 1)
        cost_risk = min(float(total_estimated_cost or 0) / 10000, 1)
        delay_risk = min((delay_1 + delay_2) / 20, 1)
        multi_risk = 0.3 if (estimated_date_2 and estimated_date_2.strip()) else 0

        # Compute confidence
        confidence = 1 - (
            0.25 * extra_risk +
            0.25 * cost_risk +
            0.35 * delay_risk +
            0.15 * multi_risk
        )

        # Clamp and round
        final_confidence = round(max(0, min(1, confidence)), 2)
        
        return final_confidence

    except Exception as e:
        # On error, return None (cannot verify)
        return None


# ============================================================
# VERIFICATION PROMPT (AUTHORITATIVE CONTRACT)
# ============================================================

CONFIDENCE_SCORE_ACCURACY_PROMPT = """You are an evaluation agent.
Your task is to verify whether a given confidence score is mathematically correct.

You are provided with:
1. Input fields used to compute confidence
2. The confidence score produced by the system

You MUST:
- Recompute the confidence score strictly using the logic below
- Compare your computed value with the provided confidence
- Decide whether the confidence is correct

DO NOT estimate, approximate, or use intuition.
ONLY validate mathematical correctness.
--------------------------------------------------
CONFIDENCE CALCULATION LOGIC (AUTHORITATIVE)
--------------------------------------------------
delay(d):
- If d is empty, null, or missing → return 0
- Else:
    max( (date(d) - date(delivery_date)).days , 0 )
extra_risk:
    min( float(extra_charges) / 100 , 1 )
cost_risk:
    min( float(total_estimated_cost) / 10000 , 1 )
delay_risk:
    min( ( delay(estimated_date_1) + delay(estimated_date_2) ) / 20 , 1 )
multi_risk:
    0.3 if estimated_date_2 is present and non-empty
    else 0
confidence:
    1 - (
        0.25 * extra_risk +
        0.25 * cost_risk +
        0.35 * delay_risk +
        0.15 * multi_risk
    )
Final confidence:
    round( clamp(confidence, 0, 1), 2 )
--------------------------------------------------
EVALUATION RULES
--------------------------------------------------
1. Recalculate the confidence score exactly.
2. Compare it to the provided confidence.
3. Allow a tolerance of ±0.01 due to rounding.
4. If within tolerance → PASS
5. Otherwise → FAIL
--------------------------------------------------
SCORING RULE
--------------------------------------------------
- PASS → score = 1.0
- FAIL → score = 0.0
--------------------------------------------------
OUTPUT FORMAT (STRICT JSON ONLY)
--------------------------------------------------
{
  "per_span_results": [
    {
      "span_id": "<string>",
      "expected_confidence": <number>,
      "actual_confidence": <number>,
      "difference": <number>,
      "result": "PASS" | "FAIL",
      "score": <number>,
      "reason": "matches calculation | short explanation"
    }
  ]
}
--------------------------------------------------
INPUT DATA
--------------------------------------------------
{input_json}
delivery_date: {delivery_date}
"""


# ============================================================
# OVERALL REASON PROMPT
# ============================================================

OVERALL_REASON_PROMPT = """You are an evaluation summarizer.

Given aggregate confidence score validation results, explain the overall outcome.

Rules:
- Do NOT compute or suggest numeric scores
- Do NOT change PASS/FAIL result
- Only explain why the overall result is PASS or FAIL
- Be concise and factual

Return ONLY this JSON:
{
  "overall_reason": "<short explanation>"
}
"""


# ============================================================
# MAIN EVALUATION FUNCTION
# ============================================================

def run_confidence_score_accuracy_eval(trace_id, scenario, llm_client):
    """
    Evaluate confidence score accuracy for a trace.
    
    Args:
        trace_id: LangSmith trace ID
        scenario: Scenario context/query description
        llm_client: Azure OpenAI client (temperature=0)
    
    Returns:
        dict with keys:
        - status: "completed" | "failed"
        - error: error message if failed
        - trace_id, scenario, overall_result, overall_score, overall_reason
        - per_span_results: list of per-span evaluation dicts
        - (all ready for Excel dump)
    """
    try:
        client = Client()

        # Fetch spans for this trace
        all_spans = list(client.list_runs(trace_id=trace_id))
        forecast_spans = [
            span for span in all_spans
            if span.name and "Calculate Forecast Confidence Tool" in span.name
        ]

        if not forecast_spans:
            return {
                "status": "failed",
                "error": "No 'Calculate Forecast Confidence Tool' spans found",
                "trace_id": trace_id,
                "scenario": scenario,
            }

        # Extract input/output records
        records = []
        for span in forecast_spans:
            raw_input = span.inputs.get("input", "{}")

            try:
                input_data = ast.literal_eval(raw_input)
                if not isinstance(input_data, dict):
                    input_data = {}
            except Exception:
                input_data = {}

            confidence = None
            try:
                content = span.outputs["output"]["content"]
                confidence = json.loads(content).get("confidence")
            except Exception:
                pass

            records.append({
                "span_id": span.id,
                "confidence": confidence,
                **input_data
            })

        if not records:
            return {
                "status": "failed",
                "error": "No valid input/output records extracted",
                "trace_id": trace_id,
                "scenario": scenario,
            }

        # Extract delivery_date from first record (external constant)
        delivery_date = records[0].get("delivery_date", "2026-10-01")

        # Verify each span's confidence
        per_span_results = []

        for r in records:
            # Compute expected confidence using authoritative formula
            expected_confidence = compute_confidence(
                extra_charges=r.get("extra_charges"),
                total_estimated_cost=r.get("total_estimated_cost"),
                estimated_date_1=r.get("estimated_date_1"),
                estimated_date_2=r.get("estimated_date_2"),
                delivery_date=delivery_date,
            )

            actual_confidence = r.get("confidence")

            # Determine PASS/FAIL (tolerance ±0.01)
            if expected_confidence is not None and actual_confidence is not None:
                difference = abs(expected_confidence - actual_confidence)
                within_tolerance = difference <= 0.01
                result = "PASS" if within_tolerance else "FAIL"
                score = 1.0 if within_tolerance else 0.0
                reason = (
                    f"Expected {expected_confidence}, got {actual_confidence}"
                    if within_tolerance
                    else f"Expected {expected_confidence}, got {actual_confidence} (diff={difference:.4f})"
                )
            else:
                result = "FAIL"
                score = 0.0
                difference = None
                reason = "Could not compute expected confidence"

            per_span_results.append({
                "span_id": str(r.get("span_id")),
                "expected_confidence": expected_confidence,
                "actual_confidence": actual_confidence,
                "difference": difference,
                "result": result,
                "score": score,
                "reason": reason,
            })

        # Aggregate results
        total = len(per_span_results)
        passed = sum(1 for r in per_span_results if r["result"] == "PASS")
        failed = total - passed

        overall_score = round(
            sum(r["score"] for r in per_span_results) / total, 2
        ) if total > 0 else 0.0

        overall_result = "PASS" if failed == 0 else "FAIL"

        # Generate overall reason via LLM
        def generate_overall_reason_llm(total, passed, failed, overall_result, per_span_results):
            payload = {
                "total_spans": total,
                "passed": passed,
                "failed": failed,
                "overall_result": overall_result,
                "per_span_results": [
                    {
                        "span_id": str(r["span_id"]),
                        "result": r["result"],
                        "difference": r["difference"]
                    }
                    for r in per_span_results
                ]
            }

            try:
                response = llm_client.invoke([
                    ("system", OVERALL_REASON_PROMPT),
                    ("human", json.dumps(payload, indent=2))
                ])

                parsed = safe_json_load(response.content)
                return parsed.get("overall_reason", "")
            except Exception:
                return ""

        overall_reason = generate_overall_reason_llm(
            total=total,
            passed=passed,
            failed=failed,
            overall_result=overall_result,
            per_span_results=per_span_results
        )

        return {
            "status": "completed",
            "trace_id": trace_id,
            "scenario": scenario,
            "overall_result": overall_result,
            "overall_score": overall_score,
            "overall_reason": overall_reason,
            "per_span_results": per_span_results,
            "total_spans": total,
            "passed": passed,
            "failed": failed,
            "model": "gpt-5",
            "temperature": 0,
            "timestamp": datetime.utcnow().isoformat(),
        }

    except Exception as e:
        return {
            "status": "failed",
            "error": str(e),
            "trace_id": trace_id,
            "scenario": scenario,
        }


# ============================================================
# EXCEL DUMP FUNCTION
# ============================================================

def dump_confidence_score_accuracy_to_excel(eval_result, output_excel, utils):
    """
    Dump confidence score accuracy evaluation to Excel sheet.
    
    Args:
        eval_result: dict from run_confidence_score_accuracy_eval()
        output_excel: path to Excel file
        utils: utils module with get_or_create_workbook, get_or_create_sheet
    """
    try:
        sheet_name = "Confidence Score Accuracy"

        wb = utils.get_or_create_workbook(output_excel)
        sheet = utils.get_or_create_sheet(
            wb,
            sheet_name,
            headers=[
                "Trace_ID",
                "Query",
                "Expected_Confidence",
                "Actual_Confidence",
                "Difference",
                "Result",
                "Reason",
                "Overall_Score",
                "Overall_Result",
                "Overall_Reason",
                "Traceback",
                "Status",
                "Timestamp",
            ]
        )

        trace_id = eval_result.get("trace_id")
        scenario = eval_result.get("scenario")
        status = eval_result.get("status")
        error = eval_result.get("error", "")

        per_span_results = eval_result.get("per_span_results", [])

        if status == "failed":
            sheet.append([
                trace_id,
                scenario,
                "",
                "",
                "",
                "",
                "",
                "",
                "",
                "",
                "",
                "",
                "",
                "",
                "",
                "",
                "",
                "",
                status,
                error,
            ])
        else:
            overall_result = eval_result.get("overall_result")
            overall_score = eval_result.get("overall_score")
            overall_reason = eval_result.get("overall_reason")
            total_spans = eval_result.get("total_spans")
            passed = eval_result.get("passed")
            failed = eval_result.get("failed")
            model = eval_result.get("model")
            temperature = eval_result.get("temperature")
            timestamp = eval_result.get("timestamp")

            # Full per-span results as JSON for traceability
            traceback_json = json.dumps(
                per_span_results,
                ensure_ascii=False,
                default=str
            )

            for span in per_span_results:
                sheet.append([
                    trace_id,
                    scenario,
                    str(span.get("span_id")),
                    span.get("expected_confidence"),
                    span.get("actual_confidence"),
                    span.get("difference"),
                    span.get("result"),
                    span.get("score"),
                    span.get("reason"),
                    overall_result,
                    overall_score,
                    overall_reason,
                    total_spans,
                    passed,
                    failed,
                    model,
                    temperature,
                    timestamp,
                    status,
                    error,
                ])

        wb.save(output_excel)

    except Exception as e:
        print(f"❌ Error dumping Confidence Score Accuracy to Excel: {e}")
