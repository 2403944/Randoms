import plotly.graph_objects as go
import plotly.offline as plot
import plotly.express as px
import pandas as pd
import json
import sys
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional, Union, Any
from flask import Flask, request, Response
import tempfile
import os
import re
import unicodedata
import difflib

try:
    from loguru import logger
except ImportError:
    import logging
    logger = logging.getLogger(__name__)


class ReportGenerator:
    """
    Professional GenAI Model Monitoring Report Generator
    """

    def __init__(self, config: Optional[Dict] = None):
        logger.info('Initializing ReportGenerator')
        self.config = config or self._get_default_config()
        self.report_timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        self.metric_details_excel_path = Path(__file__).resolve().parent / "final_eval_results01.xlsx"

    def _get_default_config(self) -> Dict[str, Any]:
        return {
            'title': 'GenAI Model Monitoring Report',
            'subtitle': 'LLM-as-a-Judge Assurance Pipeline',
            'description': 'Advanced monitoring pipeline that evaluates GenAI model outputs against predefined criteria, ensuring quality, safety, and alignment with project requirements.',
            'theme': {
                'primary_color': '#2E86AB',
                'secondary_color': '#A23B72',
                'accent_color': '#F18F01',
                'success_color': '#28a745',
                'danger_color': '#dc3545',
                'warning_color': '#ffc107',
                'info_color': '#17a2b8',
                'light_bg': '#f8f9fa',
                'dark_bg': '#343a40',
                'border_color': '#dee2e6',
                'font_family': "'Segoe UI', Tahoma, Geneva, Verdana, sans-serif"
            },
            'status_colors': {
                'Passed': '#28a745',
                'Failed': '#dc3545',
                'Skipped': '#6c757d',
                'passed': '#28a745',
                'failed': '#dc3545',
                'skipped': '#6c757d'
            },
            'reverse_metrics': ['Hallucination CoVe'],
            'chart_height': 450
        }

    def _highlight_diff(self, base, augmented):
        if pd.isna(base) or pd.isna(augmented):
            return augmented
        base_words = str(base).split()
        aug_words  = str(augmented).split()
        diff = list(difflib.ndiff(base_words, aug_words))
        tokens = []
        for token in diff:
            if token.startswith("+ "):
                tokens.append((token[2:], True))
            elif token.startswith("  "):
                tokens.append((token[2:], False))
        result = []
        i = 0
        while i < len(tokens):
            word, is_added = tokens[i]
            if is_added:
                group = []
                while i < len(tokens) and tokens[i][1]:
                    group.append(tokens[i][0])
                    i += 1
                result.append(f"<span class='diff-added'>{' '.join(group)}</span>")
            else:
                result.append(word)
                i += 1
        return " ".join(result)

    def _normalize_query_match(self, text: str) -> str:
        if not text:
            return ""
        text = str(text)
        text = unicodedata.normalize("NFKD", text)
        text = text.lower()
        text = re.sub(r"[^\w\s]", "", text)
        text = re.sub(r"\s+", " ", text).strip()
        return text

    def _normalize_text(self, text: Any) -> str:
        if text is None:
            return ""
        text = str(text)
        text = unicodedata.normalize("NFKD", text)
        text = text.lower()
        text = re.sub(r"[^\w\s]", "", text)
        text = re.sub(r"\s+", " ", text).strip()
        return text

    def _text_equal(self, a: Any, b: Any) -> bool:
        return self._normalize_text(a) == self._normalize_text(b)

    # ==================== UTILITY METHODS ====================

    def _find_column(self, df: pd.DataFrame, possible_names: List[str]) -> Optional[str]:
        try:
            for name in possible_names:
                if name in df.columns:
                    return name
            return df.columns[0] if len(df.columns) > 0 else None
        except Exception as e:
            logger.error(f"Error finding column: {e}")
            return None

    def _safe_numeric_conversion(self, value: Any) -> float:
        try:
            return pd.to_numeric(value, errors='coerce')
        except:
            return float('nan')

    def _format_percentage(self, value: float, total: float) -> str:
        if total == 0:
            return "0%"
        return f"{(value/total)*100:.1f}%"

    def _truncate_text(self, text: str, max_length: int = 100) -> str:
        text = str(text).strip()
        if len(text) <= max_length:
            return text
        return text[:max_length-3] + "..."

    # ==================== STATUS CALCULATION ====================

    def _calculate_status(self, df: pd.DataFrame, metrics: List[str], thresholds: Dict[str, float]) -> pd.DataFrame:
        try:
            df_copy = df.copy()
            for metric in metrics:
                if metric not in df_copy.columns:
                    continue
                status_col = f"{metric}_status"
                reason_col = f"{metric}-reason"
                threshold = thresholds.get(metric)
                if threshold is None:
                    df_copy[status_col] = "Unknown"
                    continue
                if reason_col in df_copy.columns:
                    df_copy[status_col] = df_copy.apply(
                        lambda row: self._determine_status_with_reason(row, metric, reason_col, threshold), axis=1
                    )
                else:
                    df_copy[status_col] = df_copy[metric].apply(
                        lambda x: self._determine_status_simple(x, metric, threshold)
                    )
            return df_copy
        except Exception as e:
            logger.error(f"Error calculating status: {e}")
            return df

    def _determine_status_with_reason(self, row: pd.Series, metric: str, reason_col: str, threshold: float) -> str:
        reason = str(row.get(reason_col, "")).strip().upper()
        if reason == "NA":
            return "Skipped"
        score = self._safe_numeric_conversion(row[metric])
        if pd.isna(score):
            return "Failed"
        if metric in self.config['reverse_metrics']:
            return "Passed" if score <= threshold else "Failed"
        else:
            return "Passed" if score >= threshold else "Failed"

    def _determine_status_simple(self, value: Any, metric: str, threshold: float) -> str:
        score = self._safe_numeric_conversion(value)
        if pd.isna(score):
            return "Failed"
        if metric in self.config['reverse_metrics']:
            return "Passed" if score <= threshold else "Failed"
        else:
            return "Passed" if score >= threshold else "Failed"

    # ==================== CHART GENERATION ====================

    def _create_modern_charts(self, summary_df: pd.DataFrame, overall_df: pd.DataFrame,
                               metrics_df: pd.DataFrame, metrics_col: str, score_col: str,
                               threshold_col: str) -> Dict[str, str]:
        try:
            charts = {}
            theme = self.config['theme']
            charts['metrics']      = self._create_metrics_bar_chart(summary_df, theme)
            charts['overall']      = self._create_overall_pie_chart(overall_df, theme)
            charts['comparison']   = self._create_score_comparison_chart(metrics_df, metrics_col, score_col, threshold_col, theme)
            base_dir = Path(__file__).resolve().parent
            charts['coverage']     = self._create_test_coverage_sunburst(excel_path=base_dir / "Metrics_template02.xlsx", sheet_name='Test data coverage')
            charts['augmentation'] = self._generate_augmented_data_table(excel_path=base_dir / "agent_query_augmentations.xlsx", sheet_name='Sheet1')
            charts['disaggregated']= self._create_disaggregated_table(base_dir / "Metrics_template02.xlsx")
            return charts
        except Exception as e:
            logger.error(f"Error creating charts: {e}")
            return {}

    def _create_metrics_bar_chart(self, summary_df: pd.DataFrame, theme: Dict) -> str:
        try:
            metrics_col = self._find_column(summary_df, ['Metrics', 'Metric'])
            passed_col  = self._find_column(summary_df, ["Passed"])
            failed_col  = self._find_column(summary_df, ["Failed"])
            metrics = summary_df[metrics_col].astype(str).tolist()
            failed  = summary_df[failed_col].fillna(0).tolist()
            passed  = summary_df[passed_col].fillna(0).tolist()
            fig = go.Figure()
            fig.add_bar(x=metrics, y=failed, name='Failed', marker_color=self.config['status_colors']['Failed'])
            fig.add_bar(x=metrics, y=passed, name='Passed', marker_color=self.config['status_colors']['Passed'])
            fig.update_layout(
                barmode='group', title='Metrics Performance Overview',
                xaxis_title='Metrics', yaxis_title='Number of Test Cases',
                bargap=0.25, bargroupgap=0.05, width=len(metrics) * 140,
                legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="center", x=0.5),
                **self._get_chart_layout(theme)
            )
            fig.update_yaxes(autorange=True)
            return plot.plot(fig, output_type='div', include_plotlyjs=False)
        except Exception as e:
            logger.error(f"Error creating metrics bar chart: {e}")
            return f"<div>Error creating metrics chart: {e}</div>"

    def _create_overall_pie_chart(self, overall_df: pd.DataFrame, theme: Dict) -> str:
        try:
            passed = int(overall_df[[c for c in overall_df.columns if 'passed' in c.lower()][0]].sum())
            failed = int(overall_df[[c for c in overall_df.columns if 'failed' in c.lower()][0]].sum())
            labels, values, colors = [], [], []
            if passed > 0:
                labels.append(f"Passed ({passed})"); values.append(passed); colors.append(self.config['status_colors']['passed'])
            if failed > 0:
                labels.append(f"Failed ({failed})"); values.append(failed); colors.append(self.config['status_colors']['failed'])
            total = sum(values)
            fig = go.Figure(data=[go.Pie(labels=labels, values=values, hole=0.4,
                marker=dict(colors=colors), textinfo="label+percent", hoverinfo="label+percent+value")])
            fig.update_layout(title="Overall Performance Distribution", **self._get_chart_layout(theme),
                annotations=[dict(text=f"Total<br>{total}", x=0.5, y=0.5, font_size=16, showarrow=False)])
            return plot.plot(fig, output_type='div', include_plotlyjs=False)
        except Exception as e:
            logger.error(f"Error creating overall pie chart: {e}")
            return f"<div>Error creating overall chart: {e}</div>"

    def _create_score_comparison_chart(self, metrics_df: pd.DataFrame, metrics_col: str,
                                        score_col: str, threshold_col: str, theme: Dict) -> str:
        try:
            metrics    = metrics_df[metrics_col].tolist()
            scores     = [self._safe_numeric_conversion(x) for x in metrics_df[score_col].tolist()]
            thresholds = [self._safe_numeric_conversion(x) for x in metrics_df[threshold_col].tolist()]
            bar_colors = []
            for score, threshold, metric in zip(scores, thresholds, metrics):
                if pd.isna(score) or pd.isna(threshold):
                    bar_colors.append(theme['border_color']); continue
                if metric in self.config['reverse_metrics']:
                    color = self.config['status_colors']['passed'] if score <= threshold else self.config['status_colors']['failed']
                else:
                    color = self.config['status_colors']['passed'] if score >= threshold else self.config['status_colors']['failed']
                bar_colors.append(color)
            fig = go.Figure()
            fig.add_trace(go.Bar(x=metrics, y=scores, name='Actual Score', marker_color=bar_colors,
                hovertemplate="<b>%{x}</b><br>Score: %{y:.3f}<extra></extra>", opacity=0.8))
            fig.add_trace(go.Scatter(x=metrics, y=thresholds, mode='lines+markers', name='Threshold',
                line=dict(color=theme['accent_color'], width=3, dash='dash'),
                marker=dict(size=8, color=theme['accent_color']),
                hovertemplate="<b>%{x}</b><br>Threshold: %{y:.3f}<extra></extra>"))
            fig.update_layout(**self._get_chart_layout(theme), title="Score vs Threshold Comparison",
                xaxis_title="Metrics", yaxis_title="Score", bargap=0.25, bargroupgap=0.05,
                width=len(metrics) * 140,
                legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="center", x=0.5))
            fig.update_yaxes(range=[0, 1.1])
            return plot.plot(fig, output_type='div', include_plotlyjs=False)
        except Exception as e:
            logger.error(f"Error creating score comparison chart: {e}")
            return f"<div>Error creating comparison chart: {e}</div>"

    def _create_test_coverage_sunburst(self, excel_path: str, sheet_name: str) -> str:
        try:
            df = pd.read_excel(excel_path, sheet_name=sheet_name)
            df["topic"]       = df["topic"].astype(str).str.strip().str.upper()
            df["sub_topic"]   = df["sub_topic"].astype(str).str.strip().str.title()
            df["sub_subtopic"] = df["sub_subtopic"].astype(str).str.strip().replace({"": None, "nan": None, "None": None})
            has_expected = "expected_record_count" in df.columns
            agg_cols = {"count": ("query", lambda x: x.notna().sum())}
            if has_expected:
                agg_cols["expected"] = ("expected_record_count", "sum")
            sunburst_df = df.groupby(["topic", "sub_topic", "sub_subtopic"], dropna=False).agg(**agg_cols).reset_index()
            table_rows = ""
            for _, row in sunburst_df.iterrows():
                actual   = int(row["count"])
                sub_sub  = row["sub_subtopic"] if pd.notna(row["sub_subtopic"]) else "-"
                expected_val = int(row["expected"]) if has_expected and pd.notna(row.get("expected")) else "-"
                table_rows += f"""
                <tr>
                    <td>{row['topic']}</td><td>{row['sub_topic']}</td><td>{sub_sub}</td>
                    <td>{expected_val}</td><td>{actual}</td>
                </tr>"""
            table_html = f"""
            <div style="width:100%; margin-bottom:32px;">
                <div class="table-container" style="width:100%; max-width:100%; overflow-x:auto;">
                    <table class="modern-table" style="width:100%;">
                        <thead><tr>
                            <th>Topic</th><th>Sub Topic</th><th>Sub Subtopic</th>
                            <th>Expected Record Count</th><th>Actual Record Count</th>
                        </tr></thead>
                        <tbody>{table_rows}</tbody>
                    </table>
                </div>
            </div>"""
            fig = px.sunburst(sunburst_df, path=["topic", "sub_topic", "sub_subtopic"],
                values="count", color="topic", branchvalues="total", maxdepth=2)
            fig.update_traces(
                texttemplate="<b>%{label}</b><br>Count: %{value}<br>%{percentParent:.0%}",
                hovertemplate="<b>%{label}</b><br>Count: %{value}<br>%{percentParent:.0%}<extra></extra>",
                textfont=dict(size=14))
            fig.update_layout(sunburstcolorway=px.colors.qualitative.Pastel, margin=dict(t=60, l=20, r=20, b=20))
            chart_html = plot.plot(fig, output_type="div", include_plotlyjs="cdn")
            return table_html + f"""
            <div style="display:flex; justify-content:center; width:100%;">
                <div style="width:fit-content;">{chart_html}</div>
            </div>"""
        except Exception as e:
            logger.error(f"Error creating test coverage sunburst: {e}")
            return "<div class='text-center p-3'><b>Error loading test coverage</b></div>"

    def _create_run_comparison_chart(self, prev_df: pd.DataFrame, curr_df: pd.DataFrame, theme: Dict) -> str:
        try:
            if prev_df.empty or curr_df.empty:
                return "<div class='text-center p-3'><b>No data available</b></div>"
            def find_existing(df, candidates):
                for c in candidates:
                    if c in df.columns: return c
                return None
            mc_p = find_existing(prev_df, ["Metric","Metrics","metric"])
            sc_p = find_existing(prev_df, ["Score","aggregate_score","score"])
            mc_c = find_existing(curr_df, ["Metric","Metrics","metric"])
            sc_c = find_existing(curr_df, ["Score","aggregate_score","score"])
            if not all([mc_p, sc_p, mc_c, sc_c]):
                return "<div class='text-center p-3'><b>No data available</b></div>"
            prev_df = prev_df[[mc_p, sc_p]].rename(columns={mc_p:"Metric", sc_p:"Previous"})
            curr_df = curr_df[[mc_c, sc_c]].rename(columns={mc_c:"Metric", sc_c:"Current"})
            merged = pd.merge(prev_df, curr_df, on="Metric", how="inner")
            if merged.empty:
                return "<div class='text-center p-3'><b>No data available</b></div>"
            fig = go.Figure()
            fig.add_bar(x=merged["Metric"], y=pd.to_numeric(merged["Previous"], errors="coerce"),
                name="Previous Run", marker_color=theme["secondary_color"])
            fig.add_bar(x=merged["Metric"], y=pd.to_numeric(merged["Current"], errors="coerce"),
                name="Current Run", marker_color=theme["primary_color"])
            fig.update_layout(barmode="group", title="Run Comparison (Previous vs Current)",
                xaxis_title="Metrics", yaxis_title="Score", **self._get_chart_layout(theme))
            return plot.plot(fig, output_type="div", include_plotlyjs=False)
        except Exception as e:
            logger.error(f"Run comparison error: {e}")
            return "<div class='text-center p-3'><b>No data available</b></div>"

    def _create_disaggregated_table(self, excel_path: Path) -> str:
        df = pd.read_excel(excel_path, sheet_name="Disaggregated View", header=None)
        agg_scores = {}
        for col in range(2, len(df.columns)):
            metric = str(df.iloc[0, col]).strip()
            val = df.iloc[1, col]
            if metric and metric.lower() != "nan":
                try:    agg_scores[metric] = float(val)
                except: agg_scores[metric] = None
        parsed = []
        i = 0
        while i < len(df):
            cell = str(df.iloc[i, 2]).strip().lower()
            if cell == "topic":
                topic     = str(df.iloc[i+1, 2]).strip()
                sub_topic = str(df.iloc[i+1, 3]).strip()
                pass_row  = df.iloc[i+2]
                fail_row  = df.iloc[i+3]
                metrics_data = {}
                for col in range(4, len(df.columns)):
                    metric_name = str(df.iloc[i, col]).strip()
                    if not metric_name or metric_name.lower() == "nan": continue
                    try:
                        passed_m = int(str(pass_row[col]).split()[0])
                        failed_m = int(str(fail_row[col]).split()[0])
                    except: continue
                    metrics_data[metric_name] = {"passed": passed_m, "failed": failed_m, "aggregate_score": agg_scores.get(metric_name)}
                parsed.append({"topic": topic, "sub_topic": sub_topic, "metrics": metrics_data})
                i += 5
            else:
                i += 1
        return f"""
        <div class="card-header"><h3>🔍 Disaggregated Analysis</h3></div>
        <div class="card-content">
            <label>Topic</label><br>
            <select id="topicSelect"></select><br><br>
            <label>Sub-topic</label><br>
            <div id="subTopicWrapper" class="multi-select">
                <div id="selectedSubTopics" class="chips"></div>
                <input id="subTopicInput" placeholder="Select sub-topics" readonly/>
                <div id="subTopicDropdown" class="dropdown"></div>
            </div><br><br>
            <div class="chart-scroll"><div id="disaggChart"></div></div>
        </div>
        <script>const DISAGG_DATA = {json.dumps(parsed)};</script>"""

    def _get_chart_layout(self, theme: Dict) -> Dict:
        return {
            'font': {'family': theme['font_family'], 'size': 12},
            'plot_bgcolor': 'rgba(0,0,0,0)', 'paper_bgcolor': 'rgba(0,0,0,0)',
            'height': self.config['chart_height'],
            'margin': dict(l=60, r=60, t=80, b=100),
            'xaxis': {'showgrid': True, 'gridcolor': theme['border_color'], 'tickangle': -45, 'tickfont': {'size': 10}},
            'yaxis': {'showgrid': True, 'gridcolor': theme['border_color'], 'tickfont': {'size': 10}}
        }

    # ==================== DATA PREPARATION ====================

    def _prepare_modal_data(self, df: pd.DataFrame, metrics: List[str], thresholds: Dict[str, float]) -> Dict:
        try:
            modal_data = {}
            metric_sheets = {}
            try:
                if self.metric_details_excel_path.exists():
                    xls = pd.ExcelFile(self.metric_details_excel_path)
                    for sheet in xls.sheet_names:
                        try: metric_sheets[sheet] = pd.read_excel(xls, sheet_name=sheet)
                        except: continue
                else:
                    logger.warning(f"Metric details file not found: {self.metric_details_excel_path}")
            except Exception as e:
                logger.warning(f"Unable to read metric details excel: {e}")
                metric_sheets = {}

            normalized_sheet_map = {str(s).strip().lower(): s for s in metric_sheets.keys()}

            for idx, row in df.iterrows():
                modal_data[idx] = {
                    'query': self._clean_text(row.get('Query', 'N/A')),
                    'response': self._clean_text(row.get('Response', 'N/A')),
                    'timestamp': self.report_timestamp, 'metrics': {}
                }
                modal_data[idx]["metric_fields"] = {}

                for metric in metrics:
                    norm_metric = str(metric).strip().lower()
                    if norm_metric in normalized_sheet_map:
                        sheet_name = normalized_sheet_map[norm_metric]
                        metric_df = metric_sheets.get(sheet_name)
                        if isinstance(metric_df, pd.DataFrame):
                            query_col   = self._find_column(metric_df, ['Query', 'query', 'Question'])
                            found_entry = {}
                            if query_col and query_col in metric_df.columns:
                                metric_df[query_col] = metric_df[query_col].ffill()
                                details_query = self._normalize_text(row.get('Query', ''))
                                mask  = metric_df[query_col].apply(lambda x: self._normalize_text(x) == details_query)
                                matched = metric_df[mask]
                                if not matched.empty:
                                    found_entry = matched.iloc[0].replace({pd.NA: None}).to_dict() if len(matched)==1 else [r.replace({pd.NA: None}).to_dict() for _, r in matched.iterrows()]
                                else:
                                    mask2 = metric_df[query_col].apply(lambda x: self._text_equal(x, details_query))
                                    matched2 = metric_df[mask2]
                                    if not matched2.empty:
                                        found_entry = matched2.iloc[0].replace({pd.NA: None}).to_dict() if len(matched2)==1 else [r.replace({pd.NA: None}).to_dict() for _, r in matched2.iterrows()]
                            modal_data[idx]["metric_fields"][str(metric).strip()] = found_entry
                        else:
                            modal_data[idx]["metric_fields"][metric] = {}
                    else:
                        modal_data[idx]["metric_fields"][metric] = {}

                self._add_metrics_data(modal_data[idx], row, metrics, thresholds)
            return modal_data
        except Exception as e:
            logger.error(f"Error preparing modal data: {e}")
            return {}

    def _clean_text(self, text: Any) -> str:
        if pd.isna(text) or text is None: return 'N/A'
        text = str(text).strip()
        if not text or text.lower() in ['nan', 'none', '']: return 'N/A'
        text = text.replace('\\n', '\n').replace('\n', '<br>')
        return text

    def _add_metrics_data(self, modal_item: Dict, row: pd.Series, metrics: List[str], thresholds: Dict) -> None:
        for metric in metrics:
            metric_str  = str(metric).strip()
            metric_norm = self._normalize_text(metric_str)
            metric_data = {
                'score': self._clean_text(row.get(metric, 'N/A')),
                'threshold': str(thresholds.get(metric, 'N/A')),
                'status': self._clean_text(row.get(f"{metric}_status", 'Unknown')),
                'additional_fields': {}
            }
            for col in row.index:
                col_norm = self._normalize_text(str(col).strip())
                if col_norm == metric_norm or col_norm.endswith("status"): continue
                if col_norm.startswith(metric_norm):
                    field_name  = col_norm.replace(metric_norm, "").strip(" _-")
                    field_value = self._clean_text(row.get(col, ''))
                    if field_value != 'N/A':
                        metric_data['additional_fields'][field_name] = field_value
            modal_item['metrics'][metric_str] = metric_data

    def _generate_modern_modal(self) -> str:
        return """
        <div id="detailModal" class="modal">
            <div class="modal-content">
                <div class="modal-header">
                    <div>
                        <h3 class="modal-title" id="modalTitle">Metric Details</h3>
                        <p class="modal-subtitle" id="modalSubtitle">Threshold: N/A</p>
                    </div>
                    <button class="modal-close" onclick="closeModal()">×</button>
                </div>
                <div class="modal-body">
                    <div class="modal-left">
                        <div id="scoreReasonBlock">
                            <div class="modal-section score-box">
                                <h4>Score Analysis</h4>
                                <div id="scorePieChart"></div>
                            </div>
                            <div class="modal-section evaluation-box">
                                <h4>Evaluation Reason</h4>
                                <p id="modalReason">N/A</p>
                            </div>
                        </div>
                        <div class="modal-section">
                            <h4>Question</h4>
                            <p id="modalQuestion">N/A</p>
                        </div>
                        <div id="rcaContainer">N/A</div>
                        <div id="secondaryContainer">N/A</div>
                        <div class="collapsible-section">
                            <div class="collapsible-header" onclick="toggleCollapsible('response')">
                                <h4>Response</h4>
                                <span class="toggle-icon" id="responseIcon">▼</span>
                            </div>
                            <div class="collapsible-content collapsed" id="responseContent">
                                <p id="modalResponse">N/A</p>
                            </div>
                        </div>
                        <div id="metricContainer">
                            <div class="collapsible-section">
                                <div class="collapsible-header" onclick="toggleCollapsible('traceback')">
                                    <h4>Traceback</h4>
                                    <span class="toggle-icon" id="tracebackIcon">▼</span>
                                </div>
                                <div class="collapsible-content collapsed" id="tracebackContent">
                                    <div id="tracebackFields">N/A</div>
                                </div>
                            </div>
                            <div class="collapsible-section">
                                <div class="collapsible-header" onclick="toggleCollapsible('metricFields')">
                                    <h4>Metric Fields</h4>
                                    <span class="toggle-icon" id="metricFieldsIcon">▼</span>
                                </div>
                                <div class="collapsible-content collapsed" id="metricFieldsContent">
                                    <div id="metricSheetFields">N/A</div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div id="rcaOutputModal" class="modal">
            <div class="modal-content" style="max-width:900px;">
                <div class="modal-header">
                    <h3>Actual Problematic Output</h3>
                    <button class="modal-close" onclick="closeRcaOutput()">×</button>
                </div>
                <div class="modal-body">
                    <pre id="rcaOutputContent" style="white-space:pre-wrap; max-height:70vh; overflow:auto;"></pre>
                </div>
            </div>
        </div>"""

    # ==================== UI COMPONENTS ====================

    def _get_modern_css(self) -> str:
        theme = self.config['theme']
        status_colors = self.config['status_colors']
        return f"""
        * {{ box-sizing: border-box; margin: 0; padding: 0; }}
        body {{ font-family: {theme['font_family']}; line-height: 1.6; color: #333;
            background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
            min-height: 100vh; margin: 0; padding: 20px; }}
        .container {{ max-width: 1400px; margin: 0 auto; background: white;
            border-radius: 15px; box-shadow: 0 20px 40px rgba(0,0,0,0.1); overflow: hidden; }}
        #rcaOutputContent.empty-json {{ display:flex; font-weight:600; color:#666; text-align:center; width:100%; }}
        .empty-json {{ color:#888; font-style:italic; }}
        .report-header {{ background: linear-gradient(135deg, {theme['primary_color']} 0%, {theme['secondary_color']} 100%);
            color: white; padding: 40px; text-align: center; position: relative; overflow: hidden; }}
        .report-header::before {{ content: ''; position: absolute; top: -50%; left: -50%;
            width: 200%; height: 200%;
            background: repeating-linear-gradient(0deg, transparent, transparent 2px, rgba(255,255,255,0.03) 2px, rgba(255,255,255,0.03) 4px);
            animation: shimmer 20s linear infinite; }}
        @keyframes shimmer {{ 0% {{ transform: translateX(-100%); }} 100% {{ transform: translateX(100%); }} }}
        .report-title {{ font-size: 2.5rem; font-weight: 700; margin-bottom: 10px;
            text-shadow: 2px 2px 4px rgba(0,0,0,0.3); position: relative; z-index: 1; }}
        .report-subtitle {{ font-size: 1.4rem; font-weight: 300; margin-bottom: 15px; opacity: 0.9; position: relative; z-index: 1; }}
        .report-description {{ font-size: 1rem; max-width: 800px; margin: 0 auto; opacity: 0.85; line-height: 1.6; position: relative; z-index: 1; }}
        .report-timestamp {{ position: absolute; top: 20px; right: 20px; background: rgba(255,255,255,0.2);
            padding: 8px 15px; border-radius: 20px; font-size: 0.9rem; z-index: 2; }}
        .tab-navigation {{ background: {theme['light_bg']}; border-bottom: 3px solid {theme['primary_color']};
            display: flex; justify-content: center; padding: 0; position: sticky; top: 0; z-index: 100; }}
        .tab-button {{ background: none; border: none; padding: 20px 30px; font-size: 1.1rem; font-weight: 500;
            cursor: pointer; transition: all 0.3s ease; position: relative; color: #666; }}
        .tab-button:hover {{ background: rgba(46, 134, 171, 0.1); color: {theme['primary_color']}; }}
        .tab-button.active {{ background: {theme['primary_color']}; color: white; box-shadow: inset 0 -3px 0 {theme['accent_color']}; }}
        .tab-button.active::after {{ content: ''; position: absolute; bottom: -3px; left: 0; right: 0; height: 3px; background: {theme['accent_color']}; }}
        .tab-content {{ display: none; padding: 30px; animation: fadeIn 0.3s ease-in; width: 100%; }}
        .tab-content.active {{ display: block; height: auto; overflow: visible; }}
        .sub-tab-content {{ display: none; padding: 20px 0; animation: fadeIn 0.3s ease-in; }}
        .sub-tab-content.active {{ display: block; }}
        @keyframes fadeIn {{ from {{ opacity: 0; transform: translateY(10px); }} to {{ opacity: 1; transform: translateY(0); }} }}
        .card {{ background: white; border-radius: 12px; box-shadow: 0 4px 20px rgba(0,0,0,0.08);
            margin-bottom: 25px; overflow: hidden; transition: all 0.3s ease; border: 1px solid {theme['border_color']}; }}
        .card:hover {{ transform: translateY(-5px); box-shadow: 0 8px 30px rgba(0,0,0,0.12); }}
        .card-header {{ background: linear-gradient(135deg, {theme['primary_color']} 0%, {theme['secondary_color']} 100%);
            color: white; padding: 20px; font-weight: 600; font-size: 1.2rem; position: relative; }}
        .card-content {{ padding: 20px; }}
        .charts-grid {{ display: block; width: 100%; }}
        .chart-card {{ background: white; border-radius: 12px; box-shadow: 0 4px 20px rgba(0,0,0,0.08);
            overflow: visible; transition: all 0.3s ease; margin-bottom: 25px; }}
        .chart-card:hover {{ transform: translateY(-5px); box-shadow: 0 8px 30px rgba(0,0,0,0.12); }}
        .chart-card.full-width {{ grid-column: 1 / -1; }}
        .multi-select {{ position: relative; width: 300px; border: 1px solid #ccc; border-radius: 6px; padding: 6px; }}
        .multi-select input {{ border: none; outline: none; width: 100%; cursor: pointer; }}
        .chips {{ display: flex; flex-wrap: wrap; gap: 6px; margin-bottom: 4px; }}
        .chip {{ background: #e0e0e0; padding: 4px 8px; border-radius: 12px; font-size: 12px; display: flex; align-items: center; }}
        .chip span {{ margin-left: 6px; cursor: pointer; }}
        .dropdown {{ position: absolute; background: white; border: 1px solid #ccc; width: 100%;
            max-height: 150px; overflow-y: auto; display: none; z-index: 10; }}
        .dropdown div {{ padding: 6px; cursor: pointer; }}
        .dropdown div:hover {{ background: #f0f0f0; }}
        .chart-scroll {{ width:100%; overflow-x: auto; overflow-y: hidden; }}
        .chart-scroll > div {{ min-width: max-content; }}
        .table-container {{ background: white; border-radius: 12px; box-shadow: 0 4px 20px rgba(0,0,0,0.08);
            overflow-x: auto; overflow-y: auto; max-width: 100%; max-height: 600px;
            position: relative; margin-bottom: 25px; }}
        .modern-table {{ width: 100%; border-collapse: collapse; font-size: 0.95rem; }}
        .modern-table th {{ background: linear-gradient(135deg, {theme['primary_color']} 0%, {theme['secondary_color']} 100%);
            color: white; padding: 15px 12px; text-align: left; font-weight: 600; border: none;
            position: sticky; top: 0; z-index: 10; }}
        .modern-table td {{ padding: 12px; border-bottom: 1px solid {theme['border_color']}; vertical-align: top; }}
        .modern-table tr:hover {{ background: rgba(46, 134, 171, 0.04); }}
        .modern-table tr:nth-child(even) {{ background: rgba(0,0,0,0.02); }}
        .modern-table tr:nth-child(even):hover {{ background: rgba(46, 134, 171, 0.04); }}
        .details-table {{ width: max-content; min-width: 100%; border-collapse: collapse; font-size: 0.95rem; table-layout: auto; }}
        .details-table thead th {{ background: linear-gradient(135deg, {theme['primary_color']} 0%, {theme['secondary_color']} 100%);
            color: white; padding: 15px 12px; text-align: left; font-weight: 600; border: none;
            position: sticky; top: 0; z-index: 10; resize: none; overflow: hidden; }}
        .details-table td {{ padding: 12px; border-bottom: 1px solid {theme['border_color']}; vertical-align: top;
            white-space: normal; word-break: break-word; max-width: 600px; }}
        .details-table tr:hover {{ background: rgba(46, 134, 171, 0.04); }}
        .details-table tr:nth-child(even) {{ background: rgba(0,0,0,0.02); }}
        .details-table tr:nth-child(even):hover {{ background: rgba(46, 134, 171, 0.04); }}
        .details-table td:first-child, .details-table td:nth-child(2) {{ white-space: normal; max-width: 600px; }}
        .resizer {{ position: absolute; right: 0; top: 0; width: 6px; height: 100%; cursor: col-resize; user-select: none; }}
        .metric-table {{ width: 100%; border-collapse: collapse; margin-top: 10px; }}
        .metric-table th, .metric-table td {{ border: 1px solid #ddd; padding: 8px; vertical-align: top; }}
        .metric-table th {{ background-color: #7393B3; font-weight: 600; text-transform: capitalize; }}
        .metric-table thead th {{ position: sticky; top: 0; z-index: 20;
            background: linear-gradient(135deg, #2E86AB 0%, #A23B72 100%); color: white; }}
        .traceback-card {{ background: #f8fafc; border-radius: 12px; padding: 16px 18px; margin: 14px 0;
            border: 1px solid #e5eaf2; box-shadow: 0 2px 6px rgba(0,0,0,0.04); }}
        .traceback-subcard {{ margin-left: 14px; border-left: 3px solid #e2e8f0; padding-left: 12px; margin-top: 10px; }}
        .traceback-card > .traceback-card-title {{ font-size:18px; font-weight:700; color:#111827; margin-bottom:10px; }}
        .traceback-subcard > .traceback-card-title, .traceback-card-title.section {{ font-size:14px; font-weight:600; color:#374151; }}
        .traceback-param-row {{ display: flex; justify-content: space-between; align-items: baseline; font-size: 13px; padding: 3px 0; }}
        .traceback-param-name {{ color: #1f2937; font-weight: 700; }}
        .traceback-param-value {{ color: #6b7280; font-weight: 500; }}
        .traceback-param-value.na {{ color: #9ca3af; font-style: italic; font-weight: 500; }}
        .tb-badge {{ display:inline-flex; align-items:center; gap:4px; padding:2px 8px; border-radius:10px; font-size:12px; font-weight:600; }}
        .tb-pass {{ background:#ecfdf5; color:#059669; border:1px solid #a7f3d0; }}
        .tb-fail {{ background:#fef2f2; color:#dc2626; border:1px solid #fecaca; }}
        .status-cell {{ padding: 6px 12px; border-radius: 20px; font-size: 0.85rem; font-weight: 600;
            text-align: center; min-width: 80px; display: inline-block; cursor: pointer; transition: all 0.2s ease; }}
        .status-cell:hover {{ transform: scale(1.05); box-shadow: 0 2px 8px rgba(0,0,0,0.2); }}
        .status-warning {{ background: #e6c65c; color: #4a3a00; }}
        .status-passed {{ background: {status_colors['passed']}; color: white; }}
        .status-failed {{ background: {status_colors['failed']}; color: white; }}
        .status-skipped {{ background: {status_colors['skipped']}; color: white; }}
        .diff-added {{ background:#00bcd4; color:white; padding:2px 4px; border-radius:3px; }}
        .diff-removed {{ background:#ffebee; color:#c62828; padding:2px 4px; border-radius:3px; text-decoration:line-through; }}
        .rca-diff-legend {{ display:flex; gap:16px; align-items:center; font-size:0.82rem; margin-bottom:10px; flex-wrap:wrap; }}
        .rca-diff-legend span {{ display:inline-flex; align-items:center; gap:6px; }}
        .metric-score {{ font-weight: 600; font-size: 1.1rem; }}
        .below-threshold {{ background: linear-gradient(135deg, #ffebee 0%, #ffcdd2 100%);
            color: {status_colors['failed']}; font-weight: bold; border-left: 4px solid {status_colors['failed']}; }}
        .equal-threshold {{ background: linear-gradient(135deg, #fff8e1 0%, #ffecb3 100%);
            color: #e65100; font-weight: bold; border-left: 4px solid {theme['warning_color']}; }}
        .pagination-container {{ background: {theme['light_bg']}; border-top: 1px solid {theme['border_color']};
            padding: 20px; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 15px; }}
        .pagination-controls {{ display: flex; align-items: center; gap: 10px; }}
        .page-btn {{ padding: 10px 15px; border: 1px solid {theme['border_color']}; background: white;
            cursor: pointer; border-radius: 6px; font-size: 14px; transition: all 0.2s ease; min-width: 40px; text-align: center; }}
        .page-btn:hover:not(:disabled) {{ background: {theme['primary_color']}; color: white; border-color: {theme['primary_color']}; }}
        .page-btn.active {{ background: {theme['primary_color']}; color: white; border-color: {theme['primary_color']}; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }}
        .page-btn:disabled {{ background: {theme['light_bg']}; color: #999; cursor: not-allowed; border-color: {theme['border_color']}; }}
        .page-info {{ font-size: 0.9rem; color: #666; font-weight: 500; }}
        .rows-selector {{ padding: 8px 12px; border: 1px solid {theme['border_color']}; border-radius: 6px; background: white; font-size: 14px; }}
        .modal {{ display: none; position: fixed; z-index: 1000; left: 0; top: 0; width: 100%; height: 100%;
            background: rgba(0,0,0,0.6); backdrop-filter: blur(5px); }}
        .modal-content {{ background: white; margin: 2% auto; border-radius: 15px; display: flex; flex-direction: column;
            width: 95%; max-width: 1400px; max-height: 90vh; overflow: hidden;
            box-shadow: 0 20px 60px rgba(0,0,0,0.3); animation: modalSlideIn 0.3s ease-out; }}
        @keyframes modalSlideIn {{ from {{ opacity: 0; transform: translateY(-50px) scale(0.9); }} to {{ opacity: 1; transform: translateY(0) scale(1); }} }}
        .modal-header {{ background: linear-gradient(135deg, {theme['primary_color']} 0%, {theme['secondary_color']} 100%);
            color: white; padding: 25px; position: relative; }}
        .modal-title {{ font-size: 1.5rem; font-weight: 600; margin: 0; }}
        .modal-subtitle {{ font-size: 1rem; opacity: 0.9; margin: 5px 0 0; }}
        .modal-close {{ position: absolute; top: 20px; right: 25px; background: rgba(255,255,255,0.2);
            border: none; color: white; font-size: 24px; font-weight: bold; cursor: pointer;
            width: 40px; height: 40px; border-radius: 50%; display: flex; align-items: center;
            justify-content: center; transition: all 0.2s ease; }}
        .modal-close:hover {{ background: rgba(255,255,255,0.3); transform: scale(1.1); }}
        .modal-body {{ display: flex; flex: 1; overflow: hidden; }}
        .modal-left {{ flex: 1; width: 100%; padding: 25px; overflow-y: auto; border-right: none; }}
        #scoreReasonBlock {{ display:flex; flex-direction:row; gap:24px; align-items:stretch; }}
        #scoreReasonBlock .score-box {{ flex:0 0 320px; max-width:320px; }}
        #scoreReasonBlock .evaluation-box {{ flex:1; min-width:0; }}
        #scoreReasonBlock .modal-section {{ width:auto; }}
        .modal-left > #scoreReasonBlock {{ display:flex !important; flex-direction:row !important; gap:24px; }}
        .modal-section {{ background: white; border-radius: 8px; padding: 0 20px 20px 20px; margin-bottom: 20px;
            border-left: 4px solid {theme['accent_color']}; box-shadow: 0 2px 8px rgba(0,0,0,0.05); }}
        .modal-section h4 {{ color: {theme['primary_color']}; margin-bottom: 8px; font-size: 1.1rem; font-weight: 600; }}
        .modal-section p {{ line-height: 1.6; color: #555; }}
        .collapsible-section {{ background: white; border-radius: 8px; margin-bottom: 20px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.05); overflow: hidden; }}
        .collapsible-header {{ background: linear-gradient(135deg, {theme['light_bg']} 0%, rgba(46,134,171,0.1) 100%);
            padding: 15px 20px; cursor: pointer; display: flex; justify-content: space-between;
            align-items: center; border-left: 4px solid {theme['accent_color']}; transition: all 0.2s ease; }}
        .collapsible-header:hover {{ background: linear-gradient(135deg, rgba(46,134,171,0.1) 0%, rgba(46,134,171,0.2) 100%); }}
        .collapsible-content {{ padding: 0 20px 20px 20px; max-height: 200px; overflow-y: auto;
            transition: all 0.3s ease; border-left: 4px solid {theme['accent_color']}; }}
        .collapsible-content.collapsed {{ max-height: 0; padding: 0 20px; overflow: hidden; }}
        #tracebackContent:not(.collapsed), #metricFieldsContent:not(.collapsed) {{ max-height: 420px; overflow-y: auto; position: relative; }}
        #rcaContainer {{ max-height: 420px; overflow-y: auto; position: relative; }}
        #rcaContainer table thead th {{ position: sticky; top: 0; z-index: 5;
            background: linear-gradient(135deg, #2E86AB 0%, #A23B72 100%); color: white; }}
        .toggle-icon {{ font-size: 1.2rem; transition: transform 0.3s ease; color: {theme['primary_color']}; transform: rotate(180deg); }}
        .toggle-icon.expanded {{ transform: rotate(0deg); }}
        #scorePieChart {{ margin: 0 auto; display: flex; justify-content: center; align-items: center;
            max-width: 100%; max-height: 200px; overflow: hidden; }}
        #metricSheetFields {{ padding: 0; margin: 0; }}
        .trajectory-wrapper {{ display:flex; gap:20px; margin-bottom:20px; }}
        .trajectory-wrapper .modal-section {{ flex:1; }}
        .constant-collapsible {{ margin-bottom:15px; }}
        .constant-header {{ background:#f1f4f8; padding:10px 14px; border-radius:6px; cursor:pointer; font-weight:600; border:1px solid #e3e6ea; }}
        .constant-content {{ border:1px solid #e3e6ea; border-top:none; padding:12px; display:none;
            border-radius:0 0 6px 6px; max-height:350px; overflow:auto; white-space:pre-wrap; }}
        @media (max-width: 768px) {{
            .container {{ margin: 10px; border-radius: 10px; }}
            .report-title {{ font-size: 2rem; }}
            .tab-content {{ padding: 20px; }}
            .modal-content {{ width: 98%; max-height: 95vh; }}
            .modal-left {{ padding: 20px; }}
        }}
        .loading {{ display: inline-block; width: 20px; height: 20px; border: 3px solid rgba(46,134,171,0.3);
            border-radius: 50%; border-top-color: {theme['primary_color']}; animation: spin 1s ease-in-out infinite; }}
        @keyframes spin {{ to {{ transform: rotate(360deg); }} }}
        .text-center {{ text-align: center; }} .text-right {{ text-align: right; }}
        .text-primary {{ color: {theme['primary_color']}; }} .text-secondary {{ color: {theme['secondary_color']}; }}
        .text-success {{ color: {status_colors['passed']}; }} .text-danger {{ color: {status_colors['failed']}; }}
        .text-warning {{ color: {theme['warning_color']}; }} .text-muted {{ color: #666; }}
        .p-0 {{ padding: 0; }} .p-1 {{ padding: 0.5rem; }} .p-2 {{ padding: 1rem; }} .p-3 {{ padding: 1.5rem; }}
        .mb-0 {{ margin-bottom: 0; }} .mb-1 {{ margin-bottom: 0.5rem; }} .mb-2 {{ margin-bottom: 1rem; }} .mb-3 {{ margin-bottom: 1.5rem; }}
        .mt-0 {{ margin-top: 0; }} .mt-1 {{ margin-top: 0.5rem; }} .mt-2 {{ margin-top: 1rem; }} .mt-3 {{ margin-top: 1.5rem; }}
        .font-weight-bold {{ font-weight: 700; }} .font-weight-normal {{ font-weight: 400; }}
        .font-size-sm {{ font-size: 0.875rem; }} .font-size-lg {{ font-size: 1.125rem; }}
        """

    # ==================== TABLE GENERATION ====================

    def _generate_metrics_summary_table(self, df: pd.DataFrame) -> str:
        try:
            if df.empty:
                return "<div class='text-center p-3'>No metrics data available</div>"
            threshold_col = self._find_column(df, ['Threshold_Value', 'Threshold'])
            score_col     = self._find_column(df, ['aggregate_score', 'score', 'Score'])
            metrics_col   = self._find_column(df, ['Metrics', 'Metric'])
            html = ['<div class="table-container"><table class="modern-table"><thead><tr>']
            for col in df.columns:
                html.append(f'<th>{col.replace("_"," ").title()}</th>')
            html.append('</tr></thead><tbody>')
            for _, row in df.iterrows():
                html.append('<tr>')
                for col in df.columns:
                    value = row[col]
                    if isinstance(value, (int, float)) and not pd.isna(value):
                        value = f'{value:.2f}' if col in [threshold_col, score_col] else (f'{value:.2f}' if value != int(value) else str(int(value)))
                    if pd.isna(value) or value is None: value = 'N/A'
                    else: value = str(value).replace('\n','<br>').replace('\r','')
                    cell_class = ''
                    if col == score_col and threshold_col and score_col:
                        cell_class = self._get_score_cell_class(row, score_col, threshold_col, metrics_col)
                    html.append(f'<td class="{cell_class} metric-score">{value}</td>')
                html.append('</tr>')
            html.append('</tbody></table></div>')
            return '\n'.join(html)
        except Exception as e:
            logger.error(f"Error generating metrics table: {e}")
            return f"<div class='alert alert-error'>Error generating table: {e}</div>"

    def _get_score_cell_class(self, row, score_col, threshold_col, metrics_col) -> str:
        try:
            if not all([score_col, threshold_col, metrics_col]): return ''
            score     = self._safe_numeric_conversion(row.get(score_col))
            threshold = self._safe_numeric_conversion(row.get(threshold_col))
            metric    = row.get(metrics_col, '')
            if pd.isna(score) or pd.isna(threshold): return ''
            if metric in self.config['reverse_metrics']:
                if score > threshold: return 'below-threshold'
            else:
                if score < threshold: return 'below-threshold'
            if abs(score - threshold) < 0.001: return 'equal-threshold'
            return ''
        except Exception as e:
            logger.error(f"Error determining score cell class: {e}")
            return ''

    def _generate_interactive_details_table(self, df: pd.DataFrame, metrics: List[str]) -> str:
        try:
            if df.empty:
                return "<div class='text-center p-3'>No details data available</div>"
            html = []
            html.append('<div class="table-container"><table class="details-table"><thead><tr>')
            html.append('<th style="position:sticky;left:0;z-index:11;min-width:50px;text-align:center;background:linear-gradient(135deg,#2E86AB 0%,#A23B72 100%);">#</th>')
            html.append('<th>TC ID</th>')
            html.append('<th>Question</th>')
            html.append('<th>Response</th>')
            for metric in metrics:
                display_name = metric.replace('_', ' ')
                display_name = ' '.join(
                    w.upper() if w.upper() in ('RCA','LLM','ID','TC','API','NLP','ML','AI') else w.title()
                    for w in display_name.split()
                )
                html.append(f'<th class="text-center">{display_name}</th>')
            html.append('</tr></thead><tbody id="tableBody"></tbody></table></div>')
            html.append(self._generate_pagination_controls())
            html.append(self._generate_table_javascript(df, metrics))
            return '\n'.join(html)
        except Exception as e:
            logger.error(f"Error generating details table: {e}")
            return f"<div class='alert alert-error'>Error generating details table: {e}</div>"

    def _get_coverage_edit_data(self) -> list:
        try:
            excel_path = Path(__file__).resolve().parent / "Metrics_template02.xlsx"
            df = pd.read_excel(excel_path, sheet_name='Test data coverage')
            df["topic"]        = df["topic"].astype(str).str.strip().str.upper()
            df["sub_topic"]    = df["sub_topic"].astype(str).str.strip().str.title()
            df["sub_subtopic"] = df["sub_subtopic"].astype(str).str.strip().replace({"nan": None, "None": None, "": None})
            has_expected = "expected_record_count" in df.columns
            agg_cols = {"count": ("query", lambda x: x.notna().sum())}
            if has_expected:
                agg_cols["expected_record_count"] = ("expected_record_count", "first")
            agg = df.groupby(["topic","sub_topic","sub_subtopic"], dropna=False).agg(**agg_cols).reset_index()
            rows = []
            for _, row in agg.iterrows():
                rows.append({
                    "topic":                 row["topic"],
                    "sub_topic":             row["sub_topic"],
                    "sub_subtopic":          row["sub_subtopic"] if pd.notna(row["sub_subtopic"]) else "-",
                    "expected_record_count": int(row["expected_record_count"]) if has_expected and pd.notna(row.get("expected_record_count")) else "",
                    "actual_record_count":   int(row["count"]),
                })
            return rows
        except Exception as e:
            logger.error(f"Error loading coverage edit data: {e}")
            return []

    def _load_recovery_loop_global(self) -> list:
        """Read Recovery Loop Global sheet and return as list of dicts."""
        try:
            if not self.metric_details_excel_path.exists():
                logger.warning(f"File not found: {self.metric_details_excel_path}")
                return []
            xls   = pd.ExcelFile(self.metric_details_excel_path)
            logger.info(f"Sheets in {self.metric_details_excel_path.name}: {xls.sheet_names}")
            match = next((s for s in xls.sheet_names if s.strip().lower() == 'recovery loop global'), None)
            if not match:
                logger.warning("Sheet 'Recovery Loop Global' not found")
                return []
            df = pd.read_excel(xls, sheet_name=match)
            if df.empty:
                logger.warning("Recovery Loop Global sheet is empty")
                return []
            logger.info(f"Recovery Loop Global: {len(df)} rows, columns: {list(df.columns)}")
            return [{str(k): (None if pd.isna(v) else v) for k, v in row.items()} for _, row in df.iterrows()]
        except Exception as e:
            logger.error(f"Error loading Recovery Loop Global: {e}")
            return []

    def _generate_aggregated_results_tab(self, recovery_global_data: list) -> str:
        """Generate the Aggregated Results sub-tab with summary cards + full table."""
        try:
            if not recovery_global_data:
                return """
                <div style="text-align:center;padding:60px 20px;color:#888;">
                    <div style="font-size:3rem;margin-bottom:12px;">📭</div>
                    <div style="font-size:1.1rem;font-weight:600;">No aggregated data available</div>
                    <div style="font-size:0.88rem;margin-top:6px;">
                        Ensure a sheet named <b>Recovery Loop Global</b> exists in
                        <b>final_eval_results01.xlsx</b>
                    </div>
                </div>"""

            df = pd.DataFrame(recovery_global_data)

            # identify numeric columns for summary cards
            numeric_cols = []
            for col in df.columns:
                try:
                    converted = pd.to_numeric(df[col], errors='coerce')
                    if converted.notna().any():
                        numeric_cols.append((col, converted))
                except Exception:
                    pass

            card_colors = [
                ("linear-gradient(135deg,#2E86AB,#1a5f7a)", "white"),
                ("linear-gradient(135deg,#A23B72,#6d2750)", "white"),
                ("linear-gradient(135deg,#F18F01,#c47300)", "white"),
                ("linear-gradient(135deg,#28a745,#1a7030)", "white"),
            ]

            cards_html = ""
            for i, (col, series) in enumerate(numeric_cols[:4]):
                bg, fg = card_colors[i % len(card_colors)]
                total   = series.sum()
                avg     = series.mean()
                display = f"{int(total)}" if total == int(total) else f"{total:.2f}"
                cards_html += f"""
                <div style="flex:1;min-width:180px;border-radius:12px;padding:20px 24px;
                            background:{bg};color:{fg};box-shadow:0 4px 16px rgba(0,0,0,0.12);">
                    <div style="font-size:0.82rem;font-weight:600;opacity:0.85;text-transform:uppercase;
                                letter-spacing:0.5px;margin-bottom:6px;">{col.replace('_',' ')}</div>
                    <div style="font-size:2rem;font-weight:800;line-height:1.1;">{display}</div>
                    <div style="font-size:0.78rem;opacity:0.8;margin-top:4px;">
                        Avg: {avg:.2f} &nbsp;|&nbsp; Rows: {int(series.notna().sum())}
                    </div>
                </div>"""

            # full table
            columns = list(df.columns)
            thead = "".join(f"<th>{c.replace('_',' ')}</th>" for c in columns)
            tbody = ""
            for _, row in df.iterrows():
                cells = "".join(f"<td>{'N/A' if pd.isna(row[c]) else str(row[c])}</td>" for c in columns)
                tbody += f"<tr>{cells}</tr>"

            cards_section = f"""
            <div style="display:flex;gap:16px;flex-wrap:wrap;margin-bottom:28px;">
                {cards_html}
            </div>""" if cards_html else ""

            return f"""
            <div style="margin-bottom:20px;">
                <h3 style="font-size:1.2rem;font-weight:700;color:#2E86AB;margin-bottom:4px;">
                    🌐 Recovery Loop Global
                </h3>
                <p style="color:#888;font-size:0.88rem;">
                    Static global configuration — applies to all queries.
                </p>
            </div>
            {cards_section}
            <div style="border-top:2px solid #e2e8f0;margin-bottom:20px;"></div>
            <div style="font-size:0.88rem;font-weight:700;color:#555;
                        text-transform:uppercase;letter-spacing:0.5px;margin-bottom:10px;">
                Full Data
            </div>
            <div class="table-container" style="max-height:400px;">
                <table class="modern-table" style="width:100%;">
                    <thead><tr>{thead}</tr></thead>
                    <tbody>{tbody}</tbody>
                </table>
            </div>"""

        except Exception as e:
            logger.error(f"Error generating aggregated results tab: {e}")
            return f"<div class='text-center p-3'><b>Error: {e}</b></div>"

    def _generate_trustworthy_table(self, excel_file: str, sheet_name: str, table_id: str, auto_render: bool = False) -> str:
        try:
            excel_path = Path(__file__).resolve().parent / excel_file
            df = pd.read_excel(excel_path, sheet_name=sheet_name)
            if df.empty:
                return "<div class='text-center p-3'>No data available</div>"
            columns = list(df.columns)
            rows = []
            for _, row in df.iterrows():
                cells = []
                for col in columns:
                    val = row[col]
                    if pd.isna(val) or val is None:
                        cells.append("N/A")
                    else:
                        str_val = str(val).strip()
                        if str(col).strip().lower() == "result":
                            if str_val.lower() == "pass":
                                cells.append("<span style='display:inline-flex;align-items:center;gap:5px;background:#28a745;color:white;padding:4px 12px;border-radius:20px;font-size:0.82rem;font-weight:700;'>&#10003; Pass</span>")
                            elif str_val.lower() == "fail":
                                cells.append("<span style='display:inline-flex;align-items:center;gap:5px;background:#dc3545;color:white;padding:4px 12px;border-radius:20px;font-size:0.82rem;font-weight:700;'>&#10007; Fail</span>")
                            else:
                                cells.append(str_val)
                        else:
                            cells.append(str_val.replace('\n','<br>').replace('\r','').replace("'","&#39;"))
                rows.append(cells)

            rows_json  = json.dumps(rows)
            cols_lower = json.dumps([str(c).strip().lower() for c in columns])
            tbody_id   = f"{table_id}Body"
            rpp_id     = f"{table_id}Rpp"
            pg_btns_id = f"{table_id}PgBtns"
            pg_info_id = f"{table_id}PgInfo"
            render_fn  = f"render{table_id[0].upper()}{table_id[1:]}"
            auto_js    = f'document.addEventListener("DOMContentLoaded", function() {{ render(); }});' if auto_render else ''

            html = []
            html.append('<div class="table-container"><table class="details-table"><thead><tr>')
            for col in columns:
                align = ' style="text-align:center;"' if str(col).strip().lower() == "result" else ''
                html.append(f'<th{align}>{str(col).replace("_"," ").title()}</th>')
            html.append(f'</tr></thead><tbody id="{tbody_id}"></tbody></table></div>')
            html.append(f"""
            <div class="pagination-container">
                <div class="pagination-controls">
                    <select id="{rpp_id}" class="rows-selector">
                        <option value="10">10 rows/page</option>
                        <option value="25">25 rows/page</option>
                        <option value="50">50 rows/page</option>
                        <option value="100">100 rows/page</option>
                    </select>
                </div>
                <div class="pagination-controls" id="{pg_btns_id}"></div>
                <div class="page-info"><span id="{pg_info_id}">Page 1 of 1</span></div>
            </div>""")
            html.append(f"""
            <script>
            (function() {{
                var rows      = {rows_json};
                var colsLower = {cols_lower};
                var curPage   = 1;
                function getRpp() {{ var el = document.getElementById('{rpp_id}'); return el ? parseInt(el.value) : 10; }}
                function render() {{
                    var rpp = getRpp(), total = rows.length;
                    var totalPages = Math.max(1, Math.ceil(total / rpp));
                    if (curPage > totalPages) curPage = totalPages;
                    var start = (curPage-1)*rpp, end = Math.min(start+rpp, total);
                    var tbody = document.getElementById('{tbody_id}');
                    if (!tbody) return;
                    var html = '';
                    for (var i = start; i < end; i++) {{
                        html += '<tr>';
                        for (var ci = 0; ci < rows[i].length; ci++) {{
                            var isResult = colsLower[ci] === 'result';
                            var tdStyle  = isResult ? ' style="text-align:center;"' : '';
                            html += '<td' + tdStyle + '>' + rows[i][ci] + '</td>';
                        }}
                        html += '</tr>';
                    }}
                    tbody.innerHTML = html;
                    var info = document.getElementById('{pg_info_id}');
                    if (info) info.textContent = 'Page ' + curPage + ' of ' + totalPages + ' (' + (end-start) + ' of ' + total + ' records)';
                    var pgBtns = document.getElementById('{pg_btns_id}');
                    if (pgBtns) {{
                        pgBtns.innerHTML =
                            '<button class="page-btn" id="{table_id}Prev">Prev</button>' +
                            '<span class="page-btn disabled">' + curPage + ' / ' + totalPages + '</span>' +
                            '<button class="page-btn" id="{table_id}Next">Next</button>';
                        var prevBtn = document.getElementById('{table_id}Prev');
                        var nextBtn = document.getElementById('{table_id}Next');
                        if (curPage <= 1) prevBtn.disabled = true;
                        if (curPage >= totalPages) nextBtn.disabled = true;
                        prevBtn.addEventListener('click', function() {{ if (curPage > 1) {{ curPage--; render(); }} }});
                        nextBtn.addEventListener('click', function() {{ if (curPage < totalPages) {{ curPage++; render(); }} }});
                    }}
                }}
                var rppEl = document.getElementById('{rpp_id}');
                if (rppEl) rppEl.addEventListener('change', function() {{ curPage = 1; render(); }});
                window['{render_fn}'] = render;
                {auto_js}
            }})();
            </script>""")
            return '\n'.join(html)
        except Exception as e:
            logger.error(f"Error generating trustworthy table ({sheet_name}): {e}")
            return f"<div class='text-center p-3'><b>Error loading {sheet_name}: {e}</b></div>"

    def _get_upload_runs_js(self) -> str:
        return """<script>
function uploadRuns() {
    var prevFile = document.getElementById("prevRun").files[0];
    var currFile = document.getElementById("currRun").files[0];
    if (!prevFile || !currFile) { alert("Please upload both files"); return; }
    var formData = new FormData();
    formData.append("previous_run", prevFile);
    formData.append("current_run", currFile);
    fetch("/compare-runs", { method: "POST", body: formData })
        .then(function(res) { return res.text(); })
        .then(function(responseHtml) {
            var container = document.getElementById("runComparisonResult");
            if (!container) return;
            container.innerHTML = responseHtml;
            Array.from(container.querySelectorAll("script")).forEach(function(oldScript) {
                var newScript = document.createElement("script");
                if (oldScript.src) { newScript.src = oldScript.src; newScript.async = false; }
                else { newScript.textContent = oldScript.innerHTML; }
                document.body.appendChild(newScript);
                document.body.removeChild(newScript);
            });
        })
        .catch(function() {
            document.getElementById("runComparisonResult").innerHTML = "<b>Error comparing runs</b>";
        });
}
</script>"""

    def _get_disagg_js(self) -> str:
        return """<script>
var selectedSubs = [];
window.onload = function() {
    var topicSelect = document.getElementById("topicSelect");
    var dropdown = document.getElementById("subTopicDropdown");
    if (!topicSelect) return;
    topicSelect.innerHTML = "<option value=''>Select Topic</option>";
    Array.from(new Set(DISAGG_DATA.map(function(d) { return d.topic; }))).forEach(function(t) {
        var opt = document.createElement("option");
        opt.value = t; opt.textContent = t;
        topicSelect.appendChild(opt);
    });
    topicSelect.onchange = function() {
        selectedSubs = []; renderChips(); dropdown.innerHTML = "";
        var topic = topicSelect.value;
        if (!topic) return;
        Array.from(new Set(
            DISAGG_DATA.filter(function(d) { return d.topic === topic; })
                       .map(function(d) { return d.sub_topic; })
        )).forEach(function(st) {
            var div = document.createElement("div");
            div.textContent = st;
            div.onclick = function() { addSubTopic(st); };
            dropdown.appendChild(div);
        });
    };
    var subInput = document.getElementById("subTopicInput");
    if (subInput) subInput.onclick = function() { dropdown.style.display = "block"; };
    document.addEventListener("click", function(e) {
        if (!e.target.closest(".multi-select")) dropdown.style.display = "none";
    });
};
function addSubTopic(sub) {
    if (selectedSubs.indexOf(sub) === -1) { selectedSubs.push(sub); renderChips(); }
}
function removeSub(sub) {
    selectedSubs = selectedSubs.filter(function(s) { return s !== sub; });
    renderChips();
}
function renderChips() {
    var chipBox = document.getElementById("selectedSubTopics");
    if (!chipBox) return;
    chipBox.innerHTML = "";
    selectedSubs.forEach(function(sub) {
        var chip = document.createElement("div");
        chip.className = "chip";
        var label = document.createElement("span");
        label.textContent = sub;
        var close = document.createElement("span");
        close.textContent = " x";
        close.style.cursor = "pointer";
        close.addEventListener("click", function() { removeSub(sub); });
        chip.appendChild(label);
        chip.appendChild(close);
        chipBox.appendChild(chip);
    });
    updateChart();
}
function updateChart() {
    var topicEl = document.getElementById("topicSelect");
    var topic = topicEl ? topicEl.value : "";
    if (!topic || selectedSubs.length === 0) return;
    var rows = DISAGG_DATA.filter(function(d) {
        return d.topic === topic && selectedSubs.indexOf(d.sub_topic) !== -1;
    });
    var metrics = {};
    rows.forEach(function(r) {
        Object.keys(r.metrics).forEach(function(m) {
            var v = r.metrics[m];
            if (!metrics[m]) metrics[m] = { passed: 0, failed: 0 };
            metrics[m].passed += v.passed;
            metrics[m].failed += v.failed;
        });
    });
    var labels = Object.keys(metrics);
    if (!labels.length) return;
    var maxCount = Math.max.apply(null, labels.map(function(m) {
        return Math.max(metrics[m].passed, metrics[m].failed);
    })) || 1;
    Plotly.newPlot("disaggChart", [
        { x: labels, y: labels.map(function(m) { return metrics[m].passed; }),
          name: "Passed", type: "bar", marker: { color: "#2ca02c" } },
        { x: labels, y: labels.map(function(m) { return metrics[m].failed; }),
          name: "Failed", type: "bar", marker: { color: "#d62728" } }
    ], {
        barmode: "group",
        title: topic + " - " + selectedSubs.join(", "),
        yaxis: { title: "Count", range: [0, maxCount], tickmode: "linear", dtick: 1 }
    });
}
</script>"""

    def _generate_secondary_llm_table(self, df: pd.DataFrame, metrics: List[str]) -> str:
        try:
            if df.empty:
                return "<div class='text-center p-3'>No details data available</div>"
            html = []
            html.append('<div class="table-container"><table class="details-table"><thead><tr>')
            html.append('<th style="position:sticky;left:0;z-index:11;min-width:50px;text-align:center;background:linear-gradient(135deg,#2E86AB 0%,#A23B72 100%);">#</th>')
            html.append('<th>Question</th><th>Response</th>')
            for metric in metrics:
                html.append(f'<th>Primary_{metric}</th><th>Secondary_{metric}</th>')
            html.append('</tr></thead><tbody id="secondaryTableBody"></tbody></table></div>')
            html.append(self._generate_secondary_pagination_controls())
            html.append(self._generate_secondary_llm_javascript(df, metrics))
            return "\n".join(html)
        except Exception as e:
            logger.error(f"Error generating secondary llm table: {e}")
            return f"<div class='alert alert-error'>Error generating secondary llm table: {e}</div>"

    def _generate_augmented_data_table(self, excel_path: str, sheet_name: str) -> str:
        try:
            df = pd.read_excel(excel_path, sheet_name=sheet_name)
            if df.empty:
                return "<div class='text-center p-3'>No augmentation data available</div>"

            df.columns = [str(c).strip() for c in df.columns]
            base_col = aug_col = case_col = reason_col = None
            for c in df.columns:
                name = c.lower()
                if "base" in name and "query" in name: base_col = c
                if "augmented" in name: aug_col = c
                if name == "case": case_col = c
                if "reason" in name and "augment" in name: reason_col = c

            if case_col is None:
                for c in df.columns:
                    if c.strip().lower() == "case": case_col = c; break

            display_cols = [c for c in df.columns if c not in [x for x in [case_col, reason_col] if x]]
            case_styles  = {
                "P": ("P", "#1565C0", "#E3F2FD"),
                "N": ("N", "#B71C1C", "#FFEBEE"),
                "E": ("E", "#1B5E20", "#E8F5E9"),
            }

            aug_modal_rows = []
            for i, (_, row) in enumerate(df.iterrows()):
                base_q = str(row[base_col]) if base_col and pd.notna(row.get(base_col)) else ""
                aug_q  = str(row[aug_col])  if aug_col  and pd.notna(row.get(aug_col))  else ""
                reason_data = []
                if reason_col and pd.notna(row.get(reason_col)):
                    raw = str(row[reason_col]).strip()
                    try:
                        import ast
                        parsed = ast.literal_eval(raw)
                        reason_data = parsed if isinstance(parsed, list) else ([parsed] if isinstance(parsed, dict) else [])
                    except Exception:
                        try:
                            parsed = json.loads(raw)
                            reason_data = parsed if isinstance(parsed, list) else ([parsed] if isinstance(parsed, dict) else [])
                        except Exception:
                            reason_data = []
                flat_rows, all_keys = [], set()
                for entry in reason_data:
                    if not isinstance(entry, dict): continue
                    flat = {}
                    for k, v in entry.items():
                        if isinstance(v, dict):
                            for sk, sv in v.items():
                                flat[f"{k} — {sk}"] = sv; all_keys.add(f"{k} — {sk}")
                        else:
                            flat[k] = v; all_keys.add(k)
                    flat_rows.append(flat)
                case_key = ""
                if case_col and pd.notna(row.get(case_col)):
                    raw_case = str(row[case_col]).strip().lower()
                    case_key = "P" if raw_case.startswith("p") else ("N" if raw_case.startswith("n") else ("E" if raw_case.startswith("e") else ""))
                aug_modal_rows.append({
                    "base_query":  base_q, "aug_query": aug_q,
                    "reason_keys": list(all_keys), "reason_rows": flat_rows, "case_key": case_key,
                })

            html = []
            html.append("""
            <div style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:12px;margin-bottom:16px;">
                <div style="display:flex;align-items:center;gap:10px;flex-wrap:wrap;">
                    <span style="font-size:0.82rem;font-weight:700;color:#555;margin-right:4px;">Legend:</span>
                    <span style="display:inline-flex;align-items:center;gap:6px;padding:4px 12px;border-radius:20px;background:#E3F2FD;color:#1565C0;border:1px solid #1565C0;font-size:0.82rem;font-weight:700;"><b>P</b> = Positive</span>
                    <span style="display:inline-flex;align-items:center;gap:6px;padding:4px 12px;border-radius:20px;background:#FFEBEE;color:#B71C1C;border:1px solid #B71C1C;font-size:0.82rem;font-weight:700;"><b>N</b> = Negative</span>
                    <span style="display:inline-flex;align-items:center;gap:6px;padding:4px 12px;border-radius:20px;background:#E8F5E9;color:#1B5E20;border:1px solid #1B5E20;font-size:0.82rem;font-weight:700;"><b>E</b> = Edge</span>
                </div>
                <div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap;">
                    <span style="font-size:0.82rem;font-weight:700;color:#555;">Filter:</span>
                    <button onclick="filterAugTable('ALL')" id="aug-filter-ALL" style="padding:5px 14px;border-radius:20px;border:2px solid #2E86AB;background:#2E86AB;color:white;cursor:pointer;font-size:0.82rem;font-weight:700;">All</button>
                    <button onclick="filterAugTable('P')"   id="aug-filter-P"   style="padding:5px 14px;border-radius:20px;border:2px solid #1565C0;background:white;color:#1565C0;cursor:pointer;font-size:0.82rem;font-weight:700;">Positive</button>
                    <button onclick="filterAugTable('N')"   id="aug-filter-N"   style="padding:5px 14px;border-radius:20px;border:2px solid #B71C1C;background:white;color:#B71C1C;cursor:pointer;font-size:0.82rem;font-weight:700;">Negative</button>
                    <button onclick="filterAugTable('E')"   id="aug-filter-E"   style="padding:5px 14px;border-radius:20px;border:2px solid #1B5E20;background:white;color:#1B5E20;cursor:pointer;font-size:0.82rem;font-weight:700;">Edge</button>
                </div>
            </div>""")

            html.append('<div id="augTableContainer"><div class="table-container"><table class="modern-table" id="augMainTable"><thead><tr>')
            for col in display_cols:
                html.append(f'<th>{col.replace("_"," ").title()}</th>')
            html.append('<th>Details</th></tr></thead><tbody id="augTableBody">')

            for i, (_, row) in enumerate(df.iterrows()):
                base_query = str(row[base_col]) if base_col and pd.notna(row.get(base_col)) else ""
                aug_query  = str(row[aug_col])  if aug_col  and pd.notna(row.get(aug_col))  else ""
                case_key   = aug_modal_rows[i]["case_key"]
                badge_html = ""
                if case_key in case_styles:
                    label, fg, bg = case_styles[case_key]
                    badge_html = (f"<span style='display:inline-block;padding:2px 8px;border-radius:4px;"
                                  f"font-size:0.75rem;font-weight:800;background:{bg};color:{fg};"
                                  f"border:1px solid {fg};line-height:1.4;'>{label}</span>")
                html.append(f'<tr data-case="{case_key}">')
                for col in display_cols:
                    val = row.get(col, "")
                    if col == aug_col:
                        diff_html = self._highlight_diff(base_query, aug_query)
                        cell_content = (f"<div style='position:relative;min-height:24px;'>"
                                        f"<div style='position:absolute;top:0;right:0;line-height:1;'>{badge_html}</div>"
                                        f"<div style='padding-right:36px;'>{diff_html}</div></div>") if badge_html else diff_html
                        html.append(f'<td>{cell_content}</td>')
                    else:
                        html.append(f'<td>{"N/A" if pd.isna(val) else str(val)}</td>')
                html.append(f'<td style="text-align:center;"><button onclick="openAugModal({i})" style="padding:5px 14px;background:#2E86AB;color:white;border:none;border-radius:6px;cursor:pointer;font-weight:600;">Show</button></td>')
                html.append('</tr>')

            html.append('</tbody></table></div></div>')

            counts = {"ALL": len(aug_modal_rows), "P": 0, "N": 0, "E": 0}
            for r in aug_modal_rows:
                if r["case_key"] in counts: counts[r["case_key"]] += 1

            html.append(f"""
            <div id="augDetailModal" class="modal" style="z-index:1100;">
                <div class="modal-content" style="max-width:1000px;">
                    <div class="modal-header">
                        <h3 class="modal-title">Augmentation Details</h3>
                        <button class="modal-close" onclick="closeAugModal()">x</button>
                    </div>
                    <div class="modal-body" style="flex-direction:column;overflow-y:auto;max-height:75vh;padding:25px;display:block;">
                        <div class="modal-section"><h4>Base Query</h4><p id="augBaseQuery">N/A</p></div>
                        <div class="modal-section"><h4>Augmented Output</h4><p id="augAugQuery">N/A</p></div>
                        <div class="collapsible-section" id="augTracebackSection">
                            <div class="collapsible-header" onclick="toggleCollapsible('augTraceback')">
                                <h4>Traceback</h4>
                                <span class="toggle-icon" id="augTracebackIcon">&#9660;</span>
                            </div>
                            <div class="collapsible-content collapsed" id="augTracebackContent">
                                <div id="augTracebackTable"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <script>
            const AUG_MODAL_DATA = {json.dumps(aug_modal_rows, default=str)};
            const AUG_COUNTS     = {json.dumps(counts)};
            var currentAugFilter = 'ALL';
            document.addEventListener('DOMContentLoaded', function() {{
                var btnAll=document.getElementById('aug-filter-ALL'); if(btnAll) btnAll.textContent='All ('+AUG_COUNTS['ALL']+')';
                var btnP  =document.getElementById('aug-filter-P');   if(btnP)   btnP.textContent  ='Positive ('+AUG_COUNTS['P']+')';
                var btnN  =document.getElementById('aug-filter-N');   if(btnN)   btnN.textContent  ='Negative ('+AUG_COUNTS['N']+')';
                var btnE  =document.getElementById('aug-filter-E');   if(btnE)   btnE.textContent  ='Edge ('+AUG_COUNTS['E']+')';
            }});
            function filterAugTable(caseKey) {{
                currentAugFilter = caseKey;
                var filters = {{'ALL':{{bg:'#2E86AB',fg:'white',border:'#2E86AB'}},'P':{{bg:'#1565C0',fg:'white',border:'#1565C0'}},'N':{{bg:'#B71C1C',fg:'white',border:'#B71C1C'}},'E':{{bg:'#1B5E20',fg:'white',border:'#1B5E20'}}}};
                var inactive= {{'ALL':{{bg:'white',fg:'#2E86AB',border:'#2E86AB'}},'P':{{bg:'white',fg:'#1565C0',border:'#1565C0'}},'N':{{bg:'white',fg:'#B71C1C',border:'#B71C1C'}},'E':{{bg:'white',fg:'#1B5E20',border:'#1B5E20'}}}};
                ['ALL','P','N','E'].forEach(function(k){{
                    var btn=document.getElementById('aug-filter-'+k); if(!btn) return;
                    var s=k===caseKey?filters[k]:inactive[k];
                    btn.style.background=s.bg; btn.style.color=s.fg; btn.style.borderColor=s.border;
                }});
                document.querySelectorAll('#augTableBody tr').forEach(function(row){{
                    row.style.display=(caseKey==='ALL'||row.getAttribute('data-case')===caseKey)?'':'none';
                }});
            }}
            function openAugModal(idx) {{
                var d=AUG_MODAL_DATA[idx]; if(!d) return;
                document.getElementById('augBaseQuery').innerHTML=d.base_query||'N/A';
                document.getElementById('augAugQuery').innerHTML =d.aug_query ||'N/A';
                var tbTable=document.getElementById('augTracebackTable');
                var tbSection=document.getElementById('augTracebackSection');
                tbTable.innerHTML='';
                if(!d.reason_rows||d.reason_rows.length===0){{ tbSection.style.display='none'; }}
                else{{
                    tbSection.style.display='';
                    var keys=d.reason_keys;
                    var tHtml='<table class="metric-table"><thead><tr>';
                    keys.forEach(function(k){{tHtml+='<th>'+k.replace(/_/g,' ')+'</th>';}});
                    tHtml+='</tr></thead><tbody>';
                    d.reason_rows.forEach(function(row){{
                        tHtml+='<tr>';
                        keys.forEach(function(k){{var v=row[k]; tHtml+='<td>'+(v===null||v===undefined?'N/A':String(v))+'</td>';}});
                        tHtml+='</tr>';
                    }});
                    tHtml+='</tbody></table>';
                    tbTable.innerHTML=tHtml;
                    var content=document.getElementById('augTracebackContent');
                    var icon   =document.getElementById('augTracebackIcon');
                    if(content) content.classList.add('collapsed');
                    if(icon)    icon.classList.remove('expanded');
                }}
                document.getElementById('augDetailModal').style.display='block';
            }}
            function closeAugModal(){{ document.getElementById('augDetailModal').style.display='none'; }}
            window.addEventListener('click',function(e){{ var m=document.getElementById('augDetailModal'); if(e.target===m) closeAugModal(); }});
            </script>""")

            return '\n'.join(html)

        except Exception as e:
            logger.error(f"Error generating augmentation table: {e}")
            return f"<div class='alert alert-error'>Error generating table: {e}</div>"

    def _generate_pagination_controls(self) -> str:
        return """
        <div class="pagination-container">
            <div class="pagination-controls">
                <select id="rowsPerPage" class="rows-selector" onchange="changeRowsPerPage()">
                    <option value="10">10 rows/page</option>
                    <option value="25">25 rows/page</option>
                    <option value="50">50 rows/page</option>
                    <option value="100">100 rows/page</option>
                </select>
            </div>
            <div class="pagination-controls" id="paginationButtons"></div>
            <div class="page-info"><span id="pageInfo">Page 1 of 1</span></div>
        </div>"""

    def _generate_secondary_pagination_controls(self) -> str:
        return """
        <div class="pagination-container">
            <div class="pagination-controls">
                <select id="secondaryRowsPerPage" class="rows-selector" onchange="secondaryChangeRowsPerPage()">
                    <option value="10">10 rows/page</option>
                    <option value="25">25 rows/page</option>
                    <option value="50">50 rows/page</option>
                    <option value="100">100 rows/page</option>
                </select>
            </div>
            <div class="pagination-controls" id="secondaryPaginationButtons"></div>
            <div class="page-info"><span id="secondaryPageInfo">Page 1 of 1</span></div>
        </div>"""

    def _generate_table_javascript(self, df: pd.DataFrame, metrics: List[str]) -> str:
        try:
            table_data = []
            for idx, row in df.iterrows():
                question_short = str(row.get('Query', 'N/A')).replace('\\n','<br>').replace('\n','<br>')
                response_short = self._truncate_text(str(row.get('Response', 'N/A')), 100).replace('\\n','<br>').replace('\n','<br>')
                tc_id          = str(row.get('TC ID', 'N/A'))
                metric_cells   = {}
                for metric in metrics:
                    status = row.get(f"{metric}_status", 'Unknown')
                    score  = row.get(metric, 'N/A')
                    formatted_score = f'{score:.2f}' if pd.notna(score) and isinstance(score, (int, float)) else (str(score) if score != 'N/A' else 'N/A')
                    css_class = 'status-warning' if pd.isna(score) else ('status-passed' if str(status).lower()=='passed' else ('status-failed' if str(status).lower()=='failed' else ('status-skipped' if str(status).lower()=='skipped' else 'status-unknown')))
                    metric_cells[metric.strip()] = {'value': formatted_score, 'status': status, 'class': css_class, 'clickable': True}
                table_data.append({'index': int(idx), 'tc_id': tc_id, 'query': question_short, 'response': response_short, 'metrics': metric_cells})

            return f"""
            <script>
            let currentPage = 1, rowsPerPage = 10, totalRows = 0;
            let allTableData = {json.dumps(table_data)};
            let allMetrics   = {json.dumps(metrics)};

            function initializeTable() {{ totalRows = allTableData.length; displayPage(); }}

            function displayPage() {{
                const startIdx = (currentPage-1)*rowsPerPage;
                const endIdx   = Math.min(startIdx+rowsPerPage, totalRows);
                const tbody    = document.getElementById('tableBody');
                if (!tbody) return;
                let html = '';
                for (let i = startIdx; i < endIdx; i++) {{
                    const rowData = allTableData[i];
                    const rowNum  = (currentPage-1)*rowsPerPage + (i-startIdx) + 1;
                    html += '<tr>';
                    html += `<td style="position:sticky;left:0;z-index:5;background:#f8f9fa;text-align:center;font-weight:700;color:#555;border-right:2px solid #dee2e6;min-width:50px;">${{rowNum}}</td>`;
                    html += `<td>${{rowData.tc_id}}</td>`;
                    html += `<td>${{rowData.query}}</td>`;
                    html += `<td>${{rowData.response}}</td>`;
                    allMetrics.forEach(metric => {{
                        const md = rowData.metrics[metric] || {{value:"N/A",status:"Skipped",class:"status-skipped",clickable:false}};
                        if (md.clickable) {{
                            html += `<td class="text-center"><span class="status-cell ${{md.class}}" onclick="openModal(${{rowData.index}},'${{metric}}')" title="Click for details">${{md.value}}</span></td>`;
                        }} else {{
                            html += `<td class="text-center"><span class="status-cell status-skipped">N/A</span></td>`;
                        }}
                    }});
                    html += '</tr>';
                }}
                tbody.innerHTML = html;
                updatePaginationInfo();
            }}

            function updatePaginationInfo() {{
                const totalPages = Math.ceil(totalRows/rowsPerPage);
                const el = document.getElementById('pageInfo');
                if (el) el.textContent = `Page ${{currentPage}} of ${{totalPages}} (Showing ${{Math.min(rowsPerPage, totalRows-(currentPage-1)*rowsPerPage)}} of ${{totalRows}} records)`;
                const container = document.getElementById('paginationButtons');
                if (container) container.innerHTML = `
                    <button class="page-btn" onclick="previousPage()" ${{currentPage===1?"disabled":""}}>Prev</button>
                    <span class="page-btn disabled">${{currentPage}} / ${{totalPages}}</span>
                    <button class="page-btn" onclick="nextPage()" ${{currentPage===totalPages?"disabled":""}}>Next</button>`;
            }}

            function nextPage() {{ if (currentPage < Math.ceil(totalRows/rowsPerPage)) {{ currentPage++; displayPage(); }} }}
            function previousPage() {{ if (currentPage > 1) {{ currentPage--; displayPage(); }} }}
            function changeRowsPerPage() {{
                const s = document.getElementById('rowsPerPage');
                if (s) {{ rowsPerPage = parseInt(s.value); currentPage = 1; displayPage(); }}
            }}
            document.addEventListener('DOMContentLoaded', initializeTable);
            document.addEventListener('DOMContentLoaded', () => {{
                const table = document.querySelector(".details-table");
                if (!table) return;
                table.querySelectorAll("th").forEach((th, index) => {{
                    const resizer = document.createElement("div");
                    resizer.className = "resizer";
                    th.appendChild(resizer);
                    let startX, startWidth;
                    resizer.addEventListener("mousedown", (e) => {{
                        startX = e.pageX; startWidth = th.offsetWidth;
                        document.addEventListener("mousemove", onMouseMove);
                        document.addEventListener("mouseup", onMouseUp);
                    }});
                    function onMouseMove(e) {{
                        const nw = startWidth + (e.pageX - startX);
                        if (nw > 50) {{
                            th.style.width = nw + "px";
                            table.querySelectorAll("tr").forEach(r => {{ const c = r.children[index]; if(c) c.style.width = nw+"px"; }});
                        }}
                    }}
                    function onMouseUp() {{
                        document.removeEventListener("mousemove", onMouseMove);
                        document.removeEventListener("mouseup", onMouseUp);
                    }}
                }});
            }});
            </script>"""
        except Exception as e:
            logger.error(f"Error generating table JavaScript: {e}")
            return f"<script>console.error('Error: {e}');</script>"

    def _generate_secondary_llm_javascript(self, df: pd.DataFrame, metrics: List[str]) -> str:
        try:
            table_data = []
            for idx, row in df.iterrows():
                question_short = str(row.get('Query','N/A')).replace('\\n','<br>').replace('\n','<br>')
                response_short = self._truncate_text(str(row.get('Response','N/A')),100).replace('\\n','<br>').replace('\n','<br>')
                query_key      = self._normalize_query_match(question_short)
                metric_cells   = {}
                for metric in metrics:
                    status = row.get(f"{metric}_status",'Unknown')
                    score  = row.get(metric,'N/A')
                    formatted_score = f'{score:.2f}' if pd.notna(score) and isinstance(score,(int,float)) else (str(score) if score!='N/A' else 'N/A')
                    css_class = 'status-warning' if pd.isna(score) else ('status-passed' if str(status).lower()=='passed' else ('status-failed' if str(status).lower()=='failed' else ('status-skipped' if str(status).lower()=='skipped' else 'status-unknown')))
                    metric_cells[metric.strip()] = {'value':formatted_score,'status':status,'class':css_class,'clickable':True}
                table_data.append({'index':int(idx),'query':question_short,'query_key':query_key,'response':response_short,'metrics':metric_cells})

            secondary_meta_map = {}
            try:
                base_dir      = Path(__file__).resolve().parent
                fallback_path = base_dir / "Metrics_template02.xlsx"
                if fallback_path.exists():
                    xls = pd.ExcelFile(fallback_path)
                    if "Secondary LLM" in xls.sheet_names:
                        sec_df = pd.read_excel(xls, sheet_name="Secondary LLM")
                        sec_df = sec_df.rename(columns=lambda c: str(c).strip())
                        for _, srow in sec_df.iterrows():
                            eval_name  = str(srow.get("Eval_Name","")).strip()
                            query_val  = str(srow.get("Query","")).strip()
                            if not eval_name: continue
                            metric_key = eval_name.strip().lower()
                            qkey       = self._normalize_query_match(query_val)
                            meta = {}
                            for col in sec_df.columns:
                                if str(col).strip().lower() in ("eval_name","trace_id"): continue
                                val = srow.get(col)
                                meta[col] = None if pd.isna(val) else val
                            existing = secondary_meta_map.setdefault(metric_key,{}).setdefault(qkey,[])
                            if meta.get("Few_Shot_Example"): existing.insert(0,meta)
                            else: existing.append(meta)
            except Exception as e:
                logger.warning(f"Unable to read Secondary LLM sheet: {e}")

            return f"""
                <script>
                let secondaryCurrentPage = 1, secondaryRowsPerPage = 10;
                const secondaryTableData = {json.dumps(table_data)};
                const secondaryMetaMap   = {json.dumps(secondary_meta_map)};
                let allSecondaryMetrics  = {json.dumps(metrics)};

                function renderSecondaryTable() {{
                    const tbody = document.getElementById("secondaryTableBody");
                    if (!tbody) return;
                    const start = (secondaryCurrentPage-1)*secondaryRowsPerPage;
                    const end   = Math.min(start+secondaryRowsPerPage, secondaryTableData.length);
                    let html = "";
                    for (let i = start; i < end; i++) {{
                        const row    = secondaryTableData[i];
                        const rowNum = (secondaryCurrentPage-1)*secondaryRowsPerPage + (i-start) + 1;
                        html += "<tr>";
                        html += `<td style="position:sticky;left:0;z-index:5;background:#f8f9fa;text-align:center;font-weight:700;color:#555;border-right:2px solid #dee2e6;min-width:50px;">${{rowNum}}</td>`;
                        html += `<td>${{row.query}}</td><td>${{row.response}}</td>`;
                        allSecondaryMetrics.forEach(metric => {{
                            const md = row.metrics[metric] || {{value:"N/A",class:"status-skipped",clickable:false}};
                            if (md.clickable) {{
                                html += `<td class="text-center"><span class="status-cell ${{md.class}}" onclick="openModal(${{row.index}},'${{metric}}')" title="Click for details">${{md.value}}</span></td>`;
                            }} else {{
                                html += `<td class="text-center"><span class="status-cell status-skipped">N/A</span></td>`;
                            }}
                            const metricMap = secondaryMetaMap[metric.toLowerCase()] || {{}};
                            const metaList  = metricMap[row.query_key] || [];
                            const meta      = metaList.length > 0 ? metaList[0] : null;
                            const errorType = (meta && meta.Error_Type != null && meta.Error_Type !== "") ? String(meta.Error_Type) : "none";
                            const btnClass  = errorType.toLowerCase() !== "none" ? "status-failed" : "status-passed";
                            const btnLabel  = errorType.toLowerCase() !== "none" ? errorType : "No Violation";
                            html += `<td class="text-center"><button class="status-cell ${{btnClass}}" onclick="openSecondaryModal(${{i}},'${{escapeHtml(metric)}}')" style="border:none;padding:8px 10px;border-radius:8px;">${{btnLabel}}</button></td>`;
                        }});
                        html += "</tr>";
                    }}
                    tbody.innerHTML = html;
                    const totalPages = Math.ceil(secondaryTableData.length/secondaryRowsPerPage);
                    document.getElementById("secondaryPageInfo").innerText = `Page ${{secondaryCurrentPage}} of ${{totalPages}}`;
                    const container = document.getElementById("secondaryPaginationButtons");
                    if (container) container.innerHTML = `
                        <button class="page-btn" onclick="secondaryPreviousPage()" ${{secondaryCurrentPage===1?"disabled":""}}>Prev</button>
                        <span class="page-btn disabled">${{secondaryCurrentPage}} / ${{totalPages}}</span>
                        <button class="page-btn" onclick="secondaryNextPage()" ${{secondaryCurrentPage===totalPages?"disabled":""}}>Next</button>`;
                }}
                function secondaryNextPage() {{ if (secondaryCurrentPage < Math.ceil(secondaryTableData.length/secondaryRowsPerPage)) {{ secondaryCurrentPage++; renderSecondaryTable(); }} }}
                function secondaryPreviousPage() {{ if (secondaryCurrentPage > 1) {{ secondaryCurrentPage--; renderSecondaryTable(); }} }}
                function secondaryChangeRowsPerPage() {{
                    const s = document.getElementById("secondaryRowsPerPage");
                    secondaryRowsPerPage = parseInt(s.value); secondaryCurrentPage = 1; renderSecondaryTable();
                }}
                function openSecondaryModal(rowIndex, metricName) {{
                    const modal = document.getElementById('detailModal');
                    if (!modal) return;
                    modal.querySelectorAll('.modal-left .modal-section').forEach(s => s.style.display = 'none');
                    const col = modal.querySelector('.collapsible-section');
                    if (col) col.style.display = 'none';
                    document.getElementById("scoreReasonBlock").style.display = "none";
                    document.getElementById("metricContainer").style.display  = "none";
                    document.getElementById("secondaryContainer").style.display = "block";
                    document.getElementById("rcaContainer").style.display = "none";
                    document.getElementById("tracebackFields").innerHTML  = "";
                    document.getElementById("metricSheetFields").innerHTML = "";
                    document.getElementById("rcaContainer").innerHTML = "";
                    document.getElementById('modalTitle').textContent    = metricName + ' - Secondary LLM Details';
                    document.getElementById('modalSubtitle').textContent = '';
                    const container = document.getElementById('secondaryContainer');
                    container.innerHTML = '';
                    const row  = secondaryTableData[rowIndex];
                    const qKey = row.query_key;
                    const metricMap = secondaryMetaMap[metricName.toLowerCase()] || {{}};
                    const metaList  = metricMap[qKey] || [];
                    if (metaList.length === 0) {{
                        const section = document.createElement('div');
                        section.className = 'modal-section';
                        section.innerHTML = '<h4>No metadata</h4><p>N/A</p>';
                        container.appendChild(section);
                    }} else {{
                        metaList.forEach((meta, idx) => {{
                            const keys = Object.keys(meta || {{}}).filter(k => k && k.toLowerCase() !== 'eval_name' && k.toLowerCase() !== 'trace_id');
                            if (keys.length === 0) {{
                                const section = document.createElement('div');
                                section.className = 'modal-section';
                                section.innerHTML = `<h4>Row ${{idx+1}}</h4><p>N/A</p>`;
                                container.appendChild(section);
                            }} else {{
                                keys.forEach(k => {{
                                    let v = meta[k];
                                    const section = document.createElement('div');
                                    section.className = 'modal-section';
                                    const heading = document.createElement('h4');
                                    heading.textContent = String(k).replace(/_/g,' ');
                                    section.appendChild(heading);
                                    const content = document.createElement('div');
                                    if (v === null || v === undefined) {{ content.innerHTML = '<p>N/A</p>'; }}
                                    else if (typeof v === 'object') {{ content.innerHTML = `<pre>${{escapeHtml(JSON.stringify(v,null,2)).replace(/\\n/g,"<br>")}}</pre>`; }}
                                    else {{ content.innerHTML = `<p>${{escapeHtml(String(v)).replace(/\\n/g,"<br>")}}</p>`; }}
                                    section.appendChild(content);
                                    container.appendChild(section);
                                }});
                            }}
                        }});
                    }}
                    modal.style.display = 'block';
                }}
                function escapeHtml(str) {{
                    if (str === null || str === undefined) return '';
                    return String(str).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#39;');
                }}
                document.addEventListener("DOMContentLoaded", renderSecondaryTable);
                </script>"""
        except Exception as e:
            logger.error(f"Error generating secondary llm javascript: {e}")
            return f"<script>console.error('Error: {e}');</script>"

    # ==================== HTML GENERATION ====================

    def _generate_modern_html(self, metrics_df: pd.DataFrame, details_df: pd.DataFrame,
                               all_metrics: List[str], charts: Dict[str, str], modal_data: Dict) -> str:
        try:
            metrics_count        = metrics_df['Metrics'].notna().sum()
            all_metrics          = [str(m).strip() for m in all_metrics]
            recovery_global_data = self._load_recovery_loop_global()

            html_content = f"""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{self.config['title']}</title>
    <style>{self._get_modern_css()}</style>
    <script src="https://cdn.plot.ly/plotly-latest.min.js"></script>
</head>
<body>
<div class="container">
    <div class="report-header">
        <div class="report-timestamp">Generated: {self.report_timestamp}</div>
        <h1 class="report-title">{self.config['title']}</h1>
        <h2 class="report-subtitle">{self.config['subtitle']}</h2>
        <p class="report-description">{self.config['description']}</p>
    </div>

    <nav class="tab-navigation">
        <button class="tab-button active" onclick="showTab('metrics', event)">📊 Metrics Summary ({metrics_count})</button>
        <button class="tab-button" onclick="showTab('analytics', event)">📈 Data Assurance</button>
        <button class="tab-button" onclick="showTab('details', event)">🔍 Model Quality Assurance</button>
        <button class="tab-button" onclick="showTab('trustworthy', event)">🛡️ Trustworthy Assurance</button>
        <button class="tab-button" onclick="showTab('secondary_llm', event)">🤖 Secondary LLM</button>
    </nav>

    <!-- Trustworthy sub-nav -->
    <div id="trustworthy_subtabs" style="display:none;flex-direction:row;gap:0;border-bottom:2px solid #e2e8f0;margin-bottom:24px;position:relative;z-index:10;">
        <button id="tw-btn-bias-func" onclick="showTWTab(&quot;tw_bias_func&quot;)" style="padding:10px 22px;font-size:0.88rem;font-weight:700;border:none;background:transparent;cursor:pointer;border-bottom:3px solid #2E86AB;color:#2E86AB;">⚖️ Bias Evaluation Functional</button>
        <button id="tw-btn-explain"   onclick="showTWTab(&quot;tw_explain&quot;)"   style="padding:10px 22px;font-size:0.88rem;font-weight:700;border:none;background:transparent;cursor:pointer;border-bottom:3px solid transparent;color:#718096;">💡 Explainability Evaluation</button>
        <button id="tw-btn-trust"     onclick="showTWTab(&quot;tw_trust&quot;)"     style="padding:10px 22px;font-size:0.88rem;font-weight:700;border:none;background:transparent;cursor:pointer;border-bottom:3px solid transparent;color:#718096;">🔒 Trust Metric Evaluation</button>
    </div>

    <!-- Data Assurance sub-nav -->
    <div id="analytics_subtabs" style="display:none;flex-direction:row;gap:0;border-bottom:2px solid #e2e8f0;margin-bottom:24px;position:relative;z-index:10;">
        <button id="da-btn-analytics"     onclick="showDATab('analytics_analytics')"    style="padding:10px 22px;font-size:0.88rem;font-weight:700;border:none;background:transparent;cursor:pointer;border-bottom:3px solid #2E86AB;color:#2E86AB;">📊 Analytics Dashboard</button>
        <button id="da-btn-augmentation"  onclick="showDATab('analytics_augmentation')" style="padding:10px 22px;font-size:0.88rem;font-weight:700;border:none;background:transparent;cursor:pointer;border-bottom:3px solid transparent;color:#718096;">✨ Augmentation</button>
    </div>

    <!-- Model Quality Assurance sub-nav -->
    <div id="details_subtabs" style="display:none;flex-direction:row;gap:0;border-bottom:2px solid #e2e8f0;margin-bottom:24px;position:relative;z-index:10;">
        <button id="mqa-btn-analytics"   onclick="showMQATab('details_analytics')"   style="padding:10px 22px;font-size:0.88rem;font-weight:700;border:none;background:transparent;cursor:pointer;border-bottom:3px solid transparent;color:#718096;">📊 Analytics Dashboard</button>
        <button id="mqa-btn-results"     onclick="showMQATab('details_results')"     style="padding:10px 22px;font-size:0.88rem;font-weight:700;border:none;background:transparent;cursor:pointer;border-bottom:3px solid #2E86AB;color:#2E86AB;">🔍 Detailed Results</button>
        <button id="mqa-btn-aggregated"  onclick="showMQATab('details_aggregated')"  style="padding:10px 22px;font-size:0.88rem;font-weight:700;border:none;background:transparent;cursor:pointer;border-bottom:3px solid transparent;color:#718096;">📋 Aggregated Results</button>
    </div>

    <main>
        <!-- METRICS SUMMARY -->
        <div id="metrics" class="tab-content active">
            <div class="card"><div class="card-content">
                {self._generate_metrics_summary_table(metrics_df)}
            </div></div>
        </div>

        <!-- DATA ASSURANCE -->
        <div id="analytics" class="tab-content">
            <div id="analytics_analytics" class="sub-tab-content active">
                <div class="chart-card full-width">
                    <div class="card-header" style="display:flex;justify-content:space-between;align-items:center;">
                        <h3>📦 Data Coverage</h3>
                        <button onclick="openCoverageEdit()" style="background:rgba(255,255,255,0.2);border:1px solid rgba(255,255,255,0.5);color:white;padding:6px 16px;border-radius:6px;cursor:pointer;font-size:0.85rem;font-weight:600;"
                            onmouseover="this.style.background='rgba(255,255,255,0.35)'"
                            onmouseout="this.style.background='rgba(255,255,255,0.2)'">✏️ Edit</button>
                    </div>
                    <div class="card-content">{charts.get('coverage','<div>No coverage data</div>')}</div>
                </div>
            </div>
            <div id="analytics_augmentation" class="sub-tab-content">
                {charts.get('augmentation','<div>No augmentation data</div>')}
            </div>
        </div>

        <!-- MODEL QUALITY ASSURANCE -->
        <div id="details" class="tab-content">
            <div id="details_analytics" class="sub-tab-content">
                <div class="charts-grid">
                    <div class="chart-card"><div class="card-header"><h3>🎯 Overall Performance Distribution</h3></div><div class="card-content">{charts.get('overall','<div>No data</div>')}</div></div>
                    <div class="chart-card"><div class="card-header"><h3>📊 Metrics Performance Comparison</h3></div><div class="card-content"><div style="overflow-x:auto;width:100%;">{charts.get('comparison','<div>No data</div>')}</div></div></div>
                    <div class="chart-card full-width"><div class="card-header"><h3>📋 Metrics Overview by Status</h3></div><div class="card-content"><div style="overflow-x:auto;width:100%;">{charts.get('metrics','<div>No data</div>')}</div></div></div>
                    <div class="chart-card full-width">
                        <div class="card-header"><h3>🔁 Run Comparison</h3></div>
                        <div class="card-content">
                            <input type="file" id="prevRun"><input type="file" id="currRun"><br><br>
                            <button onclick="uploadRuns()">Compare Runs</button>
                            <div id="runComparisonResult" style="margin-top:20px;"><i>Upload files to compare runs</i></div>
                        </div>
                    </div>
                    <div class="chart-card full-width"><div class="card-content">{charts.get('disaggregated','<div>No data</div>')}</div></div>
                </div>
            </div>
            <div id="details_results" class="sub-tab-content active">
                <div class="card-content p-0">{self._generate_interactive_details_table(details_df, all_metrics)}</div>
            </div>
            <div id="details_aggregated" class="sub-tab-content">
                <div class="card-content">
                    {self._generate_aggregated_results_tab(recovery_global_data)}
                </div>
            </div>
        </div>

        <!-- TRUSTWORTHY ASSURANCE -->
        <div id="trustworthy" class="tab-content">
            <div id="tw_bias_func" class="sub-tab-content" style="display:block;">
                <div class="card-content p-0">
                    {self._generate_trustworthy_table('logistics_bias_evaluation_dataset.xlsx', 'Bias Evaluation', 'twBiasFunc', auto_render=True)}
                </div>
            </div>
            <div id="tw_explain" class="sub-tab-content" style="display:none;">
                <div class="card-content p-0">
                    {self._generate_trustworthy_table('logistics_explainability_dataset.xlsx', 'Explainability Dataset', 'twExplain')}
                </div>
            </div>
            <div id="tw_trust" class="sub-tab-content" style="display:none;">
                <div class="card-content p-0">
                    {self._generate_trustworthy_table('logistics_bias_evaluation_dataset.xlsx', 'Trust Details', 'twTrust')}
                </div>
            </div>
        </div>

        <!-- SECONDARY LLM -->
        <div id="secondary_llm" class="tab-content">
            <div class="card-content">{self._generate_secondary_llm_table(details_df, all_metrics)}</div>
        </div>
    </main>
</div>

{self._generate_modern_modal()}

<!-- Coverage Edit Modal -->
<div id="coverageEditModal" class="modal">
    <div class="modal-content" style="max-width:900px;">
        <div class="modal-header">
            <h3 class="modal-title">✏️ Edit Data Coverage</h3>
            <button class="modal-close" onclick="closeCoverageEdit()">×</button>
        </div>
        <div class="modal-body" style="padding:25px;overflow-y:auto;flex-direction:column;">
            <div id="coverageEditTableWrapper" style="overflow-x:auto;width:100%;"></div>
            <div style="display:flex;justify-content:flex-end;gap:12px;margin-top:20px;">
                <button onclick="closeCoverageEdit()" style="padding:8px 20px;border-radius:6px;border:1px solid #ccc;cursor:pointer;background:white;">Cancel</button>
                <button onclick="saveCoverageEdit()" style="padding:8px 20px;border-radius:6px;border:none;cursor:pointer;background:#2E86AB;color:white;font-weight:600;">Save Changes</button>
            </div>
        </div>
    </div>
</div>

<script>
    const modalData          = {json.dumps(modal_data, default=str)};
    const config             = {json.dumps(self.config, default=str)};
    const COVERAGE_EDIT_DATA = {json.dumps(self._get_coverage_edit_data(), default=str)};

    function showTab(tabName, event) {{
        document.querySelectorAll('.tab-content').forEach(t => {{ t.classList.remove('active'); t.style.display='none'; }});
        document.querySelectorAll('.tab-button').forEach(b => b.classList.remove('active'));
        const sel = document.getElementById(tabName);
        if (sel) {{ sel.classList.add('active'); sel.style.display='block'; }}
        if (event && event.target) event.target.classList.add('active');
        const aSubs = document.getElementById('analytics_subtabs');
        const dSubs = document.getElementById('details_subtabs');
        const tSubs = document.getElementById('trustworthy_subtabs');
        if (aSubs) aSubs.style.display = tabName==='analytics'   ? 'flex' : 'none';
        if (dSubs) dSubs.style.display = tabName==='details'     ? 'flex' : 'none';
        if (tSubs) tSubs.style.display = tabName==='trustworthy' ? 'flex' : 'none';
        if (tabName==='analytics')   showDATab('analytics_analytics');
        if (tabName==='details')     showMQATab('details_results');
        if (tabName==='trustworthy') showTWTab('tw_bias_func');
    }}

    function showDATab(tabName) {{
        ['analytics_analytics','analytics_augmentation'].forEach(function(id) {{
            var el = document.getElementById(id);
            if (el) {{ el.style.display = id===tabName ? 'block':'none'; el.classList.toggle('active', id===tabName); }}
        }});
        document.getElementById('da-btn-analytics').style.borderBottomColor    = tabName==='analytics_analytics'   ? '#2E86AB':'transparent';
        document.getElementById('da-btn-analytics').style.color                = tabName==='analytics_analytics'   ? '#2E86AB':'#718096';
        document.getElementById('da-btn-augmentation').style.borderBottomColor = tabName==='analytics_augmentation'? '#2E86AB':'transparent';
        document.getElementById('da-btn-augmentation').style.color             = tabName==='analytics_augmentation'? '#2E86AB':'#718096';
    }}

    function showMQATab(tabName) {{
        ['details_analytics','details_results','details_aggregated'].forEach(function(id) {{
            var el = document.getElementById(id);
            if (el) {{ el.style.display = id===tabName ? 'block':'none'; el.classList.toggle('active', id===tabName); }}
        }});
        var btnMap = {{
            'details_analytics':  'mqa-btn-analytics',
            'details_results':    'mqa-btn-results',
            'details_aggregated': 'mqa-btn-aggregated'
        }};
        Object.keys(btnMap).forEach(function(tab) {{
            var btn = document.getElementById(btnMap[tab]);
            if (btn) {{
                btn.style.borderBottomColor = tab===tabName ? '#2E86AB':'transparent';
                btn.style.color             = tab===tabName ? '#2E86AB':'#718096';
            }}
        }});
    }}

    function showTWTab(tabName) {{
        var tabs = ['tw_bias_func','tw_explain','tw_trust'];
        var btns = ['tw-btn-bias-func','tw-btn-explain','tw-btn-trust'];
        for (var i=0; i<tabs.length; i++) {{
            var el  = document.getElementById(tabs[i]);
            var btn = document.getElementById(btns[i]);
            if (el)  el.style.cssText = tabs[i]===tabName ? 'display:block !important;' : 'display:none !important;';
            if (btn) {{ btn.style.borderBottomColor = tabs[i]===tabName ? '#2E86AB':'transparent'; btn.style.color = tabs[i]===tabName ? '#2E86AB':'#718096'; }}
        }}
        var renderMap = {{'tw_bias_func':'renderTwBiasFunc','tw_explain':'renderTwExplain','tw_trust':'renderTwTrust'}};
        var fn = renderMap[tabName];
        if (fn && window[fn]) window[fn]();
    }}

    function closeModal()     {{ var m=document.getElementById('detailModal');    if(m) m.style.display='none'; }}
    function closeRcaOutput() {{ document.getElementById("rcaOutputModal").style.display="none"; }}
    function openRcaOutput(content) {{
        var el=document.getElementById("rcaOutputContent");
        if(!content||content==="{{}}"||content.trim()==="") {{ el.textContent="No Output Available"; el.classList.add("empty-json"); }}
        else {{ el.textContent=content; el.classList.remove("empty-json"); }}
        document.getElementById("rcaOutputModal").style.display="block";
    }}

    function toggleCollapsible(section) {{
        var content = document.getElementById(section+"Content");
        var icon    = document.getElementById(section+"Icon");
        if (!content||!icon) return;
        var collapsed = content.classList.contains("collapsed");
        if (collapsed) {{
            content.classList.remove("collapsed");
            icon.classList.add("expanded");
            // re-apply RCA diff when metricFields collapsible is opened
            if (section === 'metricFields') {{
                var titleEl = document.getElementById('modalTitle');
                if (titleEl && titleEl.textContent.toUpperCase().includes('RCA')) {{
                    setTimeout(function() {{ applyRcaDiff(); }}, 50);
                }}
            }}
        }} else {{
            content.classList.add("collapsed");
            icon.classList.remove("expanded");
        }}
    }}

    function escapeHtml(str) {{
        if (str===null||str===undefined) return '';
        return String(str).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#39;');
    }}

    // ── Word-level diff for RCA Expected Output vs Actual Output ──
    function diffWords(expected, actual) {{
        var expWords = String(expected || '').split(/\s+/).filter(Boolean);
        var actWords = String(actual   || '').split(/\s+/).filter(Boolean);
        var m = expWords.length, n = actWords.length;
        var dp = [];
        for (var i = 0; i <= m; i++) {{ dp[i] = []; for (var j = 0; j <= n; j++) dp[i][j] = 0; }}
        for (var i = 1; i <= m; i++) for (var j = 1; j <= n; j++)
            dp[i][j] = expWords[i-1]===actWords[j-1] ? dp[i-1][j-1]+1 : Math.max(dp[i-1][j], dp[i][j-1]);
        var ops = [], i = m, j = n;
        while (i > 0 || j > 0) {{
            if (i>0&&j>0&&expWords[i-1]===actWords[j-1]) {{ ops.unshift({{type:'equal',val:actWords[j-1]}}); i--; j--; }}
            else if (j>0&&(i===0||dp[i][j-1]>=dp[i-1][j])) {{ ops.unshift({{type:'added',val:actWords[j-1]}}); j--; }}
            else {{ ops.unshift({{type:'removed',val:expWords[i-1]}}); i--; }}
        }}
        var merged = [];
        ops.forEach(function(op) {{
            if (merged.length&&merged[merged.length-1].type===op.type) merged[merged.length-1].val+=' '+op.val;
            else merged.push({{type:op.type,val:op.val}});
        }});
        var expHtml = merged.map(function(op) {{
            if (op.type==='equal')   return escapeHtml(op.val);
            if (op.type==='removed') return "<span class='diff-removed'>"+escapeHtml(op.val)+"</span>";
            return '';
        }}).join(' ');
        var actHtml = merged.map(function(op) {{
            if (op.type==='equal') return escapeHtml(op.val);
            if (op.type==='added') return "<span class='diff-added'>"+escapeHtml(op.val)+"</span>";
            return '';
        }}).join(' ');
        return {{expectedHtml: expHtml, actualHtml: actHtml}};
    }}

    function applyRcaDiff() {{
        var modalLeft = document.querySelector('.modal-left');
        if (!modalLeft) return;
        var tables = modalLeft.querySelectorAll('table.metric-table');
        tables.forEach(function(table) {{
            var headers = Array.from(table.querySelectorAll('thead th')).map(function(th) {{ return th.textContent.trim().toLowerCase(); }});
            var expIdx = headers.findIndex(function(h) {{ return h === 'expected output'; }});
            var actIdx = headers.findIndex(function(h) {{ return h === 'actual output'; }});
            if (expIdx===-1||actIdx===-1) return;
            if (!table.previousElementSibling||!table.previousElementSibling.classList.contains('rca-diff-legend')) {{
                var legend = document.createElement('div');
                legend.className = 'rca-diff-legend';
                legend.innerHTML = '<span><span class="diff-removed">removed</span> In Expected but not in Actual</span>' +
                                   '<span><span class="diff-added">added</span> In Actual but not in Expected</span>';
                table.parentNode.insertBefore(legend, table);
            }}
            table.querySelectorAll('tbody tr').forEach(function(row) {{
                var cells = row.querySelectorAll('td');
                if (!cells[expIdx]||!cells[actIdx]) return;
                if (cells[expIdx].querySelector('.diff-removed,.diff-added')||cells[actIdx].querySelector('.diff-removed,.diff-added')) return;
                var expText = cells[expIdx].textContent.trim();
                var actText = cells[actIdx].textContent.trim();
                if (!expText||!actText||expText==='N/A'||actText==='N/A') return;
                var diff = diffWords(expText, actText);
                cells[expIdx].innerHTML = diff.expectedHtml;
                cells[actIdx].innerHTML = diff.actualHtml;
            }});
        }});
    }}

    function openModal(rowIndex, metricName) {{
        document.querySelectorAll(".modal-left .modal-section").forEach(el => el.style.display="block");
        document.getElementById("scoreReasonBlock").style.display  = "block";
        document.querySelector(".collapsible-section").style.display = "block";
        document.getElementById("rcaContainer").style.display      = "none";
        document.getElementById("secondaryContainer").style.display = "none";
        document.getElementById("metricContainer").style.display   = "block";
        document.getElementById("secondaryContainer").innerHTML = "";
        document.getElementById("rcaContainer").innerHTML      = "";

        const modal = document.getElementById('detailModal');
        if (!modal || !modalData[rowIndex]) return;
        const data           = modalData[rowIndex];
        const metricData     = data.metrics[metricName] || {{}};
        const metricSheetData= data.metric_fields?.[metricName] || {{}};

        const modalLeft = modal.querySelector('.modal-left');
        if (modalLeft) modalLeft.scrollTop = 0;

        const responseContent = document.getElementById('responseContent');
        const responseIcon    = document.getElementById('responseIcon');
        if (responseContent && responseIcon) {{
            responseContent.classList.add('collapsed');
            responseIcon.classList.remove('expanded');
            responseIcon.textContent = '▼';
        }}

        const updateEl = (id, content) => {{
            const el = document.getElementById(id);
            if (!el) return;
            el.innerHTML = (content===null||content===undefined||content==='') ? 'N/A' : content;
        }};
        updateEl('modalTitle',    metricName.replace(/_/g,' ').toUpperCase());
        updateEl('modalSubtitle', 'Threshold: ' + (metricData.threshold||'N/A'));
        updateEl('modalQuestion', data.query);
        updateEl('modalResponse', data.response);

        function parseVal(v) {{
            if (v==null) return v;
            let cur = v;
            for (let i=0; i<10; i++) {{
                if (typeof cur !== 'string') break;
                let s = cur.trim();
                if ((s.startsWith('"')&&s.endsWith('"'))||(s.startsWith("'")&&s.endsWith("'"))) s=s.slice(1,-1);
                if (s.includes('""')) s=s.replace(/""/g,'"');
                try {{ const p=JSON.parse(s); if(p===cur) break; cur=p; }} catch {{ break; }}
            }}
            return cur;
        }}
        function stripHtml(v) {{
            if (typeof v !== 'string') return v;
            const d=document.createElement('div'); d.innerHTML=v; return d.textContent||d.innerText||'';
        }}
        function hasDeepStructure(obj, depth=0) {{
            if (depth>1) return true;
            if (!obj||typeof obj!=='object') return false;
            if (Array.isArray(obj)) return obj.some(v=>hasDeepStructure(v,depth+1));
            return Object.values(obj).some(v=>hasDeepStructure(v,depth+1));
        }}
        function renderStatus(v) {{
            if (v==null) return 'N/A';
            const t=String(v).toLowerCase().trim();
            if (t==='pass'||t==='passed') {{ const b=document.createElement('span'); b.className='tb-badge tb-pass'; b.innerHTML='&#10004; Pass'; return b; }}
            if (t==='fail'||t==='failed') {{ const b=document.createElement('span'); b.className='tb-badge tb-fail'; b.innerHTML='&#10006; Fail'; return b; }}
            return stripHtml(v);
        }}

        // ── TRACEBACK ──
        let uniqueTracebacks = [];
        const tracebackContainer = document.getElementById('tracebackFields');
        if (tracebackContainer) tracebackContainer.innerHTML = '';

        if (tracebackContainer) {{
            let tbRows = Array.isArray(metricSheetData) ? metricSheetData : (metricSheetData && typeof metricSheetData==='object' ? [metricSheetData] : []);
            if (tbRows.length > 0) {{
                const TRACE_KEYS = Object.keys(tbRows[0]).filter(k => ['traceback','tracebacks'].includes(k.toLowerCase()));
                if (TRACE_KEYS.length > 0) {{
                    tbRows.forEach(row => {{
                        const obj={{}};
                        TRACE_KEYS.forEach(k => obj[k]=row[k]);
                        const s=JSON.stringify(obj);
                        if (!uniqueTracebacks.some(u=>JSON.stringify(u)===s)) uniqueTracebacks.push(obj);
                    }});

                    function flattenObject(obj, prefix='') {{
                        const result={{}};
                        Object.entries(obj).forEach(([key,value]) => {{
                            const fullKey = prefix ? prefix+'.'+key : key;
                            if (value&&typeof value==='object'&&!Array.isArray(value)) Object.assign(result, flattenObject(value,fullKey));
                            else result[fullKey]=value;
                        }});
                        return result;
                    }}

                    function createTracebackTable(data) {{
                        const table=document.createElement('table'); table.className='metric-table';
                        let allKeys=new Set(), flattened=[];
                        if (Array.isArray(data)) {{ data.forEach(item=>{{ const f=flattenObject(item); flattened.push(f); Object.keys(f).forEach(k=>allKeys.add(k)); }}); }}
                        else {{ const f=flattenObject(data); flattened.push(f); allKeys=new Set(Object.keys(f)); }}
                        const keys=Array.from(allKeys);
                        const thead=document.createElement('thead'); const trH=document.createElement('tr');
                        keys.forEach(k=>{{ const th=document.createElement('th'); th.textContent=k.replace(/_/g,' '); trH.appendChild(th); }});
                        thead.appendChild(trH); table.appendChild(thead);
                        const tbody=document.createElement('tbody');
                        flattened.forEach(row=>{{
                            const tr=document.createElement('tr');
                            keys.forEach(k=>{{
                                const td=document.createElement('td');
                                const val=row[k]; const rendered=renderStatus(val);
                                if (rendered instanceof HTMLElement) td.appendChild(rendered);
                                else td.textContent=rendered||'N/A';
                                tr.appendChild(td);
                            }});
                            tbody.appendChild(tr);
                        }});
                        table.appendChild(tbody); return table;
                    }}

                    uniqueTracebacks.forEach(row => {{
                        TRACE_KEYS.forEach(h => {{
                            const val = parseVal(row[h]);
                            if (val==null) return;
                            if (Array.isArray(val)&&val.length>0&&val[0]&&typeof val[0]==='object') {{
                                tracebackContainer.appendChild(createTracebackTable(val)); return;
                            }}
                            if (val&&typeof val==='object') {{
                                tracebackContainer.appendChild(createTracebackTable(val)); return;
                            }}
                        }});
                    }});
                }}
            }}
        }}

        const tbSection = document.getElementById('tracebackFields')?.closest('.collapsible-section');
        if (tracebackContainer && (!tracebackContainer.children.length || tracebackContainer.textContent.trim()===''||tracebackContainer.textContent.trim()==='N/A')) {{
            if (tbSection) tbSection.style.display='none';
        }} else {{ if (tbSection) tbSection.style.display=''; }}

        // ── METRIC FIELDS ──
        const metricFieldsContainer = document.getElementById('metricSheetFields');
        if (metricFieldsContainer) {{
            metricFieldsContainer.innerHTML = '';
            let rows = Array.isArray(metricSheetData) ? metricSheetData : (metricSheetData&&typeof metricSheetData==='object' ? [metricSheetData] : []);
            if (rows.length === 0) {{ metricFieldsContainer.innerHTML='<p>N/A</p>'; }}
            else {{
                if (metricName==="Hallucination CoVe") rows=rows.map(r=>{{ const c={{...r}}; delete c["Actual Output"]; return c; }});
                function normalizeVal(v) {{
                    if (v===null||v===undefined) return '';
                    if (typeof v==='string') return v.replace(/<[^>]*>/g,'').replace(/\\s+/g,' ').trim().toLowerCase();
                    return JSON.stringify(v);
                }}
                if (rows.length > 1) {{
                    const excludeKeys=new Set(['query','response','score','overall reason','overall_reason','overall score','overall_score','eval_name','timestamp','traceback','tracebacks']);
                    const allHeaders=Object.keys(rows[0]).filter(k=>!excludeKeys.has(k.toLowerCase()));
                    const constantCols=[], variableCols=[];
                    allHeaders.forEach(col=>{{
                        const firstVal=normalizeVal(rows[0][col]);
                        const same=rows.every(r=>normalizeVal(r[col])===firstVal);
                        const textLength=rows[0][col]?String(rows[0][col]).length:0;
                        if ((same&&textLength>=80)||col.toLowerCase().startsWith("overall")) constantCols.push(col);
                        else variableCols.push(col);
                    }});
                    constantCols.forEach((col,index)=>{{
                        const sId="constant_"+index;
                        const wrapper=document.createElement('div'); wrapper.className='collapsible-section';
                        const header=document.createElement('div'); header.className='collapsible-header';
                        header.setAttribute("onclick",`toggleCollapsible('${{sId}}')`);
                        const title=document.createElement('h4'); title.textContent=col.replace(/_/g,' ');
                        const icon=document.createElement('span'); icon.className='toggle-icon'; icon.id=sId+"Icon"; icon.textContent="▼";
                        header.appendChild(title); header.appendChild(icon);
                        const cw=document.createElement('div'); cw.className='collapsible-content collapsed'; cw.id=sId+"Content";
                        const cv=document.createElement('div'); const v=rows[0][col];
                        cv.innerHTML=(v===null||v===undefined||String(v).toLowerCase()==='nan')?'N/A':String(v).replace(/\\n/g,"<br>");
                        cw.appendChild(cv); wrapper.appendChild(header); wrapper.appendChild(cw);
                        metricFieldsContainer.appendChild(wrapper);
                    }});
                    function buildTable(cols) {{
                        const table=document.createElement('table'); table.className='metric-table';
                        const thead=document.createElement('thead'); const trH=document.createElement('tr');
                        cols.forEach(col=>{{ const th=document.createElement('th'); th.textContent=col.replace(/_/g,' '); trH.appendChild(th); }});
                        thead.appendChild(trH); table.appendChild(thead);
                        const tbody=document.createElement('tbody');
                        rows.forEach(row=>{{
                            const tr=document.createElement('tr');
                            cols.forEach(col=>{{
                                const td=document.createElement('td'); const v=row[col];
                                if (v===null||v===undefined||String(v).toLowerCase()==='nan') {{ td.innerHTML='N/A'; }}
                                else {{ const r=renderStatus(v); if(r instanceof HTMLElement) td.appendChild(r); else td.innerHTML=String(r).replace(/\\n/g,"<br>"); }}
                                tr.appendChild(td);
                            }}); tbody.appendChild(tr);
                        }}); table.appendChild(tbody); return table;
                    }}
                    if (variableCols.length>0) metricFieldsContainer.appendChild(buildTable(variableCols));
                }} else {{
                    const record=rows[0];
                    const excludeKeys=new Set(['query','response','score','overall reason','overall_reason','overall score','overall_score','eval_name','timestamp','traceback','tracebacks']);
                    const trajSections=[], normSections=[];
                    Object.entries(record).forEach(([key,value])=>{{
                        if (excludeKeys.has(key.toLowerCase())) return;
                        if (value===null||value===undefined||String(value).trim()===''||String(value).toLowerCase()==='nan') return;
                        const section=document.createElement('div'); section.className='modal-section';
                        const heading=document.createElement('h4'); heading.textContent=key.replace(/_/g,' '); section.appendChild(heading);
                        const content=document.createElement('div'); const rendered=renderStatus(value);
                        if (rendered instanceof HTMLElement) content.appendChild(rendered);
                        else content.innerHTML=String(rendered).replace(/\\n/g,"<br>");
                        section.appendChild(content);
                        if (key.toLowerCase().includes("expected")||key.toLowerCase().includes("actual")) trajSections.push(section);
                        else normSections.push(section);
                    }});
                    if (trajSections.length>0) {{
                        const wrapper=document.createElement('div'); wrapper.className='trajectory-wrapper';
                        trajSections.forEach(sec=>wrapper.appendChild(sec));
                        metricFieldsContainer.appendChild(wrapper);
                    }}
                    normSections.forEach(sec=>metricFieldsContainer.appendChild(sec));
                    if (!metricFieldsContainer.hasChildNodes()) metricFieldsContainer.innerHTML='<p></p>';
                }}
            }}

            requestAnimationFrame(()=>{{
                const mfC=document.getElementById('metricSheetFields');
                if (!mfC) return;
                const mfSection=mfC.closest('.collapsible-section');
                const hasReal=mfC.querySelector('table,.modal-section');
                if (!hasReal) {{ if(mfSection) mfSection.style.display='none'; }}
                else {{ if(mfSection) mfSection.style.display=''; }}
            }});
        }}

        updateEl('modalReason', metricData.additional_fields?.reason || 'No reason provided');

        const scoreElement=document.getElementById('scorePieChart');
        if (scoreElement) scoreElement.innerHTML='';
        if (metricData.score&&metricData.score!='N/A'&&metricData.threshold&&metricData.threshold!='N/A') {{
            createScorePieChart(parseFloat(metricData.score), parseFloat(metricData.threshold), metricName);
        }} else {{ if(scoreElement) scoreElement.innerHTML="<p style='color:#777'>No score available</p>"; }}

        // Apply RCA diff highlighting after metric fields are rendered
        if (metricName.toUpperCase() === 'RCA') {{
            // auto-expand metric fields collapsible so diff is immediately visible
            var mfContent = document.getElementById('metricFieldsContent');
            var mfIcon    = document.getElementById('metricFieldsIcon');
            if (mfContent && mfContent.classList.contains('collapsed')) {{
                mfContent.classList.remove('collapsed');
                if (mfIcon) mfIcon.classList.add('expanded');
            }}
            setTimeout(function() {{ applyRcaDiff(); }}, 100);
        }}

        modal.style.display='block';
    }}

    function createScorePieChart(score, threshold, metric) {{
        if (isNaN(score)||isNaN(threshold)) return;
        const remaining=Math.max(0,1-score);
        const isReverse=config.reverse_metrics?.includes(metric)||false;
        const isPass=isReverse?score<=threshold:score>=threshold;
        const sc=config.status_colors||{{}};
        const passColor=sc.passed||'#28a745', failColor=sc.failed||'#dc3545';
        const data=[{{values:[score,remaining],labels:['Score','Remaining'],type:'pie',hole:0.4,
            marker:{{colors:[isPass?passColor:failColor,'#f0f0f0']}},textinfo:'none',
            hovertemplate:'<b>%{{label}}</b><br>Value: %{{value:.3f}}<br>Percentage: %{{percent}}<extra></extra>'}}];
        const layout={{showlegend:false,margin:{{t:20,b:20,l:20,r:20}},height:160,width:160,autosize:false,
            annotations:[{{text:score.toFixed(2)+'<br>'+(isPass?'PASS':'FAIL'),x:0.5,y:0.5,
                font:{{size:14,color:isPass?passColor:failColor,weight:'bold'}},showarrow:false,align:'center'}}],
            plot_bgcolor:'rgba(0,0,0,0)',paper_bgcolor:'rgba(0,0,0,0)'}};
        try {{ Plotly.newPlot('scorePieChart',data,layout,{{displayModeBar:false,responsive:true}}); }} catch(e) {{}}
    }}

    function openCoverageEdit() {{
        const wrapper=document.getElementById('coverageEditTableWrapper');
        if (!wrapper) return;
        if (!COVERAGE_EDIT_DATA||COVERAGE_EDIT_DATA.length===0) {{
            wrapper.innerHTML='<p>No data available to edit.</p>';
            document.getElementById('coverageEditModal').style.display='block'; return;
        }}
        const cols=Object.keys(COVERAGE_EDIT_DATA[0]);
        let html='<table class="modern-table" style="width:100%;"><thead><tr>';
        cols.forEach(c=>{{ html+=`<th>${{c.replace(/_/g,' ').replace(/\\b\\w/g,l=>l.toUpperCase())}}</th>`; }});
        html+='</tr></thead><tbody>';
        COVERAGE_EDIT_DATA.forEach((row,ri)=>{{
            html+='<tr>';
            cols.forEach(col=>{{
                const val=row[col]===null||row[col]===undefined?'':row[col];
                if (col==='expected_record_count') {{
                    html+=`<td><input type="number" min="0" style="width:90px;padding:4px 6px;border:1px solid #ccc;border-radius:4px;" data-row="${{ri}}" data-col="${{col}}" value="${{val}}"></td>`;
                }} else {{ html+=`<td>${{val}}</td>`; }}
            }});
            html+='</tr>';
        }});
        html+='</tbody></table>';
        wrapper.innerHTML=html;
        document.getElementById('coverageEditModal').style.display='block';
    }}
    function closeCoverageEdit() {{ document.getElementById('coverageEditModal').style.display='none'; }}
    function saveCoverageEdit() {{
        const inputs=document.querySelectorAll('#coverageEditTableWrapper input[data-row]');
        const updates={{}};
        inputs.forEach(inp=>{{
            const ri=inp.getAttribute('data-row'), col=inp.getAttribute('data-col');
            if(!updates[ri]) updates[ri]={{}};
            updates[ri][col]=inp.value;
        }});
        fetch('/update-coverage',{{method:'POST',headers:{{'Content-Type':'application/json'}},body:JSON.stringify({{updates}})}})
            .then(r=>r.json())
            .then(data=>{{ if(data.success){{closeCoverageEdit();alert('Saved! Reload to see updates.');}}else{{alert('Save failed: '+(data.error||'Unknown'));}} }})
            .catch(e=>alert('Save failed: '+e));
    }}

    window.addEventListener('click', function(e) {{
        const m1=document.getElementById('detailModal');    if(e.target===m1) closeModal();
        const m2=document.getElementById('coverageEditModal'); if(e.target===m2) closeCoverageEdit();
    }});
    document.addEventListener('keydown', function(e) {{ if(e.key==='Escape') closeModal(); }});
    document.addEventListener('DOMContentLoaded', function() {{ console.log('Report loaded successfully'); }});
</script>

UPLOAD_RUNS_PLACEHOLDER
DISAGG_AND_SUBTOPIC_PLACEHOLDER
</body>
</html>"""

            html_content = html_content.replace("UPLOAD_RUNS_PLACEHOLDER",        self._get_upload_runs_js())
            html_content = html_content.replace("DISAGG_AND_SUBTOPIC_PLACEHOLDER", self._get_disagg_js())
            return html_content

        except Exception as e:
            logger.error(f"Error generating HTML: {e}")
            return f"""<!DOCTYPE html><html><head><title>Error</title></head><body>
<div style="padding:20px;text-align:center;">
    <h1 style="color:#dc3545;">Error Generating Report</h1><p>{e}</p>
</div></body></html>"""

    # ==================== MAIN REPORT GENERATION ====================

    def generate_report(self, metrics_df: pd.DataFrame, details_df: pd.DataFrame,
                        summary_df: pd.DataFrame, overall_df: pd.DataFrame) -> str:
        try:
            logger.info("Starting report generation")
            if any(df.empty for df in [metrics_df, details_df, summary_df, overall_df]):
                return self._generate_error_report("One or more input DataFrames are empty")
            metrics_col   = self._find_column(metrics_df, ['Metrics','Metric','metric'])
            threshold_col = self._find_column(metrics_df, ['Threshold_Value','Threshold','threshold'])
            score_col     = self._find_column(metrics_df, ['aggregate_score','score','Score'])
            if not all([metrics_col, threshold_col, score_col]):
                return self._generate_error_report("Required columns not found in metrics DataFrame")
            all_metrics = metrics_df[metrics_col].dropna().astype(str).tolist()
            thresholds  = dict(zip(metrics_df[metrics_col], metrics_df[threshold_col]))
            logger.info(f"Processing {len(all_metrics)} metrics: {all_metrics}")
            details_df  = self._calculate_status(details_df, all_metrics, thresholds)
            charts      = self._create_modern_charts(summary_df, overall_df, metrics_df, metrics_col, score_col, threshold_col)
            modal_data  = self._prepare_modal_data(details_df, all_metrics, thresholds)
            html_content= self._generate_modern_html(metrics_df, details_df, all_metrics, charts, modal_data)
            logger.info("Report generation completed successfully")
            return html_content
        except Exception as e:
            logger.error(f"Error in report generation: {e}")
            return self._generate_error_report(f"Error in report generation: {e}")

    def _generate_error_report(self, error_message: str) -> str:
        return f"""<!DOCTYPE html>
<html><head><title>Report Generation Error</title>
<style>body{{font-family:Arial,sans-serif;padding:40px;text-align:center;}}
.error{{color:#dc3545;margin:20px 0;}}.suggestion{{color:#6c757d;margin:20px 0;}}</style></head>
<body><h1>Report Generation Error</h1>
<div class="error">{error_message}</div>
<div class="suggestion">Please check that your data contains the required columns.</div>
</body></html>"""


def demo_report_generation():
    try:
        input_file_path = 'Metrics_template02.xlsx'
        metrics_df = pd.read_excel(input_file_path, sheet_name='Metrics Interpretability')
        details_df = pd.read_excel(input_file_path, sheet_name='Test Data')
        summary_df = pd.read_excel(input_file_path, sheet_name='Metrics_wise Pass-Fail')
        overall_df = pd.read_excel(input_file_path, sheet_name='Overall Summary')
        report_generator = ReportGenerator()
        html_content = report_generator.generate_report(metrics_df, details_df, summary_df, overall_df)
        try:
            file_path = "report.html"
            with open(file_path, "w", encoding="utf-8") as f:
                f.write(html_content)
            print("HTML length:", len(html_content))
            print("Report saved at:", Path(file_path).resolve())
        except Exception as e:
            logger.info(f"Exception in line {sys.exc_info()[-1].tb_lineno}: {e}")
        print("✅ Demo report generated successfully!")
        return html_content
    except Exception as e:
        print(f"❌ Error generating demo report: {e}")
        return None


app = Flask(__name__)

@app.route("/")
def demo_report():
    try:
        result = demo_report_generation()
        if result is None:
            return "<h1>Report generation failed</h1><p>Check the server console/logs for the full error.</p>", 500
        return result
    except Exception as e:
        logger.error(f"Flask route error: {e}")
        return f"<h1>Error</h1><pre>{e}</pre>", 500

@app.route("/update-coverage", methods=["POST"])
def update_coverage():
    import json as _json
    try:
        payload    = request.get_json()
        updates    = payload.get("updates", {})
        excel_path = Path(__file__).resolve().parent / "Metrics_template02.xlsx"
        df = pd.read_excel(excel_path, sheet_name='Test data coverage')
        if "expected_record_count" not in df.columns:
            df["expected_record_count"] = None
        df["topic"]        = df["topic"].astype(str).str.strip().str.upper()
        df["sub_topic"]    = df["sub_topic"].astype(str).str.strip().str.title()
        df["sub_subtopic"] = df["sub_subtopic"].astype(str).str.strip().replace({"nan": None, "None": None, "": None})
        agg = df.groupby(["topic","sub_topic","sub_subtopic"], dropna=False).agg(count=("query", lambda x: x.notna().sum())).reset_index()
        for ri_str, cols in updates.items():
            ri = int(ri_str)
            if ri >= len(agg): continue
            agg_row = agg.iloc[ri]
            new_val = cols.get("expected_record_count", "")
            new_val = int(new_val) if str(new_val).strip().isdigit() else None
            mask = (
                (df["topic"]       == agg_row["topic"]) &
                (df["sub_topic"]   == agg_row["sub_topic"]) &
                (df["sub_subtopic"].fillna("-") == (agg_row["sub_subtopic"] if pd.notna(agg_row["sub_subtopic"]) else "-"))
            )
            df.loc[mask, "expected_record_count"] = new_val
        from openpyxl import load_workbook
        wb = load_workbook(excel_path)
        ws_name = 'Test data coverage'
        if ws_name in wb.sheetnames: del wb[ws_name]
        ws = wb.create_sheet(ws_name)
        for ci, col in enumerate(df.columns, 1):
            ws.cell(row=1, column=ci, value=col)
        for ri, row in enumerate(df.itertuples(index=False), 2):
            for ci, val in enumerate(row, 1):
                ws.cell(row=ri, column=ci, value=val)
        wb.save(excel_path)
        return _json.dumps({"success": True})
    except Exception as e:
        logger.error(f"Coverage update error: {e}")
        return _json.dumps({"success": False, "error": str(e)})

@app.route("/compare-runs", methods=["POST"])
def compare_runs():
    try:
        prev_file = request.files.get("previous_run")
        curr_file = request.files.get("current_run")
        if not prev_file or not curr_file:
            return "<div class='text-center'><b>Upload both files</b></div>"
        prev_df = pd.read_excel(prev_file)
        curr_df = pd.read_excel(curr_file)
        generator = ReportGenerator()
        return generator._create_run_comparison_chart(prev_df, curr_df, generator.config["theme"])
    except Exception as e:
        return f"<div class='text-center'><b>Error: {e}</b></div>"

if __name__ == "__main__":
    app.run(debug=True)
