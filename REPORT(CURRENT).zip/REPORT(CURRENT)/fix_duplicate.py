import re

# Read the file
with open('report.html', 'r', encoding='utf-8', errors='ignore') as f:
    content = f.read()

# Count how many times DISAGG_DATA is declared
count = len(re.findall(r'const DISAGG_DATA = \[', content))
print(f"Found {count} declarations of DISAGG_DATA")

# Find all script block positions with DISAGG_DATA
matches = list(re.finditer(r'<script>\s*const DISAGG_DATA', content))
print(f"Found {len(matches)} script blocks with DISAGG_DATA")

if len(matches) > 1:
    # Remove the second occurrence
    # Find the closing </script> for the second occurrence
    second_match_start = matches[1].start()
    closing_script = content.find('</script>', second_match_start)
    closing_script_end = closing_script + len('</script>')
    
    # Find the preceding newline and optional whitespace
    # Go back from the <script> to find the newline before it
    preceding_newline = content.rfind('\n', 0, second_match_start)
    
    # Remove from the preceding newline (inclusive) to the closing script tag (inclusive)
    new_content = content[:preceding_newline] + content[closing_script_end:]
    
    # Write back
    with open('report.html', 'w', encoding='utf-8') as f:
        f.write(new_content)
    
    print("Removed duplicate DISAGG_DATA declaration")
    print(f"Original file size: {len(content)} bytes")
    print(f"New file size: {len(new_content)} bytes")
else:
    print("No duplicate found")
